﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace MPDS.API.Data
{
    public class AuthDBContext : IdentityDbContext
    {
        public AuthDBContext(DbContextOptions options) : base(options)
        {
        }
        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
            var readerRoleId = "07d979df-9abe-4f8b-8fea-5d47cc6c4ee5";
            var writerRoleId = "ab710dba-e8a9-4c36-b83f-bdf080fa10b4";
            //Create the roles, to start with try reader and writer roles
            var roles = new List<IdentityRole>
            {
                new IdentityRole()
                {
                    Id=readerRoleId,
                    Name="Reader",
                    NormalizedName="Reader".ToUpper(),
                    ConcurrencyStamp = readerRoleId,
                },
                 new IdentityRole()
                {
                    Id=writerRoleId,
                    Name="Writer",
                    NormalizedName="Writer".ToUpper(),
                    ConcurrencyStamp = writerRoleId,
                }
            };
            //seed the roles
            builder.Entity<IdentityRole>().HasData(roles);
            // create an admin user
            var adminUserId = "3589f463-94c0-4c5f-b35e-04b6556b0e76";
            var admin = new IdentityUser()
            {
                Id = adminUserId,
                UserName = "eswar.avidi",
                Email = "avidie1@michigan.gov",
                NormalizedEmail = "avidie1@michigan.gov".ToUpper(),
                NormalizedUserName = "eswar.avidi".ToUpper(),

            };
            admin.PasswordHash = new PasswordHasher<IdentityUser>().HashPassword(admin, "Admin@123");
            builder.Entity<IdentityUser>().HasData(admin);
            //Give roles to Admin
            var adminRoles = new List<IdentityUserRole<string>>()
            {
                new()
                {
                    UserId = adminUserId,
                    RoleId = readerRoleId
                },
                new()
                {
                    UserId = adminUserId,
                    RoleId = writerRoleId
                }

            };
            builder.Entity<IdentityUserRole<string>>().HasData(adminRoles);
        }
    }
}
