﻿using Microsoft.EntityFrameworkCore;
using MPDS.API.Models.Domain;
using MPDS.API.Models.DTO;

namespace MPDS.API.Data
{
    public class MPDSDbContext : DbContext
    {
        public MPDSDbContext(DbContextOptions options) : base(options)
        {
        }
        public DbSet<ActivitiesDto> ActivityDetails { get; set; }
        public DbSet<ActivityTable> Activity { get; set; }
        public DbSet<ActivityGroup> ActivityGroup { get; set; }
        public DbSet<ActivityEthnicity> Activity_Ethnicity { get; set; }
        public DbSet<ActivityRace> Activity_Race { get; set; }
        public DbSet<ActivityParticipantAgeGroup> Activity_ParticipantAgeGroup { get; set; }
        public DbSet<ActivityStaff> Activity_Staff { get; set; }
        public DbSet<ActivityOptionalData> Activity_OptionalData { get; set; }
        public DbSet<BlogPost> BlogPosts { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<CoordinatingAgency> CoordinatingAgency { get; set; }
        public DbSet<CoordinatingAgencyCounty> CoordinatingAgency_County { get; set; }
        public DbSet<CoordinatingAgencySchoolDistrict> CoordinatingAgency_SchoolDistrict { get; set; }
        public DbSet<CoordinatingAgencyOptionalData> CoordinatingAgency_OptionalData { get; set; }
        public DbSet<CoordinatingAgencyProgramNames> CoordinatingAgency_ProgramNames { get; set; }
        public DbSet<ExceptionLog> ExceptionLogs { get; set; }
        public DbSet<ProviderAgency> GetAllProviderAgencies { get; set; }
        public DbSet<Counties> Master_County { get; set; }
        public DbSet<MasterFundingSource> Master_FundingSource { get; set; }
        public DbSet<MasterGrpOptionalData> Master_GroupOptionalData { get; set; }
        
        public DbSet<MasterStates> Master_State { get; set; }
       
        
        public DbSet<MasterSchoolDistrict> Master_SchoolDistrict { get; set; }
        public DbSet<MasterProgramName> Master_ProgramName { get; set; }
        public DbSet<MasterIntendedPopulation> Master_IntendedPopulation { get; set; }
        public DbSet<MasterProgramType> Master_ProgramType { get; set; }
        public DbSet<MasterPermission> Master_Permission { get; set; }        
        public DbSet<MasterGroupType> Master_GroupType { get; set; }
        public DbSet<MasterEBPServiceType> Master_EBPServiceType { get; set; }
        public DbSet<MasterServiceDomain> Master_ServiceDomain { get; set; }
        public DbSet<MasterServiceSetting> Master_ServiceSetting { get; set; }
        public DbSet<MasterServicePopulation> Master_ServicePopulation { get; set; }
        public DbSet<MasterStrategy> Master_Strategy { get; set; }
        public DbSet<MasterStrategyCategory> Master_StrategyCategory { get; set; }
        public DbSet<MasterInterventionType> Master_InterventionType { get; set; }
        public DbSet<MasterUserType> Master_UserType { get; set; }
        public DbSet<MasterUserTypePermissionMapping> Master_UserType_Permission_Mapping { get; set; }
        public DbSet<UserPermissions> GetPermissionsByUserType { get; set; }
        public DbSet<ProviderAgency> ProviderAgency { get; set; }
        public DbSet<ProviderAgencyCounty> ProviderAgency_County { get; set; }
        public DbSet<ProviderAgencySchoolDistrict> ProviderAgency_SchoolDistrict { get; set; }
        public DbSet<ProviderAgencyOptionalData> ProviderAgency_OptionalData { get; set; }
        public DbSet<Staff> Staff { get; set; }
        public DbSet<Users> Users { get; set; }
        public DbSet<ActivityGroup> AddGroup { get; set; }
        public DbSet<viewRemainingIncompleteAttendees> vRemainingIncompleteAttendees { get; set; }
        public DbSet<ActivityRaceRequestModel> vActivityRaceAttendees { get; set; }
        public DbSet<ActivityParticipantAgeGroupModel> vActivityAgeAttendees { get; set; }
        public DbSet<ActivityEthnicityRequestModel> vActivityEthnicityAttendees { get; set; }
        public DbSet<PESRReportResult> Report_PESR { get; set; }
        public DbSet<PESRByFundSourceReportResult> Report_PESRByFundingSource { get; set; }        
        //public DbSet<funcCalculateActivityUnits> CalculateActivityUnits { get; set; }
        [DbFunction(Name = "CalculateActivityUnits", IsBuiltIn = true)]
        public int CalculateActivityUnitsFromMin(int minutes)     => throw new NotSupportedException();
        
    }
}
