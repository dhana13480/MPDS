
ALTER TABLE [dbo].[ActivityGroup] DROP CONSTRAINT [FK_ActivityGroup_Master_FundingSource] 
GO 
ALTER TABLE [dbo].[ActivityGroup] DROP CONSTRAINT [FK_ActivityGroup_Master_ServicePopulation] 
GO
ALTER TABLE [dbo].[ActivityGroup] DROP CONSTRAINT [FK_ActivityGroup_Master_Strategy]
GO 
ALTER TABLE [dbo].[ActivityGroup] DROP CONSTRAINT [FK_ActivityGroup_Group_OptionalData]
 
  