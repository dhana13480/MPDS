USE [MPDS]

SELECT top 100 *  FROM [MPDS].[dbo].[ActivityGroup]

GO
select * from Master_StrategyCategory
select * from Master_Strategy
select * from Master_Strategy where code = 'N02'
 select * from [MPDS].[dbo].[ActivityGroup] where [MasterStrategyEmployed] = 14
 select * from  [MPDS].[dbo].[ActivityGroup] WHERE  [MasterStrategyEmployed] = (select Id from dbo.Master_Strategy where code = 'N02' ) 
--N02 Supervision and technical assistance for development of PSA and other PI material
UPDATE  [MPDS].[dbo].[ActivityGroup] SET  [MasterStrategyEmployed] = (select Id from dbo.Master_Strategy where code = 'N02' )  WHERE  [MasterStrategyEmployed] = (select Id from dbo.Master_Strategy where code = 'N02' ) 

--N06 Speaking engagement (direct) Presentation about SUD

--N07 Speaking engagement indirect (radio or TV interview, print media, pre-recorded video)
UPDATE  [MPDS].[dbo].[ActivityGroup] SET  [MasterStrategyEmployed] = (select Id from dbo.Master_Strategy where code = 'N06' )  WHERE  [MasterStrategyEmployed] = (select Id from dbo.Master_Strategy where code = 'N07' ) 
--N01 Distribution of materials at events. (brief) presentation, interaction with participants
UPDATE  [MPDS].[dbo].[ActivityGroup] SET  [MasterStrategyEmployed] = (select Id from dbo.Master_Strategy where code = 'N07' )  WHERE  [MasterStrategyEmployed] = (select Id from dbo.Master_Strategy where code = 'N01' ) 
--E03 Other Group Education becomes E04
UPDATE  [MPDS].[dbo].[ActivityGroup] SET  [MasterStrategyEmployed] = (select Id from dbo.Master_Strategy where code = 'E03' )  WHERE  [MasterStrategyEmployed] = (select Id from dbo.Master_Strategy where code = 'E04' ) 
 
--A04 Supervision, guiding Youth - Adult Leadership events becomes A02
UPDATE  [MPDS].[dbo].[ActivityGroup] SET  [MasterStrategyEmployed] = (select Id from dbo.Master_Strategy where code = 'A02' )  WHERE  [MasterStrategyEmployed] = (select Id from dbo.Master_Strategy where code = 'A04' )
--A04 Supervision, guiding Youth - Adult Leadership events becomes A02
UPDATE  [MPDS].[dbo].[ActivityGroup] SET  [MasterStrategyEmployed] = (select Id from dbo.Master_Strategy where code = 'A02' )  WHERE  [MasterStrategyEmployed] = (select Id from dbo.Master_Strategy where code = 'A04' )
