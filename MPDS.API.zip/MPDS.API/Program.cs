using Microsoft.AspNetCore.Authentication;
using Microsoft.EntityFrameworkCore;
using MPDS.API.Data;
using MPDS.API.Models.Domain;
using MPDS.API.Repositories.Implementation;
using MPDS.API.Repositories.Interface;
using MPDS.API.Utilities;


var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

//Inject the DBContext
builder.Services.AddDbContext<MPDSDbContext>(options =>
{
    options.UseSqlServer(builder.Configuration.GetConnectionString("MPDSConnectionString"));
    //options.UseSqlServer(builder.Configuration.GetConnectionString("MPDSDevConnectionString"));    
});
//Inject the MiLogin
builder.Services.Configure<AppIdentitySettings>(builder.Configuration.GetSection("AppIdentitySettings"));

builder.Services.AddScoped<IActivityRepository, ActivityRepository>();
builder.Services.AddScoped<IActivityGroupRepository, ActivityGroupRepository>();
builder.Services.AddScoped<ICategoryRepository, CategoryRepository>();
builder.Services.AddScoped<ICoordinatingAgencyRepository, CoordinatingAgencyRepository>();
builder.Services.AddScoped<ICountiesRepository, CountiesRepository>();
builder.Services.AddScoped<IProviderAgencyRepository, ProviderAgencyRepository>();
builder.Services.AddScoped<IProgramNameByCoordinatingAgencyRepository, ProgramNameByCoordinatingAgencyRepository>();
builder.Services.AddScoped<IMasterFundSourceRepository, MasterFundSourceRepository>();
builder.Services.AddScoped<IMasterGrpOptionalDataRepository, MasterGrpOptionalDataRepository>();
builder.Services.AddScoped<IMasterGroupTypeRepository, MasterGroupTypeRepository>();
builder.Services.AddScoped<IMasterInterventionTypeRepository, MasterInterventionTypeRepository>();
builder.Services.AddScoped<IMasterStrategyRepository, MasterStrategyRepository>();
builder.Services.AddScoped<IMasterStatesRepository, MasterStatesRepository>();
builder.Services.AddScoped<IMasterSchoolDistrictRepository, MasterSchoolDistrictRepository>();
builder.Services.AddScoped<IMasterProgramNameRepository, MasterProgramNameRepository>();
builder.Services.AddScoped<IMasterProgramTypeRepository, MasterProgramTypeRepository>();
builder.Services.AddScoped<IMasterPermissionRepository, MasterPermissionRepository>();
builder.Services.AddScoped<IMasterEBPServiceTypeRepository, MasterEBPServiceTypeRepostory>();
builder.Services.AddScoped<IMasterServiceDomainRepository, MasterServiceDomainRepository>();
builder.Services.AddScoped<IMasterServiceSettingRepository, MasterServiceSettingRepository>();
builder.Services.AddScoped<IMasterServicePopulationRepository, MasterServicePopulationRepository>();
builder.Services.AddScoped<IMasterStrategyRepository, MasterStrategyRepository>();
builder.Services.AddScoped<IMasterStrategyCategoryRepository, MasterStrategyCategoryRepository>();
builder.Services.AddScoped<IMasterIntendedPopulationRepository, MasterIntendedPopulationRepository>();
builder.Services.AddScoped<IReportRepository, ReportRepository>();
builder.Services.AddScoped<IStaffRepository, StaffRepository>();
builder.Services.AddScoped<IUserRepository, UserRepository>();
builder.Services.AddHttpClient<ReportService>();
builder.Services.AddScoped<IDatabaseLoggerService, DatabaseLoggerService>();
builder.Services.AddAuthentication("BasicAuthentication")
    .AddScheme<AuthenticationSchemeOptions, BasicAuthenticationHandler>("BasicAuthentication", null);
builder.Services.AddAuthorization();
var app = builder.Build();

// Configure the HTTP request pipeline.

//app.UseMiddleware<ExceptionLoggingMiddleware>();
app.UseSwagger();
app.UseSwaggerUI();

app.UseHttpsRedirection();
app.UseCors(options =>
{
    options.AllowAnyHeader();
    options.AllowAnyMethod();
    options.AllowAnyOrigin();
});
app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

app.Run();
