﻿using Azure;
using Azure.Core;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.Extensions.FileSystemGlobbing;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.OAuth;
using MPDS.API.Data;
using MPDS.API.Extensions;
using MPDS.API.Models.Domain;
using MPDS.API.Models.DTO;
using MPDS.API.Repositories.Implementation;
using MPDS.API.Repositories.Interface;
using MPDS.API.Utilities;
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Text.Json;
using static System.Net.WebRequestMethods;
using System.Runtime.InteropServices.JavaScript;
using static MPDS.API.Models.Domain.Enums;
using Microsoft.Extensions.Options;

namespace MPDS.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserRepository userRepository;
        private readonly AppIdentitySettings _appIdentitySettings;
        private readonly IDatabaseLoggerService _logger;
        public UserController(IUserRepository userRepository, IOptions<AppIdentitySettings> appIdentitySettingsAccessor, IDatabaseLoggerService _logger)
        {
            this.userRepository = userRepository;
            this._appIdentitySettings = appIdentitySettingsAccessor.Value;
            this._logger = _logger;
        }
        //[HttpGet("throw")]
        //public IActionResult ThrowException()
        //{
        //    try
        //    {
        //        _logger.LogExceptionAsync(new Exception("This is a test exception."), "AppUser");
        //    }
        //    catch (Exception ex)
        //    {

        //        throw;
        //    }

        //    throw new Exception("This is a test exception.");
        //}
        [HttpPost]
        [Route("GetTestUserDetailsFromEmail/{Email}")]
        public async Task<IActionResult> GetTestUserDetailsFromEmail([FromRoute] string Email)
        {
            var existingUsers = await userRepository.GetMPDSUserByMiLoginEmail(Email.ToLower());

            if (existingUsers is null)
            {
                return NotFound();
            }

            var response = new List<UserInfoDto>();
            foreach (var existingUser in existingUsers)
            {
                response.Add(new UserInfoDto
                {
                    Id = existingUser.Id,
                    FirstName = existingUser.FirstName,
                    LastName = existingUser.LastName,
                    UserName = existingUser.UserName,
                    Password = existingUser.Password,
                    Email = existingUser.Email.ToLower(),
                    Phone = existingUser.Phone,
                    UserTypeId = existingUser.UserTypeId,
                    IsActive = existingUser.IsActive,
                    Permissions = existingUser.Permissions,
                    CoordinatingAgencyId = existingUser.CoordinatingAgencyId,
                    ProviderAgencyId = existingUser.ProviderAgencyId,
                    IsPasswordResetRequired = existingUser.IsPasswordResetRequired,
                    Address1 = existingUser.Address1,
                    Address2 = existingUser.Address2,
                    City = existingUser.City,
                    StateId = existingUser.StateId,
                    Zip = existingUser.Zip,
                    Comments = existingUser.Comments,
                    csvCoordinatingAgencies = existingUser.csvCoordinatingAgencies,
                    csvProviderAgencies = existingUser.csvProviderAgencies,
                    miloginusername = existingUser.UserName,
                    //miloginusername = "AvidiE1"
                });
            }

            return Ok(response);
        }

        [HttpPost]
        [Route("GetUserDetailsFromMiLogin/{code}")]
        public async Task<IActionResult> GetUserDetailsFromMiLogin([FromRoute] string code)
        {
            string client_id = string.Empty;
            string client_secret = string.Empty;
            string client_idTP = string.Empty;
            string client_secretTP = string.Empty;
            string redirect_uri = string.Empty;
            string token = string.Empty;
            string tokenTP = string.Empty;
            string Email = string.Empty;
            string FirstName = string.Empty, LastName = string.Empty, MiloginUserName = string.Empty;
            StackFrame CallStack = new StackFrame(1, true);
            string mpdsEnvironment = string.Empty;
            string mpdsVersion = string.Empty;
            await _logger.LogInfo("1.MiLogin Authentication Code:" + code, "UserControllerGetUserDetailsFromMiLogin ", "AppUser");
            try
            {
                client_id = _appIdentitySettings.MiloginInfo.client_id;
                client_secret = _appIdentitySettings.MiloginInfo.client_secret;
                redirect_uri = _appIdentitySettings.MiloginInfo.redirect_uri.ToString();
                token = _appIdentitySettings.MiloginInfo.token.ToString();
                client_idTP = _appIdentitySettings.MiloginInfo.client_idTP;
                client_secretTP = _appIdentitySettings.MiloginInfo.client_secretTP;
                tokenTP = _appIdentitySettings.MiloginInfo.token.ToString();
                mpdsEnvironment = _appIdentitySettings.MiloginInfo.environment.ToString();
                mpdsVersion = _appIdentitySettings.MiloginInfo.mpdsVersion.ToString();
                await _logger.LogInfo("2.mpdsEnvironment:" + mpdsEnvironment, "UserControllerGetUserDetailsFromMiLogin ", "AppUser");
            }
            catch (Exception ex)
            {
                await _logger.LogInfo("3. MiLogin config entries error:" + code, "UserControllerGetUserDetailsFromMiLogin line 136 ", "AppUser");
                //_logger.LogExceptionAsync(new Exception("MiLogin config entries error:" ), "AppUser");
            }

            var values = new Dictionary<string, string>
                {
                    { "grant_type", "authorization_code" },
                    { "client_id", client_id},
                    { "client_secret", client_secret },
                    { "code" , code },
                    { "redirect_uri", redirect_uri}
                };

            //Try Worker first
            if ((code.Equals(string.Empty)) || (code != ""))
                if (code != "undefined")
                {
                    await _logger.LogInfo("4. Trying for MiLogin Token Worker first with Auth Code " + code, "UserControllerGetUserDetailsFromMiLogin ", "AppUser");
                    var MiLoginToken = MiLoginDetails.GetToken(code, client_id, client_secret, redirect_uri, token);
                    await _logger.LogInfo("5. MiLogin Token:" + MiLoginToken, "UserControllerGetUserDetailsFromMiLogin line 151", "AppUser");

                    //try MiLogin TP
                    if (MiLoginToken is null)
                        //var MiLoginToken = MiLoginDetails.GetToken(code);
                        if (MiLoginToken is null)
                        {
                            await _logger.LogInfo("6. Trying for MiLogin Token Thirt Party TP next with Auth Code " + code, "UserControllerGetUserDetailsFromMiLogin line 158 ", "AppUser");
                            MiLoginToken = MiLoginDetails.GetToken(code, client_idTP, client_secretTP, redirect_uri, tokenTP);
                        }

                    if (MiLoginToken is null)
                    {
                        await _logger.LogInfo("7. MiLogin Token for third party is also not available", "UserControllerGetUserDetailsFromMiLoginLine164", "AppUser");
                    }
                    else
                    {
                        MiLoginTokenDetails miloginToken = JsonSerializer.Deserialize<MiLoginTokenDetails>(MiLoginToken);
                        Console.WriteLine($"Token: {miloginToken.id_token}");
                        await _logger.LogInfo("8. MiLogin Token received:" + miloginToken.id_token, "UserControllerGetUserDetailsFromMiLoginline 170", "AppUser");
                        var miLoginTokenDetails = new MiLoginTokenDetails
                        {
                            id_token = miloginToken.id_token,
                            access_token = miloginToken.access_token,
                            refresh_token = miloginToken.refresh_token,
                            token_type = miloginToken.token_type,
                            expires_in = miloginToken.expires_in
                        };
                        var handler = new JwtSecurityTokenHandler();
                        var jsonToken = handler.ReadToken(miloginToken.id_token) as JwtSecurityToken;

                        if (jsonToken != null)
                        {
                            // Print out the claims
                            foreach (var claim in jsonToken.Claims)
                            {
                                if (claim.Type.Equals("firstname"))
                                    FirstName = claim.Value;
                                if (claim.Type.Equals("lastname"))
                                    LastName = claim.Value;
                                if (claim.Type.Equals("mail"))
                                    Email = claim.Value;
                                if (claim.Type.Equals("micamusername"))
                                    MiloginUserName = claim.Value;
                                Console.WriteLine($"Type: {claim.Type}, Value: {claim.Value}");
                                await _logger.LogInfo("8. Parsing JWT token: " + claim.Type + ": " + claim.Value, "UserControllerGetUserDetailsFromMiLoginline 200", "AppUser");
                            }
                        }
                        else
                        {
                            await _logger.LogInfo("9. Invalid JWT token" + miloginToken.id_token, "UserControllerGetUserDetailsFromMiLoginline 200", "AppUser");
                            Console.WriteLine("Invalid JWT token");
                        }
                        // get user details from MPDS database
                        if (Email.Equals(string.Empty))
                        {
                            await _logger.LogInfo("10. User not found in MiLogin ", "UserControllerGetUserDetailsFromMiLoginline 200", "AppUser");
                            Console.WriteLine("User not found in MiLogin");
                           // return Ok("Not Found");
                        }
                    }
                    //var response = new MiLoginUserDetailsFromToken
                    //{
                    //    firstname = FirstName,
                    //    lastname = LastName,
                    //    mail = Email,
                    //    miloginusername = MiloginUserName
                    //};
                }

            if ((Email.Equals(string.Empty)) || Email.Equals(""))
            {
                await _logger.LogInfo("11. User not found",  "UserControllerGetUserDetailsFromMiLoginline 223", "AppUser");
                //return NotFound();
                //test
                if (mpdsEnvironment.Equals("Dev"))
                {
                    try
                    {
                       string UseTestLogin = _appIdentitySettings.MiloginInfo.UseTestLogin;
                       string testLogin = _appIdentitySettings.MiloginInfo.testLogin;
                        if (UseTestLogin=="Yes")
                            Email = testLogin;
                        await _logger.LogInfo("12. User not found using test login: " + Email, "UserControllerGetUserDetailsFromMiLoginline 227", "AppUser");
                    }
                    catch (Exception)
                    {
                        //ignore                         
                    }
                  
                }
            }
            if ((Email.Equals(string.Empty)) || Email.Equals(""))
                return NotFound();

            await _logger.LogInfo("13. User  found : " + Email, "UserControllerGetUserDetailsFromMiLoginline 232", "AppUser");
            var existingUsers = await userRepository.GetMPDSUserByMiLoginEmail(Email);

            if (existingUsers is null)
            {
                await _logger.LogInfo("14. User's Email " + Email + " not found in MPDS: ", "UserControllerGetUserDetailsFromMiLoginline 237", "AppUser");
                return NotFound();
            }
            await _logger.LogInfo("15. User's Email " + Email + "  found in MPDS: ", "UserControllerGetUserDetailsFromMiLoginline 240", "AppUser");
            var response = new List<UserInfoDto>();
            foreach (var existingUser in existingUsers)
            {
                response.Add(new UserInfoDto
                {
                    Id = existingUser.Id,
                    FirstName = existingUser.FirstName,
                    LastName = existingUser.LastName,
                    UserName = existingUser.UserName,
                    Password = existingUser.Password,
                    Email = existingUser.Email,
                    Phone = existingUser.Phone,
                    UserTypeId = existingUser.UserTypeId,
                    IsActive = existingUser.IsActive,
                    Permissions = existingUser.Permissions,
                    CoordinatingAgencyId = existingUser.CoordinatingAgencyId,
                    ProviderAgencyId = existingUser.ProviderAgencyId,
                    IsPasswordResetRequired = existingUser.IsPasswordResetRequired,
                    Address1 = existingUser.Address1,
                    Address2 = existingUser.Address2,
                    City = existingUser.City,
                    StateId = existingUser.StateId,
                    Zip = existingUser.Zip,
                    Comments = existingUser.Comments,
                    csvCoordinatingAgencies = existingUser.csvCoordinatingAgencies,
                    csvProviderAgencies = existingUser.csvProviderAgencies,
                    miloginusername = MiloginUserName,
                    MPDSEnvironment = string.IsNullOrEmpty(mpdsEnvironment) ? "" : "Environment: " + mpdsEnvironment,
                    mpdsVersion = string.IsNullOrEmpty(mpdsVersion) ? DateTime.Now.ToString() : "Version: " + mpdsVersion
                });
            }
            await _logger.LogInfo("16. Sending User's Email " + Email + " to front end to create the session ", "UserControllerGetUserDetailsFromMiLoginline 271", "AppUser");
            return Ok(response);
        }

        [HttpGet]
        [Route("ValidateLogin/{username}/{password}")]
        //Gets top 100 groups by Coordinating Agency Id
        public async Task<IActionResult> ValidateLogin([FromRoute] string username, [FromRoute] string password)
        {

            string encryptedPwd = HashUtility.SHA512Hash(password);
            var existingUsers = await userRepository.ValidateLogin(username, encryptedPwd);
            if ((existingUsers is null))
            {
                return NotFound();
            }
            int count = existingUsers.Count();
            if (count <= 0) return NotFound();

            //convert domain to dto
            var response = new List<UserInfoDto>();
            foreach (var existingUser in existingUsers)
            {
                response.Add(new UserInfoDto
                {
                    Id = existingUser.Id,
                    FirstName = existingUser.FirstName,
                    LastName = existingUser.LastName,
                    UserName = existingUser.UserName,
                    Password = existingUser.Password,
                    Email = existingUser.Email,
                    Phone = existingUser.Phone,
                    UserTypeId = existingUser.UserTypeId,
                    IsActive = existingUser.IsActive,
                    Permissions = existingUser.Permissions,
                    CoordinatingAgencyId = existingUser.CoordinatingAgencyId,
                    ProviderAgencyId = existingUser.ProviderAgencyId,
                    IsPasswordResetRequired = existingUser.IsPasswordResetRequired,
                    Address1 = existingUser.Address1,
                    Address2 = existingUser.Address2,
                    City = existingUser.City,
                    StateId = existingUser.StateId,
                    Zip = existingUser.Zip,
                    Comments = existingUser.Comments,
                    csvCoordinatingAgencies = existingUser.csvCoordinatingAgencies,
                    csvProviderAgencies = existingUser.csvProviderAgencies,
                });
            }
            return Ok(response);
        }
        [HttpPost]
        [Route("GetPermissionsByUserType/{userTypeId:int}")]
        public async Task<IActionResult> GetPermissionsByUserType([FromRoute] int userTypeId)
        {
            var permissions = await userRepository.GetPermissionsByUserType(userTypeId);
            if (permissions is null)
            {
                return NotFound();
            }
            var response = new List<UserPermissionsDto>();
            foreach (var permission in permissions)
            {
                response.Add(new UserPermissionsDto
                {
                    PermissionId = permission.PermissionId,
                    Permission = permission.Permission,
                });
            }
            return Ok(response);
        }
        [HttpPost]
        [Route("GetAllUsers")]
        public async Task<IActionResult> GetAllUsers(UserSearchInputParameters request)
        {
            var existingUsers = await userRepository.GetAllUsers(request);

            if (existingUsers is null)
            {
                return NotFound();
            }
            //convert domain to dto
            var response = new List<UserInfoDto>();
            foreach (var existingUser in existingUsers)
            {
                response.Add(new UserInfoDto
                {
                    Id = existingUser.Id,
                    FirstName = existingUser.FirstName,
                    LastName = existingUser.LastName,
                    UserName = existingUser.UserName,
                    Password = existingUser.Password,
                    Email = existingUser.Email,
                    Phone = existingUser.Phone,
                    UserTypeId = existingUser.UserTypeId,
                    IsActive = existingUser.IsActive,
                    Permissions = existingUser.Permissions,
                    CoordinatingAgencyId = existingUser.CoordinatingAgencyId,
                    ProviderAgencyId = existingUser.ProviderAgencyId,
                    IsPasswordResetRequired = existingUser.IsPasswordResetRequired,
                    Address1 = existingUser.Address1,
                    Address2 = existingUser.Address2,
                    City = existingUser.City,
                    StateId = existingUser.StateId,
                    Zip = existingUser.Zip,
                    Comments = existingUser.Comments,
                    csvCoordinatingAgencies = existingUser.csvCoordinatingAgencies,
                    csvProviderAgencies = existingUser.csvProviderAgencies,


                });
            }
            return Ok(response);
        }
        [HttpPost]
        [Route("GetAllUsersPaginated")]
        public async Task<ActionResult<PagedList<UserInfoDto>>> GetAllUsersPaginanted([FromQuery] UserParams userParams, UserSearchInputParameters request)
        {
            var existingUsers = await userRepository.GetAllUsersPaginated(userParams, request);

            if (existingUsers is null)
            {
                return NotFound();
            }
            //convert domain to dto
            var response = new List<UserInfoDto>();
            foreach (var existingUser in existingUsers)
            {
                response.Add(new UserInfoDto
                {
                    Id = existingUser.Id,
                    FirstName = existingUser.FirstName,
                    LastName = existingUser.LastName,
                    UserName = existingUser.UserName,
                    Password = existingUser.Password,
                    Email = existingUser.Email,
                    Phone = existingUser.Phone,
                    UserTypeId = existingUser.UserTypeId,
                    IsActive = existingUser.IsActive,
                    Permissions = existingUser.Permissions,
                    CoordinatingAgencyId = existingUser.CoordinatingAgencyId,
                    ProviderAgencyId = existingUser.ProviderAgencyId,
                    IsPasswordResetRequired = existingUser.IsPasswordResetRequired,
                    Address1 = existingUser.Address1,
                    Address2 = existingUser.Address2,
                    City = existingUser.City,
                    StateId = existingUser.StateId,
                    Zip = existingUser.Zip,
                    Comments = existingUser.Comments,
                    csvCoordinatingAgencies = existingUser.csvCoordinatingAgencies,
                    csvProviderAgencies = existingUser.csvProviderAgencies,


                });
            }
            Response.AddPaginationHeader(new PaginationHeader(existingUsers.CurrentPage,
                existingUsers.PageSize, existingUsers.TotalCount, existingUsers.TotalPages));
            return Ok(existingUsers);
        }
        //[HttpGet]
        //[Route("GetUsersEmailByCAPA")]
        //public async Task<IActionResult> GetUsersEmailByCAPA()
        //{
        //    //todo
        //    // return objUser.GetUsersEmailByCAPA(notificationTypeId, csvCoordinatingAGencyIds, csvProviderAgencyIds);
        //    return Ok(null);
        //}
        //[HttpPut]
        //[Route("UpdateUser")]
        //public async Task<IActionResult> UpdateUser()
        //{
        //    //todo  
        //    return Ok(null);
        //}
        //[HttpPost]
        //[Route("ResetPwd")]
        //public async Task<IActionResult> ResetPassword()
        //{
        //    return Ok(null);
        //}
        [HttpPost]
        [Route("AddUser")]
        public async Task<IActionResult> AddUser(CreateUserRequestDto request)
        {

            if (request != null)
            {
                //Map DTO to Domain model
                var addUser = new Users()
                {
                    Id = request.Id,
                    FirstName = request.FirstName,
                    MiddleName = request.MiddleName,
                    LastName = request.LastName,
                    Password = request.Password,
                    IsActive = request.IsActive,
                    UserTypeId = request.UserTypeId,
                    CoordinatingAgencyId = request.CoordinatingAgencyId,
                    ProviderAgencyId = request.ProviderAgencyId,
                    Permissions = request.Permissions,
                    UserName = request.UserName,
                    Email =  request.Email.ToLower(),
                    Phone = request.Phone,
                    Address1 = request.Address1,
                    Address2 = request.Address2,
                    City = request.City,
                    StateId = request.StateId,
                    Zip = request.Zip,
                    Comments = request.Comments,
                    CreatedBy = request.CreatedBy,
                    UpdatedBy = request.UpdatedBy,
                    CreationDate = DateTime.UtcNow,
                    HashingAlgorithm = "",
                    csvCoordinatingAgencies = request.csvCoordinatingAgencies,
                    csvProviderAgencies = request.csvProviderAgencies,
                };
                await userRepository.AddNewUser(addUser);

                var response = new UserInfoDto
                {
                    Id = addUser.Id,
                    FirstName = addUser.FirstName,
                    MiddleName = addUser.MiddleName,
                    LastName = addUser.LastName,
                    Password = addUser.Password,
                    IsActive = addUser.IsActive,
                    UserTypeId = addUser.UserTypeId,
                    CoordinatingAgencyId = addUser.CoordinatingAgencyId,
                    ProviderAgencyId = addUser.ProviderAgencyId,
                    Permissions = addUser.Permissions,
                    UserName = addUser.UserName,
                    Email = addUser.Email.ToLower(),
                    Phone = addUser.Phone,
                    Address1 = addUser.Address1,
                    Address2 = addUser.Address2,
                    City = addUser.City,
                    StateId = addUser.StateId,
                    Zip = addUser.Zip,
                    Comments = addUser.Comments,
                    csvCoordinatingAgencies = addUser.csvCoordinatingAgencies,
                    csvProviderAgencies = addUser.csvProviderAgencies,
                };
                return Ok(response);
            }
            return BadRequest("Invalid user info");
        }

        [HttpPut]
        [Route("EditUser")]
        public async Task<IActionResult> EditUser(Users request)
        {
            DateTime dtCreationDate = DateTime.UtcNow;
            DateTime dtUpdationDate = DateTime.UtcNow;

            //convert DTO to Domain model
            var updatedUser = new Users()
            {
                Id = request.Id,
                FirstName = request.FirstName,
                MiddleName = request.MiddleName,
                LastName = request.LastName,
                Password = request.Password,
                IsActive = request.IsActive,
                UserTypeId = request.UserTypeId,
                CoordinatingAgencyId = request.CoordinatingAgencyId,
                ProviderAgencyId = request.ProviderAgencyId,
                Permissions = request.Permissions,
                UserName = request.UserName,
                Email = request.Email,
                Phone = request.Phone,
                Address1 = request.Address1,
                Address2 = request.Address2,
                City = request.City,
                StateId = request.StateId,
                Zip = request.Zip,
                Comments = request.Comments,
                CreatedBy = request.CreatedBy,
                UpdatedBy = request.UpdatedBy,
                CreationDate = dtCreationDate,
                UpdationDate = dtUpdationDate,
                HashingAlgorithm = "",
                csvCoordinatingAgencies = request.csvCoordinatingAgencies,
                csvProviderAgencies = request.csvProviderAgencies,
            };

            updatedUser = await userRepository.UpdateUser(updatedUser);
            if (updatedUser == null)
                return NotFound();

            var response = new UserInfoDto
            {
                Id = updatedUser.Id,
                FirstName = updatedUser.FirstName,
                MiddleName = updatedUser.MiddleName,
                LastName = updatedUser.LastName,
                Password = updatedUser.Password,
                IsActive = updatedUser.IsActive,
                UserTypeId = updatedUser.UserTypeId,
                CoordinatingAgencyId = updatedUser.CoordinatingAgencyId,
                ProviderAgencyId = updatedUser.ProviderAgencyId,
                Permissions = updatedUser.Permissions,
                UserName = updatedUser.UserName,
                Email = updatedUser.Email,
                Phone = updatedUser.Phone,
                Address1 = updatedUser.Address1,
                Address2 = updatedUser.Address2,
                City = updatedUser.City,
                StateId = updatedUser.StateId,
                Zip = updatedUser.Zip,
                Comments = updatedUser.Comments,
                csvCoordinatingAgencies = updatedUser.csvCoordinatingAgencies,
                csvProviderAgencies = updatedUser.csvProviderAgencies
            };
            return Ok(response);
        }

        [HttpGet]
        [Route("{id:int}")]
        public async Task<IActionResult> GetByUserId([FromRoute] int id)
        {
            var existingUser = await userRepository.GetByUserId(id);

            if (existingUser is null)
            {
                return NotFound();
            }

            var response = new Users
            {
                Id = existingUser.Id,
                FirstName = existingUser.FirstName,
                MiddleName = existingUser.MiddleName,
                LastName = existingUser.LastName,
                Password = existingUser.Password,
                IsActive = existingUser.IsActive,
                UserTypeId = existingUser.UserTypeId,
                CoordinatingAgencyId = existingUser.CoordinatingAgencyId,
                ProviderAgencyId = existingUser.ProviderAgencyId,
                Permissions = existingUser.Permissions,
                UserName = existingUser.UserName,
                Email = existingUser.Email,
                Phone = existingUser.Phone,
                Address1 = existingUser.Address1,
                Address2 = existingUser.Address2,
                City = existingUser.City,
                StateId = existingUser.StateId,
                Zip = existingUser.Zip,
                Comments = existingUser.Comments,
                csvCoordinatingAgencies = existingUser.csvCoordinatingAgencies,
                csvProviderAgencies = existingUser.csvProviderAgencies
            };
            return Ok(response);
        }

        [HttpDelete]
        [Route("{id:int}")]
        public async Task<IActionResult> DeleteUser([FromRoute] int id)
        {
            var user = await userRepository.RemoveUser(id);
            if (user == null) return NotFound();

            return Ok(HttpStatusCode.OK);
        }

        //[HttpGet]
        //[Route("GetUserDetails/{id:long}")]
        //public async Task<IActionResult> GetUserDetails([FromRoute] long id)
        //{
        //    return Ok(null);
        //}


    }
}
