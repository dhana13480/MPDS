﻿using Azure.Core;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MPDS.API.Data;
using MPDS.API.Extensions;
using MPDS.API.Models.Domain;
using MPDS.API.Models.DTO;
using MPDS.API.Repositories.Implementation;
using MPDS.API.Repositories.Interface;
using MPDS.API.Utilities;
using static MPDS.API.Models.Domain.Enums;

namespace MPDS.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProviderAgencyController : ControllerBase
    {
        private readonly IProviderAgencyRepository providerAgencyRepository;
        public ProviderAgencyController(IProviderAgencyRepository providerAgencyRepository)
        {
            this.providerAgencyRepository = providerAgencyRepository;
        }
        //put method //https://localhost:7164/api/ProviderAgency/{id}
        [HttpPut]
        [Route("{id:int}")]
        public async Task<IActionResult> EditProviderAgency([FromRoute] int id, ProviderAgencyUpdateRequestDto request)
        {
            if (request.Name == "")
                return BadRequest("Please enter Provider Name");
            if (request.CoordinatingAgencyId <= 0)
                return BadRequest("Please select a Coordinating Agency");
            if (request.License == "")
                return BadRequest("Please enter License Number");
            if (request.DaysAllowedForDataEntry <= 0)
                return BadRequest("Please enter Days Allowed for Data Entry");
            if (request.Address1 == "")
                return BadRequest("Please enter Address");
            if (request.City == "")
                return BadRequest("Please enter City Name");
            if (request.Zip == "")
                return BadRequest("Please enter Zip");

            //convert DTO to Domain model
            var providerAgency = new ProviderAgency()
            {
                Id = id,
                //uKeyOldCA = request.uKeyOldCA,
                //uKeyOldORG = request.uKeyOldORG,
                Name = request.Name,
                CoordinatingAgencyId = request.CoordinatingAgencyId,
                License = request.License,
                DaysAllowedForDataEntry = request.DaysAllowedForDataEntry,
                IsActive = request.IsActive,

                OfficePhone = request.OfficePhone,
                Fax = request.Fax,
                Address1 = request.Address1,
                Address2 = request.Address2,
                City = request.City,
                State = request.State,
                Zip = request.Zip,
                Comments = request.Comments,
                AddressComments = request.AddressComments,
                CreatedBy = request.CreatedBy,
                CreationDate = DateTime.Now,
                UpdatedBy = request.UpdatedBy,
                //UpdationDate = DateTime.Now
                OptionalData = request.OptionalData,
                Counties = request.Counties,
                SchoolDistricts = request.SchoolDistricts
            };
            providerAgency = await providerAgencyRepository.UpdateAsync(providerAgency);
            if (providerAgency == null)
                return NotFound();

            var response = new ProviderAgencyDto
            {
                Id = providerAgency.Id,
                Name = providerAgency.Name,
                CoordinatingAgencyId = providerAgency.CoordinatingAgencyId,
                License = providerAgency.License,
                DaysAllowedForDataEntry = providerAgency.DaysAllowedForDataEntry,
                IsActive = providerAgency.IsActive,
                OfficePhone = providerAgency.OfficePhone,
                Fax = providerAgency.Fax,
                Address1 = providerAgency.Address1,
                Address2 = providerAgency.Address2,
                City = providerAgency.City,
                State = providerAgency.State,
                Zip = providerAgency.Zip,
                Comments = providerAgency.Comments,
                AddressComments = providerAgency.AddressComments,
                CreatedBy = providerAgency.CreatedBy,
                CreationDate = providerAgency.CreationDate,
                UpdatedBy = providerAgency.UpdatedBy,
                //UpdationDate = coordinatingAgency.UpdationDate
                OptionalData = providerAgency.OptionalData,
                Counties = request.Counties,
                SchoolDistricts = request.SchoolDistricts
            };
            return Ok(response);
        }

        //GET: {apibaseurl}/api/getProviderAgencies
        //https://localhost:7164/api/getProviderAgencies
        [HttpGet]
        public async Task<IActionResult> GetAllProviderAgencies()
        {
            var providerAgencies = await providerAgencyRepository.GetAllAsync();
            //convert domain to dto
            var response = new List<ProviderAgencyDto>();
            foreach (var providerAgency in providerAgencies)
            {
                response.Add(new ProviderAgencyDto
                {
                    Id = providerAgency.Id,
                    //UKeyOld = providerAgency.UKeyOld,
                    //UKeyOldOrg = providerAgency.UKeyOldOrg,
                    Name = providerAgency.Name,
                    CoordinatingAgencyId = providerAgency.CoordinatingAgencyId,
                    License = providerAgency.License,
                    DaysAllowedForDataEntry = providerAgency.DaysAllowedForDataEntry,
                    IsActive = providerAgency.IsActive,
                    OfficePhone = providerAgency.OfficePhone,
                    Fax = providerAgency.Fax,
                    Address1 = providerAgency.Address1,
                    Address2 = providerAgency.Address2,
                    City = providerAgency.City,
                    State = providerAgency.State,
                    Zip = providerAgency.Zip,
                    Comments = providerAgency.Comments,
                    AddressComments = providerAgency.AddressComments,
                    CreatedBy = providerAgency.CreatedBy,
                    CreationDate = providerAgency.CreationDate,
                    UpdatedBy = providerAgency.UpdatedBy,
                    // UpdationDate = providerAgency.UpdationDate,                    
                    OptionalData = providerAgency.OptionalData,
                    Counties = providerAgency.Counties,
                    SchoolDistricts = providerAgency.SchoolDistricts
                });
            }
            return Ok(response);
        }
        [HttpPost]
        [Route("GetAllProviderAgenciesPaginated")]
        public async Task<IActionResult> GetAllProviderAgenciesPaginated([FromQuery] UserParams userParams, ProviderSearchInput inputParam)
        {
            UserRoles userRoles = new UserRoles();
            userRoles.userTypeId = inputParam.userTypeId;
            userRoles.coordinatingAgencyId = inputParam.coordinatingAgencyId;
            userRoles.providerAgencyId = inputParam.providerAgencyId;
            userRoles.permissions = inputParam.permissions;
            if (userRoles.userTypeId == 3)
                if (userRoles.coordinatingAgencyId <= 0)
                    return BadRequest("User type of Coordinating Agency is not assigned any PIHP Regions.");
            if (userRoles.userTypeId == 4)
                if (userRoles.providerAgencyId <= 0)
                    return BadRequest("User type of Provider Agency is not assigned any Coordinating Agencies.");
            var providerAgencies = await providerAgencyRepository.GetAllAsyncPaginated(userParams, inputParam, userRoles);

            Response.AddPaginationHeader(new PaginationHeader(providerAgencies.CurrentPage, providerAgencies.PageSize, providerAgencies.TotalCount, providerAgencies.TotalPages));

            return Ok(providerAgencies);
        }
        //GET: {apibaseurl}/api/getProviderAgencies
        //https://localhost:7164/api/ProviderAgency/{id}
        [HttpGet]
        [Route("{id:int}")]

        public async Task<IActionResult> GetProviderAgencyById([FromRoute] int id)
        {
            var existingProviderAgency = await providerAgencyRepository.GetById(id);
            if (existingProviderAgency is null)
            {
                return NotFound();
            }
            var response = new ProviderAgencyDto
            {
                Id = existingProviderAgency.Id,
                //uKeyOld = staff.uKeyOld,
                Name = existingProviderAgency.Name,
                CoordinatingAgencyId = existingProviderAgency.CoordinatingAgencyId,
                License = existingProviderAgency.License,
                DaysAllowedForDataEntry = existingProviderAgency.DaysAllowedForDataEntry,
                IsActive = existingProviderAgency.IsActive,
                OfficePhone = existingProviderAgency.OfficePhone,
                Fax = existingProviderAgency.Fax,
                Address1 = existingProviderAgency.Address1,
                Address2 = existingProviderAgency.Address2,
                City = existingProviderAgency.City,
                State = existingProviderAgency.State,
                Zip = existingProviderAgency.Zip,
                Comments = existingProviderAgency.Comments,
                AddressComments = existingProviderAgency.AddressComments,
                CreatedBy = existingProviderAgency.CreatedBy,
                CreationDate = existingProviderAgency.CreationDate,
                UpdatedBy = existingProviderAgency.UpdatedBy,
                //UpdationDate = existingProviderAgency.UpdationDate,                
                OptionalData = existingProviderAgency.OptionalData,
                Counties = existingProviderAgency.Counties,
                SchoolDistricts = existingProviderAgency.SchoolDistricts
            };
            return Ok(response);
        }
        //GET: {apibaseurl}/api/getProviderAgencies
        //https://localhost:7164/api/ProviderAgency/{id}

        [HttpGet]
        [Route("provideragenciesByCoordId/{id:long}")]

        public async Task<IActionResult> GetProviderAgencyByCoordinatingAgencyId([FromRoute] int id)                
        {
            var providerAgencies = await providerAgencyRepository.GetAllByCoordinatingAgencyId(id);
            var response = new List<ProviderAgencyDto>();
            if (providerAgencies != null)
                foreach (var providerAgency in providerAgencies)
                {
                    response.Add(new ProviderAgencyDto
                    {
                        Id = providerAgency.Id,
                        Name = providerAgency.Name,
                        CoordinatingAgencyId = providerAgency.CoordinatingAgencyId,
                        License = providerAgency.License,
                        DaysAllowedForDataEntry = providerAgency.DaysAllowedForDataEntry,
                        IsActive = providerAgency.IsActive,
                        OfficePhone = providerAgency.OfficePhone,
                        Fax = providerAgency.Fax,
                        Address1 = providerAgency.Address1,
                        Address2 = providerAgency.Address2,
                        City = providerAgency.City,
                        State = providerAgency.State,
                        Zip = providerAgency.Zip,
                        Comments = providerAgency.Comments,
                        AddressComments = providerAgency.AddressComments,
                        CreatedBy = providerAgency.CreatedBy,
                        CreationDate = providerAgency.CreationDate,
                        UpdatedBy = providerAgency.UpdatedBy,
                        // UpdationDate = providerAgency.UpdationDate,                        
                        OptionalData = providerAgency.OptionalData,
                        Counties = providerAgency.Counties,
                        SchoolDistricts = providerAgency.SchoolDistricts
                    });
                }
            return Ok(response);
        }

        [HttpGet]
        [Route("coordinatingagency/{id:long}")]

        public async Task<IActionResult> GetProviderAgencyByCoordAgencyId([FromRoute] int id)
        {
            var providerAgencies = await providerAgencyRepository.GetAllByCoordinatingAgencyId(id);
            var response = new List<ProviderAgencyDto>();
            if (providerAgencies != null)
                foreach (var providerAgency in providerAgencies)
                {
                    response.Add(new ProviderAgencyDto
                    {
                        Id = providerAgency.Id,
                        Name = providerAgency.Name,
                        CoordinatingAgencyId = providerAgency.CoordinatingAgencyId,
                        License = providerAgency.License,
                        DaysAllowedForDataEntry = providerAgency.DaysAllowedForDataEntry,
                        IsActive = providerAgency.IsActive,
                        OfficePhone = providerAgency.OfficePhone,
                        Fax = providerAgency.Fax,
                        Address1 = providerAgency.Address1,
                        Address2 = providerAgency.Address2,
                        City = providerAgency.City,
                        State = providerAgency.State,
                        Zip = providerAgency.Zip,
                        Comments = providerAgency.Comments,
                        AddressComments = providerAgency.AddressComments,
                        CreatedBy = providerAgency.CreatedBy,
                        CreationDate = providerAgency.CreationDate,
                        UpdatedBy = providerAgency.UpdatedBy,
                        // UpdationDate = providerAgency.UpdationDate,                        
                        OptionalData = providerAgency.OptionalData,
                        Counties = providerAgency.Counties,
                        SchoolDistricts = providerAgency.SchoolDistricts
                    });
                }
            return Ok(response);
        }

        [HttpPost]
        public async Task<IActionResult> CreateProviderAgency(CreateProviderAgencyRequestDto request)
        {
            if (request.Name == "")
                return BadRequest("Please enter Provider Name");
            if (request.CoordinatingAgencyId <= 0)
                return BadRequest("Please select a Coordinating Agency");
            if (request.License == "")
                return BadRequest("Please enter License Number");
            if (request.DaysAllowedForDataEntry <= 0)
                return BadRequest("Please enter Days Allowed for Data Entry");
            if (request.Address1 == "")
                return BadRequest("Please enter Address");
            if (request.City == "")
                return BadRequest("Please enter City Name");
            if (request.Zip == "")
                return BadRequest("Please enter Zip");

            DateTime dtCreationDate = DateTime.MinValue;

            try
            {
                if (request.CreationDate != null)
                    dtCreationDate = DateTime.Parse(request.CreationDate, Thread.CurrentThread.CurrentCulture);
            }
            catch (Exception)
            {
                //ignore                
            }

            //Map DTO to Domain model
            var providerAgency = new ProviderAgency
            {
                Name = request.Name,
                CoordinatingAgencyId = request.CoordinatingAgencyId,
                License = request.License,
                DaysAllowedForDataEntry = request.DaysAllowedForDataEntry,
                IsActive = request.IsActive,
                OfficePhone = request.OfficePhone,
                Fax = request.Fax,
                Address1 = request.Address1,
                Address2 = request.Address2,
                City = request.City,
                State = request.State,
                Zip = request.Zip,
                Comments = request.Comments,
                AddressComments = request.AddressComments,
                CreationDate = dtCreationDate,
                //UpdationDate = DateTime.Now,
                CreatedBy = request.CreatedBy,
                UpdatedBy = request.UpdatedBy,
                OptionalData = request.OptionalData,
                Counties = request.Counties,
                SchoolDistricts = request.SchoolDistricts
            };

            var newAgency = await providerAgencyRepository.CreateAsync(providerAgency);
            //Domain model to DTO
            var response = new ProviderAgencyDto
            {
                Id = newAgency.Id,
                Name = newAgency.Name,
                CoordinatingAgencyId = newAgency.CoordinatingAgencyId,
                License = newAgency.License,
                DaysAllowedForDataEntry = newAgency.DaysAllowedForDataEntry,
                IsActive = newAgency.IsActive,
                OfficePhone = newAgency.OfficePhone,
                Fax = newAgency.Fax,
                Address1 = newAgency.Address1,
                Address2 = newAgency.Address2,
                City = newAgency.City,
                State = newAgency.State,
                Zip = newAgency.Zip,
                Comments = newAgency.Comments,
                AddressComments = newAgency.AddressComments,
                OptionalData = newAgency.OptionalData,
                Counties = newAgency.Counties,
                SchoolDistricts = newAgency.SchoolDistricts
            };
            return Ok(response);
        }
        [HttpPost]
        [Route("UpdateCountiesForProviderAgencyId")]
        public async Task<IActionResult> UpdateCountiesForProviderAgency(ProviderAgencyCountyRequest request)
        {
            var response = await providerAgencyRepository.UpdateCountyListForProviderAgencyId(request);
            return Ok(response);
        }
        [HttpPost]
        [Route("UpdateSchoolDistrictsForProviderAgencyId")]
        public async Task<IActionResult> UpdateSchoolDistrictsForProviderAgency(ProviderAgencySchoolDistrictRequest request)
        {
            var response = await providerAgencyRepository.UpdateSchoolDistrictListForProviderAgencyId(request);
            return Ok(response);
        }
        [HttpPost]
        [Route("UpdateOptionalDataForProviderAgencyId")]
        public async Task<IActionResult> UpdateOptionalDataForProviderAgency(ProviderAgencyOptionalDataRequest request)
        {
            var response = await providerAgencyRepository.UpdateOptionalDataForProviderAgency(request);
            return Ok(response);
        }
    }
}
