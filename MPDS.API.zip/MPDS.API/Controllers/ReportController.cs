﻿using Microsoft.AspNetCore.Mvc;
using MPDS.API.Models.Domain;
using MPDS.API.Repositories.Interface;
using System.Net;
using Microsoft.Extensions.Options;
using System;
using System.IO;
using System.Net;
using System.ServiceModel;

using System.Threading.Tasks;
using System.Web.Http;
using Microsoft.AspNetCore.Mvc;
using System.Text;
//using ssrsReportService;
using System.ServiceModel;
using MPDS.API.Utilities;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Reflection.Metadata;
//using ServiceReference;
using System.Collections;
using ReportExecutionService;
using ssrsWebServiceRef;
namespace MPDS.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ReportController : ControllerBase
    {
        private readonly IReportRepository reportRepository;
        private readonly AppIdentitySettings _appIdentitySettings;
        private readonly ReportService _reportService;
        private readonly HttpClient _httpClient;
        //private readonly ReportingService2010SoapClient _reportingService;
        private readonly IDatabaseLoggerService _logger;
        private readonly string reportServerUrl = "https://hcv491msqltdm01.ngds.state.mi.us/ReportServer/ReportExecution2010.asmx";
        private readonly string reportPath = "/ReportFolder/YourReportName";
        private readonly string reportUser = "your-ssrs-username";
        private readonly string reportPassword = "your-ssrs-password";
        private readonly string reportDomain = "your-ssrs-domain"; // May not be needed, depends on authentication setup

        private readonly IHttpClientFactory _httpClientFactory;


        public ReportController(IHttpClientFactory httpClientFactory, IOptions<AppIdentitySettings> appIdentitySettingsAccessor, IDatabaseLoggerService logger, ReportService reportService)
        {
            _httpClientFactory = httpClientFactory;

            this._appIdentitySettings = appIdentitySettingsAccessor.Value;
            this._logger = logger;
            _reportService = reportService;
        }

        //[HttpGet("DownloadReport/{reportPath}")]
        //public IActionResult DownloadReport(string reportPath, [FromQuery] Dictionary<string, string> parameters)

        //{

        //    // Connect to SSRS server

        //    var reportServer = new ReportServerCredentials("ServerUrl", "Username", "Password", "Domain");
        //    var reportService = new ReportServer();
        //    reportService.Credentials = reportServer;
        //    // Load report and set parameters
        //    var report = reportService.LoadReport(reportPath);
        //    foreach (var param in parameters)
        //    {
        //        report.SetParameterValue(param.Key, param.Value);
        //    }
        //    // Render as PDF stream
        //    var stream = report.Render("PDF", null, null);
        //    // Return stream as download
        //    return File(stream, "application/pdf", "report.pdf");
        //}

        [HttpGet("RunSSRSReport")]
        public async Task<IActionResult> GetSSRSReport(string format, string reportPath, [FromQuery] Dictionary<string, string> parameters)
        {
            try
            {
                // create client
                var rsBinding = new BasicHttpBinding();
                rsBinding.Security.Mode = BasicHttpSecurityMode.TransportCredentialOnly;
                rsBinding.Security.Transport.ClientCredentialType = HttpClientCredentialType.Basic;

                // So we can download reports bigger than 64 KBytes
                // See https://stackoverflow.com/questions/884235/wcf-how-to-increase-message-size-quota
                rsBinding.MaxBufferPoolSize = 20000000;
                rsBinding.MaxBufferSize = 20000000;
                rsBinding.MaxReceivedMessageSize = 20000000;

                var rsEndpointAddress = new EndpointAddress(reportServerUrl);
                var rsClient = new ReportExecutionServiceSoapClient(rsBinding, rsEndpointAddress);

                // Set user name and password
                rsClient.ClientCredentials.Windows.AllowedImpersonationLevel = System.Security.Principal.TokenImpersonationLevel.Impersonation;
                rsClient.ClientCredentials.Windows.ClientCredential = new System.Net.NetworkCredential(
                    _appIdentitySettings.MiloginInfo.SSRSUserName.ToString(),
                    _appIdentitySettings.MiloginInfo.SSRSPassword.ToString()
                    );


                ReportExecutionServiceSoapClient rs = rsClient;
                var trustedHeader = new TrustedUserHeader();

                LoadReportResponse loadReponse = await _reportService.LoadReport(rs, trustedHeader, reportPath);
                parameters = parameters.Where(kv => !kv.Key.Contains("format")).ToDictionary(kv => kv.Key, kv => kv.Value);
                parameters = parameters.Where(kv => !kv.Key.Contains("reportPath")).ToDictionary(kv => kv.Key, kv => kv.Value);

                //SetExecutionParametersResponse setParamsResponse = await rs.SetExecutionParametersAsync(rs, trustedHeader, parameters, "en-US");

                return null;
            }
            catch (Exception ex)
            {
                return null;
                throw;
            }
        }
        [HttpGet("GetSSRSReport")]
        public async Task<IActionResult> GetReport(string format, string reportPath, [FromQuery] Dictionary<string, string> parameters)
        {

            try
            {
                await _logger.LogInfo("1.Report Controller Creating httpClient ", "ReportControllerGetReport ", "AppUser");
                var client = _httpClientFactory.CreateClient();
                await _logger.LogInfo("1.Report Controller Creating httpClient successful", "ReportControllerGetReport ", "AppUser");

                string reportServerUrl = _appIdentitySettings.MiloginInfo.SSRSWebServiceUrl.ToString();

                string userName = _appIdentitySettings.MiloginInfo.SSRSUserName.ToString();
                string password = _appIdentitySettings.MiloginInfo.SSRSPassword.ToString();
                string Domain = "SOM";
                string ReportPath = reportPath;
                string Format = format;
                parameters = parameters.Where(kv => !kv.Key.Contains("format")).ToDictionary(kv => kv.Key, kv => kv.Value);
                parameters = parameters.Where(kv => !kv.Key.Contains("reportPath")).ToDictionary(kv => kv.Key, kv => kv.Value);
                //parameters = parameters.Add(new KeyValuePair<string,string>("parameters", "CoordinatingAgencyIds=18&ProviderAgencyIds=NULL9&GroupIds=NULL&StartDate=10/01/2006&EndDate=10/01/2015&IsGamblingRelated=false"));
                
                //CoordinatingAgencyIds=18&ProviderAgencyIds=NULL9&GroupIds=NULL&StartDate=10/01/2006&EndDate=10/01/2015&IsGamblingRelated=false
                //remove this next line in next with the next report upload
                //parameters = parameters.Where(kv => !kv.Key.Contains("isGamblingRelated")).ToDictionary(kv => kv.Key, kv => kv.Value);
                string Params = Utilities.Utilities.ToDebugString(parameters);
                if (format == "EXCEL")                     
                 format = "EXCELOPENXML";
                var reportData = await _reportService.RunReport("/MPDS/Reports/" + reportPath, parameters, reportServerUrl, userName, password, format);
                await _logger.LogInfo("1.Report Controller Returning file report/data", "ReportControllerGetReport ", "AppUser");
                return File(reportData, format == "PDF" ? "application/pdf" : "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");

            }
            catch (Exception ex)
            {
                await _logger.LogInfo("6.Report Controller Creating httpClient failed: " + ex.Message, "ReportControllerGetReport ", "AppUser");
            }
            return null;
        }

        [HttpGet("ssrs-report")]
        public async Task<IActionResult> GetSSRSReport(string reportName, string format = "PDF")
        {
            await _logger.LogInfo("10.Report Controller ssrs-report: ", "ReportControllerGetReport ", "AppUser");
            reportName = "Report_P12A";
            // SSRS Report URL
            //var ssrsUrl = $"https://hcv491msqltdm01.ngds.state.mi.us/Reports/report/MPDS/Reports/ActivityDataReport/{reportName}&rs:Command=Render&rs:Format={format}";
            var ssrsUrl = $"https://hcv491msqltdm01.ngds.state.mi.us/ReportServer?/MPDS/Reports/Report_P12A&CoordinatingAgencyIds=3&ProviderAgencyIds=29&GroupIds=2793&StartDate=10%2F01%2F2024&EndDate=10%2F02%2F2024&IsGamblingRelated=false&rs:format=PDF";

            //var url = "https://cnn.com";
            var response = await _httpClient.GetAsync(ssrsUrl);

            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                return Ok(content);
            }

            // Basic Authentication credentials
            var username = "mpds";
            var password = "Pass__123";
            //var password = "Pass__123";

            try
            {
                var filePath = Path.Combine(Directory.GetCurrentDirectory(), "Files", "sample.pdf");

                // Check if file exists
                if (!System.IO.File.Exists(filePath))
                {
                    return NotFound("File not found");
                }

                // Read the file as a byte array
                var fileBytes = await System.IO.File.ReadAllBytesAsync(filePath);

                // Return the file as a downloadable response
                return File(fileBytes, "application/pdf", "sample.pdf");
            }
            catch (Exception ex)
            {

                throw;
            }
            /* string reportServerUrl = "http://your-reportserver/ReportServer";
             string reportPath = $"/YourReportFolder/{reportName}";

             // Create the full SSRS report URL with parameters and render as PDF
             string reportUrl = $"{reportServerUrl}?{reportPath}&{parameters}&rs:Format=PDF";

             // Set up credentials if needed (for non-public access)
             _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue(
                 "Basic", Convert.ToBase64String(System.Text.Encoding.ASCII.GetBytes("username:password"))
             );

             try
             {
                 // Make a request to the SSRS report URL
                 var response = await _httpClient.GetAsync(reportUrl);
                 response.EnsureSuccessStatusCode();

                 // Read the PDF file bytes
                 var fileBytes = await response.Content.ReadAsByteArrayAsync();

                 // Return the PDF file as a downloadable response
                 return File(fileBytes, "application/pdf", $"{reportName}.pdf");
             }
             catch (HttpRequestException ex)
             {
                 return StatusCode(500, $"Error fetching report: {ex.Message}");
             }


             try
             {
                 // Set the basic authentication header
                 var authToken = Encoding.ASCII.GetBytes($"{username}:{password}");
                 _httpClient.DefaultRequestHeaders.Authorization =
                     new AuthenticationHeaderValue("Basic", Convert.ToBase64String(authToken));

                 // Send a GET request to the SSRS server
                 var response = await _httpClient.GetAsync(ssrsUrl);

                 if (response.IsSuccessStatusCode)
                 {
                     // Read report content as byte array
                     var reportData = await response.Content.ReadAsByteArrayAsync();

                     // Set the content type based on the format (e.g., PDF)
                     string contentType = format == "PDF" ? "application/pdf" : "application/octet-stream";

                     // Return the report data as a file
                     return File(reportData, contentType, $"{reportName}.{format.ToLower()}");
                 }
                 else
                 {
                     // Handle unsuccessful response
                     return StatusCode((int)response.StatusCode, "Failed to retrieve report from SSRS.");
                 }
             }
             catch (Exception ex)
             {
                 // Handle errors (log exception, etc.)
                 return StatusCode(500, $"Internal server error: {ex.Message}");
             }*/
        }
        [HttpGet]
        public async Task<IActionResult> GetReport()
        {
            try
            {
                var reportBytes = await _reportService.GetReportAsync();
                return File(reportBytes, "application/pdf", "report.pdf");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
        public static byte[] GenerateReport(string ReportServer, string Username, string Password, string Domain, string ReportPath, string Format, string Parameters)
        {

            ReportPath = ReportPath.Replace("/", "%2f").Replace(" ", "+");
            string URL = ReportServer + "?" + ReportPath + $"&rs:Command=Render&rs:Format=" + Format + "&rs:ParameterLanguage=en-GB" + "&" + Parameters;
            WebRequest Req = WebRequest.Create(URL);
            Req.Credentials = new NetworkCredential(Username, Password, Domain);
            //Req.Timeout = 500000; // Convert.ToInt32(ConfigurationManager.AppSettings["SSRSTimeout"]);
            Stream WebStream = Req.GetResponse().GetResponseStream();
            MemoryStream MemStream = new MemoryStream();
            WebStream.CopyTo(MemStream);
            long Len = MemStream.Length;
            byte[] ReportReturn = new byte[Len];
            MemStream.Seek(0, SeekOrigin.Begin);
            MemStream.Read(ReportReturn, 0, (int)Len);
            WebStream.Close();
            MemStream.Close();
            MemStream.Dispose();
            return ReportReturn;
        }
        [HttpGet("RenderSSRSReport")]
        public async Task<IActionResult> RenderSSRSReport(string reportPath, string format = "PDF", [FromQuery] Dictionary<string, string> parameters = null)
        {
            await _logger.LogInfo("In RenderReport:", "ReportController RenderReport method 1", "AppUser");
            // SSRS Report Server Endpoint and credentials
            string reportServerUrl = _appIdentitySettings.MiloginInfo.SSRSWebServiceUrl.ToString();
            string SSRSUrl = _appIdentitySettings.MiloginInfo.SSRSUrl.ToString();

            //string _reportPath = _appIdentitySettings.MiloginInfo.ReportPath.ToString();
            // string _reportUserName = _appIdentitySettings.MiloginInfo.SSRSUserName.ToString();
            //string _reportPassword = _appIdentitySettings.MiloginInfo.SSRSPassword.ToString();
            //await _logger.LogInfo("1.ReportController RenderReport method:", "reportServerUrl: " + reportServerUrl, "AppUser");
            // await _logger.LogInfo("2.ReportController RenderReport method:", "_reportPath: " + _reportPath, "AppUser");
            //  await _logger.LogInfo("3.ReportController RenderReport method:", "_reportUserName: " + _reportUserName, "AppUser");

            //var queryParams = new StringBuilder();
            //if (parameters != null && parameters.Any())
            //{
            //    foreach (var param in parameters)
            //    {
            //        if ((param.Value != "undefined") || (!param.Key.Equals("reportPath"))|| (!param.Key.Equals("format")) || (param.Value != "/Reports/") || (param.Value != "PDF"))
            //        { queryParams.Append($"&{param.Key}={param.Value}"); }
            //    }
            //}
            //reportServerUrl = "https://hcv491msqltdm01.ngds.state.mi.us/Reports/report/MPDS/Reports";
            //reportServerUrl = "https://hcv491msqltdm01.ngds.state.mi.us/ReportServer/ReportService2010.asmx";
            // reportServerUrl = "https://hcv491msqltdm01.ngds.state.mi.us/ReportServer/ReportService2005.asmx";

            //string domain = "SOM"; // For domain authentication (if needed)
            // Prepare SSRS report parameters and the report path
            //var reportUrl = $"{reportServerUrl}?{reportPath}&rs:Command=Render&rs:Format={format}";

            //var reportUrl = $"{reportServerUrl}/{reportPath}&rs:Command=Render&rs:Format={format}";
            //var reportUrl = $"{reportServerUrl}?{reportPath}{queryParams}&rs:Command=Render&rs:Format={format}";
            //var reportUrl = $"{SSRSUrl}/{_reportPath}?{queryParams}";
            //var reportUrl = "https://hcv491msqltdm01.ngds.state.mi.us/Reports/report/MPDS/Reports/Report_P12A?CoordinatingAgencyIds=23&StartDate=10%2F01%2F2014&EndDate=10%2F01%2F2024&IsGamblingRelated=False";
            var reportUrl = "https://hcv491msqltdm01.ngds.state.mi.us/ReportServer?/MPDS/Reports/Report_P12A&CoordinatingAgencyIds=3&ProviderAgencyIds=29&GroupIds=2793&StartDate=10%2F01%2F2024&EndDate=10%2F02%2F2024&IsGamblingRelated=false&rs:format=PDF";


            // Set up the HttpClient for basic authentication
            //var credentials = Convert.ToBase64String(Encoding.ASCII.GetBytes($"{domain}\\{username}:{password}"));
            //var credentials = Convert.ToBase64String(Encoding.ASCII.GetBytes($"{_reportUserName}:{_reportPassword}"));
            //_httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", credentials);

            try
            {
                // Call SSRS endpoint to get the report
                var response = await _httpClient.GetAsync(reportUrl);
                await _logger.LogInfo("4.ReportController RenderReport method:", " _httpClient.GetAsync(reportUrl) response.StatusCode : " + response.StatusCode + "response.message: line 204 " + response.RequestMessage, "AppUser");
                if (response.IsSuccessStatusCode)
                {
                    // Read the content as byte array (this will be the report file in the desired format)
                    var reportContent = await response.Content.ReadAsByteArrayAsync();

                    // Set the file format based on the requested format
                    var mimeType = format.ToUpper() switch
                    {
                        "PDF" => "application/pdf",
                        "EXCEL" => "application/vnd.ms-excel",
                        "WORD" => "application/msword",
                        _ => "application/octet-stream"
                    };

                    // Return the file as a response
                    return File(reportContent, mimeType, $"report.{format.ToLower()}");
                }
                else
                {
                    return BadRequest($"Error retrieving the report. Status Code: {response.StatusCode}" + "RequestMessage: " + response.RequestMessage);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
        [HttpGet("RenderReport")]
        public async Task<IActionResult> RenderReport(string reportPath, string format = "PDF", [FromQuery] Dictionary<string, string> parameters = null)
        {
            await _logger.LogInfo("In RenderReport:", "ReportController RenderReport method 1", "AppUser");
            // SSRS Report Server Endpoint and credentials
            string reportServerUrl = _appIdentitySettings.MiloginInfo.SSRSWebServiceUrl.ToString();
            string SSRSUrl = _appIdentitySettings.MiloginInfo.SSRSUrl.ToString();
            string _reportPath = _appIdentitySettings.MiloginInfo.SSRSFolder.ToString();
            string _reportUserName = _appIdentitySettings.MiloginInfo.SSRSUserName.ToString();
            string _reportPassword = _appIdentitySettings.MiloginInfo.SSRSPassword.ToString();
            var queryParams = new StringBuilder();
            if (parameters != null && parameters.Any())
            {
                foreach (var param in parameters)
                {
                    if (param.Value != "undefined")
                        queryParams.Append($"&{param.Key}={param.Value}");
                }
            }

            //reportServerUrl = "https://hcv491msqltdm01.ngds.state.mi.us/Reports/report/MPDS/Reports";
            //reportServerUrl = "https://hcv491msqltdm01.ngds.state.mi.us/ReportServer/ReportService2010.asmx";
            // reportServerUrl = "https://hcv491msqltdm01.ngds.state.mi.us/ReportServer/ReportService2005.asmx"; 
            // Prepare SSRS report parameters and the report path
            //var reportUrl = $"{reportServerUrl}?{reportPath}&rs:Command=Render&rs:Format={format}";            
            var reportUrl = $"{SSRSUrl}/{reportPath}?{queryParams}";
            await _logger.LogInfo("1.ReportController RenderReport method:", "reportServerUrl: " + reportServerUrl, "AppUser");
            await _logger.LogInfo("2.ReportController RenderReport method:", "_reportPath: " + _reportPath, "AppUser");
            await _logger.LogInfo("3.ReportController RenderReport method:", "_reportUserName: " + _reportUserName, "AppUser");

            // Set up the HttpClient for basic authentication
            //var credentials = Convert.ToBase64String(Encoding.ASCII.GetBytes($"{domain}\\{username}:{password}"));
            var credentials = Convert.ToBase64String(Encoding.ASCII.GetBytes($"{_reportUserName}:{_reportPassword}"));
            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", credentials);

            try
            {
                // Call SSRS endpoint to get the report
                var response = await _httpClient.GetAsync(reportUrl);
                await _logger.LogInfo("4.ReportController RenderReport method:", " _httpClient.GetAsync(reportUrl) response.StatusCode : " + response.StatusCode + "response.message: line 204 " + response.RequestMessage, "AppUser");
                if (response.IsSuccessStatusCode)
                {
                    // Read the content as byte array (this will be the report file in the desired format)
                    var reportContent = await response.Content.ReadAsByteArrayAsync();

                    // Set the file format based on the requested format
                    var mimeType = format.ToUpper() switch
                    {
                        "PDF" => "application/pdf",
                        "EXCEL" => "application/vnd.ms-excel",
                        "WORD" => "application/msword",
                        _ => "application/octet-stream"
                    };

                    // Return the file as a response
                    return File(reportContent, mimeType, $"report.{format.ToLower()}");
                }
                else
                {
                    return BadRequest("Error retrieving the report." + response.RequestMessage);
                }
            }
            catch (Exception ex)
            {
                await _logger.LogException(ex, "AppUser");
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet]
        [Route("ExecuteReport")]
        public async Task<IHttpActionResult> GetReport(ReportsParam loadReportRequest)
        {
            string _reportServerUrl = _appIdentitySettings.MiloginInfo.SSRSWebServiceUrl.ToString();
            string _reportPath = _appIdentitySettings.MiloginInfo.SSRSFolder.ToString();
            string _reportUserName = _appIdentitySettings.MiloginInfo.SSRSUserName.ToString();
            string _reportPassword = _appIdentitySettings.MiloginInfo.SSRSPassword.ToString();

            string Domain = "SOM";
            string Username = _reportUserName;
            string Password = _reportPassword;
            string ReportServer = _reportServerUrl;

            string ReportPath = "mpds";
            string Params = "ParamName=ParamValue";

            byte[] ReportData = GenerateReport(ReportServer, Username, Password, Domain, ReportPath, "PDF", Params);

            //File.WriteAllBytes(AppDomain.CurrentDomain.BaseDirectory + @"\" + "savedfilename.pdf", ReportData);

            //try
            //{
            //    var reportExecutionService = new ReportExec(
            //         new BasicHttpBinding(),
            //        new EndpointAddress(_reportServerUrl));

            //    reportExecutionService.ClientCredentials.Windows.ClientCredential = new NetworkCredential(_reportUserName, _reportPassword, "som");
            //    var rs = new ReportExecutionServiceSoapClient()
            //    rs.ClientCredentials.Windows.ClientCredential = new NetworkCredential(_reportUserName, _reportPassword, "som");
            //    string report = _reportPath;
            //    string historyID = null;
            //    ExecutionInfo execInfo = new ExecutionInfo();
            //    ExecutionHeader execHeader = new ExecutionHeader();
            //    rs.LoadReport(report, historyID);

            //    ParameterValue[] parameters = new ParameterValue[1];
            //    parameters[0] = new ParameterValue();
            //    parameters[0].Name = "ParameterName";
            //    parameters[0].Value = "ParameterValue";
            //    rs.SetExecutionParameters(parameters, "en-us");
            //    execInfo = rs.GetExecutionInfo();

            //    // Render the report in the desired format
            //    string deviceInfo = "<DeviceInfo><OutputFormat>" + format + "</OutputFormat></DeviceInfo>";
            //    string mimeType, encoding, extension;
            //    Warning[] warnings = null;
            //    string[] streamIDs = null;

            //    byte[] result = rs.Render(format, deviceInfo, out extension, out mimeType, out encoding, out warnings, out streamIDs);

            //    // Return the report as a file
            //    var contentType = mimeType ?? "application/octet-stream";
            //    return ResponseMessage(new HttpResponseMessage(HttpStatusCode.OK)
            //    {
            //        Content = new ByteArrayContent(result)
            //        {
            //            Headers = { ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue(contentType) }
            //        }
            //    });





            //}
            //catch (Exception)
            //{

            //    throw;
            //}


            //try
            //{
            //    var reportExecutionService = new ReportExecutionServiceSoapClient(
            //        new BasicHttpBinding(),
            //        new EndpointAddress(_reportServerUrl));

            //    // Set credentials (if needed)
            //    reportExecutionService.ClientCredentials.Windows.ClientCredential =
            //        new NetworkCredential("mpds", "Pass__123", "som");

            //    // Load the report
            //    var loadReportRequest = new LoadReportRequest
            //    {
            //        Report = _reportPath
            //    };
            //    var loadReportResponse = await reportExecutionService.LoadReportAsync(loadReportRequest);

            //    // Set the parameters (if needed)
            //    var parameters = new ParameterValue[]
            //    {
            //        new ParameterValue
            //        {
            //            Name = "YourParameterName",
            //            Value = "YourParameterValue"
            //        }
            //    };

            //    var setParametersRequest = new SetReportParametersRequest
            //    {
            //        Parameters = parameters
            //    };
            //    await reportExecutionService.SetReportParametersAsync(setParametersRequest);

            //    // Render the report
            //    var renderRequest = new RenderRequest
            //    {
            //        Format = "PDF" // Or any other supported format
            //    };
            //    var renderResponse = await reportExecutionService.RenderAsync(renderRequest);

            //    // Return the report as a file
            //    var fileStream = new MemoryStream(renderResponse.Result);
            //    return File(fileStream, "application/pdf", "report.pdf");

            //}
            //catch (Exception ex)
            //{
            //    // Handle exceptions
            //    return null;//InternalServerError(ex);
            //}


            return null;
        }
    }

    public interface IHttpActionResult
    {
    }
}
