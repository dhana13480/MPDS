﻿using Microsoft.AspNetCore.Mvc;
using MPDS.API.Models.DTO;
using MPDS.API.Repositories.Implementation;
using MPDS.API.Repositories.Interface;

namespace MPDS.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MasterServiceDomainController : ControllerBase
    {
        private readonly IMasterServiceDomainRepository masterServiceDomainRepository;

        public MasterServiceDomainController(IMasterServiceDomainRepository masterServiceDomainRepository)
        {
            this.masterServiceDomainRepository = masterServiceDomainRepository;
        }
        [HttpGet]
        public async Task<IActionResult> GetAllServiceDomains()
        {
            var serviceDomains = await masterServiceDomainRepository.GetAllSync();
            //convert domain to dto
            var response = new List<MasterServiceDomainDto>();
            foreach (var serviceDomain in serviceDomains)
            {
                response.Add(new MasterServiceDomainDto
                {
                    id = serviceDomain.id,
                    code = serviceDomain.code,
                    serviceDomain = serviceDomain.serviceDomain,
                    description = serviceDomain.description
                });
            }
            return Ok(response);
        }
    }
}
