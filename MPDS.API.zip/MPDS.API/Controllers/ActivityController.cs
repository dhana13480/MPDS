﻿using Azure;
using Azure.Core;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.Extensions.FileSystemGlobbing;
using MPDS.API.Data;
using MPDS.API.Extensions;
using MPDS.API.Models.Domain;
using MPDS.API.Models.DTO;
using MPDS.API.Repositories.Implementation;
using MPDS.API.Repositories.Interface;
using MPDS.API.Utilities;
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Net.Http;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.ServiceModel;
using System.Data;

namespace MPDS.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ActivityController : ControllerBase
    {
        private readonly IActivityRepository activityRepository;
        public ActivityController(IActivityRepository activityRepository)
        {
            this.activityRepository = activityRepository;
        }

        [HttpPost]


        [Route("ActStaffData/{id:long}")]
        public async Task<IActionResult> AddActivityStaff([FromBody] List<DatatableAcivitytStaff> data, [FromRoute] long id)
        {
            if (data == null || data.Count == 0)
            {
                return BadRequest("Invalid data, cannot create Activity Staff.");
            }

            DataTable dataTable = new DataTable();
            dataTable.Columns.Add("activityId", typeof(long));
            dataTable.Columns.Add("activityStaffId", typeof(long));
            dataTable.Columns.Add("activityStaffStartDate", typeof(string));
            dataTable.Columns.Add("activityStaffEndDate", typeof(string));
            dataTable.Columns.Add("units", typeof(int));

            DateTime dtActivityStaffStartDate = DateTime.MinValue;
            DateTime dtActivityStaffEndDate = DateTime.MinValue;

            //    if (request.activityStaffStartDate != null)
            //        dtActivityStaffStartDate = DateTime.Parse(request.activityStaffStartDate, Thread.CurrentThread.CurrentCulture);
            //    if (request.activityStaffEndDate != null)
            //        dtActivityStaffEndDate = DateTime.Parse(request.activityStaffEndDate, Thread.CurrentThread.CurrentCulture);

            //  staffName: '',// name
            //staffStartDt: '',//start dt
            //staffEndDt: '',//end dt
            //staffUnits: '', //units
            //staffId: '', //id
            //activityId: '',
            foreach (var staff in data)
            {
                dataTable.Rows.Add(id, staff.staffId, staff.staffStartDt, staff.staffEndDt, staff.staffUnits);

                var actstaff = new ActivityStaff
                {
                    ActivityId = id,
                    StaffId = Convert.ToInt64(staff.staffId),
                    StrategyId = 0,
                    Units = Convert.ToInt32(staff.staffUnits),
                    OptionalLocalMBO = "",
                    StartDate = DateTime.Parse(staff.staffStartDt, Thread.CurrentThread.CurrentCulture),
                    EndDate = DateTime.Parse(staff.staffEndDt, Thread.CurrentThread.CurrentCulture),

                };
                try
                {
                    await activityRepository.CreateActivityStaff(actstaff);
                }

                catch (Exception ex)
                {
                    return BadRequest("Error Adding Activity Staff" + ex.Message);
                }

            }

            return Ok(data);
            return BadRequest("Not successful");
        }

        [HttpPost]
        [Route("ActivityDataReport")]
        public async Task<IActionResult> ActivityDataReport(ActivityReportParam request)
        {
            DateTime dtStartDate = DateTime.MinValue;
            DateTime dtEndDate = DateTime.MinValue;
            if (request.StartDate != null)
                dtStartDate = DateTime.Parse(request.StartDate, Thread.CurrentThread.CurrentCulture);
            if (request.EndDate != null)
                dtEndDate = DateTime.Parse(request.EndDate, Thread.CurrentThread.CurrentCulture);
            var activities = await activityRepository.GetActivityReportData(request);
            //convert domain to dto
            var response = new List<ActivityReportResult>();
            foreach (var activity in activities)
            {
                response.Add(new ActivityReportResult
                {
                    PIHPId = activity.PIHPId,
                    ProviderId = activity.ProviderId,
                    GroupId = activity.GroupId,
                    PIHP = activity.PIHP,
                    Provider = activity.Provider,
                    Group = activity.Group,
                    ProgramName = activity.ProgramName,
                    GroupMinActivities = activity.GroupMinActivities,
                    GroupMaxActivities = activity.GroupMaxActivities,
                    GroupNoteText = activity.GroupNoteText,
                    Group_Type = activity.Group_Type,
                    FundingSource = activity.FundingSource,
                    ServiceDomain = activity.ServiceDomain,
                    ProgramType = activity.ProgramType,
                    EBPServiceType = activity.EBPServiceType,
                    InterventionType = activity.InterventionType,
                    ServicePopulation = activity.ServicePopulation,
                    YATRelated = activity.YATRelated,
                    IsGamblingRelated = activity.IsGamblingRelated,
                    RemainingIncompleteAttendees = activity.RemainingIncompleteAttendees,
                    ProgramNameId = activity.ProgramNameId,
                    ActivityName = activity.ActivityName,
                    PrimaryStrategy = activity.PrimaryStrategy,
                    ActivityStartDate = activity.ActivityStartDate,
                    ActivityStartTime = activity.ActivityStartTime,
                    ActivityEndDate = activity.ActivityEndDate,
                    ActivityEndTime = activity.ActivityEndTime,
                    ActivityDuration = activity.ActivityDuration,
                    ActivityUnits = activity.ActivityUnits,
                    ActivityCreationDate = activity.ActivityCreationDate,
                    TotalAttendees = activity.TotalAttendees,
                    NewMaleAttendees = activity.NewMaleAttendees,
                    NewFemaleAttendees = activity.NewFemaleAttendees,
                    NewTransManAttendees = activity.NewTransManAttendees,
                    NewTransWomanAttendees = activity.NewTransWomanAttendees,
                    NewGenderNonConformingAttendees = activity.NewGenderNonConformingAttendees,
                    NewOtherAttendees = activity.NewOtherAttendees,
                    NumberCompletingEvent = activity.NumberCompletingEvent,
                    EstimatedNumberReached = activity.EstimatedNumberReached,
                    ActivityRecordNumber = activity.ActivityRecordNumber,
                    ActivityVerified = activity.ActivityVerified,
                    ActivityVerifiedOn = activity.ActivityVerifiedOn,
                    ActivityVerifiedBy = activity.ActivityVerifiedBy,
                    NumberOriginalItems = activity.NumberOriginalItems,
                    NumberBrochures = activity.NumberBrochures,
                    IndirectSpeakingEngagementCount = activity.IndirectSpeakingEngagementCount,
                    IndirectSpeakingEngagementReach = activity.IndirectSpeakingEngagementReach,
                    SchoolBased = activity.SchoolBased,
                    strSchoolBased = activity.strSchoolBased,
                    LocationZipCode = activity.LocationZipCode,
                    SchoolDistrict = activity.SchoolDistrict,
                    County = activity.County,
                    ServiceSetting = activity.ServiceSetting,
                    ActivityNotes = activity.ActivityNotes,
                    AmericanIndianAlaskanNative = activity.AmericanIndianAlaskanNative,
                    HawaiianPacificIslander = activity.HawaiianPacificIslander,
                    White = activity.White,
                    Asian = activity.Asian,
                    AfricanAmerican = activity.AfricanAmerican,
                    MultiRacial = activity.MultiRacial,
                    UnknownOther = activity.UnknownOther,
                    ActivityId = activity.ActivityId,
                    ZeroTo5 = activity.ZeroTo5,
                    SixTo12 = activity.SixTo12,
                    ThirteenTo17 = activity.ThirteenTo17,
                    EighteenTo20 = activity.EighteenTo20,
                    TwentyOneTo24 = activity.TwentyOneTo24,
                    TwentyFiveTo44 = activity.TwentyFiveTo44,
                    FortyFiveTo64 = activity.FortyFiveTo64,
                    SixtyFiveTo74 = activity.SixtyFiveTo74,
                    SeventyFivePlus = activity.SeventyFivePlus,
                    HispanicLatinoEthnicity = activity.HispanicLatinoEthnicity,
                    ArabAmericanCanadianEthnicity = activity.ArabAmericanCanadianEthnicity,
                    NotListed = activity.NotListed,

                });
            }

            return Ok(response);

        }
        [HttpGet]
        [Route("ShowReport")]
        [AllowAnonymous]

        public HttpResponseMessage ShowReport(string ResponseType)
        {

            return null;
        }

        //public HttpResponseMessage GenerateReport (string reportName, string ExportFileName, string ExportFileType, List params)
        //{

        //}

        [HttpPost]
        [Route("PESRReportByFundSource")]
        public async Task<IActionResult> PESRReportByFundSource(PESRReportParam request)
        {

            var activities = await activityRepository.GetPESRByFundSourceReportData(request);
            //convert domain to dto
            var response = new List<PESRByFundSourceReportResult>();
            foreach (var activity in activities)
            {
                response.Add(new PESRByFundSourceReportResult
                {
                    ProviderAgencyId = activity.ProviderAgencyId,
                    ProviderAgency = activity.ProviderAgency,
                    StrategyId = activity.StrategyId,
                    Strategy = activity.Strategy,
                    InterventionTypeId = activity.InterventionTypeId,
                    InterventionType = activity.InterventionType,
                    GroupCount = activity.GroupCount,
                    Units = activity.Units,
                    UnitsAllEBP = activity.UnitsAllEBP,
                    NewAttendeesPopulation = activity.NewAttendeesPopulation,
                    NewAttendeesIndividual = activity.NewAttendeesIndividual,
                    FundingSource = activity.FundingSource
                });
            }
            return Ok(response);
        }

        [HttpPost]
        [Route("PESRReport")]
        public async Task<IActionResult> PESRReport(PESRReportParam request)
        {
            DateTime dtStartDate = DateTime.MinValue;
            DateTime dtEndDate = DateTime.MinValue;
            if (request.StartDate != null)
                dtStartDate = DateTime.Parse(request.StartDate, Thread.CurrentThread.CurrentCulture);
            if (request.EndDate != null)
                dtEndDate = DateTime.Parse(request.EndDate, Thread.CurrentThread.CurrentCulture);
            var activities = await activityRepository.GetPESRReportData(request);
            //convert domain to dto
            var response = new List<PESRReportResult>();
            foreach (var activity in activities)
            {
                response.Add(new PESRReportResult
                {
                    ProviderAgencyId = activity.ProviderAgencyId,
                    ProviderAgency = activity.ProviderAgency,
                    StrategyId = activity.StrategyId,
                    Strategy = activity.Strategy,
                    InterventionTypeId = activity.InterventionTypeId,
                    InterventionType = activity.InterventionType,
                    GroupCount = activity.GroupCount,
                    Units = activity.Units,
                    UnitsAllEBP = activity.UnitsAllEBP,
                    NewAttendeesPopulation = activity.NewAttendeesPopulation,
                    NewAttendeesIndividual = activity.NewAttendeesIndividual,
                });
            }
            return Ok(response);
        }
        [HttpGet]
        [Route("ActivityOptionalData/{id:long}")]
        public async Task<IActionResult> GetActivityOptionalDataDetails([FromRoute] long id)
        {
            var activityOptionalData = await activityRepository.GetOptionalDataById(id);
            if (activityOptionalData is null)
            {
                return NotFound();
            }
            var response = new List<ActivityOptionalDataDto>();
            foreach (var activity in activityOptionalData)
            {
                response.Add(new ActivityOptionalDataDto
                {
                    Id = activity.Id,
                    numberOfOriginalItemsCreated = activity.numberOfOriginalItemsCreated,
                    numberOfBrochuresDistributed = activity.numberOfBrochuresDistributed,
                    IsSchoolBasedActivity = activity.IsSchoolBasedActivity ? "Yes" : "No",
                    IndirectSpeakingEngagementReach = activity.IndirectSpeakingEngagementReach,
                    IndirectSpeakingEngagementCount = activity.IndirectSpeakingEngagementCount,
                    SchoolDistrictId = activity.SchoolDistrictId,
                    CountyId = activity.CountyId,
                    LocationZipCode = activity.LocationZipCode,
                    ServiceSettingId = activity.ServiceSettingId
                });
            }

            return Ok(response);
        }
        [HttpGet]
        [Route("ActivityRace/{id:long}")]
        public async Task<IActionResult> GetActivityRaceDetails([FromRoute] long id)
        {
            var activityRace = await activityRepository.GetRaceByActivityId(id);
            if (activityRace is null)
            {
                return NotFound();
            }
            //var response = new List<ActivityRaceDto>();

            //foreach (var activity in activityRace)
            //{
            //    response.Add(new ActivityRaceDto
            //    {
            //        Id = activity.Id,
            //        ActivityId = activity.ActivityId,
            //        RaceId = activity.RaceId,
            //        NoOfAttendees = activity.NoOfAttendees
            //    });
            //}
            var response = new ActivityRaceRequestModel();
            foreach (var activity in activityRace)
            {
                response.ActivityId = (long)activity.ActivityId;

                switch (activity.RaceId)
                {
                    case (int)enumRace.AmericanIndianAlaskanNative:
                        response.AmericanIndianAlaskanNative = (int)activity.NoOfAttendees;
                        break;
                    case (int)enumRace.HawaiianPacificIslander:
                        response.HawaiianPacificIslander = (int)activity.NoOfAttendees;
                        break;
                    case (int)enumRace.White:
                        response.White = (int)activity.NoOfAttendees;
                        break;
                    case (int)enumRace.AfricanAmerican:
                        response.AfricanAmerican = (int)activity.NoOfAttendees;
                        break;
                    case (int)enumRace.MultiRacial:
                        response.MultiRacial = (int)activity.NoOfAttendees;
                        break;
                    case (int)enumRace.UnknownOther:
                        response.UnknownOther = (int)activity.NoOfAttendees;
                        break;
                    default:
                        break;
                }
            }
            return Ok(response);
        }
        //[HttpGet]
        //[Route("GetActivityTotalAttendees/{id:long}")]
        //public async Task<IActionResult> GetActivityTotalAttendees(long TotalAttendees)
        //{
        //    var totalAttendees = await activityRepository.GetActivityTotalAttendees(long TotalAttendees);
        //    if (activityfundSrc is null)
        //    {
        //        return NotFound();
        //    }
        //    var response = new List<MasterFundingSourceDto>();

        //    foreach (var activity in activityfundSrc)
        //    {
        //        response.Add(new MasterFundingSourceDto
        //        {
        //            Id = activity.Id,
        //            FundingSource = activity.FundingSource,
        //            Description = activity.Description,
        //            IsActive = activity.IsActive,
        //            CreatedBy = activity.CreatedBy,
        //            CreationDate = activity.CreationDate,
        //            UpdatedBy = activity.UpdatedBy,
        //            UpdationDate = activity.UpdationDate
        //        });
        //    }

        //    return Ok(response);
        //}

        
        //[HttpGet]
        //[Route("masterfundingsource")]
        //public async Task<IActionResult> GetAllFundingSources()
        //{
        //    var activityfundSrc = await activityRepository.GetAllMasterFundingSource();
        //    if (activityfundSrc is null)
        //    {
        //        return NotFound();
        //    }
        //    var response = new List<MasterFundingSourceDto>();

        //    foreach (var activity in activityfundSrc)
        //    {
        //        response.Add(new MasterFundingSourceDto
        //        {
        //            Id = activity.Id,
        //            FundingSource = activity.FundingSource,
        //            Description = activity.Description,
        //            IsActive = activity.IsActive,
        //            CreatedBy = activity.CreatedBy,
        //            CreationDate = activity.CreationDate,
        //            UpdatedBy = activity.UpdatedBy,
        //            UpdationDate = activity.UpdationDate
        //        });
        //    }

        //    return Ok(response);
        //}

        [HttpGet]
        [Route("ActivityEthnicity/{id:long}")]
        public async Task<IActionResult> GetActivityEthnicityDetails([FromRoute] long id)
        {
            var activityEthnicity = await activityRepository.GetEthnicityByActivityId(id);
            if (activityEthnicity is null)
            {
                return NotFound();
            }
            //var response = new List<ActivityEthnicityDto>();
            //foreach (var activity in activityEthnicity)
            //{
            //    response.Add(new ActivityEthnicityDto
            //    {
            //        Id = activity.Id,
            //        ActivityId = activity.ActivityId,
            //        EthnicityId = activity.EthnicityId,
            //        NoOfAttendees = activity.NoOfAttendees
            //    });
            //}


            var response = new ActivityEthnicityRequestModel();
            foreach (var activity in activityEthnicity)
            {
                response.ActivityId = (long)activity.ActivityId;

                switch (activity.EthnicityId)
                {
                    case (int)enumEthnicities.ArabAmericanCanadianEthnicity:
                        response.ArabAmericanCanadianEthnicity = (int)activity.NoOfAttendees;
                        break;
                    case (int)enumEthnicities.HispanicLatinoEthnicity:
                        response.HispanicLatinoEthnicity = (int)activity.NoOfAttendees;
                        break;
                    case (int)enumEthnicities.NotListed:
                        response.NotListed = (int)activity.NoOfAttendees;
                        break;
                    default:
                        break;
                }
            }

            return Ok(response);
        }
        [HttpGet]
        [Route("ActivityParticipantAgeGroup/{id:long}")]
        public async Task<IActionResult> GetActivityParticipantAgeGroupDetails([FromRoute] long id)
        {
            var activityParticipantAgeGroup = await activityRepository.GetParticipantAgeGroupByActivityId(id);
            if (activityParticipantAgeGroup is null)
            {
                return NotFound();
            }
            //var response = new List<ActivityParticipantAgeGroupDto>();
            //foreach (var activity in activityParticipantAgeGroup)
            //{
            //    response.Add(new ActivityParticipantAgeGroupDto
            //    {
            //        Id = activity.Id,
            //        ActivityId = activity.ActivityId,
            //        ParticipantAgeGroupId = activity.ParticipantAgeGroupId,
            //        NoOfAttendees = activity.NoOfAttendees
            //    });
            //}         

            var response = new ActivityParticipantAgeGroupModel();
            foreach (var activity in activityParticipantAgeGroup)
            {
                response.ActivityId = (long)activity.ActivityId;
            /*
            ZeroTo5 = 1,
            SixTo12 = 2,
            ThirteenTo17 = 3,            
            EighteenTo20 = 4,
            TwentyOneTo24 = 5,
            TwentyFiveTo44 = 6,
            FortyFiveTo64 = 7,
            SixtyFiveTo74 = 8,
            SeventyFivePlus = 9
            */
                switch (activity.ParticipantAgeGroupId)
                {
                    case 1 :
                        response.ZeroTo5 = (int)activity.NoOfAttendees;
                        break;
                    case 2:
                        response.SixTo12 = (int)activity.NoOfAttendees;
                        break;
                    case 3:
                        response.ThirteenTo17 = (int)activity.NoOfAttendees;
                        break;
                    case 4:
                        response.EighteenTo20 = (int)activity.NoOfAttendees;
                        break;
                    case 5:
                        response.TwentyOneTo24 = (int)activity.NoOfAttendees;
                        break;
                    case 6:
                        response.TwentyFiveTo44 = (int)activity.NoOfAttendees;
                        break;
                    case 7:
                        response.FortyFiveTo64 = (int)activity.NoOfAttendees;
                        break;
                    case 8:
                        response.SixtyFiveTo74 = (int)activity.NoOfAttendees;
                        break;
                    case 9:
                        response.SeventyFivePlus = (int)activity.NoOfAttendees;
                        break;
                    default:
                        break;
                }
            }
            return Ok(response);
        }
        //ActivityStaff create
        [HttpPost]
        [Route("ActivityStaff/Add")]
        public async Task<IActionResult> CreateActivityStaff(CreateActivityStaff request)
        {
            if (request is not null)
            {
                DateTime dtActivityStaffStartDate = DateTime.MinValue;
                DateTime dtActivityStaffEndDate = DateTime.MinValue;

                if (request.activityStaffStartDate != null)
                    dtActivityStaffStartDate = DateTime.Parse(request.activityStaffStartDate, Thread.CurrentThread.CurrentCulture);
                if (request.activityStaffEndDate != null)
                    dtActivityStaffEndDate = DateTime.Parse(request.activityStaffEndDate, Thread.CurrentThread.CurrentCulture);

                var staff = new ActivityStaff
                {
                    ActivityId = request.activityId,
                    StaffId = request.activityStaffId,
                    StrategyId = request.activityStrategyId,
                    Units = request.Units,
                    OptionalLocalMBO = request.activityOptionalLocalMBO,
                    StartDate = dtActivityStaffStartDate,
                    EndDate = dtActivityStaffEndDate,
                };
                if (request.activityStaffId <= 0)
                    return BadRequest("Error Adding Activity Staff");
                if (request.activityId <= 0)
                    return BadRequest("Error Adding Activity Staff");

                try
                {
                    await activityRepository.CreateActivityStaff(staff);
                }

                catch (Exception ex)
                {
                    return BadRequest("Error Adding Activity Staff" + ex.Message);
                }
                var response = new CreateActivityStaff
                {
                    //Id = staff.Id,
                    activityId = (int)staff.ActivityId,
                    activityStaffId = request.activityStaffId,
                    activityStrategyId = request.activityStrategyId,
                    Units = request.Units,
                    activityOptionalLocalMBO = request.activityOptionalLocalMBO,
                    activityStaffStartDate = request.activityStaffStartDate,
                    activityStaffEndDate = request.activityStaffEndDate,
                };
                return Ok(response);
            }
            return BadRequest("Internal Server Error, Error Adding Activity Staff.");
        }

        [HttpGet]
        [Route("ActivityStaffByActivityId/{activityId:long}")]
        public async Task<IActionResult> ActivityStaffByActivityId([FromRoute] long activityId)
        {
            var activityStaff = await activityRepository.GetActivityStaffByActivityId(activityId);
            if (activityStaff is null)
            {
                return NotFound();
            }
            var response = new List<DatatableAcivitytStaff>();
            foreach (var activity in activityStaff)
            {
                response.Add(new DatatableAcivitytStaff
                {
                    //staffName { get; set; }// name
                    // staffStartDt { get; set; }//start dt
                    // staffEndDt { get; set; }//end dt
                    // staffUnits { get; set; }//units
                    // staffId { get; set; }//id
                    // activityId { get; set; }

                    staffName = activity.staffName,
                    staffStartDt = activity.staffStartDt,
                    staffEndDt = activity.staffEndDt,
                    staffUnits = activity.staffUnits,
                    staffId = activity.staffId,
                    activityId = activity.activityId,

                });
            }
            return Ok(response);
        }


        [HttpGet]
        [Route("ActivityStaff/{id:long}")]
        public async Task<IActionResult> GetActivityStaffDetails([FromRoute] long id)
        {
            var activityStaff = await activityRepository.GetStaffByActivityId(id);
            if (activityStaff is null)
            {
                return NotFound();
            }
            var response = new List<ActivityStaffDto>();
            foreach (var activity in activityStaff)
            {
                response.Add(new ActivityStaffDto
                {
                    Id = activity.Id,
                    ActivityId = activity.ActivityId,
                    StaffId = activity.StaffId,
                    StrategyId = activity.StrategyId,
                    Units = activity.Units,
                    OptionalLocalMBO = activity.OptionalLocalMBO,
                    StartDate = activity.StartDate,
                    EndDate = activity.EndDate
                });
            }
            return Ok(response);
        }

        [HttpPut]
        [Route("{id:long}")]
        public async Task<IActionResult> EditActivity([FromRoute] long id, ActivityDto request)
        {
            bool ModelState = true;
            StringBuilder ExceptionMsg = new StringBuilder("", 5000);
            ExceptionMsg.AppendLine("Please select ");
            ExceptionMsg.AppendLine();
            //ExceptionMsg.AppendLine("Total Attendees, ");

            if (request.CoordinatingAgencyId <= 0)
            {
                ModelState = false;
                ExceptionMsg.AppendLine("Coordinating Agency, ");
                //return BadRequest("Please select a Coordinating Agency");
            }

            if (request.ProviderAgencyId <= 0)
            {
                ModelState = false;
                ExceptionMsg.AppendLine();
                ExceptionMsg.AppendLine("Provider Agency, ");
                //return BadRequest("Please select a Coordinating Agency");
            }

            //return BadRequest("Please select a Provider Agency");
            if (request.GroupId <= 0)
            {
                ModelState = false;
                ExceptionMsg.AppendLine();
                ExceptionMsg.AppendLine(" Group, ");
                //return BadRequest("Please select a Group");
            }

            if (request.ActivityName == "")
            {
                ModelState = false;
                ExceptionMsg.AppendLine();
                ExceptionMsg.AppendLine(" Activity Name, ");
                //return BadRequest("Please enter Activity Name");
            }

            if (request.StartDate == "")
            {
                ModelState = false;
                ExceptionMsg.AppendLine();
                ExceptionMsg.AppendLine("Start Date, ");
                //  return BadRequest("Please select a Start Date");
            }

            if (request.EndDate == "")
            {
                ModelState = false;
                ExceptionMsg.AppendLine();
                ExceptionMsg.AppendLine("End Date, ");
                //return BadRequest("Please select a End Date");
            }

            if (request.TotalAttendees <= 0)
            {
                ModelState = false;
                ExceptionMsg.AppendLine();
                ExceptionMsg.AppendLine("Total Attendees, ");
                //return BadRequest("Please select Total Attendees");
            }



            int AllAttendeesTotal = (request.NewMaleAttendees ?? 0) + (request.NewFemaleAttendees ?? 0) + (request.NewTransManAttendees ?? 0) + (request.NewTransWomanAttendees ?? 0) + (request.NewGenderNonConformingAttendees ?? 0) + (request.NewOtherAttendees ?? 0);
            if (!request.TotalAttendees.Equals(AllAttendeesTotal))
            {
                ModelState = false;
                ExceptionMsg.AppendLine();
                ExceptionMsg.AppendLine("The Total Attendees should match the count with the total of all people attended, ");
                //return BadRequest("The Total Attendees should match the count with the total of all people attended");
            }


            if (request.PrimaryStrategyEmployedId <= 0)
            {
                ModelState = false;
                ExceptionMsg.AppendLine();
                ExceptionMsg.AppendLine("Primary Strategy Employed, ");
                //return BadRequest("Please select Primary Strategy Employed");
            }

            if (request.IsFirstActivityInGroup == null)
                request.IsFirstActivityInGroup = true;
            // return Ok("Please select New Female Attendees");
            if (request.AttendeesCompletingGroup < 0)
            {
                ModelState = false;
                ExceptionMsg.AppendLine();
                ExceptionMsg.AppendLine("Attendees Completing Group, ");
                //return BadRequest("Please select Attendees Completing Group");
            }
            if (!ModelState)
            {
                ExceptionMsg.Length--;
                ExceptionMsg.Length--;
                return BadRequest(ExceptionMsg.ToString());
            }
            //if (request.NewMaleAttendees <= 0)
            //    return Ok("Please select New Male Attendees");
            //if (request.NewFemaleAttendees <= 0)
            //return Ok("Please select New Female Attendees");
            if (request.IsFirstActivityInGroup == null)
                request.IsFirstActivityInGroup = false;
            // return Ok("Please select New Female Attendees");

            /*
            if (request.ActivityStaffStartDate == "")
                return BadRequest("Please select Activity Staff Start Date");
            if (request.ActivityStaffEndDate == "")
                return BadRequest("Please select Activity Staff End Date");
            */
            DateTime dtStartDate = DateTime.MinValue;
            DateTime dtEndDate = DateTime.MinValue;
            DateTime dtCreationDate = DateTime.MinValue;
            DateTime dtUpdationDate = DateTime.MinValue;
            DateTime dtVerifiedOn = DateTime.MinValue;
            DateTime dtActivityStaffStartDate = DateTime.MinValue;
            DateTime dtActivityStaffEndDate = DateTime.MinValue;
            try
            {

                if (request.StartDate != null)
                    dtStartDate = DateTime.Parse(request.StartDate, Thread.CurrentThread.CurrentCulture);
                if (request.EndDate != null)
                    dtEndDate = DateTime.Parse(request.EndDate, Thread.CurrentThread.CurrentCulture);
                if (request.CreationDate != null)
                    dtCreationDate = DateTime.Parse(request.CreationDate, Thread.CurrentThread.CurrentCulture);
                if (request.UpdationDate != null)
                    dtUpdationDate = DateTime.Parse(request.UpdationDate, Thread.CurrentThread.CurrentCulture);
                if ((request.VerifiedOn != null) && (!request.VerifiedOn.Equals(string.Empty)))
                    dtVerifiedOn = DateTime.Parse(request.VerifiedOn, Thread.CurrentThread.CurrentCulture);
                else dtVerifiedOn = DateTime.Parse("01/01/1900 00:00:00 AM", Thread.CurrentThread.CurrentCulture);
                if ((request.ActivityStaffStartDate != null) && (!request.ActivityStaffStartDate.Equals(string.Empty)))
                    dtActivityStaffStartDate = DateTime.Parse(request.ActivityStaffStartDate, Thread.CurrentThread.CurrentCulture);
                if ((request.ActivityStaffEndDate != null) && (!request.ActivityStaffEndDate.Equals(string.Empty)))
                    dtActivityStaffEndDate = DateTime.Parse(request.ActivityStaffEndDate, Thread.CurrentThread.CurrentCulture);
            }
          
            catch (Exception ex)
            {

            }

            if (request.IsVerified.Equals(true))
            {
                if (request.VerifyComments != "")
                    if(request.VerifiedOn=="")
                        request.VerifiedOn =DateTime.Now.ToString()  ;
            }
            try
            {

           
            var activity = new ActivitiesDto
            {
                Id = id,
                ActivityName = request.ActivityName,
                GroupId = request.GroupId,
                StartDate = dtStartDate,
                EndDate = dtEndDate,
                TotalAttendees = request.TotalAttendees,
                NewMaleAttendees = request.NewMaleAttendees,
                NewFemaleAttendees = request.NewFemaleAttendees,
                NewTransManAttendees = request.NewTransManAttendees,
                NewTransWomanAttendees = request.NewTransWomanAttendees,
                NewGenderNonConformingAttendees = request.NewGenderNonConformingAttendees,
                NewOtherAttendees = request.NewOtherAttendees,

                EstimatePeopleReached = request.EstimatePeopleReached,
                AttendeesCompletingGroup = request.AttendeesCompletingGroup,
                ActivityOptionalDataId = request.ActivityOptionalDataId,
                IsActive = request.IsActive,
                IsDeleted = request.IsDeleted,
                IsTobaccoRelated = request.IsTobaccoRelated,
                IsFirstActivityInGroup = request.IsFirstActivityInGroup,
                RecordNumber = request.RecordNumber,
                IsVerified = request.IsVerified,
                VerifiedOn = dtVerifiedOn,
                VerifiedByName = request.VerifiedByName,
                VerifiedBy = request.VerifiedBy,
                Comments = request.Comments,
                VerifyComments = request.VerifyComments,
                UpdatedBy = request.UpdatedBy,
                CreatedBy = request.CreatedBy,
                CreationDate = dtCreationDate,
                UpdationDate = dtUpdationDate,
                OrderNumber = request.OrderNumber,

                numberOfOriginalItemsCreated = request.numberOfOriginalItemsCreated,
                numberOfBrochuresDistributed = request.numberOfBrochuresDistributed,
                IsSchoolBasedActivity = request.IsSchoolBasedActivity,
                IndirectSpeakingEngagementReach = request.IndirectSpeakingEngagementReach,
                IndirectSpeakingEngagementCount = request.IndirectSpeakingEngagementCount,
                SchoolDistrictId = request.SchoolDistrictId,
                CountyId = request.CountyId,
                LocationZipCode = request.LocationZipCode,
                ServiceSettingId = request.ServiceSettingId,
                ActivityOptionalId = request.ActivityOptionalDataId,
                PrimaryStrategyEmployedId = request.PrimaryStrategyEmployedId,
                ServicePopulationId = request.ServicePopulationId,
                FundingSourceId = request.FundingSourceId,
                TotalPeopleReached = request.TotalPeopleReached,
                TotalImpressions = request.TotalImpressions,
                MethodsUsed = request.MethodsUsed,
                SocialMediaUsed = request.SocialMediaUsed,
                TotalPSA = request.TotalPSA
    };
            try
            {
                await activityRepository.UpdateAsync(activity);
            }
            catch (Exception ex)
            {

                return BadRequest("Activity updation not successful: " + ex.Message);
            }

            var response = activity.Id;
            return Ok(response);
            }
            catch (Exception ex)
            {
                return BadRequest("Activity Creation not successful: " + ex.Message);

            }
        }
        public enum enumEthnicities : int
        {
            ArabAmericanCanadianEthnicity = 1,
            HispanicLatinoEthnicity = 2,
            NotListed = 3
        }
        public enum enumRace : int
        {
            AmericanIndianAlaskanNative = 1,
            HawaiianPacificIslander = 2,
            White = 3,
            Asian = 4,
            AfricanAmerican = 5,
            MultiRacial = 6,
            UnknownOther = 7
        }
        public enum enumParticipantAgeGrp : int
        {
            ZeroTo5 = 1,
            SixTo12 = 2,
            ThirteenTo17 = 3,
            EighteenTo20 = 4,
            TwentyOneTo24 = 5,
            TwentyFiveTo44 = 6,
            FortyFiveTo64 = 7,
            SixtyFiveTo74 = 8,
            SeventyFivePlus = 9
        }

        [HttpPost("AddActivityParticipantAgeGroup/{totalAttendees:int}")]
        public async Task<IActionResult> AddActivityParticipantAgeGroup(ActivityParticipantAgeGroupModel request, [FromRoute] int totalAttendees)
        {
            /*
            ZeroTo5 = 1,
            SixTo12 = 2,
            ThirteenTo17 = 3,            
            EighteenTo20 = 4,
            TwentyOneTo24 = 5,
            TwentyFiveTo44 = 6,
            FortyFiveTo64 = 7,
            SixtyFiveTo74 = 8,
            SeventyFivePlus = 9
            */
            if (request != null)
            {

                int? AllAttendeesTotal = (request.ZeroTo5) + (request.SixTo12) + (request.ThirteenTo17) + (request.EighteenTo20) + (request.TwentyOneTo24) + (request.TwentyFiveTo44);
                if (AllAttendeesTotal != totalAttendees)
                    return BadRequest("The Participants Age Group total should match total attendees");

                if (request.ZeroTo5 > 0)
                {
                    var activityZeroTo5 = new ActivityParticipantAgeGroup
                    {
                        ActivityId = request.ActivityId,
                        ParticipantAgeGroupId = (int)enumParticipantAgeGrp.ZeroTo5,
                        NoOfAttendees = request.ZeroTo5
                    };
                    try
                    {
                        await activityRepository.CreateActivityParticipantAgeGroup(activityZeroTo5);
                    }
                    catch (Exception ex)
                    {
                        return BadRequest("Activity Participant Age Group 0 to 5 creation failed: " + ex.Message);
                    }

                }
                if (request.SixTo12 > 0)
                {
                    var activityFiveTo11 = new ActivityParticipantAgeGroup
                    {
                        ActivityId = request.ActivityId,
                        ParticipantAgeGroupId = (int)enumParticipantAgeGrp.SixTo12,
                        NoOfAttendees = request.SixTo12
                    };
                    try
                    {
                        await activityRepository.CreateActivityParticipantAgeGroup(activityFiveTo11);
                    }
                    catch (Exception ex)
                    {
                        return BadRequest("Activity Participant Age Group 5 to 11 creation failed: " + ex.Message);
                    }
                }

                if (request.ThirteenTo17 > 0)
                {
                    var activityTwelveTo14 = new ActivityParticipantAgeGroup
                    {
                        ActivityId = request.ActivityId,
                        ParticipantAgeGroupId = (int)enumParticipantAgeGrp.ThirteenTo17,
                        NoOfAttendees = request.ThirteenTo17
                    };

                    try
                    {
                        await activityRepository.CreateActivityParticipantAgeGroup(activityTwelveTo14);
                    }
                    catch (Exception ex)
                    {
                        return BadRequest("Activity Participant Age Group 13  to 17 creation failed: " + ex.Message);
                    }

                }
                if (request.EighteenTo20 > 0)
                {
                    var activityEighteenTo20 = new ActivityParticipantAgeGroup
                    {
                        ActivityId = request.ActivityId,
                        ParticipantAgeGroupId = (int)enumParticipantAgeGrp.EighteenTo20,
                        NoOfAttendees = request.EighteenTo20
                    };
                    try
                    {
                        await activityRepository.CreateActivityParticipantAgeGroup(activityEighteenTo20);
                    }
                    catch (Exception ex)
                    {
                        return BadRequest("Activity Participant Age Group 18 to 20 creation failed: " + ex.Message);
                    }
                }
                if (request.TwentyOneTo24 > 0)
                {
                    var activityTwentyOneTo24 = new ActivityParticipantAgeGroup
                    {
                        ActivityId = request.ActivityId,
                        ParticipantAgeGroupId = (int)enumParticipantAgeGrp.TwentyOneTo24,
                        NoOfAttendees = request.TwentyOneTo24
                    };
                    try
                    {
                        await activityRepository.CreateActivityParticipantAgeGroup(activityTwentyOneTo24);
                    }
                    catch (Exception ex)
                    {
                        return BadRequest("Activity Participant Age Group 21 to 24 creation failed: " + ex.Message);
                    }

                }
                if (request.TwentyFiveTo44 > 0)
                {
                    var activityTwentyFiveTo44 = new ActivityParticipantAgeGroup
                    {
                        ActivityId = request.ActivityId,
                        ParticipantAgeGroupId = (int)enumParticipantAgeGrp.TwentyFiveTo44,
                        NoOfAttendees = request.TwentyOneTo24
                    };
                    try
                    {
                        await activityRepository.CreateActivityParticipantAgeGroup(activityTwentyFiveTo44);
                    }
                    catch (Exception ex)
                    {
                        return BadRequest("Activity Participant Age Group 25 to 44 creation failed: " + ex.Message);
                    }
                }

                if (request.FortyFiveTo64 > 0)
                {
                    var activityFortyFiveTo64 = new ActivityParticipantAgeGroup
                    {
                        ActivityId = request.ActivityId,
                        ParticipantAgeGroupId = (int)enumParticipantAgeGrp.FortyFiveTo64,
                        NoOfAttendees = request.FortyFiveTo64
                    };
                    await activityRepository.CreateActivityParticipantAgeGroup(activityFortyFiveTo64);
                }
                if (request.SixtyFiveTo74 > 0)
                {
                    var activitySixtyFiveTo74 = new ActivityParticipantAgeGroup
                    {
                        ActivityId = request.ActivityId,
                        ParticipantAgeGroupId = (int)enumParticipantAgeGrp.SixtyFiveTo74,
                        NoOfAttendees = request.SixtyFiveTo74
                    };
                    await activityRepository.CreateActivityParticipantAgeGroup(activitySixtyFiveTo74);
                }
                if (request.SeventyFivePlus > 0)
                {
                    var activitySeventyFivePlus = new ActivityParticipantAgeGroup
                    {
                        ActivityId = request.ActivityId,
                        ParticipantAgeGroupId = (int)enumParticipantAgeGrp.SeventyFivePlus,
                        NoOfAttendees = request.SeventyFivePlus
                    };
                    await activityRepository.CreateActivityParticipantAgeGroup(activitySeventyFivePlus);
                }
            }
            /*
           ZeroTo5 = 1,
           SixTo12 = 2,
           ThirteenTo17 = 3,            
           EighteenTo20 = 4,
           TwentyOneTo24 = 5,
           TwentyFiveTo44 = 6,
           FortyFiveTo64 = 7,
           SixtyFiveTo74 = 8,
           SeventyFivePlus = 9
           */
            var response = new ActivityParticipantAgeGroupModelDto
            {
                ZeroTo5 = request.ZeroTo5,
                SixTo12 = request.SixTo12,
                ThirteenTo17 = request.ThirteenTo17,
                EighteenTo20 = request.EighteenTo20,
                TwentyOneTo24 = request.TwentyOneTo24,
                TwentyFiveTo44 = request.TwentyFiveTo44,
                FortyFiveTo64 = request.FortyFiveTo64,
                SixtyFiveTo74 = request.SixtyFiveTo74,
                SeventyFivePlus = request.SeventyFivePlus,
                ActivityId = request.ActivityId
            };
            return Ok(response);
        }

        [HttpPost("AddActivityRace/{totalAttendees:int}")]
        public async Task<IActionResult> AddActivityRace(ActivityRaceRequestModel request, [FromRoute] int totalAttendees)
        {

            if (request != null)
            {
                int? AllAttendeesTotal = (request.AmericanIndianAlaskanNative)
                    + (request.HawaiianPacificIslander)
                    + (request.Asian)
                    + (request.White)
                    + (request.AfricanAmerican)
                    + (request.MultiRacial)
                    + (request.UnknownOther);
                if (AllAttendeesTotal != totalAttendees)
                    return BadRequest("The Participants Race total should match total attendees");


                if (request.AmericanIndianAlaskanNative > 0)
                {
                    var activityAmerican = new ActivityRace
                    {
                        ActivityId = request.ActivityId,
                        RaceId = (int)enumRace.AmericanIndianAlaskanNative,
                        NoOfAttendees = request.AmericanIndianAlaskanNative
                    };
                    await activityRepository.CreateActivityRace(activityAmerican);
                }
                if (request.HawaiianPacificIslander > 0)
                {
                    var activityHawaiianPacificIslander = new ActivityRace
                    {
                        ActivityId = request.ActivityId,
                        RaceId = (int)enumRace.HawaiianPacificIslander,
                        NoOfAttendees = request.HawaiianPacificIslander
                    };
                    await activityRepository.CreateActivityRace(activityHawaiianPacificIslander);
                }
                if (request.Asian > 0)
                {
                    var activityAsian = new ActivityRace
                    {
                        ActivityId = request.ActivityId,
                        RaceId = (int)enumRace.Asian,
                        NoOfAttendees = request.Asian
                    };
                    await activityRepository.CreateActivityRace(activityAsian);
                }
                if (request.White > 0)
                {
                    var activityWhite = new ActivityRace
                    {
                        ActivityId = request.ActivityId,
                        RaceId = (int)enumRace.White,
                        NoOfAttendees = request.White
                    };
                    await activityRepository.CreateActivityRace(activityWhite);
                }
                if (request.AfricanAmerican > 0)
                {
                    var activityAfricanAmerican = new ActivityRace
                    {
                        ActivityId = request.ActivityId,
                        RaceId = (int)enumRace.AfricanAmerican,
                        NoOfAttendees = request.AfricanAmerican
                    };
                    await activityRepository.CreateActivityRace(activityAfricanAmerican);
                }
                if (request.MultiRacial > 0)
                {
                    var activityMultiRacial = new ActivityRace
                    {
                        ActivityId = request.ActivityId,
                        RaceId = (int)enumRace.MultiRacial,
                        NoOfAttendees = request.MultiRacial
                    };
                    await activityRepository.CreateActivityRace(activityMultiRacial);
                }
                if (request.UnknownOther > 0)
                {
                    var activityUnknownOther = new ActivityRace
                    {
                        ActivityId = request.ActivityId,
                        RaceId = (int)enumRace.UnknownOther,
                        NoOfAttendees = request.UnknownOther
                    };
                    await activityRepository.CreateActivityRace(activityUnknownOther);
                }

            }

            var response = new ActivityRaceRequestModelDto
            {
                AmericanIndianAlaskanNative = request.AmericanIndianAlaskanNative,
                HawaiianPacificIslander = request.HawaiianPacificIslander,
                White = request.White,
                Asian = request.Asian,
                AfricanAmerican = request.AfricanAmerican,
                MultiRacial = request.MultiRacial,
                UnknownOther = request.UnknownOther,
                ActivityId = request.ActivityId
            };
            return Ok(response);
        }
        [HttpPut("UpdateActivityEthnicity/{totalAttendees:int}")]
        public async Task<IActionResult> UpdateActivityEthnicity(ActivityEthnicityRequestModel request, [FromRoute] int totalAttendees)
        {

            int? AllAttendeesTotal = (request.ArabAmericanCanadianEthnicity)
               + (request.HispanicLatinoEthnicity)
               + (request.NotListed);

            if (AllAttendeesTotal != totalAttendees)
                return BadRequest("The Participants Ethnicity total should match total attendees");

            if (request.ArabAmericanCanadianEthnicity > 0)
            {
                var activityArab = new ActivityEthnicity
                {
                    ActivityId = request.ActivityId,
                    EthnicityId = (int)enumEthnicities.ArabAmericanCanadianEthnicity,
                    NoOfAttendees = request.ArabAmericanCanadianEthnicity
                };
                await activityRepository.UpdateActivityEthnicity(activityArab);
            }
            if (request.HispanicLatinoEthnicity > 0)
            {
                var activityHisp = new ActivityEthnicity
                {
                    ActivityId = request.ActivityId,
                    EthnicityId = (int)enumEthnicities.HispanicLatinoEthnicity,
                    NoOfAttendees = request.HispanicLatinoEthnicity
                };
                await activityRepository.UpdateActivityEthnicity(activityHisp);
            }
            if (request.NotListed > 0)
            {
                var activityNot = new ActivityEthnicity
                {
                    ActivityId = request.ActivityId,
                    EthnicityId = (int)enumEthnicities.NotListed,
                    NoOfAttendees = request.NotListed
                };
                await activityRepository.UpdateActivityEthnicity(activityNot);
            }
            var response = new ActivityEthnicityRequestModelDto
            {
                ArabAmericanCanadianEthnicity = request.ArabAmericanCanadianEthnicity,
                HispanicLatinoEthnicity = request.HispanicLatinoEthnicity,
                NotListed = request.NotListed,
                ActivityId = request.ActivityId
            };
            return Ok(response);
        }

        [HttpPut("UpdateActivityParticipantAgeGrp/{totalAttendees:int}")]
        public async Task<IActionResult> UpdateActivityParticipantAgeGrp(ActivityParticipantAgeGroupModel request, [FromRoute] int totalAttendees)
        {
            /*
           ZeroTo5 = 1,
           SixTo12 = 2,
           ThirteenTo17 = 3,            
           EighteenTo20 = 4,
           TwentyOneTo24 = 5,
           TwentyFiveTo44 = 6,
           FortyFiveTo64 = 7,
           SixtyFiveTo74 = 8,
           SeventyFivePlus = 9
           */
            int? AllAttendeesTotal = (request.ZeroTo5) + (request.SixTo12) + (request.ThirteenTo17) + (request.EighteenTo20) + (request.TwentyOneTo24) + (request.TwentyFiveTo44);
            if (AllAttendeesTotal != totalAttendees)
                return BadRequest("The Participants Age Group total should match total attendees");

            if (request.ZeroTo5 > 0)
            {
                var activityZeroTo5 = new ActivityParticipantAgeGroup
                {
                    ActivityId = request.ActivityId,
                    ParticipantAgeGroupId = (int)enumParticipantAgeGrp.ZeroTo5,
                    NoOfAttendees = request.ZeroTo5
                };
                await activityRepository.UpdateActivityParticipantAgeGroup(activityZeroTo5);
            }
            if (request.SixTo12 > 0)
            {
                var activitySixTo12 = new ActivityParticipantAgeGroup
                {
                    ActivityId = request.ActivityId,
                    ParticipantAgeGroupId = (int)enumParticipantAgeGrp.SixTo12,
                    NoOfAttendees = request.SixTo12
                };
                await activityRepository.UpdateActivityParticipantAgeGroup(activitySixTo12);
            }
            if (request.ThirteenTo17 > 0)
            {
                var activityThirteenTo17 = new ActivityParticipantAgeGroup
                {
                    ActivityId = request.ActivityId,
                    ParticipantAgeGroupId = (int)enumParticipantAgeGrp.ThirteenTo17,
                    NoOfAttendees = request.ThirteenTo17
                };
                await activityRepository.UpdateActivityParticipantAgeGroup(activityThirteenTo17);
            }
            if (request.EighteenTo20 > 0)
            {
                var activityEighteenTo20 = new ActivityParticipantAgeGroup
                {
                    ActivityId = request.ActivityId,
                    ParticipantAgeGroupId = (int)enumParticipantAgeGrp.EighteenTo20,
                    NoOfAttendees = request.EighteenTo20
                };
                await activityRepository.UpdateActivityParticipantAgeGroup(activityEighteenTo20);
            }
            if (request.TwentyOneTo24 > 0)
            {
                var activityTwentyOneTo24 = new ActivityParticipantAgeGroup
                {
                    ActivityId = request.ActivityId,
                    ParticipantAgeGroupId = (int)enumParticipantAgeGrp.TwentyOneTo24,
                    NoOfAttendees = request.TwentyOneTo24
                };
                await activityRepository.UpdateActivityParticipantAgeGroup(activityTwentyOneTo24);
            }
            if (request.TwentyFiveTo44 > 0)
            {
                var activityTwentyFiveTo44 = new ActivityParticipantAgeGroup
                {
                    ActivityId = request.ActivityId,
                    ParticipantAgeGroupId = (int)enumParticipantAgeGrp.TwentyFiveTo44,
                    NoOfAttendees = request.TwentyFiveTo44
                };
                await activityRepository.UpdateActivityParticipantAgeGroup(activityTwentyFiveTo44);
            }
            if (request.FortyFiveTo64 > 0)
            {
                var activityFortyFiveTo64 = new ActivityParticipantAgeGroup
                {
                    ActivityId = request.ActivityId,
                    ParticipantAgeGroupId = (int)enumParticipantAgeGrp.FortyFiveTo64,
                    NoOfAttendees = request.FortyFiveTo64
                };
                await activityRepository.UpdateActivityParticipantAgeGroup(activityFortyFiveTo64);
            }
            if (request.SixtyFiveTo74 > 0)
            {
                var activitySixtyFiveTo74 = new ActivityParticipantAgeGroup
                {
                    ActivityId = request.ActivityId,
                    ParticipantAgeGroupId = (int)enumParticipantAgeGrp.SixtyFiveTo74,
                    NoOfAttendees = request.SixtyFiveTo74
                };
                await activityRepository.UpdateActivityParticipantAgeGroup(activitySixtyFiveTo74);
            }
            if (request.SeventyFivePlus > 0)
            {
                var activitySeventyFivePlus = new ActivityParticipantAgeGroup
                {
                    ActivityId = request.ActivityId,
                    ParticipantAgeGroupId = (int)enumParticipantAgeGrp.SeventyFivePlus,
                    NoOfAttendees = request.SeventyFivePlus
                };
                await activityRepository.UpdateActivityParticipantAgeGroup(activitySeventyFivePlus);
            }
            var response = new ActivityParticipantAgeGroupModelDto
            {
                ZeroTo5 = request.ZeroTo5,
                SixTo12 = request.SixTo12,
                ThirteenTo17 = request.ThirteenTo17,
                EighteenTo20 = request.EighteenTo20,
                TwentyOneTo24 = request.TwentyOneTo24,
                TwentyFiveTo44 = request.TwentyFiveTo44,
                FortyFiveTo64 = request.FortyFiveTo64,
                SixtyFiveTo74 = request.SixtyFiveTo74,
                SeventyFivePlus = request.SeventyFivePlus,
                ActivityId = request.ActivityId
            };
            return Ok(response);
        }
        [HttpPut("UpdateActivityRace/{totalAttendees:int}")]
        public async Task<IActionResult> UpdateActivityRace(ActivityRaceRequestModel request, [FromRoute] int totalAttendees)
        {
            int? AllAttendeesTotal = (request.AmericanIndianAlaskanNative)
                    + (request.HawaiianPacificIslander)
                    + (request.Asian)
                    + (request.White)
                    + (request.AfricanAmerican)
                    + (request.MultiRacial)
                    + (request.UnknownOther);
            if (AllAttendeesTotal != totalAttendees)
                return BadRequest("The Participants Race total should match total attendees");

            if (request.AmericanIndianAlaskanNative > 0)
            {
                var activityAmerican = new ActivityRace
                {
                    ActivityId = request.ActivityId,
                    RaceId = (int)enumRace.AmericanIndianAlaskanNative,
                    NoOfAttendees = request.AmericanIndianAlaskanNative
                };
                await activityRepository.UpdateActivityRace(activityAmerican);
            }

            if (request.HawaiianPacificIslander > 0)
            {
                var activityHawaiian = new ActivityRace
                {
                    ActivityId = request.ActivityId,
                    RaceId = (int)enumRace.HawaiianPacificIslander,
                    NoOfAttendees = request.HawaiianPacificIslander
                };
                await activityRepository.UpdateActivityRace(activityHawaiian);
            }
            if (request.White > 0)
            {
                var activityWhite = new ActivityRace
                {
                    ActivityId = request.ActivityId,
                    RaceId = (int)enumRace.White,
                    NoOfAttendees = request.White
                };
                await activityRepository.UpdateActivityRace(activityWhite);
            }
            if (request.Asian > 0)
            {
                var activityAsian = new ActivityRace
                {
                    ActivityId = request.ActivityId,
                    RaceId = (int)enumRace.Asian,
                    NoOfAttendees = request.Asian
                };
                await activityRepository.UpdateActivityRace(activityAsian);
            }
            if (request.AfricanAmerican > 0)
            {
                var activityAfrican = new ActivityRace
                {
                    ActivityId = request.ActivityId,
                    RaceId = (int)enumRace.AfricanAmerican,
                    NoOfAttendees = request.AfricanAmerican
                };
                await activityRepository.UpdateActivityRace(activityAfrican);
            }
            if (request.MultiRacial > 0)
            {
                var activityMultiRacial = new ActivityRace
                {
                    ActivityId = request.ActivityId,
                    RaceId = (int)enumRace.MultiRacial,
                    NoOfAttendees = request.MultiRacial
                };
                await activityRepository.UpdateActivityRace(activityMultiRacial);
            }
            if (request.UnknownOther > 0)
            {
                var activityUnknownOther = new ActivityRace
                {
                    ActivityId = request.ActivityId,
                    RaceId = (int)enumRace.UnknownOther,
                    NoOfAttendees = request.UnknownOther
                };
                await activityRepository.UpdateActivityRace(activityUnknownOther);
            }

            var response = new ActivityRaceRequestModelDto
            {
                AmericanIndianAlaskanNative = request.AmericanIndianAlaskanNative,
                HawaiianPacificIslander = request.HawaiianPacificIslander,
                White = request.White,
                Asian = request.Asian,
                AfricanAmerican = request.AfricanAmerican,
                MultiRacial = request.MultiRacial,
                UnknownOther = request.UnknownOther,
                ActivityId = request.ActivityId,
            };
            return Ok(response);
        }

        [HttpPost("AddActivityEthnicity/{totalAttendees:int}")]
        public async Task<IActionResult> AddActivityEthnicity(ActivityEthnicityRequestModel request, [FromRoute] int totalAttendees)
        {
            if (request != null)
            {
                try
                {


                    int? AllAttendeesTotal = (request.ArabAmericanCanadianEthnicity)
                       + (request.HispanicLatinoEthnicity)
                       + (request.NotListed);

                    if (AllAttendeesTotal != totalAttendees)
                        return BadRequest("The Participants Ethnicity total should match total attendees");

                    if (request.ArabAmericanCanadianEthnicity > 0)
                    {
                        var activityArab = new ActivityEthnicity
                        {
                            ActivityId = request.ActivityId,
                            EthnicityId = (int)enumEthnicities.ArabAmericanCanadianEthnicity,
                            NoOfAttendees = request.ArabAmericanCanadianEthnicity
                        };
                        await activityRepository.CreateActivityEthnicity(activityArab);
                    }
                    if (request.HispanicLatinoEthnicity > 0)
                    {
                        var activityHisp = new ActivityEthnicity
                        {
                            ActivityId = request.ActivityId,
                            EthnicityId = (int)enumEthnicities.HispanicLatinoEthnicity,
                            NoOfAttendees = request.HispanicLatinoEthnicity
                        };
                        await activityRepository.CreateActivityEthnicity(activityHisp);
                    }
                    if (request.NotListed > 0)
                    {
                        var activityNotListed = new ActivityEthnicity
                        {
                            ActivityId = request.ActivityId,
                            EthnicityId = (int)enumEthnicities.NotListed,
                            NoOfAttendees = request.NotListed
                        };
                        await activityRepository.CreateActivityEthnicity(activityNotListed);
                    }
                }
                catch (Exception ex)
                {
                    return BadRequest("Cannot Add the Participants Ethnicity " + ex.Message);
                }

            }

            var response = new ActivityEthnicityRequestModelDto
            {
                ArabAmericanCanadianEthnicity = request.ArabAmericanCanadianEthnicity,
                HispanicLatinoEthnicity = request.HispanicLatinoEthnicity,
                NotListed = request.NotListed,
                ActivityId = request.ActivityId
            };
            return Ok(response);
        }
         
        [HttpGet]
        [Route("CheckIsOneTimeActivity")]
        [AllowAnonymous]
        public async Task<IActionResult> CheckIsOneTimeActivity(long groupId)
        {
            bool IsGroupTypeOneTimeAndExists = await activityRepository.IsGroupTypeOneTimeAndExists(groupId);

            //if (IsGroupTypeOneTimeAndExists)
                
            return null;
        }
        [HttpPost("AddActivity")]
        public async Task<IActionResult> AddActivity(ActivityDto request)
        {
            bool ModelState = true;
            StringBuilder ExceptionMsg = new StringBuilder("", 5000);
            DateTime dtStartDate = DateTime.MinValue;
            DateTime dtEndDate = DateTime.MinValue;
            DateTime dtCreationDate = DateTime.MinValue;
            DateTime dtUpdationDate = DateTime.MinValue;

            DateTime dtVerifiedOn = DateTime.MinValue;
            DateTime dtActivityStaffStartDate = DateTime.MinValue;
            DateTime dtActivityStaffEndDate = DateTime.MinValue;

            ExceptionMsg.AppendLine("Please select ");

            if (request.CoordinatingAgencyId <= 0)
            {
                ModelState = false;
                ExceptionMsg.AppendLine("Coordinating Agency, ");
                //return BadRequest("Please select a Coordinating Agency");
            }

            if (request.ProviderAgencyId <= 0)
            {
                ModelState = false;
                ExceptionMsg.AppendLine();
                ExceptionMsg.AppendLine("Provider Agency, ");
                //return BadRequest("Please select a Coordinating Agency");
            }

            //return BadRequest("Please select a Provider Agency");
            if (request.GroupId <= 0)
            {
                ModelState = false;
                ExceptionMsg.AppendLine();
                ExceptionMsg.AppendLine(" Group, ");
                //return BadRequest("Please select a Group");
            }
            else
            //check if multiple activities can be created for this group
            if (request.GroupId > 0)
            {
                bool IsGroupTypeOneTimeAndExists = await activityRepository.IsGroupTypeOneTimeAndExists((long)request.GroupId);

                if (IsGroupTypeOneTimeAndExists)
                {
                    ModelState = false;
                    ExceptionMsg.AppendLine();
                    ExceptionMsg.AppendLine(" Group Type is of One Time Activity, multiple Activities cannot be created for this Group., ");
                }
            }
            if (request.ActivityName == "")
            {
                ModelState = false;
                ExceptionMsg.AppendLine();
                ExceptionMsg.AppendLine(" Activity Name, ");
                //return BadRequest("Please enter Activity Name");
            }
            //else
            //{
            //    //check if same name activity exists?

            //    bool isActivityNameExist = await activityRepository.isActivityNameAlreadyExists(request.ActivityName);
            //    if (isActivityNameExist)
            //    {
            //        return BadRequest("Activity Name " + request.ActivityName + " already exists, please choose a different Activity name.");
            //    }
            //}

            if (request.StartDate == "")
            {
                ModelState = false;
                ExceptionMsg.AppendLine();
                ExceptionMsg.AppendLine("Start Date, ");
                //  return BadRequest("Please select a Start Date");
            }
            else
            {
                try
                {
                    if (request.StartDate != null)
                        dtStartDate = DateTime.Parse(request.StartDate, Thread.CurrentThread.CurrentCulture);
                    if (dtStartDate > DateTime.Now )
                    {
                        return BadRequest("Activity Name " + request.ActivityName + " cannot start in a future date.");
                    }
                }
                catch (Exception)
                {
                    return BadRequest("Start Date input error for activity " + request.ActivityName + ".");
                }
            }

            if (request.EndDate == "")
            {
                ModelState = false;
                ExceptionMsg.AppendLine();
                ExceptionMsg.AppendLine("End Date, ");
                //return BadRequest("Please select a End Date");
            }
            else
            {
                try
                {
                    if (request.EndDate != null)
                        dtEndDate = DateTime.Parse(request.EndDate, Thread.CurrentThread.CurrentCulture);
                    if (dtEndDate > DateTime.Now)
                    {
                        return BadRequest(" Activity Name " + request.ActivityName + " cannot end in a future date.");
                    }
                }
                catch (Exception)
                {
                    return BadRequest(" End Date input error for activity " + request.ActivityName + ".");
                }
            }

            if (request.TotalAttendees <= 0)
            {
                ModelState = false;
                ExceptionMsg.AppendLine();
                ExceptionMsg.AppendLine("Total Attendees, ");
                //return BadRequest("Please select Total Attendees");
            }


            int AllAttendeesTotal = (request.NewMaleAttendees ?? 0) + (request.NewFemaleAttendees ?? 0) + (request.NewTransManAttendees ?? 0) + (request.NewTransWomanAttendees ?? 0) + (request.NewGenderNonConformingAttendees ?? 0) + (request.NewOtherAttendees ?? 0);

            if (!request.TotalAttendees.Equals(AllAttendeesTotal))
            {
                ModelState = false;
                ExceptionMsg.AppendLine();
                ExceptionMsg.AppendLine("The Total Attendees should match the count with the total of all people attended, ");
                //return BadRequest("The Total Attendees should match the count with the total of all people attended");
            }


            if (request.PrimaryStrategyEmployedId <= 0)
            {
                ModelState = false;
                ExceptionMsg.AppendLine();
                ExceptionMsg.AppendLine("Primary Strategy Employed, ");
                //return BadRequest("Please select Primary Strategy Employed");
            }

            if (request.IsFirstActivityInGroup == null)
                request.IsFirstActivityInGroup = true;
            // return Ok("Please select New Female Attendees");
            if (request.AttendeesCompletingGroup < 0)
            {
                ModelState = false;
                ExceptionMsg.AppendLine();
                ExceptionMsg.AppendLine("Attendees Completing Group, ");
                //return BadRequest("Please select Attendees Completing Group");
            }
            if (!ModelState)
            {
                ExceptionMsg.Length--;
                ExceptionMsg.Length--;
                return BadRequest(ExceptionMsg.ToString());
            }


            //DateTime dtStartDate = DateTime.MinValue;
            //DateTime dtEndDate = DateTime.MinValue;
            //DateTime dtCreationDate = DateTime.MinValue;
            //DateTime dtUpdationDate = DateTime.MinValue;

            //DateTime dtVerifiedOn = DateTime.MinValue;
            //DateTime dtActivityStaffStartDate = DateTime.MinValue;
            //DateTime dtActivityStaffEndDate = DateTime.MinValue;
            try
            {
                if ((request.VerifiedOn != null) && (request.VerifiedOn != string.Empty))
                    dtVerifiedOn = DateTime.Parse(request.VerifiedOn, Thread.CurrentThread.CurrentCulture);                
                else dtVerifiedOn = DateTime.Parse("01/01/1900 00:00:00 AM", Thread.CurrentThread.CurrentCulture);
            }
            catch (Exception)
            {
                //ignore                
            }
            try
            {
                if (request.StartDate != null)
                    dtStartDate = DateTime.Parse(request.StartDate, Thread.CurrentThread.CurrentCulture);
            }
            catch (Exception)
            {
                //ignore                
            }
            try
            {
                if (request.EndDate != null)
                    dtEndDate = DateTime.Parse(request.EndDate, Thread.CurrentThread.CurrentCulture);
            }
            catch (Exception)
            {
                //ignore                
            }
            try
            {
                if (request.ActivityStaffStartDate != null)
                    dtActivityStaffStartDate = DateTime.Parse(request.ActivityStaffStartDate, Thread.CurrentThread.CurrentCulture);
            }
            catch (Exception)
            {
                //ignore                
            }
            try
            {
                if (request.ActivityStaffEndDate != null)
                    dtActivityStaffEndDate = DateTime.Parse(request.ActivityStaffEndDate, Thread.CurrentThread.CurrentCulture);
            }
            catch (Exception)
            {
                //ignore                
            }

            try
            {
                if (request.UpdationDate != null)
                    dtUpdationDate = DateTime.Parse(request.UpdationDate, Thread.CurrentThread.CurrentCulture);
            }
            catch (Exception)
            {
                //ignore                
            }
            try
            {
                if (request.CreationDate != null)
                    dtCreationDate = DateTime.Parse(request.CreationDate, Thread.CurrentThread.CurrentCulture);
            }
            catch (Exception)
            {
                //ignore                
            }

            var activity = new ActivitiesDto
            {
                ActivityName = request.ActivityName,
                GroupId = request.GroupId,
                StartDate = dtStartDate,
                EndDate = dtEndDate,
                TotalAttendees = request.TotalAttendees,
                NewMaleAttendees = request.NewMaleAttendees,
                NewFemaleAttendees = request.NewFemaleAttendees,
                NewTransManAttendees = request.NewTransManAttendees,
                NewTransWomanAttendees = request.NewTransWomanAttendees,
                NewGenderNonConformingAttendees = request.NewGenderNonConformingAttendees,
                NewOtherAttendees = request.NewOtherAttendees,
                MasterStrategyEmployed = request.MasterStrategyEmployed,
                EstimatePeopleReached = request.EstimatePeopleReached,
                AttendeesCompletingGroup = request.AttendeesCompletingGroup,
                ActivityOptionalDataId = request.ActivityOptionalDataId,
                IsActive = request.IsActive,
                IsDeleted = request.IsDeleted,
                IsTobaccoRelated = request.IsTobaccoRelated,
                IsFirstActivityInGroup = request.IsFirstActivityInGroup,
                RecordNumber = request.RecordNumber,
                IsVerified = request.IsVerified,
                VerifiedOn = dtVerifiedOn,
                VerifiedByName = request.VerifiedByName,
                VerifiedBy = request.VerifiedBy,
                Comments = request.Comments,
                VerifyComments = request.VerifyComments,
                CreatedBy = request.CreatedBy,
                CreationDate = dtCreationDate,
                UpdatedBy = request.UpdatedBy,
                UpdationDate = dtUpdationDate,
                OrderNumber = request.OrderNumber,
                //Activity Optional Data

                numberOfOriginalItemsCreated = request.numberOfOriginalItemsCreated,
                numberOfBrochuresDistributed = request.numberOfBrochuresDistributed,
                IsSchoolBasedActivity = request.IsSchoolBasedActivity,
                IndirectSpeakingEngagementReach = request.IndirectSpeakingEngagementReach,
                IndirectSpeakingEngagementCount = request.IndirectSpeakingEngagementCount,
                SchoolDistrictId = request.SchoolDistrictId,
                CountyId = request.CountyId,
                LocationZipCode = request.LocationZipCode,
                ServiceSettingId = request.ServiceSettingId,
                //Ethnicity
                EthnicityId = request.EthnicityId,
                EthnicityNoOfAttendees = request.EthnicityNoOfAttendees,
                //Race
                RaceId = request.RaceId,
                RaceNoOfAttendees = request.RaceNoOfAttendees,
                // ParticipantAgeGroup
                ParticipantAgeGroupId = request.ParticipantAgeGroupId,
                ParticipantAgeGroupNoOfAttendees = request.ParticipantAgeGroupNoOfAttendees,
                //Staff
                StaffId = request.StaffId,
                StrategyId = request.StrategyId,
                Units = request.Units,
                OptionalLocalMBO = request.OptionalLocalMBO,
                ActivityStaffStartDate = dtActivityStaffStartDate,
                ActivityStaffEndDate = dtActivityStaffEndDate,
                PrimaryStrategyEmployedId = request.PrimaryStrategyEmployedId,
                ServicePopulationId = request.ServicePopulationId,
                FundingSourceId = request.FundingSourceId,
                TotalPeopleReached = request.TotalPeopleReached,
                TotalImpressions = request.TotalImpressions,
                MethodsUsed = request.MethodsUsed,
                SocialMediaUsed = request.SocialMediaUsed

            };
            try
            {
                await activityRepository.CreateAsync(activity);
            }
            catch (Exception ex)
            {
                return BadRequest("Activity Creation not successful: " + ex.Message);
            }
            //string idWithTotalAttendees = activity.Id.ToString() + "," + activity.TotalAttendees.ToString();
            //var response = idWithTotalAttendees;

            var response = activity.Id;
            return Ok(response);
        }

        [HttpPost]
        public async Task<IActionResult> GetAllActivity(ActivitiesSPInput inputparam)
        {

            var activities = await activityRepository.GetAllAsync(inputparam);
            //convert domain to dto
            var response = new List<ActivityDto>();
            foreach (var activity in activities)
            {
                response.Add(new ActivityDto
                {
                    Id = activity.Id,
                    ActivityName = activity.ActivityName,
                    GroupId = activity.GroupId,
                    GroupName = activity.GroupName,
                    StartDate = activity.StartDate.ToString(),
                    EndDate = activity.EndDate.ToString(),
                    TotalAttendees = activity.TotalAttendees,
                    NewMaleAttendees = activity.NewMaleAttendees,
                    NewFemaleAttendees = activity.NewFemaleAttendees,
                    NewTransManAttendees = activity.NewTransManAttendees,
                    NewTransWomanAttendees = activity.NewTransWomanAttendees,
                    NewGenderNonConformingAttendees = activity.NewGenderNonConformingAttendees,
                    NewOtherAttendees = activity.NewOtherAttendees,
                    MasterStrategyEmployed = activity.MasterStrategyEmployed,
                    EstimatePeopleReached = activity.EstimatePeopleReached,
                    AttendeesCompletingGroup = activity.AttendeesCompletingGroup,
                    ActivityOptionalDataId = activity.ActivityOptionalDataId,
                    IsActive = activity.IsActive,
                    ProgramNameId = activity.ProgramNameId,
                    Status = activity.Status,
                    RecordNumber = activity.RecordNumber,
                    VerifiedOn =  activity.VerifiedOn.ToString(),
                    VerifiedByName = activity.VerifiedByName,
                    VerifiedBy= activity.VerifiedBy,
                    IsVerified = activity.IsVerified,
                    Comments = activity.Comments,
                    VerifyComments = activity.VerifyComments,
                    OrderNumber = activity.OrderNumber,
                    ProviderAgencyId = activity.ProviderAgencyId,
                    CoordinatingAgencyId = activity.CoordinatingAgencyId,
                    PrimaryStrategyEmployedId = activity.PrimaryStrategyEmployedId,
                    ServicePopulationId = activity.ServicePopulationId,
                    FundingSourceId = activity.FundingSourceId,
                    IsFirstActivityInGroup = activity.IsFirstActivityInGroup,
                    TotalPeopleReached = activity.TotalPeopleReached,
                    TotalImpressions = activity.TotalImpressions,
                    MethodsUsed = activity.MethodsUsed,
                    SocialMediaUsed = activity.SocialMediaUsed
                });
            }

            return Ok(response);
        }            


        [HttpPost("GetActivitiesByGroupId")]
        public async Task<IActionResult> GetActivityByGroupId([FromQuery] UserParams userParams, long groupId)
        {
            var activities = await activityRepository.GetActivitiesByGroupId(groupId);
            //convert domain to dto
            var response = new List<ActivitiesDto>();
            foreach (var activity in activities)
            {
                response.Add(new ActivitiesDto
                {
                    Id = activity.Id,
                    ActivityName = activity.ActivityName,
                    GroupId = activity.GroupId,
                    GroupName = activity.GroupName,
                    StartDate = activity.StartDate,
                    EndDate = activity.EndDate,
                    TotalAttendees = activity.TotalAttendees,
                    NewMaleAttendees = activity.NewMaleAttendees,
                    NewFemaleAttendees = activity.NewFemaleAttendees,
                    NewTransManAttendees = activity.NewTransManAttendees,
                    NewTransWomanAttendees = activity.NewTransWomanAttendees,
                    NewGenderNonConformingAttendees = activity.NewGenderNonConformingAttendees,
                    NewOtherAttendees = activity.NewOtherAttendees,
                    MasterStrategyEmployed = activity.MasterStrategyEmployed,
                    EstimatePeopleReached = activity.EstimatePeopleReached,
                    AttendeesCompletingGroup = activity.AttendeesCompletingGroup,
                    ActivityOptionalDataId = activity.ActivityOptionalDataId,
                    IsActive = activity.IsActive,
                    ProgramNameId = activity.ProgramNameId,
                    Status = activity.Status,
                    RecordNumber = activity.RecordNumber,
                    VerifiedOn = activity.VerifiedOn,
                    VerifiedByName = activity.VerifiedByName,
                    IsVerified = activity.IsVerified,
                    Comments = activity.Comments,
                    VerifyComments = activity.VerifyComments,
                    OrderNumber = activity.OrderNumber,
                    ProviderAgencyId = activity.ProviderAgencyId,
                    CoordinatingAgencyId = activity.CoordinatingAgencyId,
                    PrimaryStrategyEmployedId = activity.PrimaryStrategyEmployedId,
                    ServicePopulationId = activity.ServicePopulationId,
                    FundingSourceId = activity.FundingSourceId,
                    CreatedBy = activity.CreatedBy,
                    UpdatedBy= activity.UpdatedBy,
                    CreationDate= activity.CreationDate,
                    UpdationDate=activity.UpdationDate,
                    TotalPeopleReached = activity.TotalPeopleReached,
                    TotalImpressions = activity.TotalImpressions,
                    MethodsUsed = activity.MethodsUsed,
                    SocialMediaUsed = activity.SocialMediaUsed
                });
            }
            Response.AddPaginationHeader(new PaginationHeader(activities.CurrentPage,
                activities.PageSize, activities.TotalCount, activities.TotalPages));
            return Ok(response);
        }
        [HttpPost("GetAllActivityPaginated")]
        public async Task<IActionResult> GetAllActivityPaginated([FromQuery] UserParams userParams, ActivitiesSPInput inputparam)
        {
            if (inputparam.CoordinatingAgencyId > 0)
            {
                var activities = await activityRepository.GetAllAsyncPaginated(inputparam, userParams);
                //convert domain to dto
                var response = new List<ActivitiesDto>();
                foreach (var activity in activities)
                {
                    response.Add(new ActivitiesDto
                    {
                        Id = activity.Id,
                        ActivityName = activity.ActivityName,
                        GroupId = activity.GroupId,
                        GroupName = activity.GroupName,
                        StartDate = activity.StartDate,
                        EndDate = activity.EndDate,
                        TotalAttendees = activity.TotalAttendees,
                        NewMaleAttendees = activity.NewMaleAttendees,
                        NewFemaleAttendees = activity.NewFemaleAttendees,
                        NewTransManAttendees = activity.NewTransManAttendees,
                        NewTransWomanAttendees = activity.NewTransWomanAttendees,
                        NewGenderNonConformingAttendees = activity.NewGenderNonConformingAttendees,
                        NewOtherAttendees = activity.NewOtherAttendees,
                        MasterStrategyEmployed = activity.MasterStrategyEmployed,
                        EstimatePeopleReached = activity.EstimatePeopleReached,
                        AttendeesCompletingGroup = activity.AttendeesCompletingGroup,
                        ActivityOptionalDataId = activity.ActivityOptionalDataId,
                        IsActive = activity.IsActive,
                        ProgramNameId = activity.ProgramNameId,
                        Status = activity.Status,
                        RecordNumber = activity.RecordNumber,
                        VerifiedOn = activity.VerifiedOn,
                        VerifiedByName = activity.VerifiedByName,
                        VerifiedBy = activity.VerifiedBy,
                        Comments = activity.Comments,
                        VerifyComments = activity.VerifyComments,
                        OrderNumber = activity.OrderNumber,
                        ProviderAgencyId = activity.ProviderAgencyId,
                        CoordinatingAgencyId = activity.CoordinatingAgencyId,
                        PrimaryStrategyEmployedId = activity.PrimaryStrategyEmployedId,
                        ServicePopulationId = activity.ServicePopulationId,
                        FundingSourceId = activity.FundingSourceId,
                        TotalPeopleReached = activity.TotalPeopleReached,
                        TotalImpressions = activity.TotalImpressions,
                        MethodsUsed = activity.MethodsUsed,
                        SocialMediaUsed = activity.SocialMediaUsed
                    });
                }

                Response.AddPaginationHeader(new PaginationHeader(activities.CurrentPage,
                    activities.PageSize, activities.TotalCount, activities.TotalPages));
                return Ok(response);
            }
            else
                return BadRequest("Please select a Coordinating Agency for Search");

        }

        //    [HttpPost]
        //    static async Task ExportReportFromServiceAsync(string reportName, string format, string baseUrl)
        //    {
        //        // 1. Register client
        //        ReportClient reportClient = new ReportClient(baseUrl);
        //        await reportClient.RegisterClient();


        //        // 2. Create Report Instance
        //        ReportSourceModel reportSourceModel = new ReportSourceModel()
        //        {
        //            Report = reportName
        //        };

        //        string reportSource = System.Text.Json.JsonSerializer.Serialize(reportSourceModel);
        //        string reportInstanceId = await reportClient.CreateInstance(reportSource);


        //        // 3. Create Document
        //        string reportDocumentId = await reportClient.CreateDocument(reportInstanceId, format);

        //        bool documentProcessing;
        //        do
        //        {
        //            Thread.Sleep(500);// wait before next Info request
        //            documentProcessing = await reportClient.DocumentIsProcessing(reportInstanceId, reportDocumentId);
        //        } while (documentProcessing);

        //        // 4. Get Document
        //        byte[] result = await reportClient.GetDocument(reportInstanceId, reportDocumentId);
        //        File.WriteAllBytes($"C:\\temp\\{reportName}.{format.ToLower()}", result);
        //    }

        //}


        public class ClientIDModel
        {
            [System.Text.Json.Serialization.JsonPropertyName("clientId")]
            public string ClientId { get; set; }
        }

        public class ReportSourceModel
        {
            [System.Text.Json.Serialization.JsonPropertyName("Report")]
            public string Report { get; set; }
            [System.Text.Json.Serialization.JsonPropertyName("ParameterValues")]
            public IDictionary<string, object> ParameterValues { get; set; }
        }

        public class InstanceIdModel
        {
            [System.Text.Json.Serialization.JsonPropertyName("instanceId")]
            public string InstanceId { get; set; }
        }

        public class DocumentIdModel
        {
            [System.Text.Json.Serialization.JsonPropertyName("documentId")]
            public string DocumentId { get; set; }
        }

        public class DocumentInfoModel
        {
            [System.Text.Json.Serialization.JsonPropertyName("documentReady")]
            public bool DocumentReady { get; set; }

            [System.Text.Json.Serialization.JsonPropertyName("PageCount")]
            public int PageCount { get; set; }

            [System.Text.Json.Serialization.JsonPropertyName("DocumentMapAvailable")]
            public bool DocumentMapAvailable { get; set; }
        }

        public class ErrorModel
        {
            [System.Text.Json.Serialization.JsonPropertyName("error")]
            public string Error { get; set; }

            [System.Text.Json.Serialization.JsonPropertyName("error_description")]
            public string Description { get; set; }
        }

        //public static class HttpContentExtensions
        //{
        //    public static async Task<T> ReadAsAsync<T>(this HttpContent content) =>
        //        await System.Text.Json.JsonSerializer.DeserializeAsync<T>(await content.ReadAsStreamAsync());
        //}

        public class ReportClient : IDisposable
        {
            public string BaseAddress { get; set; }
            public HttpClient client;
            public string ClientId;

            public ReportClient(string uri)
            {
                this.client = HttpClientFactory.Create();
                this.BaseAddress = uri;

                this.client.BaseAddress = new Uri(this.BaseAddress);
            }

            public void Dispose()
            {
                using (this.client) { }
            }

            public async Task RegisterClient()
            {
                var headers = new List<KeyValuePair<string, string>>();
                var content = new FormUrlEncodedContent(headers);

                var response = await this.client.PostAsync(this.BaseAddress + "/clients", content);

                if (response.IsSuccessStatusCode)
                {
                    var clientIdTask = await response.Content.ReadAsAsync<ClientIDModel>();
                    this.ClientId = clientIdTask.ClientId;
                }
                else
                {
                    var error = await response.Content.ReadAsAsync<ErrorModel>();
                    throw new Exception(error.Description);
                }
            }

            public async Task<string> CreateInstance(string reportSource)
            {
                HttpContent content = new StringContent(reportSource, Encoding.UTF8, "application/json");

                string route = $"{this.BaseAddress}/clients/{this.ClientId}/instances";
                var response = await this.client.PostAsync(route, content);

                InstanceIdModel instanceId = null;
                if (response.IsSuccessStatusCode)
                {
                    instanceId = await response.Content.ReadAsAsync<InstanceIdModel>();
                }
                else
                {
                    var error = await response.Content.ReadAsAsync<ErrorModel>();
                    throw new Exception(error.Description);
                }

                return instanceId.InstanceId;
            }

            public async Task<string> CreateDocument(string instanceId, string format, string deviceInfo = null, string useCache = "true")
            {
                string contentBody = $"{{ \"useCache\": {useCache}, \"format\": \"{format}\" }}";
                HttpContent content = new StringContent(contentBody, Encoding.UTF8, "application/json");

                string route = $"{this.BaseAddress}/clients/{this.ClientId}/instances/{instanceId}/documents";
                var response = await this.client.PostAsync(route, content);

                DocumentIdModel documentId = null;
                if (response.IsSuccessStatusCode)
                {
                    documentId = await response.Content.ReadAsAsync<DocumentIdModel>();
                }
                else
                {
                    var error = await response.Content.ReadAsAsync<ErrorModel>();
                    throw new Exception(error.Description);
                }

                return documentId.DocumentId;
            }

            public async Task<bool> DocumentIsProcessing(string instanceId, string documentId)
            {
                string route = $"{this.BaseAddress}/clients/{this.ClientId}/instances/{instanceId}/documents/{documentId}/Info";

                var response = await this.client.GetAsync(route);

                DocumentInfoModel documentInfo = null;
                if (response.IsSuccessStatusCode)
                {
                    documentInfo = await response.Content.ReadAsAsync<DocumentInfoModel>();
                }
                else
                {
                    var error = await response.Content.ReadAsAsync<ErrorModel>();
                    throw new Exception(error.Description);
                }

                return !documentInfo.DocumentReady;
            }

            public async Task<byte[]> GetDocument(string instanceId, string documentId)
            {
                string route = $"{this.BaseAddress}/clients/{this.ClientId}/instances/{instanceId}/documents/{documentId}";

                var response = await this.client.GetAsync(route);
                byte[] documentBytes;

                if (response.IsSuccessStatusCode)
                {
                    documentBytes = await response.Content.ReadAsByteArrayAsync();
                }
                else
                {
                    var error = await response.Content.ReadAsAsync<ErrorModel>();
                    throw new Exception(error.Description);
                }

                return documentBytes;
            }

            private static void EnsureSuccessStatusCode(HttpResponseMessage response)
            {
                if (!response.IsSuccessStatusCode)
                {
                    throw
                        new Exception(
                            response.ReasonPhrase +
                            Environment.NewLine +
                            response.RequestMessage.RequestUri);
                }
            }
        }

    }
}
