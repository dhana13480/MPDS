﻿using Microsoft.AspNetCore.Mvc;
using MPDS.API.Models.DTO;
using MPDS.API.Repositories.Implementation;
using MPDS.API.Repositories.Interface;

namespace MPDS.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MasterServiceSettingController : ControllerBase
    {
        private readonly IMasterServiceSettingRepository masterServiceSettingRepository;

        public MasterServiceSettingController(IMasterServiceSettingRepository masterServiceSettingRepository)
        {
            this.masterServiceSettingRepository = masterServiceSettingRepository;
        }
        [HttpGet]
        public async Task<IActionResult> GetAllServiceSettings()
        {
            var serviceSettings = await masterServiceSettingRepository.GetAllSync();
            //convert Setting to dto
            var response = new List<MasterServiceSettingDto>();
            foreach (var serviceSetting in serviceSettings)
            {
                response.Add(new MasterServiceSettingDto
                {
                    Id = serviceSetting.id,
                    Code = serviceSetting.code,
                    ServiceSetting = serviceSetting.serviceSetting,
                    Description = serviceSetting.description
                });
            }
            return Ok(response);
        }
    }
}
