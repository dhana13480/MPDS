﻿using Microsoft.AspNetCore.Mvc;
using MPDS.API.Models.DTO;
using MPDS.API.Repositories.Implementation;
using MPDS.API.Repositories.Interface;

namespace MPDS.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MasterInterventionTypeController : ControllerBase
    {
        private readonly IMasterInterventionTypeRepository masterInterventionTypeRepository;

        public MasterInterventionTypeController(IMasterInterventionTypeRepository masterInterventionTypeRepository)
        {
            this.masterInterventionTypeRepository = masterInterventionTypeRepository;
        }
        [HttpGet]
        public async Task<IActionResult> GetAllInterventionTypes()
        {
            var InterventionTypes = await masterInterventionTypeRepository.GetAllSync();
            //convert Setting to dto
            var response = new List<MasterInterventionTypeDto>();
            foreach (var InterventionType in InterventionTypes)
            {
                response.Add(new MasterInterventionTypeDto
                {
                    Id = InterventionType.Id,                    
                    InterventionType = InterventionType.InterventionType,
                    Description = InterventionType.Description
                });
            }
            return Ok(response);
        }
    }
}
