﻿using Azure.Core;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MPDS.API.Data;
using MPDS.API.Models.Domain;
using MPDS.API.Models.DTO;
using MPDS.API.Repositories.Implementation;
using MPDS.API.Repositories.Interface;

namespace MPDS.API.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class MasterSchoolDistrictController : ControllerBase
    {
        private readonly IMasterSchoolDistrictRepository masterSchoolDistrictRepository;
        public MasterSchoolDistrictController(IMasterSchoolDistrictRepository masterSchoolDistrictRepository)
        {
            this.masterSchoolDistrictRepository = masterSchoolDistrictRepository;
        }
        //GET: {apibaseurl}/api/getStates
        //https://localhost:7164/api/getSchoolDisctricts
        [HttpGet]
        public async Task<IActionResult> GetAllSchoolDisctricts()
        {
            var schoolDistricts = await masterSchoolDistrictRepository.GetAllAsync();
            //convert domain to dto
            var response = new List<MasterSchoolDistrictDto>();
            foreach (var schoolDistrict in schoolDistricts)
            {
                response.Add(new MasterSchoolDistrictDto
                {
                    Id = schoolDistrict.Id,
                    SchoolDistrict = schoolDistrict.SchoolDistrict,
                    Description = schoolDistrict.Description,
                    IsActive = schoolDistrict.IsActive,
                    CountyId = schoolDistrict.CountyId
                });
            }
            return Ok(response);
        }
    }
}
