﻿using Azure.Core;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MPDS.API.Data;
using MPDS.API.Models.Domain;
using MPDS.API.Models.DTO;
using MPDS.API.Repositories.Implementation;
using MPDS.API.Repositories.Interface;

namespace MPDS.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MasterIntendedPopulationController : ControllerBase
    {
        private readonly IMasterIntendedPopulationRepository masterIntendedPopulationRepository;
        public MasterIntendedPopulationController(IMasterIntendedPopulationRepository masterIntendedPopulationRepository)
        {
            this.masterIntendedPopulationRepository = masterIntendedPopulationRepository;
        }
        //https://localhost:7164/api/Categories
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var categories = await masterIntendedPopulationRepository.GetAllSync();
            //convert domain to dto
            var response = new List<MasterIntendedPopulationDto>();
            foreach (var category in categories)
            {
                response.Add(new MasterIntendedPopulationDto
                {
                    id = category.id,
                    code = category.code,
                    intendedPopulation = category.intendedPopulation,
                    description= category.description
                });
            }
            return Ok(response);
        }


    }
}
