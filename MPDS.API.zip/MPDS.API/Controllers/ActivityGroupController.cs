﻿using Azure.Core;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using MPDS.API.Data;
using MPDS.API.Extensions;
using MPDS.API.Models.Domain;
using MPDS.API.Models.DTO;
using MPDS.API.Repositories.Implementation;
using MPDS.API.Repositories.Interface;
using MPDS.API.Utilities;
using System.Diagnostics;
using System.Xml.Linq;

namespace MPDS.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ActivityGroupController : ControllerBase
    {

        private readonly IActivityGroupRepository activityGroupRepository;
        public ActivityGroupController(IActivityGroupRepository activityGroupRepository)
        {
            this.activityGroupRepository = activityGroupRepository;
        }

        [HttpPost("AddGroup")]
        public async Task<IActionResult> CreateActivityGroup(ActivityGroup request)
        {
            if (request.Name == "")
                return BadRequest("Please enter Group Name");
           
            if (request.CoordinatingAgencyId <= 0)
                return BadRequest("Please select a Coordinating Agency");
            if (request.ProviderAgencyId <= 0)
              return BadRequest("Please select a Provider Agency");
            //check if the group name is already used
             
            var isThereADuplicateGroupExists = await activityGroupRepository.CheckForDuplicateGroup(request.Name,(long) request.CoordinatingAgencyId, (long)request.ProviderAgencyId);

            if (isThereADuplicateGroupExists != null)
                return BadRequest("Group Name: " + request.Name + " already exists, please choose a different name");

            if (request.ProgramNameId <= 0)
                return BadRequest("Please select a Program Name");
            if (request.GroupType <= 0)
                return BadRequest("Please select a Group Type");
            if (request.ProgramType <= 0)
                return BadRequest("Please select a Program Type");
            if (request.MinActivityCount <=0)
                return BadRequest("Please enter Min Activity Count");
            if (request.MaxActivityCount <= 0)
                return BadRequest("Please enter Max Activity Count");
            if (request.InterventionType <=0)
                return BadRequest("Please select Intervention Type");
            //if (request.ServicePopulation <= 0)
            //    return BadRequest("Please select Service Population");
            //if (request.ServiceDomain <= 0)
            //    return BadRequest("Please select Service Domain");
            //if (request.FundingSource <= 0)
            //    return BadRequest("Please select Funding Source");
            //if (request.EBPServiceType <= 0)
                //return BadRequest("Please select EBP Service type");
             

            //Map DTO to Domain model
            var activityGroup = new ActivityGroup
            {
                Name = request.Name,
                CoordinatingAgencyId = request.CoordinatingAgencyId,
                ProviderAgencyId = request.ProviderAgencyId,
                IsYATRelated = request.IsYATRelated,
                IsGamblingRelated = request.IsGamblingRelated,
                MinActivityCount = request.MinActivityCount,
                MaxActivityCount = request.MaxActivityCount,
                GroupType = request.GroupType,
                ProgramType = request.ProgramType,
                InterventionType = request.InterventionType,
                ServiceDomain = request.ServiceDomain,
                EBPServiceType = request.EBPServiceType,
                Comments = request.Comments,
                IsActive = true,
                IsDeleted=false,
                //ServiceSettingId = request.ServiceSettingId,

                ProgramNameId = request.ProgramNameId,
                OtherProgramName = request.OtherProgramName,
                //CreationDate = DateTime.Now,
                //UpdationDate = DateTime.Now,
                CreatedBy = request.CreatedBy,
                UpdatedBy = request.UpdatedBy
            };

            await activityGroupRepository.CreateAsync(activityGroup);
            //Domain model to DTO
            var response = new ActivityGroupDto
            {
                Id = activityGroup.Id,
                Name = activityGroup.Name,
                CoordinatingAgencyId = activityGroup.CoordinatingAgencyId,
                ProviderAgencyId = activityGroup.ProviderAgencyId,
                IsYATRelated = activityGroup.IsYATRelated,
                IsGamblingRelated = activityGroup.IsGamblingRelated,
                MinActivityCount = activityGroup.MinActivityCount,
                MaxActivityCount = activityGroup.MaxActivityCount,
                GroupType = activityGroup.GroupType,
                ProgramType = activityGroup.ProgramType,
                InterventionType = activityGroup.InterventionType,
                ServiceDomain = activityGroup.ServiceDomain,
                EBPServiceType = activityGroup.EBPServiceType,
                Comments = activityGroup.Comments,
                IsActive = activityGroup.IsActive,
                //ServiceSettingId = request.ServiceSettingId,               
                ProgramNameId = activityGroup.ProgramNameId,
                OtherProgramName = activityGroup.OtherProgramName,
                //CreationDate = DateTime.Now,
                //UpdationDate = DateTime.Now,
                CreatedBy = activityGroup.CreatedBy,
                UpdatedBy = activityGroup.UpdatedBy,
            };
            return Ok(response.Id);
        }
        //https://localhost:7164/api/getActivityGroups

        [HttpPost("GetAllGroups")]
        //Gets top 100 groups
        public async Task<IActionResult> GetAllActivityGroups(GroupsSearchInput inputparam)
        {

            var activityGroups = await activityGroupRepository.GetAllAsync(inputparam);
            //convert domain to dto
            var response = new List<ActivityGroup>();
            foreach (var activityGroup in activityGroups)
            {
                response.Add(new ActivityGroup
                {
                    Id = activityGroup.Id,
                    Name = activityGroup.Name,
                    IsActive = activityGroup.IsActive,
                    strGroupType = activityGroup.strGroupType,
                    strProgramType = activityGroup.strProgramType,
                    ProviderAgencyStatus = activityGroup.ProviderAgencyStatus,
                    CoordinatingAgencyStatus = activityGroup.CoordinatingAgencyStatus,
                    ActivityCount = activityGroup.ActivityCount,
                    ProgramName = activityGroup.ProgramName,
                    Row_Numb = null,
                    CoordinatingAgencyId = activityGroup.CoordinatingAgencyId,
                    ProviderAgencyId = activityGroup.ProviderAgencyId,
                    ProgramNameId = activityGroup.ProgramNameId,
                    Comments = activityGroup.Comments,
                    CreatedBy = activityGroup.CreatedBy,
                    UpdatedBy = activityGroup.UpdatedBy,
                    EBPServiceType = activityGroup.EBPServiceType,
                    GroupOptionalDataId = activityGroup.GroupOptionalDataId,
                    GroupType = activityGroup.GroupType,
                    ProgramType = activityGroup.ProgramType,
                    InterventionType = activityGroup.InterventionType,
                    IsDeleted = activityGroup.IsDeleted,
                    IsGamblingRelated = activityGroup.IsGamblingRelated,
                    IsYATRelated = activityGroup.IsYATRelated,
                    MinActivityCount = activityGroup.MinActivityCount,
                    MaxActivityCount = activityGroup.MaxActivityCount,
                    OtherProgramName = activityGroup.OtherProgramName,
                    ServiceDomain = activityGroup.ServiceDomain,
                    ServiceLocation = activityGroup.ServiceLocation

                });
            }
            return Ok(response);
        }
        [HttpPost("GetAllGroupsPaginated")]
        //Gets top 100 groups
        public async Task<IActionResult> GetAllActivityGroupsPaginated([FromQuery] UserParams userParams, GroupsSearchInput inputparam)
        {
            var activityGroups = await activityGroupRepository.GetAllAsyncPaginated(inputparam, userParams);
            //convert domain to dto
            var response = new List<ActivityGroup>();
            foreach (var activityGroup in activityGroups)
            {
                activityGroup.strGroupType = (activityGroup.GroupType == 1 ? "One-Time" : activityGroup.GroupType == 2 ? "Ongoing-Sequential" : "Ongoing-Other");
                activityGroup.strProgramType = (activityGroup.ProgramType == 1 ? "Population" : "Individual");                
            }
            Response.AddPaginationHeader(new PaginationHeader(activityGroups.CurrentPage, activityGroups.PageSize,
               activityGroups.TotalCount, activityGroups.TotalPages));
            return Ok(activityGroups);
        }
        [HttpGet]
        [Route("coordinatingagency/{id:long}")]
        //Gets top 100 groups by Coordinating Agency Id
        public async Task<IActionResult> GetAllGroupsByCoodinatingAgency([FromRoute] long id)
        {
            var activityGroups = await activityGroupRepository.GetbyCoordinatingAgency(id);
            //convert domain to dto
            var response = new List<ActivityGroupSPOutDto>();
            foreach (var activityGroup in activityGroups)
            {
                response.Add(new ActivityGroupSPOutDto
                {
                    Id = activityGroup.Id,
                    Name = activityGroup.Name,
                    IsActive = activityGroup.IsActive,
                    GroupType = activityGroup.strGroupType,
                    ProgramType = activityGroup.strProgramType,
                    ProviderAgencyStatus = activityGroup.ProviderAgencyStatus,
                    CoordinatingAgencyStatus = activityGroup.CoordinatingAgencyStatus,
                    ActivityCount = activityGroup.ActivityCount,
                    ProgramName = activityGroup.ProgramName,
                    Row_Numb = activityGroup.Row_Numb,
                    CoordinatingAgencyId = activityGroup.CoordinatingAgencyId,
                    ProviderAgencyId = activityGroup.ProviderAgencyId,
                    ProgramNameId = activityGroup.ProgramNameId
                });
            }
            return Ok(response);
        }

        [HttpGet]
        [Route("CoordinatingAgencyProgramName/coordinatingAgency/{id:long}")]
        public async Task<IActionResult> GetProgramNameByCoordinatingAgencyId([FromRoute] long id)
        {
            var programNames = await activityGroupRepository.GetProgramNameByCoordinatingAgencyId(id);
            if (programNames is null)
            {
                return NotFound();
            }
            var response = new List<ProgramNameByCoordinatingAgency>();
            foreach (var programName in programNames)
            {
                response.Add(new ProgramNameByCoordinatingAgency
                {
                    id = programName.Id,
                    coordinatingAgencyId = id,
                    programNameId = programName.Id,
                    programName = programName.Name                    
                });
            }
            return Ok(response);
        }

        [HttpGet]
         
        [Route("ProgramNameByGroupId/{GroupId:long}")]
        public async Task<IActionResult> GetProgramNameByGroupId([FromRoute] long GroupId)
        {
            var programNames = await activityGroupRepository.GetProgramNameByGroupId(GroupId);
            if (programNames is null)
            {
                return NotFound();
            }
            var response = new List<ProgramName>();
            foreach (var programName in programNames)
            {
                response.Add(new ProgramName
                {
                    Id = programName.Id,
                    Name = programName.Name,
                });
                   
            }
            return Ok(response);
        }

            [HttpGet]
        [Route("{id:long}")]
        //Gets top 100 groups by Coordinating Agency Id
        public async Task<IActionResult> GetById([FromRoute] long id)
        {
            var existingGroup = await activityGroupRepository.GetByActivityGroupId(id);
            string strProgramName =string.Empty;
            if (existingGroup is null)
            {
                return NotFound();
            }
            var programNames = await activityGroupRepository.GetProgramNameByGroupId(id);
            if (programNames is not null)
            {
                var pResponse = new List<ProgramName>();
                foreach (var programName in programNames)
                {
                    strProgramName = programName.Name.ToString();
                }
                
            }
            var response = new ActivityGroupDto
            {
                Id = existingGroup.Id,
                Name = existingGroup.Name,
                IsActive = existingGroup.IsActive,
                GroupType = existingGroup.GroupType,
                ProgramType = existingGroup.ProgramType,
                strGroupType = existingGroup.strGroupType,
                strProgramType = existingGroup.strProgramType,
                ProviderAgencyStatus = existingGroup.ProviderAgencyStatus,
                CoordinatingAgencyStatus = existingGroup.CoordinatingAgencyStatus,
                ActivityCount = existingGroup.ActivityCount,
                ProgramName = strProgramName,
                Row_Numb = null,
                CoordinatingAgencyId = existingGroup.CoordinatingAgencyId,
                ProviderAgencyId = existingGroup.ProviderAgencyId,
                ProgramNameId = existingGroup.ProgramNameId,
                IsYATRelated = existingGroup.IsYATRelated,
                IsGamblingRelated = existingGroup.IsGamblingRelated,
                MinActivityCount = existingGroup.MinActivityCount,
                MaxActivityCount = existingGroup.MaxActivityCount,
                InterventionType = existingGroup.InterventionType,
                ServiceDomain = existingGroup.ServiceDomain,
                ServiceLocation = existingGroup.ServiceLocation,
                EBPServiceType = existingGroup.EBPServiceType,
                Comments = existingGroup.Comments,
                GroupOptionalDataId = existingGroup.GroupOptionalDataId,
                IsDeleted = existingGroup.IsDeleted,
                CreatedBy = existingGroup.CreatedBy,
                UpdatedBy   = existingGroup.UpdatedBy,
                OtherProgramName = existingGroup.OtherProgramName,
                
            };
            return Ok(response);
        }
        [HttpGet]
        [Route("coordinatingagency/{cid:long}/provideragency/{pid:long}")]
        //Gets top 100 groups by Coordinating Agency Id
        public async Task<IActionResult> GetAllGroupsByProviderAgency([FromRoute] long cid, long pid)
        {
            var activityGroups = await activityGroupRepository.GetbyProviderAgency(cid, pid);
            //convert domain to dto
            var response = new List<ActivityGroupSPOutDto>();
            foreach (var activityGroup in activityGroups)
            {
                response.Add(new ActivityGroupSPOutDto
                {
                    Id = activityGroup.Id,
                    Name = activityGroup.Name,
                    IsActive = activityGroup.IsActive,
                    GroupType = activityGroup.strGroupType,
                    ProgramType = activityGroup.strProgramType,
                    ProviderAgencyStatus = activityGroup.ProviderAgencyStatus,
                    CoordinatingAgencyStatus = activityGroup.CoordinatingAgencyStatus,
                    ActivityCount = activityGroup.ActivityCount,
                    ProgramName = activityGroup.ProgramName,
                    Row_Numb = activityGroup.Row_Numb,
                    CoordinatingAgencyId = activityGroup.CoordinatingAgencyId,
                    ProviderAgencyId = activityGroup.ProviderAgencyId,
                    ProgramNameId = activityGroup.ProgramNameId
                });
            }
            return Ok(response);
        }
        [HttpGet]
        [Route("provideragencyid/{pid:long}")]
        //Gets top 100 groups by Coordinating Agency Id
        public async Task<IActionResult> GetAllGroupsByProviderAgencyId([FromRoute] long pid)
        {
            var activityGroups = await activityGroupRepository.GetbyProviderAgencyId(pid);
            //convert domain to dto
            var response = new List<ActivityGroupSPOutDto>();
            foreach (var activityGroup in activityGroups)
            {
                response.Add(new ActivityGroupSPOutDto
                {
                    Id = activityGroup.Id,
                    Name = activityGroup.Name,
                    IsActive = activityGroup.IsActive,
                    GroupType = activityGroup.strGroupType,
                    ProgramType = activityGroup.strProgramType,
                    ProviderAgencyStatus = activityGroup.ProviderAgencyStatus,
                    CoordinatingAgencyStatus = activityGroup.CoordinatingAgencyStatus,
                    ActivityCount = activityGroup.ActivityCount,
                    ProgramName = activityGroup.ProgramName,
                    Row_Numb = activityGroup.Row_Numb,
                    CoordinatingAgencyId = activityGroup.CoordinatingAgencyId,
                    ProviderAgencyId = activityGroup.ProviderAgencyId,
                    ProgramNameId = activityGroup.ProgramNameId
                });
            }
            return Ok(response);
        }
        //[HttpGet]
        //[Route("{id:long}")]
        ////Gets top 100 groups by Activity Group Id
        //public async Task<IActionResult> GetAllGroupsByGroupId([FromRoute] long id)
        //{
        //    var existingGroup = await activityGroupRepository.GetByActivityGroupId(id);
        //    if (existingGroup is null)
        //    {
        //        return NotFound();
        //    }

        //    //convert domain to dto
        //    var response = new ActivityGroupDto                 
        //        {
        //            Id = existingGroup.Id,
        //            Name = existingGroup.Name,
        //            IsActive = existingGroup.IsActive,
        //            GroupType = existingGroup.GroupType,
        //            ProgramType = existingGroup.ProgramType,
        //            ProviderAgencyStatus = existingGroup.ProviderAgencyStatus,
        //            CoordinatingAgencyStatus = existingGroup.CoordinatingAgencyStatus,
        //            ActivityCount = existingGroup.ActivityCount,
        //            ProgramName = existingGroup.ProgramName,
        //            Row_Numb = existingGroup.Row_Numb,
        //            CoordinatingAgencyId = existingGroup.CoordinatingAgencyId,
        //            ProviderAgencyId = existingGroup.ProviderAgencyId,
        //            ProgramNameId = existingGroup.ProgramNameId
        //        };

        //    return Ok(response);
        //}

        //[HttpGet("provideragency/{Id}")]
        ////[Route("provideragency/{ids:string}")]
        ////Gets top 100 groups by Provider  Agency Id
        //public async Task<IActionResult> GetAllGroupsByProviderAgency([FromRoute] long Id)
        //{
        //    var activityGroups = await activityGroupRepository.GetbyProviderAgency(Id);
        //    //convert domain to dto
        //    var response = new List<ActivityGroupSPOutDto>();
        //    foreach (var activityGroup in activityGroups)
        //    {
        //        response.Add(new ActivityGroupSPOutDto
        //        {
        //            Id = activityGroup.Id,
        //            Name = activityGroup.Name,
        //            IsActive = activityGroup.IsActive,
        //            GroupType = activityGroup.strGroupType,
        //            ProgramType = activityGroup.strProgramType,
        //            ProviderAgencyStatus = activityGroup.ProviderAgencyStatus,
        //            CoordinatingAgencyStatus = activityGroup.CoordinatingAgencyStatus,
        //            ActivityCount = activityGroup.ActivityCount,
        //            ProgramName = activityGroup.ProgramName,
        //            Row_Numb = activityGroup.Row_Numb,
        //            CoordinatingAgencyId = activityGroup.CoordinatingAgencyId,
        //            ProviderAgencyId = activityGroup.ProviderAgencyId,
        //            ProgramNameId = activityGroup.ProgramNameId
        //        });
        //    }
        //    return Ok(response);
        //}
        [HttpGet]
        [Route("groupname/{name}")]         
        public async Task<IActionResult> GetAllActivityGroups([FromRoute] string name)
        {
            var activityGroups = await activityGroupRepository.GetbyGroupName(name);
            //convert domain to dto
            var response = new List<ActivityGroupSPOutDto>();
            foreach (var activityGroup in activityGroups)
            {
                response.Add(new ActivityGroupSPOutDto
                {
                    Id = activityGroup.Id,
                    Name = activityGroup.Name,
                    IsActive = activityGroup.IsActive,
                    GroupType = activityGroup.strGroupType,
                    ProgramType = activityGroup.strProgramType,
                    ProviderAgencyStatus = activityGroup.ProviderAgencyStatus,
                    CoordinatingAgencyStatus = activityGroup.CoordinatingAgencyStatus,
                    ActivityCount = activityGroup.ActivityCount,
                    ProgramName = activityGroup.ProgramName,
                    Row_Numb = activityGroup.Row_Numb,
                    CoordinatingAgencyId = activityGroup.CoordinatingAgencyId,
                    ProviderAgencyId = activityGroup.ProviderAgencyId,
                    ProgramNameId = activityGroup.ProgramNameId
                });
            }
            return Ok(response);
        }
        [HttpPost]
        [Route("DeleteGroupAndActivity/{id:long}")]
        public async Task<IActionResult> DeleteGroupAndActivity(long id)
        {
            var response = await activityGroupRepository.DeleteGroupAndActivity(id);
            if (response == null) return NotFound();

            return Ok(response);
        }

        [HttpPut]
        [Route("{id:int}")]
        public async Task<IActionResult> EditActivityGroup([FromRoute] int id, ActivityGroupDto request)
        {
            if (request.Name == "")
                return BadRequest("Please enter Group Name");
            if (request.CoordinatingAgencyId <= 0)
                return BadRequest("Please select a Coordinating Agency");
            if (request.ProviderAgencyId <= 0)
                return BadRequest("Please select a Provider Agency");
            if (request.ProgramNameId <= 0)
                return BadRequest("Please select a Program Name");
            if (request.GroupType <= 0)
                return BadRequest("Please select a Group Type");
            if (request.ProgramType <= 0)
                return BadRequest("Please select a Program Type");
            if (request.MinActivityCount <= 0)
                return BadRequest("Please enter Min Activity Count");
            if (request.MaxActivityCount <= 0)
                return BadRequest("Please enter Max Activity Count");
            if (request.InterventionType <= 0)
                return BadRequest("Please select Intervention Type");
            //if (request.ServicePopulation <= 0)
            //    return BadRequest("Please select Service Population");
            //if (request.ServiceDomain <= 0)
            //    return BadRequest("Please select Service Domain");
            if (request.FundingSource <= 0)
                return BadRequest("Please select Funding Source");
            if (request.EBPServiceType <= 0)
                return BadRequest("Please select EBP Service type");

            UserRoles userRoles = new UserRoles();
            userRoles.userTypeId = request.userTypeId;
            //userRoles.userCoordinatingAgencyId = request.userCoordinatingAgencyId;
            //userRoles.userProviderAgencyId = request.userProviderAgencyId;
            userRoles.permissions = request.permissions;
                         
            DateTime dtUpdationDate = DateTime.Now;
             
            try
            {               
                if (request.UpdationDate != null)
                    dtUpdationDate = DateTime.Parse(request.UpdationDate, Thread.CurrentThread.CurrentCulture);             
            }
            catch (Exception ex)
            {
                //throw;
            }


            //convert DTO to Domain model
            var activityGroup = new ActivityGroup()
            {
                Id = id,
                //uKeyOldCA = request.uKeyOldCA,
                //uKeyOldORG = request.uKeyOldORG,
                Name = request.Name,
                CoordinatingAgencyId = request.CoordinatingAgencyId,
                ProviderAgencyId = request.ProviderAgencyId,
                ProgramNameId = request.ProgramNameId,
                OtherProgramName = request.OtherProgramName,
                IsYATRelated = request.IsYATRelated,
                IsGamblingRelated = request.IsGamblingRelated,
                GroupType = request.GroupType > 0 ? request.GroupType : null,
                ProgramType = request.ProgramType > 0 ? request.ProgramType : null,
                MinActivityCount = request.MinActivityCount,
                MaxActivityCount = request.MaxActivityCount,
                InterventionType = request.InterventionType > 0 ? request.InterventionType : null,
                ServiceDomain = request.ServiceDomain > 0 ? request.ServiceDomain : null,
                EBPServiceType = request.EBPServiceType > 0 ? request.EBPServiceType : null,
                Comments = request.Comments,
                CreatedBy = request.CreatedBy, //add here updated by                  
                UpdatedBy = request.UpdatedBy,
                UpdationDate = dtUpdationDate

            };
            //if user has Manage Group permissions
            //if ((userRoles.userTypeId == 2) || (userRoles.userTypeId == 3) || (userRoles.userTypeId == 4))
                activityGroup = await activityGroupRepository.UpdateAsync(activityGroup);
            if (activityGroup == null)
                return NotFound();

            var response = new ActivityGroupDto
            {
                Id = activityGroup.Id,
                Name = activityGroup.Name,
                CoordinatingAgencyId = activityGroup.CoordinatingAgencyId,
                ProgramNameId = activityGroup.ProgramNameId,
                OtherProgramName = activityGroup.OtherProgramName,
                IsYATRelated = activityGroup.IsYATRelated,
                IsGamblingRelated = activityGroup.IsGamblingRelated,
                GroupType = activityGroup.GroupType,
                ProgramType = activityGroup.ProgramType,
                MinActivityCount = activityGroup.MinActivityCount,
                MaxActivityCount = activityGroup.MaxActivityCount,
                InterventionType = activityGroup.InterventionType,
                ServiceDomain = activityGroup.ServiceDomain,
                EBPServiceType = activityGroup.EBPServiceType,
                Comments = activityGroup.Comments,
                CreatedBy = activityGroup.CreatedBy, //add here updated by
                UpdatedBy = activityGroup.UpdatedBy,

            };
            return Ok(response);
        }
    }
}
