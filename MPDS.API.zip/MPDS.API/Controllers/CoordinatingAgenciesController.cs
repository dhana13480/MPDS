﻿using Azure;
using Azure.Core;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MPDS.API.Data;
using MPDS.API.Models.Domain;
using MPDS.API.Models.DTO;
using MPDS.API.Repositories.Implementation;
using MPDS.API.Repositories.Interface;
using MPDS.API.Utilities;
using static MPDS.API.Models.Domain.Enums;

namespace MPDS.API.Controllers
{
    //https://localhost:xxxx/api/coordinatingagencies
    [Route("api/[controller]")]
    [ApiController]
    public class CoordinatingAgenciesController : ControllerBase
    {
        private readonly ICoordinatingAgencyRepository coordinatingAgencyRepository;
        private readonly IDatabaseLoggerService _logger;
        public CoordinatingAgenciesController(ICoordinatingAgencyRepository coordinatingAgencyRepository, IDatabaseLoggerService logger)
        {
            this.coordinatingAgencyRepository = coordinatingAgencyRepository;
            this._logger = logger;
        }
        //GET: {apibaseurl}/api/getCoordinatingAgencies
        //https://localhost:7164/api/CoordinatingAgencies
        [HttpGet]
        [Route("GetAllCoordinatingAgencies")]
        public async Task<IActionResult> GetAllCoordinatingAgencies([FromQuery] UserRoles userRoles)
        {
            //todo
            //int userTypeId = 2;
            //int coordinatingAgencyId = 0;
            //int providerAgencyId = 0;
            //string permissions="";
            ////////////
            ///
            if (userRoles.userTypeId == 3)
            {
                if (userRoles.coordinatingAgencyId <= 0)
                    return BadRequest("User of type Coodinating Agency is not assigned to any Coordinating Agency");
            }
            if (userRoles.userTypeId == 4)
            {
                if (userRoles.providerAgencyId <= 0)
                    return BadRequest("User of type Provider Agency is not assigned to any Provider Agency");
            }
            var coordinatingAgencies = await coordinatingAgencyRepository.GetAllAsync(userRoles);
            if (coordinatingAgencies==null)
                return NotFound();
            //convert domain to dto
            var response = new List<CoordinatingAgencyDto>();
            foreach (var coordinatingAgency in coordinatingAgencies)
            {
                response.Add(new CoordinatingAgencyDto
                {
                    Id = coordinatingAgency.Id,
                    Name = coordinatingAgency.Name,
                    IsActive = coordinatingAgency.IsActive,
                    OfficePhone = coordinatingAgency.OfficePhone,
                    Fax = coordinatingAgency.Fax,
                    Address1 = coordinatingAgency.Address1,
                    Address2 = coordinatingAgency.Address2,
                    City = coordinatingAgency.City,
                    State = coordinatingAgency.State,
                    Zip = coordinatingAgency.Zip,
                    Comments = coordinatingAgency.Comments,
                    AddressComments = coordinatingAgency.AddressComments,
                    Pc_FirstName = coordinatingAgency.Pc_FirstName,
                    Pc_MiddleName = coordinatingAgency.Pc_MiddleName,
                    Pc_LastName = coordinatingAgency.Pc_LastName,
                    Pc_Email = coordinatingAgency.Pc_Email,
                    Pc_OfficePhone = coordinatingAgency.Pc_OfficePhone,
                    Pc_CellPhone = coordinatingAgency.Pc_CellPhone,
                    Pc_Comments = coordinatingAgency.Pc_Comments,
                    CreatedBy = coordinatingAgency.CreatedBy,
                    //CreationDate = coordinatingAgency.CreationDate,
                    UpdatedBy = coordinatingAgency.UpdatedBy,
                    OptionalData = coordinatingAgency.OptionalData ?? "",
                    Counties = coordinatingAgency.Counties ?? "",
                    SchoolDistricts = coordinatingAgency.SchoolDistricts ?? "",
                    ProgramNames = coordinatingAgency.ProgramNames ?? ""
                    //UpdationDate = coordinatingAgency.UpdationDate

                });
            }
            return Ok(response);
        }

        //Delete method https://localhost:7164/api/CoordinatingAgencies/DeactivateCoordinatingAgency/3
        [HttpDelete]
        [Route("DeactivateCoordinatingAgency/{id:int}")]        
        public async Task<IActionResult> DeleteCoordinatingAgency([FromRoute] int id)
        {
            // var coordinatingAgency = await coordinatingAgencyRepository.DeleteAsync(id);
            var coordinatingAgency = await coordinatingAgencyRepository.DeActivatePIHPRegion(Convert.ToInt32(id));
            if (coordinatingAgency == null) return NotFound();
            var response = new CoordinatingAgencyDto
            {
                Id = coordinatingAgency.Id,
                Name = coordinatingAgency.Name,


            };
            return Ok(response);
        }
        //deactivate
        [HttpPost]
        [Route("DeActivateCoordinatingAgency/{id:int}")]
        public async Task<IActionResult> DeActivateCoordinatingAgenc(int id)
        {
            var response = await coordinatingAgencyRepository.DeActivatePIHPRegion(Convert.ToInt32(id));
            if (response == null) return NotFound();
            
            return Ok(response);
        }

        [HttpPut]
        [Route("deactivate/{id:int}")]
        public async Task<IActionResult> DeActivateCoordinatingAgency([FromRoute] int id)
        {
            var coordinatingAgency = await coordinatingAgencyRepository.DeActivatePIHPRegion(Convert.ToInt32(id));
            if (coordinatingAgency == null) return NotFound();
           
            return Ok(coordinatingAgency);
        }

        //put method //https://localhost:7164/api/CoordinatingAgency/{id}
        [HttpPut]
        [Route("{id:int}")]
        public async Task<IActionResult> EditCoordinatingAgency([FromRoute] int id, CoordinatingAgencyUpdateRequestDto request)
        {
            try
            {


                if (request.Name == "")
                    return BadRequest("Please enter PIHP Name");
                if (request.Address1 == "")
                    return BadRequest("Please enter Address");
                if (request.City == "")
                    return BadRequest("Please enter City");
                if (request.State <= 0)
                    return BadRequest("Please enter State");
                if (request.Zip == "")
                    return BadRequest("Please enter Zip");
                if (request.Pc_FirstName == "")
                    return BadRequest("Please enter First Name");
                if (request.Pc_LastName == "")
                    return BadRequest("Please enter Last Name");
                if (request.Pc_Email == "")
                    return BadRequest("Please enter Email");
                try
                {
                    var addr = new System.Net.Mail.MailAddress(request.Pc_Email);
                }
                catch
                {
                    return BadRequest("Please enter valid Email");
                }

                if (request.Pc_OfficePhone == "")
                    return BadRequest("Please enter Phone");

                //convert DTO to Domain model
                var coordinatingAgency = new CoordinatingAgency()
                {
                    Id = id,
                    //uKeyOldCA = request.uKeyOldCA,
                    //uKeyOldORG = request.uKeyOldORG,
                    Name = request.Name,
                    IsActive = request.IsActive,
                    OfficePhone = request.OfficePhone,
                    Fax = request.Fax,
                    Address1 = request.Address1,
                    Address2 = request.Address2,
                    City = request.City,
                    State = request.State,
                    Zip = request.Zip,
                    Comments = request.Comments,
                    AddressComments = request.AddressComments,
                    Pc_FirstName = request.Pc_FirstName,
                    Pc_MiddleName = request.Pc_MiddleName,
                    Pc_LastName = request.Pc_LastName,
                    Pc_Email = request.Pc_Email,
                    Pc_OfficePhone = request.Pc_OfficePhone,
                    Pc_CellPhone = request.Pc_CellPhone,
                    Pc_Comments = request.Pc_Comments,
                    CreatedBy = request.CreatedBy,
                    CreationDate = DateTime.Now,
                    UpdatedBy = request.UpdatedBy,
                    UpdationDate = DateTime.Now,
                    Counties = request.Counties,
                    SchoolDistricts = request.SchoolDistricts,
                    ProgramNames = request.ProgramNames

                };
                coordinatingAgency = await coordinatingAgencyRepository.UpdateAsync(coordinatingAgency);
                if (coordinatingAgency == null)
                    return NotFound();

                var response = new CoordinatingAgencyDto
                {
                    Id = coordinatingAgency.Id,
                    Name = coordinatingAgency.Name,
                    IsActive = coordinatingAgency.IsActive,
                    OfficePhone = coordinatingAgency.OfficePhone,
                    Fax = coordinatingAgency.Fax,
                    Address1 = coordinatingAgency.Address1,
                    Address2 = coordinatingAgency.Address2,
                    City = coordinatingAgency.City,
                    State = coordinatingAgency.State,
                    Zip = coordinatingAgency.Zip,
                    Comments = coordinatingAgency.Comments,
                    AddressComments = coordinatingAgency.AddressComments,
                    Pc_FirstName = coordinatingAgency.Pc_FirstName,
                    Pc_MiddleName = coordinatingAgency.Pc_MiddleName,
                    Pc_LastName = coordinatingAgency.Pc_LastName,
                    Pc_Email = coordinatingAgency.Pc_Email,
                    Pc_OfficePhone = coordinatingAgency.Pc_OfficePhone,
                    Pc_CellPhone = coordinatingAgency.Pc_CellPhone,
                    Pc_Comments = coordinatingAgency.Pc_Comments,
                    CreatedBy = coordinatingAgency.CreatedBy,
                    //CreationDate = coordinatingAgency.CreationDate,
                    UpdatedBy = coordinatingAgency.UpdatedBy,
                    //UpdationDate = coordinatingAgency.UpdationDate
                    Counties = coordinatingAgency.Counties,
                    SchoolDistricts = coordinatingAgency.SchoolDistricts,
                    ProgramNames = coordinatingAgency.ProgramNames
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                _logger.LogException(ex, "MPDSUser");
                return BadRequest("Internal Server Error while Editing the Coordinating Agency Id");
            }

           
        }
        [HttpPost]
        [Route("UpdateProgramNamesForCoordinatingAgencyId")]
        public async Task<IActionResult> UpdateProgramNamesForCoordinatingAgency(CoordinatingAgencyProgramNamesRequest request)
        {
            var response = await coordinatingAgencyRepository.UpdateProgramNamesForCoordinatingAgency(request);
            return Ok(response);
        }
        [HttpPost]
        [Route("UpdateCountiesForCoordinatingAgencyId")]
        public async Task<IActionResult> UpdateCountiesForCoordinatingAgency(CoordinatingAgencyCountyRequest request)
        {
            var response = await coordinatingAgencyRepository.UpdateCountyListForCoordinatingAgencyId(request);
            return Ok(response);
        }
        [HttpPost]
        [Route("UpdateSchoolDistrictsForCoordinatingAgencyId")]
        public async Task<IActionResult> UpdateSchoolDistrictsForCoordinatingAgency(CoordinatingAgencySchoolDistrictRequest request)
        {
            var response = await coordinatingAgencyRepository.UpdateSchoolDistrictListForCoordinatingAgencyId(request);
            return Ok(response);
        }
        [HttpPost]
        [Route("UpdateOptionalDataForCoordinatingAgencyId")]
        public async Task<IActionResult> UpdateOptionalDataForCoordinatingAgency(CoordinatingAgencyOptionalDataRequest request)
        {
            var response = await coordinatingAgencyRepository.UpdateOptionalDataForCoordinatingAgency(request);
            return Ok(response);
        }
        //https://localhost:xxxx/api/CoordinatingAgency
        [HttpPost]
        public async Task<IActionResult> CreateCoordinatingAgency(CoordinatingAgencyCreateRequestDto request)
        {
            if (request.Name == "")
                return BadRequest("Please enter PIHP Name");
            if (request.Address1 == "")
                return BadRequest("Please enter Address");
            if (request.City == "")
                return BadRequest("Please enter City");
            if (request.State <= 0)
                return BadRequest("Please enter State");
            if (request.Zip == "")
                return BadRequest("Please enter Zip");
            if (request.Pc_FirstName == "")
                return BadRequest("Please enter First Name");
            if (request.Pc_LastName == "")
                return BadRequest("Please enter Last Name");
            if (request.Pc_Email == "")
                return BadRequest("Please enter Email");
            try
            {
                var addr = new System.Net.Mail.MailAddress(request.Pc_Email);
            }
            catch
            {
                return BadRequest("Please enter valid Email");
            }
            if (request.Pc_OfficePhone == "")
                return BadRequest("Please enter Phone");
            //Map DTO to Domain model
            var coordinatingAgency = new CoordinatingAgency
            {
                Name = request.Name,
                IsActive = request.IsActive,
                OfficePhone = request.OfficePhone,
                Fax = request.Fax,
                Address1 = request.Address1,
                Address2 = request.Address2,
                City = request.City,
                State = 30,
                Zip = request.Zip,
                Comments = request.Comments,
                AddressComments = request.AddressComments,
                Pc_FirstName = request.Pc_FirstName,
                Pc_MiddleName = request.Pc_MiddleName,
                Pc_LastName = request.Pc_LastName,
                Pc_Email = request.Pc_Email,
                Pc_OfficePhone = request.Pc_OfficePhone,
                Pc_CellPhone = request.Pc_CellPhone,
                Pc_Comments = request.Pc_Comments,
                CreatedBy = 1,//Use logged in user name 
                CreationDate = DateTime.Now,
                UpdatedBy = 1,//Use logged in user name 
                UpdationDate = DateTime.Now,
                OptionalData = request.OptionalData,
                Counties = request.Counties,
                SchoolDistricts = request.SchoolDistricts,
                ProgramNames = request.ProgramNames
            };

            await coordinatingAgencyRepository.CreateAsync(coordinatingAgency);
            //Domain model to DTO
            var response = new CoordinatingAgencyCreateRequestDto
            {

                Name = request.Name,
                IsActive = request.IsActive,
                OfficePhone = request.OfficePhone,
                Fax = request.Fax,
                Address1 = request.Address1,
                Address2 = request.Address2,
                City = request.City,
                State = 30,
                Zip = request.Zip,
                Comments = request.Comments,
                AddressComments = request.AddressComments,
                Pc_FirstName = request.Pc_FirstName,
                Pc_MiddleName = request.Pc_MiddleName,
                Pc_LastName = request.Pc_LastName,
                Pc_Email = request.Pc_Email,
                Pc_OfficePhone = request.Pc_OfficePhone,
                Pc_CellPhone = request.Pc_CellPhone,
                Pc_Comments = request.Pc_Comments,
                CreatedBy = 1,//Use logged in user name 
                CreationDate = DateTime.Now,
                UpdatedBy = 1,//Use logged in user name 
                UpdationDate = DateTime.Now,
                OptionalData = request.OptionalData,
                Counties = request.Counties,
                SchoolDistricts = request.SchoolDistricts,
                ProgramNames = request.ProgramNames
            };
            return Ok(response);
        }

        //GET: {apibaseurl}/api/getCoordinatingAgency
        //https://localhost:7164/api/CoordinatingAgency/{id}
        [HttpGet]
        [Route("{id:int}")]
        public async Task<IActionResult> GetCoordinatingAgencyById([FromRoute] int id)
        {
            var existingCoordinatingAgency = await coordinatingAgencyRepository.GetById(id);
            if (existingCoordinatingAgency is null)
            {
                return NotFound();
            }
            var response = new CoordinatingAgencyDto
            {
                Id = existingCoordinatingAgency.Id,
                Name = existingCoordinatingAgency.Name,
                IsActive = existingCoordinatingAgency.IsActive,
                OfficePhone = existingCoordinatingAgency.OfficePhone,
                Fax = existingCoordinatingAgency.Fax,
                Address1 = existingCoordinatingAgency.Address1,
                Address2 = existingCoordinatingAgency.Address2,
                City = existingCoordinatingAgency.City,
                State = existingCoordinatingAgency.State,
                Zip = existingCoordinatingAgency.Zip,
                Comments = existingCoordinatingAgency.Comments,
                AddressComments = existingCoordinatingAgency.AddressComments,
                Pc_FirstName = existingCoordinatingAgency.Pc_FirstName,
                Pc_MiddleName = existingCoordinatingAgency.Pc_MiddleName,
                Pc_LastName = existingCoordinatingAgency.Pc_LastName,
                Pc_Email = existingCoordinatingAgency.Pc_Email,
                Pc_OfficePhone = existingCoordinatingAgency.Pc_OfficePhone,
                Pc_CellPhone = existingCoordinatingAgency.Pc_CellPhone,
                Pc_Comments = existingCoordinatingAgency.Pc_Comments,
                CreatedBy = existingCoordinatingAgency.CreatedBy,
                UpdatedBy = existingCoordinatingAgency.UpdatedBy,
                OptionalData = existingCoordinatingAgency.OptionalData,
                Counties = existingCoordinatingAgency.Counties,
                SchoolDistricts = existingCoordinatingAgency.SchoolDistricts,
                ProgramNames = existingCoordinatingAgency.ProgramNames
            };
            return Ok(response);
        }
        [HttpGet]
        [Route("CountiesByCoordinatingAgencyId/{id:long}")]
        public async Task<IActionResult> GetCountiesByCoordinatingAgencyId([FromRoute] long id)
        {
            var counties = await coordinatingAgencyRepository.GetCountyByCoordinatingAgencyId(id);
            //convert domain to dto
            var response = new List<CoordinatingAgencyCountyDto>();
            foreach (var county in counties)
            {
                response.Add(new CoordinatingAgencyCountyDto
                {
                    Id = county.Id,
                    CoordinatingAgencyId = county.CoordinatingAgencyId,
                    CountyId = county.CountyId,
                    //County = county.County
                });
            }
            return Ok(response);
        }

    }
}