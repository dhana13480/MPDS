﻿using Azure.Core;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MPDS.API.Data;
using MPDS.API.Models.Domain;
using MPDS.API.Models.DTO;
using MPDS.API.Repositories.Implementation;
using MPDS.API.Repositories.Interface;

namespace MPDS.API.Controllers
{
    //https://localhost:xxxx/api/MasterPermission
    [Route("api/[controller]")]
    [ApiController]
    public class MasterPermissionController : ControllerBase
    {
        private readonly IMasterPermissionRepository masterPermissionRepository;
        public MasterPermissionController(IMasterPermissionRepository masterPermissionRepository)
        {
            this.masterPermissionRepository = masterPermissionRepository;
        }

        //GET: {apibaseurl}/api/MasterPermission
        //https://localhost:7164/api/MasterPermission
        [HttpGet]
        public async Task<IActionResult> GetAllMasterPermission()
        {
            var masterPermission = await masterPermissionRepository.GetAllASync();
            //convert domain to dto
            var response = new List<MasterPermissionDto>();
            foreach (var item in masterPermission)
            {
                response.Add(new MasterPermissionDto
                {
                    Id = item.Id,
                    Permission = item.Permission                    
                });
            }
            return Ok(response);
        }
        //GET: {apibaseurl}/api/MasterPermission
        //https://localhost:7164/api/MasterPermission/{id}
        [HttpGet]
        [Route("{id:int}")]
        public async Task<IActionResult> GetMasterPermissionById([FromRoute] int id)
        {
            var existingData = await masterPermissionRepository.GetById(id);
            if (existingData is null)
            {
                return NotFound();
            }
            var response = new MasterPermissionDto
            {
                Id = existingData.Id,
                Permission = existingData.Permission             
            };
            return Ok(response);
        }
    }
}
