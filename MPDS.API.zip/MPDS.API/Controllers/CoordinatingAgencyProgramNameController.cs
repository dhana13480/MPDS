﻿using Azure.Core;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using MPDS.API.Data;
using MPDS.API.Models.Domain;
using MPDS.API.Models.DTO;
using MPDS.API.Repositories.Implementation;
using MPDS.API.Repositories.Interface;
using System.Diagnostics;
using System.Xml.Linq;

namespace MPDS.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CoordinatingAgencyProgramNameController : ControllerBase
    {
        private readonly IProgramNameByCoordinatingAgencyRepository programNameByCoordinatingAgencyRepository;
        public CoordinatingAgencyProgramNameController(IProgramNameByCoordinatingAgencyRepository programNameByCoordinatingAgencyRepository)
        {
            this.programNameByCoordinatingAgencyRepository = programNameByCoordinatingAgencyRepository;
        }

        [HttpGet]
       
        public async Task<IActionResult> GetAllprogramNameByCoordinatingAgency()
        {
            var pNamesByCoorAgency = await programNameByCoordinatingAgencyRepository.GetAllAsync();
            //convert domain to dto
            var response = new List<ProgramNameByCoordinatingAgencyDto>();
            foreach (var item in pNamesByCoorAgency)
            {
                response.Add(new ProgramNameByCoordinatingAgencyDto
                {
                     Id = item.id,
                     CoordinatingAgencyId = item.coordinatingAgencyId,
                     ProgramNameId = item.programNameId,
                     ProgramName = item.programName,
                     Name = item.programName,
                });
            }
            return Ok(response);
        }

        [HttpGet]
        [Route("coordinatingagency/{id:long}")]
        public async Task<IActionResult> GetProgramNameByCoordinatingAgencyId([FromRoute] long id)
        {
            var pNamesByCoorAgency = await programNameByCoordinatingAgencyRepository.GetByCoordinatingAgencyId(id);
            //convert domain to dto
            var response = new List<ProgramNameByCoordinatingAgencyDto>();
            foreach (var item in pNamesByCoorAgency)
            {
                response.Add(new ProgramNameByCoordinatingAgencyDto
                {
                    Id = item.id,
                    CoordinatingAgencyId = item.coordinatingAgencyId,
                    ProgramNameId = item.programNameId,
                    ProgramName = item.programName,
                    Name = item.programName,
                });
            }
            return Ok(response);
        }
    }
}
