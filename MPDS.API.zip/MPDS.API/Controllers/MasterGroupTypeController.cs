﻿using Azure.Core;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MPDS.API.Data;
using MPDS.API.Models.Domain;
using MPDS.API.Models.DTO;
using MPDS.API.Repositories.Implementation;
using MPDS.API.Repositories.Interface;

namespace MPDS.API.Controllers
{ //https://localhost:xxxx/api/MasterGroupType
    [Route("api/[controller]")]
    [ApiController]
    public class MasterGroupTypeController : ControllerBase
    {
        private readonly IMasterGroupTypeRepository masterGroupTypeRepository;
        public MasterGroupTypeController(IMasterGroupTypeRepository masterGroupTypeRepository)
        {           
            this.masterGroupTypeRepository = masterGroupTypeRepository;
        }
        //GET: {apibaseurl}/api/MasterGroupType
        //https://localhost:7164/apiMasterGroupType
        [HttpGet]        
        public async Task<IActionResult> GetAllMasterGroupType()
        {
            var masterGroupType = await masterGroupTypeRepository.GetAllAsync();
            //convert domain to dto
            var response = new List<MasterGroupTypeDto>();
            foreach (var item in masterGroupType)
            {
                response.Add(new MasterGroupTypeDto
                {
                    Id = item.Id,
                    Description = item.Description,
                    GroupType = item.GroupType
                });
            }
            return Ok(response);
        }
    }
}
