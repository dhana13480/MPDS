﻿using Azure.Core;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MPDS.API.Data;
using MPDS.API.Models.Domain;
using MPDS.API.Models.DTO;
using MPDS.API.Repositories.Implementation;
using MPDS.API.Repositories.Interface;

namespace MPDS.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StateController : ControllerBase
    {
        private readonly IMasterStatesRepository masterStatesRepository;
        public StateController(IMasterStatesRepository masterStatesRepository)
        {
            this.masterStatesRepository = masterStatesRepository;
        }
        //GET: {apibaseurl}/api/getStates
        //https://localhost:7164/api/getStates
        [HttpGet]
        public async Task<IActionResult> GetAllStates()
        {
            var states = await masterStatesRepository.GetAllAsync();
            //convert domain to dto
            var response = new List<MasterStatesDto>();
            foreach (var state in states)
            {
                response.Add(new MasterStatesDto
                {
                    Id = state.Id,
                    State = state.State,
                    Description = state.Description,
                    TempOldId = state.TempOldId
                });
            }
            return Ok(response);
        }

       

    }
}
