﻿using Azure.Core;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MPDS.API.Data;
using MPDS.API.Models.Domain;
using MPDS.API.Models.DTO;
using MPDS.API.Repositories.Implementation;
using MPDS.API.Repositories.Interface;

namespace MPDS.API.Controllers
{
    //https://localhost:xxxx/api/MasterGrpOptionalData
    [Route("api/[controller]")]
    [ApiController]
    public class MasterGrpOptionalDataController : ControllerBase
    {
        private readonly IMasterGrpOptionalDataRepository masterGrpOptionalDataRepository;
        public MasterGrpOptionalDataController(IMasterGrpOptionalDataRepository masterGrpOptionalDataRepository)
        {
            this.masterGrpOptionalDataRepository = masterGrpOptionalDataRepository;
        }

        //GET: {apibaseurl}/api/getCounty
        //https://localhost:7164/api/County
        [HttpGet]
        public async Task<IActionResult> GetAllMasterGrpOptionalData()
        {
            var masterGrpOptionalData = await masterGrpOptionalDataRepository.GetAllSync();
            //convert domain to dto
            var response = new List<MasterGrpOptionalDataDto>();
            foreach (var item in masterGrpOptionalData)
            {
                response.Add(new MasterGrpOptionalDataDto
                {
                    Id = item.Id,
                    FieldName = item.Description,
                    Description = item.Description                                      
                });
            }
            return Ok(response);
        }
        //GET: {apibaseurl}/api/getMasterGrpOptionalData
        //https://localhost:7164/api/MasterGrpOptionalData/{id}
        [HttpGet]
        [Route("{id:int}")]
        public async Task<IActionResult> GetMasterGrpOptionalDataById([FromRoute] int id)
        {
            var existingData = await masterGrpOptionalDataRepository.GetById(id);
            if (existingData is null)
            {
                return NotFound();
            }
            var response = new MasterGrpOptionalDataDto
            {
                Id = existingData.Id,
                FieldName = existingData.FieldName,
                Description = existingData.Description
            };
            return Ok(response);
        }
    }
}
