﻿using Azure.Core;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MPDS.API.Data;
using MPDS.API.Models.Domain;
using MPDS.API.Models.DTO;
using MPDS.API.Repositories.Implementation;
using MPDS.API.Repositories.Interface;
using System.Diagnostics.Metrics;

namespace MPDS.API.Controllers
{
    //https://localhost:xxxx/api/county
    [Route("api/[controller]")]
    [ApiController]
    public class CountyController : ControllerBase
    {
        private readonly ICountiesRepository countiesRepository;
        public CountyController(ICountiesRepository countiesRepository)
        {
            this.countiesRepository = countiesRepository;
        }

        //GET: {apibaseurl}/api/getCounty
        //https://localhost:7164/api/County
        [HttpGet]
        public async Task<IActionResult> GetAllCounty()
        {
            var counties = await countiesRepository.GetAllAsync();
            //convert domain to dto
            var response = new List<CountiesDto>();
            foreach (var county in counties)
            {
                response.Add(new CountiesDto
                {
                    Id = county.Id,
                    County  = county.County,
                    Description = county.Description,
                    IsActive = county.IsActive,
                    CreatedBy = county.CreatedBy,
                    CreationDate = county.CreationDate,
                    UpdatedBy = county.UpdatedBy,
                    UpdationDate = county.UpdationDate,
                    //TempOldId = county.TempOldId                    
                });
            }
            return Ok(response);
        }
        //GET: {apibaseurl}/api/getCounties
        //https://localhost:7164/api/County/{id}
        [HttpGet]
        [Route("{id:int}")]
        public async Task<IActionResult> GetCountyById([FromRoute] int id)
        {
            var existingCounty = await countiesRepository.GetById(id);
            if (existingCounty is null)
            {
                return NotFound();
            }
            var response = new CountiesDto
            {
                Id = existingCounty.Id,
                County = existingCounty.County,
                Description = existingCounty.Description, 
                IsActive = existingCounty.IsActive,
                //CreatedBy = existingCounty.CreatedBy,
                //CreationDate = existingCounty.CreationDate,
                //UpdatedBy = existingCounty.UpdatedBy,
                //UpdationDate = existingCounty.UpdationDate

            };
            return Ok(response);
        }


        [HttpPost]
        public async Task<IActionResult> CreateCounty(Counties request)
        {
            //Map DTO to Domain model
            var county = new Counties
            {
                //Id = existingCounty.Id,
                County = request.County,
                Description = request.Description,
                IsActive = true,
                CreatedBy = request.CreatedBy,
                CreationDate = DateTime.Now,
                UpdatedBy = request.UpdatedBy,
                UpdationDate = DateTime.Now
            };

            await countiesRepository.CreateAsync(county);
            //Domain model to DTO
            var response = new CountiesDto
            {
                Id = county.Id,
                County = county.County,
                Description = county.Description,
                IsActive = true,
                CreatedBy = county.CreatedBy,
                CreationDate = county.CreationDate,
                UpdatedBy = county.UpdatedBy,
                UpdationDate = county.UpdationDate
            };
            return Ok(response);
        }

        //GET: {apibaseurl}/api/getCounties
        //https://localhost:7164/api/County/{id}
        [HttpGet]
        [Route("CountiesByProviderAgencyId/{id:int}")]
        public async Task<IActionResult> GetCountiesByProviderAgencyId([FromRoute] int id)
        {
            var counties = await countiesRepository.GetByProviderAgencyId(id);             
            if (counties is null)
            {
                return NotFound();
            }
            var response = new List<ProviderAgencyCountyDto>();
            foreach (var county in counties)
            {
                response.Add(new ProviderAgencyCountyDto
                {
                    Id = county.Id,
                    CountyId = county.CountyId,
                    ProviderAgencyId = county.ProviderAgencyId,
                    CountyName = county.CountyName,
                    
                    //TempOldId = county.TempOldId                    
                });
            }
            return Ok(response);
        }
    }
}
