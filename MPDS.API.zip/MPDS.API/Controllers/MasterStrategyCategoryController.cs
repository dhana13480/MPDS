﻿using Microsoft.AspNetCore.Mvc;
using MPDS.API.Models.Domain;
using MPDS.API.Models.DTO;
using MPDS.API.Repositories.Implementation;
using MPDS.API.Repositories.Interface;

namespace MPDS.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MasterStrategyCategoryController : ControllerBase
    {
        private readonly IMasterStrategyCategoryRepository masterStrategyCategoryRepository;

        public MasterStrategyCategoryController(IMasterStrategyCategoryRepository masterStrategyCategoryRepository)
        {
            this.masterStrategyCategoryRepository = masterStrategyCategoryRepository;
        }
        [HttpGet]
        public async Task<IActionResult> GetAllStrategyCategorys()
        {
            var strategyCategorys = await masterStrategyCategoryRepository.GetAllSync();
            //convert Setting to dto
            var response = new List<MasterStrategyCategoryDto>();
            foreach (var strategyCategory in strategyCategorys)
            {
                response.Add(new MasterStrategyCategoryDto
                {
                    Id = strategyCategory.Id,                    
                    StrategyCategory = strategyCategory.StrategyCategory,
                    Description = strategyCategory.Description 
                     
                });
            }
            return Ok(response);
        }
    }
}
