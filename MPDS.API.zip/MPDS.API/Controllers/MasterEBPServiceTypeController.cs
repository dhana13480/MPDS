﻿using Azure.Core;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MPDS.API.Data;
using MPDS.API.Models.Domain;
using MPDS.API.Models.DTO;
using MPDS.API.Repositories.Implementation;
using MPDS.API.Repositories.Interface;

namespace MPDS.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MasterEBPServiceTypeController : ControllerBase
    {
        private readonly IMasterEBPServiceTypeRepository masterEBPServiceTypeRepository;
        public MasterEBPServiceTypeController(IMasterEBPServiceTypeRepository masterEBPServiceTypeRepository)
        {
            this.masterEBPServiceTypeRepository = masterEBPServiceTypeRepository;
        }

        //https://localhost:7164/api/MasterEBPServiceType
        [HttpGet]
        public async Task<IActionResult> GetAllMasterEBPServiceType()
        {
            var masterEBPServiceType = await masterEBPServiceTypeRepository.GetAllAsync();
            //convert domain to dto
            var response = new List<MasterEBPServiceTypeDto>();
            foreach (var item in masterEBPServiceType)
            {
                response.Add(new MasterEBPServiceTypeDto
                {
                    Id = item.Id,
                    Description = item.Description,
                    EBPServiceType = item.EBPServiceType,
                    IsActive = true,
                   
                });
            }
            return Ok(response);
        }
    }
}
