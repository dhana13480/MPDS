﻿using Azure.Core;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MPDS.API.Data;
using MPDS.API.Models.Domain;
using MPDS.API.Models.DTO;
using MPDS.API.Repositories.Implementation;
using MPDS.API.Repositories.Interface;

namespace MPDS.API.Controllers
{
    //https://localhost:xxxx/api/MasterGrpOptionalData
    [Route("api/[controller]")]
    [ApiController]
    public class MasterProgramTypeController : ControllerBase
    {
        private readonly IMasterProgramTypeRepository masterProgramTypeRepository;
  
        public MasterProgramTypeController(IMasterProgramTypeRepository masterProgramTypeRepository)
        {
            this.masterProgramTypeRepository = masterProgramTypeRepository;
         
        }

        

        //GET: {apibaseurl}/api/MasterProgramType
        //https://localhost:7164/api/MasterProgramType
        [HttpGet]
        public async Task<IActionResult> GetAllMasterProgramType()
        {
            var masterProgramType = await masterProgramTypeRepository.GetAllASync();
            //convert domain to dto
            var response = new List<MasterProgramTypeDto>();
            foreach (var item in masterProgramType)
            {
                response.Add(new MasterProgramTypeDto
                {
                    Id = item.Id,
                    Description = item.Description,
                    ProgramType = item.ProgramType
                    
                });
            }
            return Ok(response);
        }
        //GET: {apibaseurl}/api/getMasterGrpOptionalData
        //https://localhost:7164/api/MasterGrpOptionalData/{id}
        [HttpGet]
        [Route("{id:int}")]
        public async Task<IActionResult> GetMasterProgramTypeById([FromRoute] int id)
        {
            var existingData = await masterProgramTypeRepository.GetById(id);
            if (existingData is null)
            {
                return NotFound();
            }
            var response = new MasterProgramTypeDto
            {
                Id = existingData.Id,
                Description = existingData.Description,
                ProgramType = existingData.ProgramType                
            };
            return Ok(response);
        }
    }
}
