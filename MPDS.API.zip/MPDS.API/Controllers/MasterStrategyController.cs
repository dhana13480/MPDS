﻿using Microsoft.AspNetCore.Mvc;
using MPDS.API.Models.Domain;
using MPDS.API.Models.DTO;
using MPDS.API.Repositories.Implementation;
using MPDS.API.Repositories.Interface;

namespace MPDS.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MasterStrategyController : ControllerBase
    {
        private readonly IMasterStrategyRepository masterStrategyRepository;

        public MasterStrategyController(IMasterStrategyRepository masterStrategyRepository)
        {
            this.masterStrategyRepository = masterStrategyRepository;
        }
        [HttpGet]
        public async Task<IActionResult> GetAllStrategys()
        {
            var Strategys = await masterStrategyRepository.GetAllSync();
            //convert Setting to dto
            var response = new List<MasterStrategyDto>();
            foreach (var strategy in Strategys)
            {
                response.Add(new MasterStrategyDto
                {
                    Id = strategy.Id,
                    Code = strategy.Code,
                    Strategy = strategy.Strategy,
                    Description = strategy.Description,
                    CategoryId = strategy.CategoryId
                });
            }
            return Ok(response);
        }
    }
}
