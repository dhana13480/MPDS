﻿using Azure;
using Azure.Core;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MPDS.API.Data;
using MPDS.API.Extensions;
using MPDS.API.Models.Domain;
using MPDS.API.Models.DTO;
using MPDS.API.Repositories.Implementation;
using MPDS.API.Repositories.Interface;
using MPDS.API.Utilities;
using System;
using System.Data;

namespace MPDS.API.Controllers
{
    //https://localhost:xxxx/api/staff
    [Route("api/[controller]")]
    [ApiController]
    public class StaffController : ControllerBase
    {
        private readonly IStaffRepository staffRepository;
        public StaffController(IStaffRepository staffRepository)
        {
            this.staffRepository = staffRepository;
        }
        //GET: {apibaseurl}/api/getStaff
        //https://localhost:7164/api/Staff
        [HttpGet]
        public async Task<IActionResult> GetAllStaff()
        {
            var staffs = await staffRepository.GetAllAsync();
            //convert domain to dto
            var response = new List<StaffDto>();
            foreach (var staff in staffs)
            {
                response.Add(new StaffDto
                {
                    Id = staff.Id,
                    UKeyOld = staff.UKeyOld,
                    FirstName = staff.FirstName,
                    MiddleName = staff.MiddleName,
                    LastName = staff.LastName,
                    CoordinatingAgencyId = staff.CoordinatingAgencyId,
                    ProviderAgencyId = staff.ProviderAgencyId,
                    EffectiveFrom = staff.EffectiveFrom,
                    EffectiveTo = staff.EffectiveTo,
                    IsActive = staff.IsActive,
                    Email = staff.Email,
                    CellPhone = staff.CellPhone,
                    OfficePhone = staff.OfficePhone,
                    HomePhone = staff.HomePhone,
                    Fax = staff.Fax,
                    Address1 = staff.Address1,
                    Address2 = staff.Address2,
                    City = staff.City,
                    State = staff.State,
                    Zip = staff.Zip,
                    Comments = staff.Comments,
                    CreatedBy = staff.CreatedBy,
                    CreationDate = staff.CreationDate,
                    UpdatedBy = staff.UpdatedBy,
                    UpdationDate = staff.UpdationDate,
                    StaffType = staff.StaffType,
                    IsDeleted = staff.IsDeleted
                });
            }
            return Ok(response);
        }
        [HttpPost]
        [Route("GetAllStaffPaginated")]
        public async Task<ActionResult<PagedList<StaffDto>>> GetAllStaffPagelist([FromQuery] UserParams userParams, UserSearchInputParameters request)
        {
            var staffs = await staffRepository.GetAllStaffAsyncPagelist(userParams, request);

            Response.AddPaginationHeader(new PaginationHeader(staffs.CurrentPage,
               staffs.PageSize, staffs.TotalCount, staffs.TotalPages));
            return Ok(staffs);

        }
        //ActivityStaff
        [HttpPost]
        [Route("ActivityStaff/Add/{activityId:long}")]
        
        public async Task<IActionResult> CreateActivityStaff(List<CreateActivityStaff> data  , [FromRoute] long activityId)
        {
            if (data == null || data.Count == 0)
            {
                return BadRequest("Invalid data, cannot create Activity Staff.");
            }

            DataTable dataTable = new DataTable();
            dataTable.Columns.Add("activityId", typeof(long));
            dataTable.Columns.Add("activityStaffId", typeof(long));
            dataTable.Columns.Add("activityStaffStartDate", typeof(string));
            dataTable.Columns.Add("activityStaffEndDate", typeof(string));
            dataTable.Columns.Add("units", typeof(int));

            DateTime dtActivityStaffStartDate = DateTime.MinValue;
            DateTime dtActivityStaffEndDate = DateTime.MinValue;

            //    if (request.activityStaffStartDate != null)
            //        dtActivityStaffStartDate = DateTime.Parse(request.activityStaffStartDate, Thread.CurrentThread.CurrentCulture);
            //    if (request.activityStaffEndDate != null)
            //        dtActivityStaffEndDate = DateTime.Parse(request.activityStaffEndDate, Thread.CurrentThread.CurrentCulture);


            foreach (var staff in data)
            {
                dataTable.Rows.Add(staff.activityId, staff.activityStaffId, staff.activityStaffStartDate,staff.activityStaffEndDate,staff.Units);

                var actstaff = new ActivityStaff
                {
                    ActivityId = staff.activityId,
                    StaffId = staff.activityStaffId,
                    StrategyId = 0,
                    Units = staff.Units,
                    OptionalLocalMBO = "",
                    StartDate = DateTime.Parse(staff.activityStaffStartDate, Thread.CurrentThread.CurrentCulture),
                    EndDate = DateTime.Parse(staff.activityStaffEndDate, Thread.CurrentThread.CurrentCulture),
                   
                };
                try
                {
                    await staffRepository.CreateActivityStaff(actstaff);
                }

                catch (Exception ex)
                {
                    return BadRequest("Error Adding Activity Staff" + ex.Message);
                }

            }


            //if (request is not null)
            //{
            //    if (request.activityStaffId <= 0)
            //        return BadRequest("Error Adding Activity Staff");
            //    if (request.activityId <= 0)
            //        return BadRequest("Error Adding Activity Staff");

            //    DateTime dtActivityStaffStartDate = DateTime.MinValue;
            //    DateTime dtActivityStaffEndDate = DateTime.MinValue;

            //    if (request.activityStaffStartDate != null)
            //        dtActivityStaffStartDate = DateTime.Parse(request.activityStaffStartDate, Thread.CurrentThread.CurrentCulture);
            //    if (request.activityStaffEndDate != null)
            //        dtActivityStaffEndDate = DateTime.Parse(request.activityStaffEndDate, Thread.CurrentThread.CurrentCulture);


            //var response = new CreateActivityStaff
            //{
            //    //Id = staff.Id,
            //    activityId = (int?)staff.ActivityId,
            //    activityStaffId = request.activityStaffId,
            //    activityStrategyId = request.activityStrategyId,
            //    Units = request.Units,
            //    activityOptionalLocalMBO = request.activityOptionalLocalMBO,
            //    activityStaffStartDate = request.activityStaffStartDate,
            //    activityStaffEndDate = request.activityStaffEndDate,
            //};
            return Ok("Activity Staff created successfully");
            // }
            //return BadRequest("Internal Server Error, Staff is not saved.");
        }
        //https://localhost:7164/api/staff/{id}
        [HttpGet]
        [Route("ProviderAgency/{id:long}")]
        //[Route("{id:long}")]
        public async Task<IActionResult> GetStaffByProviderId([FromRoute] long id)
        {
            var existingStaff = await staffRepository.GetStaffByProviderId(id);
            if (existingStaff is null)
            {
                return NotFound();
            }
            var response = new List<StaffDto>();
            foreach (var staff in existingStaff)
            {
                response.Add(new StaffDto
                {
                    Id = staff.Id,
                    //UKeyOld = staff.UKeyOld,
                    FirstName = staff.FirstName,
                    MiddleName = staff.MiddleName,
                    LastName = staff.LastName,
                    CoordinatingAgencyId = staff.CoordinatingAgencyId,
                    ProviderAgencyId = staff.ProviderAgencyId,
                    EffectiveFrom = staff.EffectiveFrom,
                    EffectiveTo = staff.EffectiveTo,
                    IsActive = staff.IsActive,
                    Email = staff.Email,
                    CellPhone = staff.CellPhone,
                    OfficePhone = staff.OfficePhone,
                    HomePhone = staff.HomePhone,
                    Fax = staff.Fax,
                    Address1 = staff.Address1,
                    Address2 = staff.Address2,
                    City = staff.City,
                    State = staff.State,
                    Zip = staff.Zip,
                    Comments = staff.Comments,
                    //CreatedBy = staff.CreatedBy,
                    //CreationDate = staff.CreationDate,
                    //UpdatedBy = staff.UpdatedBy,
                    // UpdationDate = staff.UpdationDate,
                    StaffType = staff.StaffType,
                    IsDeleted = staff.IsDeleted
                });
            }
            return Ok(response);

        }

        //https://localhost:7164/api/staff/{id}
        [HttpGet]
        [Route("CoordinatingAgency/{id:long}")]
        //[Route("{id:long}")]
        public async Task<IActionResult> GetStaffByPihpId([FromRoute] long id)
        {
            var existingStaff = await staffRepository.GetAllByPihpRegionId(id);
            if (existingStaff is null)
            {
                return NotFound();
            }
            var response = new List<StaffDto>();
            foreach (var staff in existingStaff)
            {
                response.Add(new StaffDto
                {
                    Id = staff.Id,
                    //UKeyOld = staff.UKeyOld,
                    FirstName = staff.FirstName,
                    MiddleName = staff.MiddleName,
                    LastName = staff.LastName,
                    CoordinatingAgencyId = staff.CoordinatingAgencyId,
                    ProviderAgencyId = staff.ProviderAgencyId,
                    EffectiveFrom = staff.EffectiveFrom,
                    EffectiveTo = staff.EffectiveTo,
                    IsActive = staff.IsActive,
                    Email = staff.Email,
                    CellPhone = staff.CellPhone,
                    OfficePhone = staff.OfficePhone,
                    HomePhone = staff.HomePhone,
                    Fax = staff.Fax,
                    Address1 = staff.Address1,
                    Address2 = staff.Address2,
                    City = staff.City,
                    State = staff.State,
                    Zip = staff.Zip,
                    Comments = staff.Comments,
                    //CreatedBy = staff.CreatedBy,
                    //CreationDate = staff.CreationDate,
                    //UpdatedBy = staff.UpdatedBy,
                    // UpdationDate = staff.UpdationDate,
                    StaffType = staff.StaffType,
                    IsDeleted = staff.IsDeleted
                });
            }
            return Ok(response);

        }

        [HttpGet]
        [Route("Activity/{id:long}")]
        //[Route("{id:long}")]
        public async Task<IActionResult> GetStaffByActivityId([FromRoute] long id)
        {
            var existingStaff = await staffRepository.GetStaffByActivityId(id);
            if (existingStaff is null)
            {
                return NotFound();
            }
            var response = new List<StaffDto>();
            foreach (var staff in existingStaff)
            {
                response.Add(new StaffDto
                {
                    Id = staff.Id,
                    FirstName = staff.FirstName,
                    MiddleName = staff.MiddleName,
                    LastName = staff.LastName,
                    CoordinatingAgencyId = staff.CoordinatingAgencyId,
                    ProviderAgencyId = staff.ProviderAgencyId,
                    EffectiveFrom = staff.EffectiveFrom,
                    EffectiveTo = staff.EffectiveTo,
                    IsActive = staff.IsActive,
                    Email = staff.Email,
                    CellPhone = staff.CellPhone,
                    OfficePhone = staff.OfficePhone,
                    HomePhone = staff.HomePhone,
                    Fax = staff.Fax,
                    Address1 = staff.Address1,
                    Address2 = staff.Address2,
                    City = staff.City,
                    State = staff.State,
                    Zip = staff.Zip,
                    Comments = staff.Comments,
                    StaffType = staff.StaffType,
                    IsDeleted = staff.IsDeleted,
                    StaffStartDate = staff.StaffStartDate,
                    StaffEndDate = staff.StaffEndDate,
                    StrategyId = staff.StrategyId,
                });
            }
            return Ok(response);

        }

        [HttpGet]
        [Route("CoordinatingAgency/{cid:long}/ProviderAgency/{pid:long}")]
        //[Route("{id:long}")]
        public async Task<IActionResult> GetStaffByCoordinatingAgencyAndProviderId([FromRoute] long cid, long pid)
        {
            var existingStaff = await staffRepository.GetStaffByCoordinatingAgencyAndProviderId(cid, pid);
            if (existingStaff is null)
            {
                return NotFound();
            }
            var response = new List<StaffDto>();
            foreach (var staff in existingStaff)
            {
                response.Add(new StaffDto
                {
                    Id = staff.Id,
                    //UKeyOld = staff.UKeyOld,
                    FirstName = staff.FirstName,
                    MiddleName = staff.MiddleName,
                    LastName = staff.LastName,
                    CoordinatingAgencyId = staff.CoordinatingAgencyId,
                    ProviderAgencyId = staff.ProviderAgencyId,
                    EffectiveFrom = staff.EffectiveFrom,
                    EffectiveTo = staff.EffectiveTo,
                    IsActive = staff.IsActive,
                    Email = staff.Email,
                    CellPhone = staff.CellPhone,
                    OfficePhone = staff.OfficePhone,
                    HomePhone = staff.HomePhone,
                    Fax = staff.Fax,
                    Address1 = staff.Address1,
                    Address2 = staff.Address2,
                    City = staff.City,
                    State = staff.State,
                    Zip = staff.Zip,
                    Comments = staff.Comments,
                    //CreatedBy = staff.CreatedBy,
                    //CreationDate = staff.CreationDate,
                    //UpdatedBy = staff.UpdatedBy,
                    // UpdationDate = staff.UpdationDate,
                    StaffType = staff.StaffType,
                    IsDeleted = staff.IsDeleted
                });
            }
            return Ok(response);

        }

        //https://localhost:7164/api/staff/member/{id}
        [HttpGet]
        [Route("{id:long}")]
        public async Task<IActionResult> GetStaffByStaffId([FromRoute] long id)
        {
            var staff = await staffRepository.GetByStaffId(id);
            if (staff is null)
            {
                return NotFound();
            }
            var response = new StaffDto()
            {
                Id = staff.Id,
                //UKeyOld = staff.UKeyOld,
                FirstName = staff.FirstName,
                MiddleName = staff.MiddleName,
                LastName = staff.LastName,
                CoordinatingAgencyId = staff.CoordinatingAgencyId,
                ProviderAgencyId = staff.ProviderAgencyId,
                EffectiveFrom = staff.EffectiveFrom,
                EffectiveTo = staff.EffectiveTo,
                IsActive = staff.IsActive,
                Email = staff.Email,
                CellPhone = staff.CellPhone,
                OfficePhone = staff.OfficePhone,
                HomePhone = staff.HomePhone,
                Fax = staff.Fax,
                Address1 = staff.Address1,
                Address2 = staff.Address2,
                City = staff.City,
                State = staff.State,
                Zip = staff.Zip,
                Comments = staff.Comments,
                //CreatedBy = staff.CreatedBy,
                //CreationDate = staff.CreationDate,
                //UpdatedBy = staff.UpdatedBy,
                // UpdationDate = staff.UpdationDate,
                StaffType = staff.StaffType,
                IsDeleted = staff.IsDeleted
            };

            return Ok(response);

        }

        [HttpPost]
        public async Task<IActionResult> CreateStaff(CreateStaffRequestDto request)
        {

            if (request.FirstName.Equals(string.Empty))
                return BadRequest("Please enter First Name");
            if (request.LastName.Equals(string.Empty))
                return BadRequest("Please enter Last Name");
            if (request.Email.Equals(string.Empty))
                return BadRequest("Please enter Email");
            try
            {
                var addr = new System.Net.Mail.MailAddress(request.Email);
            }
            catch
            {
                return BadRequest("Please enter valid Email");
            }
            if (request.Address1.Equals(string.Empty))
                return BadRequest("Please enter Address 1");
            if (request.City.Equals(string.Empty))
                return BadRequest("Please enter City");
            if (request.Zip.Equals(string.Empty))
                return BadRequest("Please enter Zip");
            if (request.StaffType == 1)
                if (request.ProviderAgencyId <= 0)
                    return BadRequest("Please Choose Provider Agency");
            if (request.StaffType == 2)
                if (request.CoordinatingAgencyId <= 0)
                    return BadRequest("Please Choose PIHP Region");

            //Map DTO to Domain model
            var staff = new Staff
            {
                FirstName = request.FirstName,
                MiddleName = request.MiddleName,
                LastName = request.LastName,
                CoordinatingAgencyId = request.CoordinatingAgencyId,
                ProviderAgencyId = request.ProviderAgencyId,
                EffectiveFrom = request.EffectiveFrom,
                EffectiveTo = request.EffectiveTo,
                IsActive = true,
                Email = request.Email,
                CellPhone = request.CellPhone,
                OfficePhone = request.OfficePhone,
                HomePhone = request.HomePhone,
                Fax = request.Fax,
                Address1 = request.Address1,
                Address2 = request.Address2,
                City = request.City,
                State = request.State,
                Zip = request.Zip,
                Comments = request.Comments,
                StaffType = request.StaffType,
                IsDeleted = false,
                CreationDate = DateTime.Now,
                UpdationDate = DateTime.Now,
                CreatedBy = request.CreatedBy,
                UpdatedBy = request.UpdatedBy
            };

            await staffRepository.CreateAsync(staff);
            //Domain model to DTO
            var response = new StaffDto
            {
                Id = staff.Id,
                FirstName = request.FirstName,
                MiddleName = request.MiddleName,
                LastName = request.LastName,
                CoordinatingAgencyId = request.CoordinatingAgencyId,
                ProviderAgencyId = request.ProviderAgencyId,
                EffectiveFrom = request.EffectiveFrom,
                EffectiveTo = request.EffectiveTo,
                IsActive = request.IsActive,
                Email = request.Email,
                CellPhone = request.CellPhone,
                OfficePhone = request.OfficePhone,
                HomePhone = request.HomePhone,
                Fax = request.Fax,
                Address1 = request.Address1,
                Address2 = request.Address2,
                City = request.City,
                State = request.State,
                Zip = request.Zip,
                Comments = request.Comments,
                StaffType = request.StaffType,
                IsDeleted = request.IsDeleted
            };
            return Ok(response);
        }

        [HttpPut]
        [Route("{id:long}")]
        public async Task<IActionResult> EditStaff([FromRoute] long id, UpdateStaffRequestDto request)
        {
            //convert DTO to Domain model
            var staff = new Staff()
            {
                Id = id,
                FirstName = request.FirstName,
                MiddleName = request.MiddleName,
                LastName = request.LastName,
                CoordinatingAgencyId = request.CoordinatingAgencyId,
                ProviderAgencyId = 2, // request.ProviderAgencyId,
                //EffectiveFrom = request.EffectiveFrom,
                //EffectiveTo = request.EffectiveTo,
                IsActive = request.IsActive,
                Email = request.Email,
                CellPhone = request.CellPhone,
                OfficePhone = request.OfficePhone,
                HomePhone = request.HomePhone,
                Fax = request.Fax,
                Address1 = request.Address1,
                Address2 = request.Address2,
                City = request.City,
                State = request.State,
                Zip = request.Zip,
                Comments = request.Comments,
                StaffType = request.StaffType,
                IsDeleted = request.IsDeleted,
                CreationDate = request.CreationDate,
                UpdationDate = request.UpdationDate,
                //CreatedBy = 1,
                UpdatedBy = 1

            };
            staff = await staffRepository.UpdateAsync(staff);
            if (staff == null)
                return NotFound();

            var response = new StaffDto
            {
                Id = staff.Id,
                FirstName = staff.FirstName,
                MiddleName = staff.MiddleName,
                LastName = staff.LastName,
                CoordinatingAgencyId = staff.CoordinatingAgencyId,
                ProviderAgencyId = 2, // request.ProviderAgencyId,
                EffectiveFrom = staff.EffectiveFrom,
                EffectiveTo = staff.EffectiveTo,
                IsActive = staff.IsActive,
                Email = staff.Email,
                CellPhone = staff.CellPhone,
                OfficePhone = staff.OfficePhone,
                HomePhone = staff.HomePhone,
                Fax = staff.Fax,
                Address1 = staff.Address1,
                Address2 = staff.Address2,
                City = staff.City,
                State = staff.State,
                Zip = staff.Zip,
                Comments = staff.Comments,
                StaffType = staff.StaffType,
                IsDeleted = staff.IsDeleted,
                CreationDate = DateTime.Now,
                UpdationDate = DateTime.Now,
                //CreatedBy = 1,
                UpdatedBy = 1

            };
            return Ok(response);
        }
    }
}
