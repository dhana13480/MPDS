﻿using Microsoft.AspNetCore.Mvc;
using MPDS.API.Models.DTO;
using MPDS.API.Repositories.Implementation;
using MPDS.API.Repositories.Interface;

namespace MPDS.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MasterServicePopulationController : ControllerBase
    {
        private readonly IMasterServicePopulationRepository masterServicePopulationRepository;

        public MasterServicePopulationController(IMasterServicePopulationRepository masterServicePopulationRepository)
        {
            this.masterServicePopulationRepository = masterServicePopulationRepository;
        }
        [HttpGet]
        public async Task<IActionResult> GetAllServicePopulations()
        {
            var servicePopulations = await masterServicePopulationRepository.GetAllSync();
            //convert Population to dto
            var response = new List<MasterServicePopulationDto>();
            foreach (var servicePopulation in servicePopulations)
            {
                response.Add(new MasterServicePopulationDto
                {
                    id = servicePopulation.Id,
                    code = servicePopulation.Code,
                    servicePopulation = servicePopulation.Code + " - " + servicePopulation.ServicePopulation,
                    description = servicePopulation.Description
                });
            }
            return Ok(response);
        }
    }
}
