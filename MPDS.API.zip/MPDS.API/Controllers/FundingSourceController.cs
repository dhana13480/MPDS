﻿using Azure.Core;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MPDS.API.Data;
using MPDS.API.Models.Domain;
using MPDS.API.Models.DTO;
using MPDS.API.Repositories.Implementation;
using MPDS.API.Repositories.Interface;
using System.Diagnostics.Metrics;

namespace MPDS.API.Controllers
{
    //https://localhost:xxxx/api/county
    [Route("api/[controller]")]
    [ApiController]
    public class FundingSourceController : ControllerBase
    {
        private readonly IMasterFundSourceRepository fundingSourceRepository;
        public FundingSourceController(IMasterFundSourceRepository fundingSourceRepository)
        {
            this.fundingSourceRepository = fundingSourceRepository;
        }

        //GET: {apibaseurl}/api/getCounty
        //https://localhost:7164/api/fundingSource
        [HttpGet]
        [Route("GetFundingSource")]
        public async Task<IActionResult> GetFundingSource()
        {
            var activityfundSrc = await fundingSourceRepository.GetAllAsync();
            if (activityfundSrc is null)
            {
                return NotFound();
            }
            var response = new List<MasterFundingSourceDto>();

            foreach (var activity in activityfundSrc)
            {
                response.Add(new MasterFundingSourceDto
                {
                    Id = activity.Id,
                    FundingSource = activity.FundingSource,
                    Description = activity.Description,
                    IsActive = activity.IsActive,
                    CreatedBy = activity.CreatedBy,
                    CreationDate = activity.CreationDate,
                    UpdatedBy = activity.UpdatedBy,
                    UpdationDate = activity.UpdationDate
                });
            }

            return Ok(response);
        }
        [HttpPut]
        [Route("updateFundSource")]
        public async Task<IActionResult> EditProgramName(MasterFundingSource request)
        {
            //convert DTO to Domain model
            var fund = new MasterFundingSource()
            {
                Id = request.Id,
                FundingSource = request.FundingSource,
                Description = request.Description,
                IsActive = request.IsActive,
                UpdatedBy = request.UpdatedBy,

            };
            fund = await fundingSourceRepository.UpdateAsync(fund);
            if (fund == null)
                return NotFound();

            var response = new MasterFundingSourceDto
            {
                Id = fund.Id,
                FundingSource = fund.FundingSource,
                Description = fund.Description,
                IsActive = fund.IsActive,
            };
            return Ok(response);
        }

        [HttpPost]
        [Route("Create")]
        public async Task<IActionResult> CreateFund(MasterFundingSource request)
        {
            //Map DTO to Domain model
            var fund = new MasterFundingSource 
            {
                //Id = existingCounty.Id,
                FundingSource = request.FundingSource,
                Description = request.Description,
                IsActive = true,
                CreatedBy = request.CreatedBy,
                CreationDate = DateTime.Now,
                UpdatedBy = request.UpdatedBy,
                UpdationDate = DateTime.Now
            };

            await fundingSourceRepository.CreateAsync(fund);
            //Domain model to DTO
            var response = new MasterFundingSourceDto
            {
                Id = fund.Id,
                FundingSource = fund.FundingSource,
                Description = fund.Description,
                IsActive = true,
                CreatedBy = fund.CreatedBy,
                CreationDate = fund.CreationDate,
                UpdatedBy = fund.UpdatedBy,
                UpdationDate = fund.UpdationDate
            };
            return Ok(response);
        }
        /*
        //GET: {apibaseurl}/api/getCounties
        //https://localhost:7164/api/County/{id}
        [HttpGet]
        [Route("{id:int}")]
        public async Task<IActionResult> GetCountyById([FromRoute] int id)
        {
            var existingCounty = await countiesRepository.GetById(id);
            if (existingCounty is null)
            {
                return NotFound();
            }
            var response = new CountiesDto
            {
                Id = existingCounty.Id,
                County = existingCounty.County,
                Description = existingCounty.Description, 
                IsActive = existingCounty.IsActive,
                //CreatedBy = existingCounty.CreatedBy,
                //CreationDate = existingCounty.CreationDate,
                //UpdatedBy = existingCounty.UpdatedBy,
                //UpdationDate = existingCounty.UpdationDate

            };
            return Ok(response);
        }


      

        //GET: {apibaseurl}/api/getCounties
        //https://localhost:7164/api/County/{id}
        [HttpGet]
        [Route("CountiesByProviderAgencyId/{id:int}")]
        public async Task<IActionResult> GetCountiesByProviderAgencyId([FromRoute] int id)
        {
            var counties = await countiesRepository.GetByProviderAgencyId(id);             
            if (counties is null)
            {
                return NotFound();
            }
            var response = new List<ProviderAgencyCountyDto>();
            foreach (var county in counties)
            {
                response.Add(new ProviderAgencyCountyDto
                {
                    Id = county.Id,
                    CountyId = county.CountyId,
                    ProviderAgencyId = county.ProviderAgencyId,
                    CountyName = county.CountyName,
                    
                    //TempOldId = county.TempOldId                    
                });
            }
            return Ok(response);
        }
        */
    }
}
