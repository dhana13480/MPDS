﻿using Azure.Core;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MPDS.API.Data;
using MPDS.API.Models.Domain;
using MPDS.API.Models.DTO;
using MPDS.API.Repositories.Implementation;
using MPDS.API.Repositories.Interface;
using static System.Net.WebRequestMethods;

namespace MPDS.API.Controllers
{
    //https://localhost:xxxx/api/MasterGrpOptionalData
    [Route("api/[controller]")]
    [ApiController]
    public class MasterProgramNameController : ControllerBase
    {
        private readonly IMasterProgramNameRepository masterProgramNameRepository;
        public MasterProgramNameController(IMasterProgramNameRepository masterProgramNameRepository)
        {
            this.masterProgramNameRepository = masterProgramNameRepository;
        }

        //GET: {apibaseurl}/api/MasterProgramName
        //https://localhost:7164/api/MasterProgramName
        [HttpGet]
        public async Task<IActionResult> GetAllMasterProgramName()
        {
            var masterProgramName = await masterProgramNameRepository.GetAllAsync();
            //convert domain to dto
            var response = new List<MasterProgramNameDto>();
            foreach (var item in masterProgramName)
            {
                response.Add(new MasterProgramNameDto
                {
                    Id = item.Id,
                    Name = item.Name,
                    Description = item.Description,
                    IsActive = item.DeactivatedBy == null ? true : false,
                    CreatedBy = item.CreatedBy,
                    UpdatedBy = item.UpdatedBy,
                    DeactivatedBy = item.DeactivatedBy,
                    ProgramId = item.Id,
                    ProgramName = item.Name,
                    //add dates
                });
            }
            return Ok(response);
        }
        //GET: {apibaseurl}/api/getMasterGrpOptionalData
        //https://localhost:7164/api/MasterGrpOptionalData/{id}
        [HttpGet]
        [Route("{id:int}")]
        public async Task<IActionResult> GetMasterProgramNameById([FromRoute] int id)
        {
            var existingData = await masterProgramNameRepository.GetById(id);
            if (existingData is null)
            {
                return NotFound();
            }
            var response = new MasterProgramNameDto
            {
                Id = existingData.Id,
                Name = existingData.Name,
                Description = existingData.Description,
                IsActive = existingData.DeactivatedBy == null ? true : false,
                CreatedBy = existingData.CreatedBy,
                UpdatedBy = existingData.UpdatedBy,
                DeactivatedBy = existingData.DeactivatedBy,
                ProgramId = existingData.Id,
                ProgramName = existingData.Name,
            };
            return Ok(response);
        }

        [HttpPost]
        public async Task<IActionResult> CreateProgramName(CreateProgramNameDto request)
        {
            //Map DTO to Domain model
            var programName = new MasterProgramName
            {
                Name = request.Name,
                Description = request.Description,
                CreatedBy = request.CreatedBy,
                CreationDate = DateTime.Now,
            };

            await masterProgramNameRepository.CreateAsync(programName);
            //Domain model to DTO
            var response = new MasterProgramNameDto
            {
                Id = programName.Id,
                Name = programName.Name,
                Description = programName.Description,
                CreatedBy = programName.CreatedBy
            };
            return Ok(response);
        }
        [HttpPut]
        [Route("{id:int}")]
        public async Task<IActionResult> EditProgramName([FromRoute] int id, UpdateProgramNameDto request)
        {
            //convert DTO to Domain model
            var programName = new MasterProgramName()
            {
                Id = id,
                Name = request.Name,
                Description = request.Description,
                UpdatedBy = request.UpdatedBy,

            };
            programName = await masterProgramNameRepository.UpdateAsync(programName);
            if (programName == null)
                return NotFound();

            var response = new MasterProgramNameDto
            {
                Id = programName.Id,
                Name = programName.Name,
                Description = programName.Description,
                IsActive = programName.DeactivatedBy == null ? true : false,
                ProgramId = programName.Id,
                ProgramName = programName.Name,

            };
            return Ok(response);
        }
    }
}
