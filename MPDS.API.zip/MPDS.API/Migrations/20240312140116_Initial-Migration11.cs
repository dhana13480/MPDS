﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace MPDS.API.Migrations
{
    /// <inheritdoc />
    public partial class InitialMigration11 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Users");

            migrationBuilder.RenameTable(
                name: "PESRReportResult",
                newName: "Report_PESR");

            migrationBuilder.RenameColumn(
                name: "optionalData",
                table: "CoordinatingAgency",
                newName: "OptionalData");

            migrationBuilder.AddColumn<string>(
                name: "OptionalData",
                table: "ProviderAgency",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "UnitsAllEBP",
                table: "Report_PESR",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AlterColumn<int>(
                name: "Units",
                table: "Report_PESR",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AlterColumn<string>(
                name: "Strategy",
                table: "Report_PESR",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "string",
                oldNullable: true);

            migrationBuilder.AlterColumn<long>(
                name: "ProviderAgencyId",
                table: "Report_PESR",
                type: "bigint",
                nullable: true,
                oldClrType: typeof(long),
                oldType: "long")
                .OldAnnotation("SqlServer:Identity", "1, 1");

            migrationBuilder.AlterColumn<string>(
                name: "ProviderAgency",
                table: "Report_PESR",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "string",
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "NewAttendeesPopulation",
                table: "Report_PESR",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AlterColumn<int>(
                name: "NewAttendeesIndividual",
                table: "Report_PESR",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AlterColumn<string>(
                name: "InterventionType",
                table: "Report_PESR",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "string",
                oldNullable: true);

            migrationBuilder.AlterColumn<long>(
                name: "GroupCount",
                table: "Report_PESR",
                type: "bigint",
                nullable: true,
                oldClrType: typeof(long),
                oldType: "long");

            migrationBuilder.AddColumn<int>(
                name: "id",
                table: "Report_PESR",
                type: "int",
                nullable: false,
                defaultValue: 0)
                .Annotation("SqlServer:Identity", "1, 1");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Report_PESR",
                table: "Report_PESR",
                column: "id");

            migrationBuilder.CreateTable(
                name: "Report_PESRByFundingSource",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ProviderAgencyId = table.Column<long>(type: "bigint", nullable: true),
                    ProviderAgency = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    StrategyId = table.Column<int>(type: "int", nullable: true),
                    Strategy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    InterventionTypeId = table.Column<int>(type: "int", nullable: true),
                    InterventionType = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    GroupCount = table.Column<long>(type: "bigint", nullable: true),
                    Units = table.Column<int>(type: "int", nullable: true),
                    UnitsAllEBP = table.Column<int>(type: "int", nullable: true),
                    NewAttendeesPopulation = table.Column<int>(type: "int", nullable: true),
                    NewAttendeesIndividual = table.Column<int>(type: "int", nullable: true),
                    FundingSource = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Report_PESRByFundingSource", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "UserInfo",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FirstName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    MiddleName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    LastName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UserName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Password = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Phone = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UserTypeId = table.Column<short>(type: "smallint", nullable: true),
                    CoordinatingAgencyId = table.Column<long>(type: "bigint", nullable: true),
                    CoordinatingAgency = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ProviderAgencyId = table.Column<long>(type: "bigint", nullable: true),
                    ProviderAgency = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PAStatus = table.Column<bool>(type: "bit", nullable: false),
                    Permissions = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Address1 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Address2 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    City = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    StateId = table.Column<short>(type: "smallint", nullable: true),
                    Zip = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Comments = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    CoordinatingAgencyStatus = table.Column<bool>(type: "bit", nullable: false),
                    IsPasswordResetRequired = table.Column<bool>(type: "bit", nullable: false),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    CreatedBy = table.Column<long>(type: "bigint", nullable: true),
                    CreationDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    UpdatedBy = table.Column<long>(type: "bigint", nullable: true),
                    UpdationDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    HashingAlgorithm = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    csvProviderAgencies = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    csvCoordinatingAgencies = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserInfo", x => x.Id);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Report_PESRByFundingSource");

            migrationBuilder.DropTable(
                name: "UserInfo");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Report_PESR",
                table: "Report_PESR");

            migrationBuilder.DropColumn(
                name: "OptionalData",
                table: "ProviderAgency");

            migrationBuilder.DropColumn(
                name: "id",
                table: "Report_PESR");

            migrationBuilder.RenameTable(
                name: "Report_PESR",
                newName: "PESRReportResult");

            migrationBuilder.RenameColumn(
                name: "OptionalData",
                table: "CoordinatingAgency",
                newName: "optionalData");

            migrationBuilder.AlterColumn<int>(
                name: "UnitsAllEBP",
                table: "PESRReportResult",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "Units",
                table: "PESRReportResult",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Strategy",
                table: "PESRReportResult",
                type: "string",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<long>(
                name: "ProviderAgencyId",
                table: "PESRReportResult",
                type: "long",
                nullable: false,
                defaultValue: 0L,
                oldClrType: typeof(long),
                oldType: "bigint",
                oldNullable: true)
                .Annotation("SqlServer:Identity", "1, 1");

            migrationBuilder.AlterColumn<string>(
                name: "ProviderAgency",
                table: "PESRReportResult",
                type: "string",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "NewAttendeesPopulation",
                table: "PESRReportResult",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "NewAttendeesIndividual",
                table: "PESRReportResult",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "InterventionType",
                table: "PESRReportResult",
                type: "string",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<long>(
                name: "GroupCount",
                table: "PESRReportResult",
                type: "long",
                nullable: false,
                defaultValue: 0L,
                oldClrType: typeof(long),
                oldType: "bigint",
                oldNullable: true);

            migrationBuilder.CreateTable(
                name: "Users",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Address1 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Address2 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    City = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Comments = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CoordinatingAgencyId = table.Column<long>(type: "bigint", nullable: true),
                    CreatedBy = table.Column<long>(type: "bigint", nullable: true),
                    CreationDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    FirstName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    HashingAlgorithm = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    IsPasswordResetRequired = table.Column<bool>(type: "bit", nullable: false),
                    LastName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    MiddleName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Password = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Permissions = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Phone = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ProviderAgencyId = table.Column<long>(type: "bigint", nullable: true),
                    StateId = table.Column<short>(type: "smallint", nullable: true),
                    UpdatedBy = table.Column<long>(type: "bigint", nullable: true),
                    UpdationDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    UserName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UserTypeId = table.Column<short>(type: "smallint", nullable: true),
                    Zip = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Users", x => x.Id);
                });
        }
    }
}
