﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace MPDS.API.Migrations
{
    /// <inheritdoc />
    public partial class InitialMigration10 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "CountyName",
                table: "ProviderAgency_County");

            migrationBuilder.DropColumn(
                name: "ProgramName",
                table: "CoordinatingAgency_ProgramNames");

            migrationBuilder.DropColumn(
                name: "CoordinatingAgencyId",
                table: "Activity");

            migrationBuilder.DropColumn(
                name: "GroupName",
                table: "Activity");

            migrationBuilder.DropColumn(
                name: "SortId",
                table: "Activity");

            migrationBuilder.DropColumn(
                name: "SortOrder",
                table: "Activity");

            migrationBuilder.DropColumn(
                name: "Status",
                table: "Activity");

            migrationBuilder.RenameColumn(
                name: "pageNumber",
                table: "Activity",
                newName: "NewTransWomanAttendees");

            migrationBuilder.RenameColumn(
                name: "count",
                table: "Activity",
                newName: "NewTransManAttendees");

            migrationBuilder.RenameColumn(
                name: "ProviderAgencyId",
                table: "Activity",
                newName: "VerifiedBy");

            migrationBuilder.AlterColumn<long>(
                name: "ProviderAgencyId",
                table: "ProviderAgency_County",
                type: "bigint",
                nullable: true,
                oldClrType: typeof(long),
                oldType: "bigint");

            migrationBuilder.AlterColumn<int>(
                name: "CountyId",
                table: "ProviderAgency_County",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AlterColumn<DateTime>(
                name: "UpdationDate",
                table: "Master_County",
                type: "datetime2",
                nullable: true,
                oldClrType: typeof(DateTime),
                oldType: "datetime2");

            migrationBuilder.AlterColumn<long>(
                name: "UpdatedBy",
                table: "Master_County",
                type: "bigint",
                nullable: true,
                oldClrType: typeof(long),
                oldType: "bigint");

            migrationBuilder.AlterColumn<DateTime>(
                name: "CreationDate",
                table: "Master_County",
                type: "datetime2",
                nullable: true,
                oldClrType: typeof(DateTime),
                oldType: "datetime2");

            migrationBuilder.AlterColumn<long>(
                name: "CreatedBy",
                table: "Master_County",
                type: "bigint",
                nullable: true,
                oldClrType: typeof(long),
                oldType: "bigint");

            migrationBuilder.AlterColumn<int>(
                name: "ProgramNameId",
                table: "CoordinatingAgency_ProgramNames",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AlterColumn<long>(
                name: "CoordinatingAgencyId",
                table: "CoordinatingAgency_ProgramNames",
                type: "bigint",
                nullable: true,
                oldClrType: typeof(long),
                oldType: "bigint");

            migrationBuilder.AddColumn<string>(
                name: "optionalData",
                table: "CoordinatingAgency",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "FundingSource",
                table: "ActivityGroup",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "ServicePopulation",
                table: "ActivityGroup",
                type: "int",
                nullable: true);

            migrationBuilder.AlterColumn<DateTime>(
                name: "UpdationDate",
                table: "Activity",
                type: "datetime2",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<DateTime>(
                name: "StartDate",
                table: "Activity",
                type: "datetime2",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "RecordNumber",
                table: "Activity",
                type: "int",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<DateTime>(
                name: "EndDate",
                table: "Activity",
                type: "datetime2",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<DateTime>(
                name: "CreationDate",
                table: "Activity",
                type: "datetime2",
                nullable: true,
                oldClrType: typeof(DateTime),
                oldType: "datetime2");

            migrationBuilder.AddColumn<int>(
                name: "NewGenderNonConformingAttendees",
                table: "Activity",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "NewOtherAttendees",
                table: "Activity",
                type: "int",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "Activity_Ethnicity",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ActivityId = table.Column<long>(type: "bigint", nullable: true),
                    EthnicityId = table.Column<int>(type: "int", nullable: true),
                    NoOfAttendees = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Activity_Ethnicity", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Activity_OptionalData",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    numberOfOriginalItemsCreated = table.Column<int>(type: "int", nullable: true),
                    numberOfBrochuresDistributed = table.Column<int>(type: "int", nullable: true),
                    IsSchoolBasedActivity = table.Column<bool>(type: "bit", nullable: false),
                    IndirectSpeakingEngagementReach = table.Column<int>(type: "int", nullable: true),
                    IndirectSpeakingEngagementCount = table.Column<int>(type: "int", nullable: true),
                    SchoolDistrictId = table.Column<int>(type: "int", nullable: true),
                    CountyId = table.Column<int>(type: "int", nullable: true),
                    LocationZipCode = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ServiceSettingId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Activity_OptionalData", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Activity_ParticipantAgeGroup",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ActivityId = table.Column<long>(type: "bigint", nullable: true),
                    ParticipantAgeGroupId = table.Column<int>(type: "int", nullable: true),
                    NoOfAttendees = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Activity_ParticipantAgeGroup", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Activity_Race",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ActivityId = table.Column<long>(type: "bigint", nullable: true),
                    RaceId = table.Column<int>(type: "int", nullable: true),
                    NoOfAttendees = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Activity_Race", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Activity_Staff",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ActivityId = table.Column<long>(type: "bigint", nullable: true),
                    StaffId = table.Column<long>(type: "bigint", nullable: true),
                    StrategyId = table.Column<int>(type: "int", nullable: true),
                    Units = table.Column<int>(type: "int", nullable: true),
                    OptionalLocalMBO = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    StartDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    EndDate = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Activity_Staff", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "ActivityDetails",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ActivityName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    GroupId = table.Column<long>(type: "bigint", nullable: true),
                    TotalAttendees = table.Column<int>(type: "int", nullable: true),
                    NewMaleAttendees = table.Column<int>(type: "int", nullable: true),
                    NewFemaleAttendees = table.Column<int>(type: "int", nullable: true),
                    NewTransManAttendees = table.Column<int>(type: "int", nullable: true),
                    NewTransWomanAttendees = table.Column<int>(type: "int", nullable: true),
                    NewGenderNonConformingAttendees = table.Column<int>(type: "int", nullable: true),
                    NewOtherAttendees = table.Column<int>(type: "int", nullable: true),
                    MasterStrategyEmployed = table.Column<int>(type: "int", nullable: true),
                    EstimatePeopleReached = table.Column<int>(type: "int", nullable: true),
                    AttendeesCompletingGroup = table.Column<int>(type: "int", nullable: true),
                    ActivityOptionalDataId = table.Column<long>(type: "bigint", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: true),
                    IsTobaccoRelated = table.Column<bool>(type: "bit", nullable: true),
                    IsFirstActivityInGroup = table.Column<bool>(type: "bit", nullable: true),
                    IsVerified = table.Column<bool>(type: "bit", nullable: true),
                    VerifiedBy = table.Column<long>(type: "bigint", nullable: true),
                    RecordNumber = table.Column<int>(type: "int", nullable: true),
                    VerifiedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    VerifiedByName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Comments = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    VerifyComments = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreatedBy = table.Column<long>(type: "bigint", nullable: true),
                    CreationDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    UpdatedBy = table.Column<long>(type: "bigint", nullable: true),
                    UpdationDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    OrderNumber = table.Column<int>(type: "int", nullable: true),
                    ProgramNameId = table.Column<long>(type: "bigint", nullable: true),
                    ProviderAgencyId = table.Column<long>(type: "bigint", nullable: true),
                    CoordinatingAgencyId = table.Column<long>(type: "bigint", nullable: true),
                    StartDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    EndDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Status = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    numberOfOriginalItemsCreated = table.Column<int>(type: "int", nullable: true),
                    numberOfBrochuresDistributed = table.Column<int>(type: "int", nullable: true),
                    IndirectSpeakingEngagementReach = table.Column<int>(type: "int", nullable: true),
                    IndirectSpeakingEngagementCount = table.Column<int>(type: "int", nullable: true),
                    IsSchoolBasedActivity = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SchoolDistrictId = table.Column<int>(type: "int", nullable: true),
                    CountyId = table.Column<int>(type: "int", nullable: true),
                    LocationZipCode = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ServiceSettingId = table.Column<int>(type: "int", nullable: true),
                    ActivityOptionalId = table.Column<long>(type: "bigint", nullable: true),
                    GroupName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: true),
                    ActivityEthnicityId = table.Column<long>(type: "bigint", nullable: true),
                    EthnicityId = table.Column<int>(type: "int", nullable: true),
                    EthnicityNoOfAttendees = table.Column<int>(type: "int", nullable: true),
                    ActivityRaceId = table.Column<long>(type: "bigint", nullable: true),
                    RaceId = table.Column<int>(type: "int", nullable: true),
                    RaceNoOfAttendees = table.Column<int>(type: "int", nullable: true),
                    ActivityParticipantAgeGroupId = table.Column<long>(type: "bigint", nullable: true),
                    ParticipantAgeGroupId = table.Column<int>(type: "int", nullable: true),
                    ParticipantAgeGroupNoOfAttendees = table.Column<int>(type: "int", nullable: true),
                    ActivityStaffId = table.Column<long>(type: "bigint", nullable: true),
                    StaffId = table.Column<long>(type: "bigint", nullable: true),
                    StrategyId = table.Column<int>(type: "int", nullable: true),
                    Units = table.Column<int>(type: "int", nullable: true),
                    OptionalLocalMBO = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ActivityStaffStartDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ActivityStaffEndDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    PrimaryStrategyEmployedId = table.Column<int>(type: "int", nullable: true),
                    ServicePopulationId = table.Column<int>(type: "int", nullable: true),
                    FundingSourceId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ActivityDetails", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "CoordinatingAgency_County",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CoordinatingAgencyId = table.Column<long>(type: "bigint", nullable: true),
                    CountyId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CoordinatingAgency_County", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "CoordinatingAgency_OptionalData",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CoordinatingAgencyId = table.Column<long>(type: "bigint", nullable: true),
                    OptionalDataId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CoordinatingAgency_OptionalData", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "CoordinatingAgency_SchoolDistrict",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CoordinatingAgencyId = table.Column<long>(type: "bigint", nullable: true),
                    SchoolDistrictId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CoordinatingAgency_SchoolDistrict", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Master_FundingSource",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FundingSource = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    CreatedBy = table.Column<long>(type: "bigint", nullable: true),
                    CreationDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    UpdatedBy = table.Column<long>(type: "bigint", nullable: true),
                    UpdationDate = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Master_FundingSource", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "ProviderAgency_OptionalData",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ProviderAgencyId = table.Column<long>(type: "bigint", nullable: true),
                    OptionalDataId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProviderAgency_OptionalData", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "ProviderAgency_SchoolDistrict",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ProviderAgencyId = table.Column<long>(type: "bigint", nullable: true),
                    SchoolDistrictId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProviderAgency_SchoolDistrict", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Users",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FirstName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    MiddleName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    LastName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UserName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Password = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Phone = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UserTypeId = table.Column<short>(type: "smallint", nullable: true),
                    CoordinatingAgencyId = table.Column<long>(type: "bigint", nullable: true),
                    ProviderAgencyId = table.Column<long>(type: "bigint", nullable: true),
                    Permissions = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Address1 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Address2 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    City = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    StateId = table.Column<short>(type: "smallint", nullable: true),
                    Zip = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Comments = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    IsPasswordResetRequired = table.Column<bool>(type: "bit", nullable: false),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    CreatedBy = table.Column<long>(type: "bigint", nullable: true),
                    CreationDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    UpdatedBy = table.Column<long>(type: "bigint", nullable: true),
                    UpdationDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    HashingAlgorithm = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Users", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "vActivityAgeAttendees",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ZeroTo5 = table.Column<int>(type: "int", nullable: false),
                    SixTo12 = table.Column<int>(type: "int", nullable: false),
                    ThirteenTo17 = table.Column<int>(type: "int", nullable: false),
                    EighteenTo20 = table.Column<int>(type: "int", nullable: false),
                    TwentyOneTo24 = table.Column<int>(type: "int", nullable: false),
                    TwentyFiveTo44 = table.Column<int>(type: "int", nullable: false),
                    FortyFiveTo64 = table.Column<int>(type: "int", nullable: false),
                    SixtyFiveTo74 = table.Column<int>(type: "int", nullable: false),
                    SeventyFivePlus = table.Column<int>(type: "int", nullable: false),
                    ActivityId = table.Column<long>(type: "bigint", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_vActivityAgeAttendees", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "vActivityEthnicityAttendees",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ActivityId = table.Column<long>(type: "bigint", nullable: false),
                    HispanicLatinoEthnicity = table.Column<int>(type: "int", nullable: false),
                    ArabAmericanCanadianEthnicity = table.Column<int>(type: "int", nullable: false),
                    NotListed = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_vActivityEthnicityAttendees", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "vActivityRaceAttendees",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    AmericanIndianAlaskanNative = table.Column<int>(type: "int", nullable: false),
                    HawaiianPacificIslander = table.Column<int>(type: "int", nullable: false),
                    White = table.Column<int>(type: "int", nullable: false),
                    Asian = table.Column<int>(type: "int", nullable: false),
                    AfricanAmerican = table.Column<int>(type: "int", nullable: false),
                    MultiRacial = table.Column<int>(type: "int", nullable: false),
                    UnknownOther = table.Column<int>(type: "int", nullable: false),
                    ActivityId = table.Column<long>(type: "bigint", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_vActivityRaceAttendees", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "vRemainingIncompleteAttendees",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    GroupId = table.Column<long>(type: "bigint", nullable: false),
                    GroupType = table.Column<int>(type: "int", nullable: true),
                    RemainingIncompleteAttendees = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_vRemainingIncompleteAttendees", x => x.Id);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Activity_Ethnicity");

            migrationBuilder.DropTable(
                name: "Activity_OptionalData");

            migrationBuilder.DropTable(
                name: "Activity_ParticipantAgeGroup");

            migrationBuilder.DropTable(
                name: "Activity_Race");

            migrationBuilder.DropTable(
                name: "Activity_Staff");

            migrationBuilder.DropTable(
                name: "ActivityDetails");

            migrationBuilder.DropTable(
                name: "CoordinatingAgency_County");

            migrationBuilder.DropTable(
                name: "CoordinatingAgency_OptionalData");

            migrationBuilder.DropTable(
                name: "CoordinatingAgency_SchoolDistrict");

            migrationBuilder.DropTable(
                name: "Master_FundingSource");

            migrationBuilder.DropTable(
                name: "ProviderAgency_OptionalData");

            migrationBuilder.DropTable(
                name: "ProviderAgency_SchoolDistrict");

            migrationBuilder.DropTable(
                name: "Users");

            migrationBuilder.DropTable(
                name: "vActivityAgeAttendees");

            migrationBuilder.DropTable(
                name: "vActivityEthnicityAttendees");

            migrationBuilder.DropTable(
                name: "vActivityRaceAttendees");

            migrationBuilder.DropTable(
                name: "vRemainingIncompleteAttendees");

            migrationBuilder.DropColumn(
                name: "optionalData",
                table: "CoordinatingAgency");

            migrationBuilder.DropColumn(
                name: "FundingSource",
                table: "ActivityGroup");

            migrationBuilder.DropColumn(
                name: "ServicePopulation",
                table: "ActivityGroup");

            migrationBuilder.DropColumn(
                name: "NewGenderNonConformingAttendees",
                table: "Activity");

            migrationBuilder.DropColumn(
                name: "NewOtherAttendees",
                table: "Activity");

            migrationBuilder.RenameColumn(
                name: "VerifiedBy",
                table: "Activity",
                newName: "ProviderAgencyId");

            migrationBuilder.RenameColumn(
                name: "NewTransWomanAttendees",
                table: "Activity",
                newName: "pageNumber");

            migrationBuilder.RenameColumn(
                name: "NewTransManAttendees",
                table: "Activity",
                newName: "count");

            migrationBuilder.AlterColumn<long>(
                name: "ProviderAgencyId",
                table: "ProviderAgency_County",
                type: "bigint",
                nullable: false,
                defaultValue: 0L,
                oldClrType: typeof(long),
                oldType: "bigint",
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "CountyId",
                table: "ProviderAgency_County",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AddColumn<string>(
                name: "CountyName",
                table: "ProviderAgency_County",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AlterColumn<DateTime>(
                name: "UpdationDate",
                table: "Master_County",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified),
                oldClrType: typeof(DateTime),
                oldType: "datetime2",
                oldNullable: true);

            migrationBuilder.AlterColumn<long>(
                name: "UpdatedBy",
                table: "Master_County",
                type: "bigint",
                nullable: false,
                defaultValue: 0L,
                oldClrType: typeof(long),
                oldType: "bigint",
                oldNullable: true);

            migrationBuilder.AlterColumn<DateTime>(
                name: "CreationDate",
                table: "Master_County",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified),
                oldClrType: typeof(DateTime),
                oldType: "datetime2",
                oldNullable: true);

            migrationBuilder.AlterColumn<long>(
                name: "CreatedBy",
                table: "Master_County",
                type: "bigint",
                nullable: false,
                defaultValue: 0L,
                oldClrType: typeof(long),
                oldType: "bigint",
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "ProgramNameId",
                table: "CoordinatingAgency_ProgramNames",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AlterColumn<long>(
                name: "CoordinatingAgencyId",
                table: "CoordinatingAgency_ProgramNames",
                type: "bigint",
                nullable: false,
                defaultValue: 0L,
                oldClrType: typeof(long),
                oldType: "bigint",
                oldNullable: true);

            migrationBuilder.AddColumn<string>(
                name: "ProgramName",
                table: "CoordinatingAgency_ProgramNames",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AlterColumn<string>(
                name: "UpdationDate",
                table: "Activity",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(DateTime),
                oldType: "datetime2",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "StartDate",
                table: "Activity",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(DateTime),
                oldType: "datetime2",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "RecordNumber",
                table: "Activity",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "EndDate",
                table: "Activity",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(DateTime),
                oldType: "datetime2",
                oldNullable: true);

            migrationBuilder.AlterColumn<DateTime>(
                name: "CreationDate",
                table: "Activity",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified),
                oldClrType: typeof(DateTime),
                oldType: "datetime2",
                oldNullable: true);

            migrationBuilder.AddColumn<long>(
                name: "CoordinatingAgencyId",
                table: "Activity",
                type: "bigint",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "GroupName",
                table: "Activity",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<short>(
                name: "SortId",
                table: "Activity",
                type: "smallint",
                nullable: true);

            migrationBuilder.AddColumn<short>(
                name: "SortOrder",
                table: "Activity",
                type: "smallint",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Status",
                table: "Activity",
                type: "nvarchar(max)",
                nullable: true);
        }
    }
}
