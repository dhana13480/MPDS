﻿using System.Text.RegularExpressions;

namespace MPDS.API.Utilities
{
    public class ValidateEmail
    {
        public static bool ValidateEmailAddresses(string emails)
        {
            if (!string.IsNullOrEmpty(emails))
            {
                string[] arrayEmails = emails.Split(',');

                foreach (string email in arrayEmails)
                {
                    if (!IsValidEmailAddress(email))
                    {
                        return false;
                    }
                }

                return true;
            }
            else
            {
                return false;
            }
        }

        public static bool IsValidEmailAddress(string sEmail)
        {
            if (sEmail == null)
            {
                return false;
            }

            int nFirstAT = sEmail.IndexOf('@');
            int nLastAT = sEmail.LastIndexOf('@');

            if ((nFirstAT > 0) && (nLastAT == nFirstAT) &&
            (nFirstAT < (sEmail.Length - 1)))
            {
                // address is ok regarding the single @ sign
                return (Regex.IsMatch(sEmail, @"(\w+)@(\w+)\.(\w+)"));
            }
            else
            {
                return false;
            }
        }
    }
}
