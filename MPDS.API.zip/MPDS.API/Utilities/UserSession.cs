﻿using MPDS.API.Models.Domain;
using System.Web;
//using MPDS.Utilities;
using System;
using System.Data;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
namespace MPDS.API.Utilities
{
    public class UserSession
    {
        public static long GetLoginUserId()
        { 
            //Todo

            // CheckUserLogInSession();
            // long userId = 0;
            // UserInfo objUserAccountInfo = (UserInfo)HttpContext.Current.Session[SessionConstants.SESSION_LOGIN_USER_INFO];
            // userId = objUserAccountInfo.Id;
            // return userId;
            return 1;
        }
    }
}
