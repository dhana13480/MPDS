﻿namespace MPDS.API.Utilities
{
    public class MPDSLogger
    {
        public static void LogError(string message)
        {
            LogError(new Exception(message));
        }

        public static void LogError(Exception ex)
        {
            try
            {
                Elmah.ErrorSignal.FromCurrentContext().Raise(ex);
            }
            catch (Exception)
            {
                //Ignore, if we couldn't log it there's nothing more we can do
            }
        }
    }
}
