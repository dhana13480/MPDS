﻿namespace MPDS.API.Utilities
{
    public class SessionConstants
    {
        public SessionConstants()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        public static string SESSION_LOGIN_USER_INFO = "Login_User_Info";
        public static string SESSION_REDIRECT_PAGE_AFTER_LOGIN = "Redirect_User_After_Login";

        public static string SESSION_SESSION_AUTHORIZED_PAGES = "Session_Authorized_Pages";
    }
}
