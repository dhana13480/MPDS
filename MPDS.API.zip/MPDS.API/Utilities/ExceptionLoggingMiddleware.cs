﻿using MPDS.API.Repositories.Interface;

namespace MPDS.API.Utilities
{
    public class ExceptionLoggingMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly IDatabaseLoggerService _logger;

        public ExceptionLoggingMiddleware(RequestDelegate next, IDatabaseLoggerService logger)
        {
            _next = next;
            _logger = logger;
        }

        public async Task Invoke(HttpContext context)
        {
            try
            {
                await _next(context);
            }
            catch (Exception ex)
            {
                // You can retrieve the user from the HttpContext if needed
                var user = context.User?.Identity?.Name ?? "Anonymous";
                //await _logger.LogExceptionAsync(ex, user);

                // Re-throw the exception after logging so it can be handled by the framework
                return null;
                throw;
            }
        }
    }

}
