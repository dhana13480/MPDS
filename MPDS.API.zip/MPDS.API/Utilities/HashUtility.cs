﻿using System;
using System.Security.Cryptography;

namespace MPDS.API.Utilities

{
    public class HashUtility
    {        public static string SHA512Hash(string strValue)
        {
             
            var hashAlgorithm = new SHA512CryptoServiceProvider();

            byte[] dataToHash = new System.Text.UnicodeEncoding().GetBytes(strValue);
            var hashValue = hashAlgorithm.ComputeHash(dataToHash);

            return BitConverter.ToString(hashValue);
        }
    }
}
