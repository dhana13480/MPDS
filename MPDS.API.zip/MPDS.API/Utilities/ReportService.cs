﻿using System;
using System.IO;
using System.Net.Http;
using System.Net;
using System.ServiceModel;
using ReportExecutionService;

using System.Web;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Text;
using MPDS.API.Models.Domain;
using MPDS.API.Repositories.Interface;
using Microsoft.Extensions.Options;
using System.ServiceModel.Description;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;
namespace MPDS.API.Utilities
{
    public class ReportService
    {
        public readonly HttpClient _httpClient;
        public readonly string _reportServerUrl;
        public readonly string _reportPath;
        public readonly NetworkCredential _credentials;
        public readonly AppIdentitySettings _appIdentitySettings;
        public readonly IDatabaseLoggerService _logger;



        public ReportService(IConfiguration configuration, IOptions<AppIdentitySettings> appIdentitySettingsAccessor, IDatabaseLoggerService _logger, HttpClient httpClient)
        {
            this._appIdentitySettings = appIdentitySettingsAccessor.Value;
            this._logger = _logger;
            _httpClient = httpClient;
            //_reportServerUrl = "https://hcv491msqltdm01.ngds.state.mi.us/ReportServer/ReportService2005.asmx"; 
            _credentials = new NetworkCredential(_appIdentitySettings.MiloginInfo.SSRSUserName, _appIdentitySettings.MiloginInfo.SSRSPassword);
            _reportServerUrl = _appIdentitySettings.MiloginInfo.SSRSWebServiceUrl;

        }


        public byte[] GenerateReport(string ReportServer, string Username, string Password, string Domain, string ReportPath, string Format, string Parameters)
        {

            ReportPath = ReportPath.Replace("/", "%2f").Replace(" ", "+");
            string URL = ReportServer + "?" + ReportPath + $"&rs:Command=Render&rs:Format=" + Format + "&rs:ParameterLanguage=en-GB" + "&" + Parameters;
            WebRequest Req = WebRequest.Create(URL);

            Req.Credentials = new NetworkCredential(Username, Password);
            Req.Timeout = Convert.ToInt32(1800000);
            Stream WebStream = Req.GetResponse().GetResponseStream();
            MemoryStream MemStream = new MemoryStream();
            WebStream.CopyTo(MemStream);
            long Len = MemStream.Length;
            byte[] ReportReturn = new byte[Len];
            MemStream.Seek(0, SeekOrigin.Begin);
            MemStream.Read(ReportReturn, 0, (int)Len);
            WebStream.Close();
            MemStream.Close();
            MemStream.Dispose();
            return ReportReturn;
        }
        /*  public async Task<byte[]> RenderReport2(string ReportServer, string Username, string Password, string report, IDictionary<string, object> parameters, string exportFormat )
          {
              //My binding setup, since ASP.NET Core apps don't use a web.config file
              var binding = new BasicHttpBinding(BasicHttpSecurityMode.TransportCredentialOnly);
              binding.Security.Transport.ClientCredentialType = HttpClientCredentialType.Basic;
              binding.MaxReceivedMessageSize = 10485760; //I wanted a 10MB size limit on response to allow for larger PDFs

              //Create the execution service SOAP Client
              var rsExec = new ReportExecutionServiceSoapClient(binding, new EndpointAddress(_reportServerUrl));

              //Setup access credentials. I use windows credentials, yours may differ
              var clientCredentials = new NetworkCredential(Username, Password);
              rsExec.ClientCredentials.Windows.AllowedImpersonationLevel = System.Security.Principal.TokenImpersonationLevel.Impersonation;
              rsExec.ClientCredentials.Windows.ClientCredential = clientCredentials;

              //This handles the problem of "Missing session identifier"
              rsExec.Endpoint.EndpointBehaviors.Add(new ReportingServicesEndpointBehavior());

              //Load the report
              var taskLoadReport = await rsExec.LoadReportAsync(report, null);

              //Set the parameteres asked for by the report
              var reportParameters = taskLoadReport.Parameters.Where(x => parameters.ContainsKey(x.Name)).Select(x => new ParameterValue() { Name = x.Name, Value = parameters[x.Name].ToString() }).ToArray();
              await rsExec.SetExecutionParametersAsync(reportParameters, "en-us");

              //run the report
              const string deviceInfo = @"<DeviceInfo><Toolbar>False</Toolbar></DeviceInfo>";
              var response = await rsExec.RenderAsync(new RenderRequest(exportFormat ?? "PDF", deviceInfo));

              //spit out the result
              return response.Result;
          }
        */
        private static ReportExecutionServiceSoapClient CreateClient(string reportServerUrl, string userName, string password)
        {
            var rsBinding = new BasicHttpBinding();
            rsBinding.Security.Mode = BasicHttpSecurityMode.Transport;
            rsBinding.Security.Transport.ClientCredentialType = HttpClientCredentialType.Basic;

            rsBinding.MaxBufferPoolSize = 20000000;
            rsBinding.MaxBufferSize = 20000000;
            rsBinding.MaxReceivedMessageSize = 20000000;
            rsBinding.OpenTimeout = TimeSpan.FromSeconds(300);
            rsBinding.SendTimeout = TimeSpan.FromSeconds(400);
            rsBinding.ReceiveTimeout = TimeSpan.FromSeconds(500);
            rsBinding.CloseTimeout = TimeSpan.FromSeconds(700);
            var rsEndpointAddress = new EndpointAddress(reportServerUrl);
            var rsClient = new ReportExecutionServiceSoapClient(rsBinding, rsEndpointAddress);

            if (rsClient.ClientCredentials != null)
            {
                rsClient.ClientCredentials.UserName.UserName = userName;
                rsClient.ClientCredentials.UserName.Password = password;
            }


            return rsClient;
        }
        public async Task<byte[]> RunReport(string reportPath, Dictionary<string, string> parameters, string reportServerUrl, string userName, string password, string format)
        {
            try
            {
                const string ReportWidth = "8.5in";
                const string ReportHeight = "11in";
                ReportExecutionServiceSoapClient rs = CreateClient(reportServerUrl, userName, password);
                //var trustedHeader = new TrustedUserHeader();
                var trustedHeader = new TrustedUserHeader { UserName = userName };
                LoadReportResponse loadReponse = await rs.LoadReportAsync(trustedHeader, reportPath, null);

                await AddParametersToTheReport(rs, loadReponse.ExecutionHeader, trustedHeader, parameters);

                RenderResponse response = await RenderReportByteArrayAsync(loadReponse.ExecutionHeader, trustedHeader, rs, format, ReportWidth, ReportHeight);
                //if (format == "PDF")
                //    SaveResultToFile(response.Result, "SomeFileName.pdf");
                //else
                //    SaveResultToFile(response.Result, "SomeFileName.xls");
                return response.Result;
            }
            catch (Exception ex)
            {
                await _logger.LogInfo("1.Report Service " + ex.Message, "RunReport ", "AppUser");
                return null;
               throw;
            }
           
        }

        private static async Task<SetExecutionParametersResponse> AddParametersToTheReport(ReportExecutionServiceSoapClient rs, ExecutionHeader executionHeader, TrustedUserHeader trustedHeader, Dictionary<string, string> parameters)
        {
            // Add parameters to the report
            var reportParameters = new List<ParameterValue>();

            foreach (KeyValuePair<string, string> entry in parameters)
            {
                reportParameters.Add(new ParameterValue() { Name = entry.Key, Value = entry.Value });
            }
            SetExecutionParametersResponse setParamsResponse = await rs.SetExecutionParametersAsync(executionHeader, trustedHeader, reportParameters.ToArray(), "en-US");
            return setParamsResponse;
        }

        private static async Task<RenderResponse> RenderReportByteArrayAsync(ExecutionHeader execHeader, TrustedUserHeader trustedHeader,
        ReportExecutionServiceSoapClient rs, string format, string width, string height)
        {
            string deviceInfo = String.Format("<DeviceInfo><PageHeight>{0}</PageHeight><PageWidth>{1}</PageWidth><PrintDpiX>300</PrintDpiX><PrintDpiY>300</PrintDpiY></DeviceInfo>", height, width);

            var renderRequest = new RenderRequest(execHeader, trustedHeader, format, deviceInfo);

            //get report bytes
            RenderResponse response = await rs.RenderAsync(renderRequest);
            return response;
        }
        //Test to save the file locally
        private static void SaveResultToFile(byte[] result, string fileName)
        {
            using (var fs = File.OpenWrite($"c:\\temp\\{fileName}"))
            using (var sw = new StreamWriter(fs))
            {
                fs.Write(result);
            }
        }

        public async Task<byte[]> RenderReport(string reportPath, string format, Dictionary<string, string> parameters)
        {
            try
            {


                using (var httpClient = new HttpClient { BaseAddress = new Uri(_reportServerUrl + "?" + reportPath) })
                {
                    var authToken = Encoding.ASCII.GetBytes("mpds:Pass__123");
                    httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(authToken));

                    var request = new HttpRequestMessage(HttpMethod.Post, "ReportExecutionService/RenderReport")
                    //var request = new HttpRequestMessage(HttpMethod.Post, reportPath)
                    {
                        Content = new FormUrlEncodedContent(new[]
                        {
                new KeyValuePair<string, string>("reportPath", reportPath),
                new KeyValuePair<string, string>("rs:format", format)
            }.Concat(parameters.Select(p => new KeyValuePair<string, string>(p.Key, p.Value))))
                    };

                    var response = await httpClient.SendAsync(request);
                    response.EnsureSuccessStatusCode();
                    // Write the byte array directly to a PDF file

                    return await response.Content.ReadAsByteArrayAsync();
                }
            }
            catch (Exception ex)
            {
                return null;
                throw;
            }
        }
        public async Task<LoadReportResponse> LoadReport(ReportExecutionServiceSoapClient rs, TrustedUserHeader trustedHeader, string reportPath)
        {
            // Get the report and set the execution header.
            // Failure to set the execution header will result in this error: "The session identifier is missing. A session identifier is required for this operation."
            // See https://social.msdn.microsoft.com/Forums/sqlserver/en-US/17199edb-5c63-4815-8f86-917f09809504/executionheadervalue-missing-from-reportexecutionservicesoapclient
            LoadReportResponse loadReponse = await rs.LoadReportAsync(trustedHeader, reportPath, "");

            return loadReponse;
        }
      
        public async Task<byte[]> GetReportAsync(string format = "PDF")
        {
            var requestMessage = new HttpRequestMessage(HttpMethod.Post, _reportServerUrl);

            // Set up request headers and body here
            // Example: You might need to construct SOAP envelopes as required by SSRS

            // Assuming the body is XML; here's a simplified example:
            var soapEnvelope = $@"
            <soap:Envelope xmlns:soap='http://schemas.xmlsoap.org/soap/envelope/' xmlns:rs='http://schemas.microsoft.com/sqlserver/2005/06/rs'>
                <soap:Body>
                    <rs:LoadReport xmlns:rs='http://schemas.microsoft.com/sqlserver/2005/06/rs'>
                        <rs:Report>{_reportPath}</rs:Report>
                    </rs:LoadReport>
                </soap:Body>
            </soap:Envelope>";

            requestMessage.Content = new StringContent(soapEnvelope);
            requestMessage.Content.Headers.ContentType = new MediaTypeHeaderValue("text/xml");

            var response = await _httpClient.SendAsync(requestMessage);
            response.EnsureSuccessStatusCode();

            var responseBody = await response.Content.ReadAsByteArrayAsync();
            return responseBody;
        }
    }
}







