﻿namespace MPDS.API.Utilities
{
    public class UserRoles
    {
        public int? userTypeId { get; set; }
        public long coordinatingAgencyId { get; set; }
        public long providerAgencyId { get; set; }
        public string? permissions { get; set; }

    }
}
