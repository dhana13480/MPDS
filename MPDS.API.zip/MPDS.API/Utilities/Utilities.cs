﻿namespace MPDS.API.Utilities
{
    public static class Utilities
    {
        public static string ToDebugString<TKey, TValue>(this IDictionary<TKey, TValue> dictionary)
        {
            return string.Join("&", dictionary.Select(kv => kv.Key + "=" + kv.Value).ToArray());
        }
    }
}
