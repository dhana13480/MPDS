﻿using Microsoft.EntityFrameworkCore.Diagnostics;
using System.Text.RegularExpressions;

namespace MPDS.API.Utilities
{
    public class MiLoginDetails
    {
         

        public static string GetToken(string code, string client_id, string client_secret, string redirect_uri, string token)
        {
            if ((code.Contains("undefined")) || (code.Equals(string.Empty)))
            {
                return null;
            }
            try
            {
              

                var values = new Dictionary<string, string>
                {
                    { "grant_type", "authorization_code" },
                    { "client_id", client_id},
                    { "client_secret", client_secret },
                    { "code" , code },
                    { "redirect_uri", redirect_uri}
                };

                HttpClient tokenClient = new HttpClient();
                var content = new FormUrlEncodedContent(values);
                var response = tokenClient.PostAsync(token, content).Result;

                if (response.IsSuccessStatusCode)
                {
                    var responseContent = response.Content;

                    return responseContent.ReadAsStringAsync().Result;
                }
                else
                    return null;

            }
            catch (Exception ex)
            {
                //_logger.LogExceptionAsync(new Exception("MiLogin config entries error:"), "Admin");
                throw; //+ response.StatusCode);
            }
        }
    }
}
