﻿using System;
using System.Net;
//using ssrsReportService;

namespace MPDS.API.Utilities
{

    public class SSRSReportHelper
    {
        public byte[] GetReport(string reportPath, string reportFormat, string username, string password)
        {
            //// Initialize the ReportExecutionService
            //ReportExecutionService rs = new ReportExecutionService();

            //// Set up the URL of the SSRS ReportExecution2005.asmx web service
            //rs.Url = "https://hcv491msqltdm01.ngds.state.mi.us/ReportServer/ReportService2010.asmx";

            //// Set credentials
            //rs.Credentials = new NetworkCredential("mpds", "Pass__123");

            //// Prepare variables for the report rendering
            //string historyID = null;
            //string deviceInfo = "<DeviceInfo></DeviceInfo>";
            //ExecutionInfo execInfo = new ExecutionInfo();
            //ExecutionHeader execHeader = new ExecutionHeader();

            //// Prepare report parameters (if needed)
            //ParameterValue[] parameters = new ParameterValue[0]; // Set report parameters here if needed

            //// Load the report
            //rs.ExecutionHeaderValue = execHeader;
            //execInfo = rs.LoadReport(reportPath, historyID);

            //// Set any parameters here
            //rs.SetExecutionParameters(parameters, "en-us");

            //// Define the report format (e.g., PDF, Excel, etc.)
            //string format = reportFormat; // Example: "PDF"
            //string extension;
            //string mimeType;
            //string encoding;
            //Warning[] warnings = null;
            //string[] streamIDs = null;

            //// Render the report
            //byte[] result = rs.Render(format, deviceInfo, out extension, out mimeType, out encoding, out warnings, out streamIDs);

            //return result;
            return null;
        }
    }
}
