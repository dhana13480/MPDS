﻿using Microsoft.Data.SqlClient;

namespace MPDS.API.Models.DTO
{
    public class MasterProgramNameDto
    {
        public Int32? ProgramId { get; set; }
        public string? ProgramName { get; set; }
        public Int32 Id { get; set; }
        public string? Name { get; set; }
        public bool? IsActive { get; set; }
        public string? Description { get; set; }
        public long? DeactivatedBy { get; set; }
        public long? CreatedBy { get; set; }
        public DateTime? CreationDate { get; set; }
        public long? UpdatedBy { get; set; }
        public DateTime? UpdationDate { get; set; }
        public DateTime? DeactivatedDate { get; set; }
    }
}
