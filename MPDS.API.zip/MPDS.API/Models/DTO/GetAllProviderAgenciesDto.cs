﻿namespace MPDS.API.Models.DTO
{
    public class GetAllProviderAgenciesDto
    {
        public int id { get; set; }
        public string? CoordinatingAgencyIds { get; set; }
        public bool? IsActive { get; set; }
        public int? count { get; set; } = 10;
        public int? pageNumber { get; set; }
        public short sortOrder { get; set; }
        public short sortId { get; set; }
    }
}
