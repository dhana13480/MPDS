﻿using System.ComponentModel.DataAnnotations;

namespace MPDS.API.Models.DTO
{
    public class UserPermissionsDto
    {
        [Key]
        public short PermissionId { get; set; }
        public string? Permission { get; set; }
    }
}
