﻿namespace MPDS.API.Models.DTO
{
    public class MasterGrpOptionalDataDto
    {
        public Int32 Id { get; set; }
        public string? FieldName { get; set; }
        public string? Description { get; set; }

    }
}

