﻿namespace MPDS.API.Models.DTO
{
    public class MasterServiceDomainDto
    {
        public int id { get; set; }
        public string? code { get; set; }
        public string? serviceDomain { get; set; }
        public string? description { get; set; }
    }
}
