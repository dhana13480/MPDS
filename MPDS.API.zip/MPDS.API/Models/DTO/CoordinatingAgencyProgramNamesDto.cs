﻿namespace MPDS.API.Models.DTO
{
    public class CoordinatingAgencyProgramNamesDto
    {
        public int? Id { get; set; }
        public long? CoordinatingAgencyId { get; set; }
        public int? ProgramNameId { get; set; }
    }
}
