﻿namespace MPDS.API.Models.DTO
{
    public class MasterGroupTypeDto
    {
        public int Id { get; set; }
        public string? GroupType { get; set; }
        public string? Description { get; set; }
    }
}
