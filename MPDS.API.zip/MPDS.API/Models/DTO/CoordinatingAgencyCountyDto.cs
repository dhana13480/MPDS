﻿namespace MPDS.API.Models.DTO
{
    public class CoordinatingAgencyCountyDto
    {
        public int? Id { get; set; }
        public long? CoordinatingAgencyId { get; set; }
        public int? CountyId { get; set; }
        //public string? County { get; set; }
    }
}
