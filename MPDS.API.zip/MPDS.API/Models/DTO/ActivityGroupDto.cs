﻿namespace MPDS.API.Models.DTO
{
    public class ActivityGroupDto
    {
        public long Id { get; set; }
        public string? Name { get; set; }
        public bool IsActive { get; set; }
        public int? GroupType { get; set; }
        public int? ProgramType { get; set; }
        public string? strGroupType { get; set; }
        public string? strProgramType { get; set; }
        public bool? ProviderAgencyStatus { get; set; }
        public bool? CoordinatingAgencyStatus { get; set; }
        public int? ActivityCount { get; set; }
        public string? ProgramName { get; set; }
        public long? Row_Numb { get; set; }
        public long? CoordinatingAgencyId { get; set; }
        public long? ProviderAgencyId { get; set; }
        public long? ProgramNameId { get; set; }
        public bool IsYATRelated { get; set; }
        public bool? IsGamblingRelated { get; set; }
        public int? MinActivityCount { get; set; }
        public int? MaxActivityCount { get; set; }
        public int? InterventionType { get; set; }
        public int? ServiceDomain { get; set; }
        public int? ServiceLocation { get; set; }
        public int? EBPServiceType { get; set; }
        public string? Comments { get; set; }
        //public int? EBPCycle { get; set; }
        public long? GroupOptionalDataId { get; set; }
        public bool IsDeleted { get; set; }
        //public int? IntendedPopulationId { get; set; }
        //public int? ServiceSettingId { get; set; }
        //public string? EBPServiceType { get; set; }
        public long? CreatedBy { get; set; }
        public long? UpdatedBy { get; set; }
        //public int? MasterStrategyEmployed { get; set; }
        public string? UpdationDate { get; set; }
        public string? OtherProgramName { get; set; }
        public int? userTypeId { get; set; }
        //public int userCoordinatingAgencyId { get; set; }
        //public int userProviderAgencyId { get; set; }
        public string? permissions { get; set; }
        public int? ServicePopulation { get; set; }
        public int? FundingSource { get; set; }
    }
}
