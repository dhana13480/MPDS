﻿namespace MPDS.API.Models.DTO
{
    public class MasterEBPServiceTypeDto
    {
        public int Id { get; set; }
        public string? EBPServiceType { get; set; }
        public string? Description { get; set; }
        public bool IsActive { get; set; }
    }
}
