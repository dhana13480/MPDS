﻿namespace MPDS.API.Models.DTO
{
    public class CoordinatingAgencySchoolDistrictDto
    {
        public int? Id { get; set; }
        public long? CoordinatingAgencyId { get; set; }
        public int? SchoolDistrictId { get; set; }
    }
}
