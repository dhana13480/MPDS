﻿namespace MPDS.API.Models.DTO
{
    public class ActivityParticipantAgeGroupDto
    {
        public long? Id { get; set; }
        public long? ActivityId { get; set; }
        public int? ParticipantAgeGroupId { get; set; }
        public int? NoOfAttendees { get; set; }
    }
}
