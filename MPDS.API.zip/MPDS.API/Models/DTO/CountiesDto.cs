﻿namespace MPDS.API.Models.DTO
{
    public class CountiesDto
    {
        public int Id { get; set; }
        public string? County { get; set; }
        public string? Description { get; set; }
        public bool IsActive { get; set; }
        public long? CreatedBy { get; set; }
        public DateTime? CreationDate { get; set; }
        public long? UpdatedBy { get; set; }
        public DateTime? UpdationDate { get; set; }  
        //public int TempOldId { get; set; }
    }
}
