﻿namespace MPDS.API.Models.DTO
{
    public class ProviderAgencyCountyDto
    {
        public int? Id { get; set; }
        public long? ProviderAgencyId { get; set; }
        public int? CountyId { get; set; }
        public string? CountyName { get; set; }
    }
}
