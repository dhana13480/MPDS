﻿namespace MPDS.API.Models.DTO
{
    public class MasterInterventionTypeDto
    {
        public int Id { get; set; }
        public string? InterventionType { get; set; }
        public string? Description { get; set; }
    }
}
