﻿namespace MPDS.API.Models.DTO
{
    public class MasterSchoolDistrictDto
    {
        public int Id { get; set; }
        public string? SchoolDistrict { get; set; }
        public string? Description { get; set; }
        public bool? IsActive { get; set; }
        public int? CountyId { get; set; }
    }
}
