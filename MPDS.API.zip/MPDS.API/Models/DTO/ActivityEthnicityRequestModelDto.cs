﻿namespace MPDS.API.Models.DTO
{
    public class ActivityEthnicityRequestModelDto
    {
        public int HispanicLatinoEthnicity { get; set; }
        public int ArabAmericanCanadianEthnicity { get; set; }
        public int NotListed { get; set; }
        public long ActivityId { get; set; }
    }
}
