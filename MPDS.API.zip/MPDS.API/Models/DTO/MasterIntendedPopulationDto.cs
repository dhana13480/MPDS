﻿namespace MPDS.API.Models.DTO
{
    public class MasterIntendedPopulationDto
    {
        public int id { get; set; }
        public string? code { get; set; }
        public string? intendedPopulation { get; set; }
        public string? description { get; set; }
    }
}
