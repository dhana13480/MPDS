﻿namespace MPDS.API.Models.DTO
{
    public class UserInfoDto
    {
        public long Id { get; set; }
        public string? FirstName { get; set; }
        public string? MiddleName { get; set; }
        public string? LastName { get; set; }
        public string? UserName { get; set; }
        public string? Password { get; set; }
        public String? FullName
        {
            get
            {
                return FirstName + " " + LastName;
            }
        }
        public string? Email { get; set; }
        public string? Phone { get; set; }
        public int? UserTypeId { get; set; }
        public long? CoordinatingAgencyId { get; set; }
        public string? CoordinatingAgency { get; set; }
        public long? ProviderAgencyId { get; set; }
        public string? ProviderAgency { get; set; }
        public string? Permissions { get; set; }
        public string? Address1 { get; set; }
        public string? Address2 { get; set; }
        public string? City { get; set; }
        public short? StateId { get; set; }
        public string? Zip { get; set; }
        public string? Comments { get; set; }
        public bool IsActive { get; set; }
        public bool  CoordinatingAgencyStatus { get; set; }
        public bool PAStatus { get; set; }

        public bool IsPasswordResetRequired { get; set; }
        public bool IsDeleted { get; set; }
        public long? CreatedBy { get; set; }
        public DateTime? CreationDate { get; set; }
        public long? UpdatedBy { get; set; }
        public DateTime? UpdationDate { get; set; } = DateTime.UtcNow;
        public string? HashingAlgorithm { get; set; }
        public string? csvProviderAgencies { get; set; }
        public string? csvCoordinatingAgencies { get; set; }
        public string? miloginusername { get; set; }
        public string? MPDSEnvironment { get; set; }
        public string? mpdsVersion { get; set; }
    }
}
