﻿namespace MPDS.API.Models.DTO
{
    public class ActivityParticipantAgeGroupModelDto
    {
        public int ZeroTo5 { get; set; }
        public int SixTo12 { get; set; }
        public int ThirteenTo17 { get; set; }
        public int EighteenTo20 { get; set; }
        public int TwentyOneTo24 { get; set; }
        public int TwentyFiveTo44 { get; set; }
        public int FortyFiveTo64 { get; set; }
        public int SixtyFiveTo74 { get; set; }
        public int SeventyFivePlus { get; set; }
        public long ActivityId { get; set; }
    }
}
