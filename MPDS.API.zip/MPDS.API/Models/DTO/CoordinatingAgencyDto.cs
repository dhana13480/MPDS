﻿namespace MPDS.API.Models.DTO
{
    public class CoordinatingAgencyDto
    {
        public long Id { get; set; }

        /// <summary>
        /// CA Unique key of old database(used for migration)
        /// </summary>
        //public Guid? UKeyOldCa { get; set; }

        /// <summary>
        /// Organization Unique Key of old Database(used for migration)
        /// </summary>
        //public Guid? UKeyOldOrg { get; set; }

        /// <summary>
        /// Name of CoordinatingAgencyId
        /// </summary>
        public string Name { get; set; } = null!;

        /// <summary>
        /// If CoordinatingAgency is active or inactive in system
        /// </summary>
        public bool? IsActive { get; set; }

        /// <summary>
        /// Office Phone of Coordinating Agency
        /// </summary>
        public string OfficePhone { get; set; } = null!;

        /// <summary>
        /// Fax Number of Coordinating Agency
        /// </summary>
        public string Fax { get; set; } = null!;

        /// <summary>
        /// Address1 of Coordinating Agency
        /// </summary>
        public string Address1 { get; set; } = null!;

        /// <summary>
        /// Address2 of Coordinating Agency
        /// </summary>
        public string Address2 { get; set; } = null!;

        /// <summary>
        /// City of Coordinating Agency
        /// </summary>
        public string City { get; set; } = null!;

        /// <summary>
        /// State of Coordinating Agency(Foreign Key to Master_State)
        /// </summary>
        public short State { get; set; }

        /// <summary>
        /// Zip of Coordinating Agency
        /// </summary>
        public string Zip { get; set; } = null!;

        /// <summary>
        /// Additional Comments/Notes related to Coordinating Agency
        /// </summary>
        public string Comments { get; set; } = null!;

        /// <summary>
        /// Not being used in new database
        /// </summary>
        public string? AddressComments { get; set; }

        /// <summary>
        ///  First Name of Prevention Coordinator of Coordinating Agency
        /// </summary>
        public string? Pc_FirstName { get; set; }

        /// <summary>
        /// Middle Name of Prevention Coordinator of Coordinating Agency
        /// </summary>
        public string? Pc_MiddleName { get; set; }

        /// <summary>
        /// Last Name of Prevention Coordinator of Coordinating Agency
        /// </summary>
        public string? Pc_LastName { get; set; }

        /// <summary>
        /// EmailId of Prevention Coordinator of Coordinating Agency
        /// </summary>
        public string? Pc_Email { get; set; }

        /// <summary>
        /// Office Phone of Prevention Coordinator of Coordinating Agency
        /// </summary>
        public string? Pc_OfficePhone { get; set; }

        /// <summary>
        /// Cell Phone Number of Prevention Coordinator of Coordinating Agency
        /// </summary>
        public string? Pc_CellPhone { get; set; }

        /// <summary>
        /// Additoinal Comments/Notes related to Prevention Coordinator of Coordinating Agency
        /// </summary>
        public string? Pc_Comments { get; set; }

        /// <summary>
        /// User who created the Coordinating Agency
        /// </summary>
        public long CreatedBy { get; set; }

        /// <summary>
        /// Date of creation of Coordinating Agency
        /// </summary>
        //public DateTime CreationDate { get; set; }

        /// <summary>
        /// User who last updated the Coordinating Agency
        /// </summary>
        public long? UpdatedBy { get; set; }

        /// <summary>
        /// Date when Coordinating Agency was last updated
        /// </summary>
        public string? OptionalData { get; set; }

        public string? Counties { get; set; }
        public string? SchoolDistricts { get; set; }
        public string? ProgramNames { get; set; }
    }
}
