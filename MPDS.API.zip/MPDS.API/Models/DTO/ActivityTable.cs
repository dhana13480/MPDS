﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;

namespace MPDS.API.Models.DTO
{
    public class ActivityTable
    {
        public long? Id { get; set; }
        public string? ActivityName { get; set; }
        public long? GroupId { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public int? TotalAttendees { get; set; }
        public int? NewMaleAttendees { get; set; }
        public int? NewFemaleAttendees { get; set; }
        public int? NewTransManAttendees { get; set; }
        public int? NewTransWomanAttendees { get; set; }
        public int? NewGenderNonConformingAttendees { get; set; }
        public int? NewOtherAttendees { get; set; }
        public int? MasterStrategyEmployed { get; set; }
        public int? EstimatePeopleReached { get; set; }
        public int? AttendeesCompletingGroup { get; set; }
        public long? ActivityOptionalDataId { get; set; }
        public bool? IsActive { get; set; }
        public bool? IsDeleted { get; set; }
        public bool? IsTobaccoRelated { get; set; }
        public int? RecordNumber { get; set; }
        public bool? IsVerified { get; set; }

        public DateTime? VerifiedOn { get; set; }


        public bool? IsFirstActivityInGroup { get; set; }
        public string? VerifiedByName { get; set; }
        public long? VerifiedBy { get; set; }
        public string? Comments { get; set; }
        public string? VerifyComments { get; set; }
        public long? CreatedBy { get; set; }
        public DateTime? CreationDate { get; set; }
        public long? UpdatedBy { get; set; }
        public DateTime? UpdationDate { get; set; }
        public int? OrderNumber { get; set; }
        public int? FundingSource { get; set; }
        public int? ServicePopulation { get; set; }
        public int? TotalPeopleReached { get; set; }
        public int? TotalImpressions { get; set; }
        public string? SocialMediaUsed { get; set; }
        public string? MethodsUsed { get; set; }
        public int? TotalPSA { get; set; }

    }
}
