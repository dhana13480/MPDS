﻿namespace MPDS.API.Models.DTO
{
    public class MasterServiceSettingDto
    {
        public int Id { get; set; }
        public string? Code { get; set; }
        public string? ServiceSetting { get; set; }
        public string? Description { get; set; }
    }
}
