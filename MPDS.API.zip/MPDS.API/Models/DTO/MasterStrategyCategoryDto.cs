﻿namespace MPDS.API.Models.DTO
{
    public class MasterStrategyCategoryDto
    {
        public int Id { get; set; }
        public string? StrategyCategory { get; set; }
        public string? Description { get; set; }
    }
}
