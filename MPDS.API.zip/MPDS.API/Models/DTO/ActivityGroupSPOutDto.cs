﻿namespace MPDS.API.Models.DTO
{
    public class ActivityGroupSPOutDto
    {
        public long Id { get; set; }
        public string? Name { get; set; }
        public bool IsActive { get; set; }
        public string? GroupType { get; set; }
        public string? ProgramType { get; set; }
        public bool? ProviderAgencyStatus { get; set; }
        public bool? CoordinatingAgencyStatus { get; set; }
        public int? ActivityCount { get; set; }
        public string? ProgramName { get; set; }
        public long? Row_Numb { get; set; }
        public long? CoordinatingAgencyId {  get; set; }    
        public long? ProviderAgencyId { get; set;}
        public long? ProgramNameId { get; set;}
    }
}
