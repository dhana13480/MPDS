﻿namespace MPDS.API.Models.DTO
{
    public class ActivitiesDto
    {
        public long? Id { get; set; }
        public string? ActivityName { get; set; }
        public long? GroupId { get; set; }

        public int? TotalAttendees { get; set; }
        public int? NewMaleAttendees { get; set; }
        public int? NewFemaleAttendees { get; set; }
        public int? NewTransManAttendees { get; set; }
        public int? NewTransWomanAttendees { get; set; }
        public int? NewGenderNonConformingAttendees { get; set; }
        public int? NewOtherAttendees { get; set; }
        public int? MasterStrategyEmployed { get; set; }
        public int? EstimatePeopleReached { get; set; }
        public int? AttendeesCompletingGroup { get; set; }
        public long? ActivityOptionalDataId { get; set; }
        //public bool? IsActive { get; set; }
        public bool? IsDeleted { get; set; }
        public bool? IsTobaccoRelated { get; set; }
        public bool? IsFirstActivityInGroup { get; set; }
        public bool? IsVerified { get; set; }
        public long? VerifiedBy { get; set; }
        public int? RecordNumber { get; set; }
        public DateTime? VerifiedOn { get; set; }
        public string? VerifiedByName { get; set; }
        public string? Comments { get; set; }
        public string? VerifyComments { get; set; }
        public long? CreatedBy { get; set; }
        public DateTime? CreationDate { get; set; }
        public long? UpdatedBy { get; set; }
        public DateTime? UpdationDate { get; set; }
        public int? OrderNumber { get; set; }
        public long? ProgramNameId { get; set; }
        public long? ProviderAgencyId { get; set; }
        public long? CoordinatingAgencyId { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public string? Status { get; set; }
        public int? numberOfOriginalItemsCreated { get; set; }
        public int? numberOfBrochuresDistributed { get; set; }
        public int? IndirectSpeakingEngagementReach { get; set; }
        public int? IndirectSpeakingEngagementCount { get; set; }
        public string?  IsSchoolBasedActivity { get; set; }
        public int? SchoolDistrictId { get; set; }
        public int? CountyId { get; set; }
        public string? LocationZipCode { get; set; }
        public int? ServiceSettingId { get; set; }
        public long? ActivityOptionalId { get; set; }
        //public int? count { get; set; }
        //public int? pageNumber { get; set; }
        //public int? Row_Number { get; set; }
        //public short? SortOrder { get; set; }
        //public short? SortId { get; set; }
        public string? GroupName { get; set; }
        public bool? IsActive { get; set; }
        //Ethnicity
        public long? ActivityEthnicityId { get; set; }
        public int? EthnicityId { get; set; }
        public int? EthnicityNoOfAttendees { get; set; }
        //Race
        public long? ActivityRaceId { get; set; }
        public int? RaceId { get; set; }
        public int? RaceNoOfAttendees { get; set; }
        //ParticipantAgeGroup
        
        public long? ActivityParticipantAgeGroupId { get; set; }
        public int? ParticipantAgeGroupId { get; set; }
        public int? ParticipantAgeGroupNoOfAttendees { get; set; }
        //Activity Staff
        public long? ActivityStaffId { get; set; }
        public long? StaffId { get; set; }
        public int? StrategyId { get; set; }
        public int? Units { get; set; }
        public string? OptionalLocalMBO { get; set; }
        public DateTime? ActivityStaffStartDate { get; set; }
        public DateTime? ActivityStaffEndDate { get; set; }
        public int? PrimaryStrategyEmployedId { get; set; }
        public int? ServicePopulationId { get; set; }
        public int? FundingSourceId { get; set; }
        public int? FundingSource { get; set; }
        public int? TotalPeopleReached { get; set; }
        public int? TotalImpressions { get; set; }
        public string? SocialMediaUsed { get; set; }
        public string? MethodsUsed { get; set; }
        public int? TotalPSA { get; set; }
    }
}
