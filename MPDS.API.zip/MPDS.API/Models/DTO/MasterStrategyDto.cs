﻿namespace MPDS.API.Models.DTO
{
    public class MasterStrategyDto
    {
        public int Id { get; set; }
        public string? Code { get; set; }
        public string? Strategy { get; set; }
        public string? Description { get; set; }
        public int? CategoryId { get; set; }
    }
}
