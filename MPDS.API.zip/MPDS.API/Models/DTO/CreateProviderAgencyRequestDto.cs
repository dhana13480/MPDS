﻿namespace MPDS.API.Models.DTO
{
    public class CreateProviderAgencyRequestDto
    {
        //public long Id { get; set; }

        /// <summary>
        /// Provider Agency Unique Key  from old database(used for migration)
        /// </summary>
        //public Guid? UKeyOld { get; set; }

        /// <summary>
        /// Organisation Unique Key  from old database(used for migration)
        /// </summary>
        //public Guid? UKeyOldOrg { get; set; }

        /// <summary>
        /// Name of Provider Agency
        /// </summary>
        public string? Name { get; set; } = null!;

        /// <summary>
        /// Coordinating Agency linked to Provider Agency (Foreign Key to Coordinating Agency)
        /// </summary>
        public long? CoordinatingAgencyId { get; set; }

        /// <summary>
        /// License Number Of Provider Agency
        /// </summary>
        public string? License { get; set; } = null!;

        /// <summary>
        /// Days allowed for data entry
        /// </summary>
        public int DaysAllowedForDataEntry { get; set; }

        /// <summary>
        /// If Provider Agency is active or inactive in the system
        /// </summary>
        public bool? IsActive { get; set; }

        /// <summary>
        /// Office Phone of Provider Agency
        /// </summary>
        public string? OfficePhone { get; set; } = null!;

        /// <summary>
        /// Fax Number of Provider Agency
        /// </summary>
        public string? Fax { get; set; } = null!;

        /// <summary>
        /// Address1 of Provider Agency
        /// </summary>
        public string? Address1 { get; set; } = null!;

        /// <summary>
        /// Address2 of Provider Agency
        /// </summary>
        public string? Address2 { get; set; } = null!;

        /// <summary>
        /// City of Provider Agency
        /// </summary>
        public string? City { get; set; } = null!;

        /// <summary>
        /// State of Provider Agency (Foreign Key to Master_State)
        /// </summary>
        public short State { get; set; }

        /// <summary>
        /// Zip of Provider Agency
        /// </summary>
        public string? Zip { get; set; } = null!;

        /// <summary>
        /// Additional Comments /Notes related to provider Agency
        /// </summary>
        public string? Comments { get; set; } = null!;

        public string? AddressComments { get; set; }

        /// <summary>
        /// User who created Provider Agency
        /// </summary>
        public long CreatedBy { get; set; }

        /// <summary>
        /// Date when Provider Agency was created
        /// </summary>
        public string? CreationDate { get; set; }

        /// <summary>
        /// User who last updated the Provider Agency
        /// </summary>
        public long? UpdatedBy { get; set; }

        /// <summary>
        /// Date when Provider Agency was last updated
        /// </summary>
        //public DateTime? UpdationDate { get; set; }

        public string? OptionalData { get; set; }
        public string? Counties { get; set; }
        public string? SchoolDistricts { get; set; }

        //public Guid? GuidId { get; set; }
    }
}
