﻿namespace MPDS.API.Models.DTO
{
    public class MasterStatesDto
    {
        /// <summary>
        /// Primary Key
        /// </summary>
        public short Id { get; set; }
        public string State { get; set; } = null!;

        /// <summary>
        /// State Description
        /// </summary>
        public string Description { get; set; } = null!;

        /// <summary>
        /// Unique Key of Service State from old database(used for migration)
        /// </summary>
        public int? TempOldId { get; set; }
    }
}
