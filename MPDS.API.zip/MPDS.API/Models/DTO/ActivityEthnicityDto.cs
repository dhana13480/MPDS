﻿namespace MPDS.API.Models.DTO
{
    public class ActivityEthnicityDto
    {
        public long? Id { get; set; }
        public long? ActivityId { get; set; }
        public int? EthnicityId { get; set; }
        public int? NoOfAttendees { get; set; }
    }
}
