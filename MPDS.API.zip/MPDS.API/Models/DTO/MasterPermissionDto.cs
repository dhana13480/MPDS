﻿namespace MPDS.API.Models.DTO
{
    public class MasterPermissionDto
    {
        public short Id { get; set; }
        public string? Permission { get; set; }
    }
}
