﻿namespace MPDS.API.Models.DTO
{
    public class ActivityReportParamDto
    {
        public long? CoordinatingAgencyId { get; set; }
        public long? ProviderAgencyId { get; set; }
        public long? GroupId { get; set; }
        public bool isGamblingRelated { get; set; }
        public string? StartDate { get; set; }
        public string? EndDate { get; set; }
        public int? templateId { get; set; }

    }
}
