﻿namespace MPDS.API.Models.DTO
{
    public class UpdateProgramNameDto
    {
        //public int Id { get; set; }
        //public long? CoordinatingAgencyId { get; set; }
        public int? ProgramNameId { get; set; }
        public string? Name { get; set; } = string.Empty;
        public string? Description { get; set; } = string.Empty;
        public long? CreatedBy { get; set; }
        public long? UpdatedBy { get; set; }
        public DateTime? DeactivatedDate { get; set; }
        public DateTime? CreationDate { get; set; }
        public DateTime? UpdationDate { get; set; }

    }
}
