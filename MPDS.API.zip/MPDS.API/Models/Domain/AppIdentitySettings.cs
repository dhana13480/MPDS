﻿namespace MPDS.API.Models.Domain
{
    public class AppIdentitySettings
    {
        public MILoginSettings MiloginInfo{ get; set; }
    }
    public class MILoginSettings
    {
        public string grant_type { get; set; }
        public string client_id { get; set; }
        public string client_secret { get; set; }
        public string code { get; set; }
        public string redirect_uri { get; set; }
        //Dev/QA/Prod
        public string environment { get; set; }
        public string mpdsVersion { get; set; }
        public string token { get;set; }
        public string client_idTP { get; set; }
        public string client_secretTP { get; set; }
        public string tokenTP { get; set; }
        //SSRS
        public string SSRSWebServiceUrl { get; set; }
        public string SSRSFolder { get; set; }
        public string ReportPath { get; set; }
        public string SSRSUserName   { get; set; }
        public string SSRSPassword { get; set; }
        public string SSRSUrl { get;set; }
        public string UseTestLogin { get; set; }
        public string testLogin { get; set; }
    }
}
