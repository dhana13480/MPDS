﻿using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using System.Xml.Linq;

namespace MPDS.API.Models.Domain
{
    public class ActivityOptionalData
    {
        public long? Id { get; set; }     
        public int? numberOfOriginalItemsCreated { get; set; }
        public int? numberOfBrochuresDistributed { get; set; }       
        public bool IsSchoolBasedActivity { get; set; }
        public int? IndirectSpeakingEngagementReach { get; set; }
        public int? IndirectSpeakingEngagementCount { get; set; }
        public int? SchoolDistrictId { get; set; }
        public int? CountyId { get; set; }
        public string? LocationZipCode { get; set; }        
        public int? ServiceSettingId { get; set; }
         
    }
}
