﻿namespace MPDS.API.Models.Domain
{
    public class ProviderAgencySchoolDistrictRequest
    {         
        public long? ProviderAgencyId { get; set; }        
        //School Dist list should be in csv like 1,2,3,4,5        
        public string? SchoolDistList {  get; set; }
    }
}
