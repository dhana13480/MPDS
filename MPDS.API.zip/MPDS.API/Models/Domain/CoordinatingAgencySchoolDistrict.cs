﻿namespace MPDS.API.Models.Domain
{
    public class CoordinatingAgencySchoolDistrict
    {
        public int? Id { get; set; }
        public long? CoordinatingAgencyId { get; set; }
        public int? SchoolDistrictId { get; set; }         
    }
}
