﻿namespace MPDS.API.Models.Domain
{
    public class CoordinatingAgencyProgramNames
    {
        public int? Id { get; set; }
        public long? CoordinatingAgencyId { get; set; }
        public int? ProgramNameId { get; set; }
    }
}
