﻿namespace MPDS.API.Models.Domain
{
    public class MasterServiceDomain
    {
        public int id { get; set; }
        public string? code { get; set; }
        public string? serviceDomain { get; set; }
        public string? description { get; set; }

    }
}
