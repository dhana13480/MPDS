﻿using Microsoft.AspNetCore.Http.HttpResults;
namespace MPDS.API.Models.Domain
{
    public class ProviderAgencyCounty
    {
        public int? Id { get; set; }
        public long? ProviderAgencyId { get; set; }
        public int? CountyId { get; set; }
        //public string? CountyName { get; set; }
    }
}
