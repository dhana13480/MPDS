﻿namespace MPDS.API.Models.Domain
{
    public class CoordinatingAgencySchoolDistrictRequest
    {
         
        public long? CoordinatingAgencyId { get; set; }        
        //School Dist list should be in csv like 1,2,3,4,5        
        public string? SchoolDistList {  get; set; }

    }
}
