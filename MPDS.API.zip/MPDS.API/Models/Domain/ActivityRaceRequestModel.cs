﻿namespace MPDS.API.Models.Domain
{
    public class ActivityRaceRequestModel
    {
        public int Id { get; set; }
        public int AmericanIndianAlaskanNative { get; set; }
        public int HawaiianPacificIslander { get; set; }
        public int White { get; set; }
        public int Asian { get; set; }
        public int AfricanAmerican { get; set; }
        public int MultiRacial { get; set; }
        public int UnknownOther { get; set; }
        public long ActivityId { get; set; }
     
    }
}
