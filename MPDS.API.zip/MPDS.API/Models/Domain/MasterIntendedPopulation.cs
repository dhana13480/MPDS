﻿namespace MPDS.API.Models.Domain
{
    public class MasterIntendedPopulation
    {
        public int id {  get; set; }
        public string? code { get; set; }
        public string? intendedPopulation { get; set; }
        public string? description { get; set; }
      
    }
}
