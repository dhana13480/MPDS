﻿using Microsoft.AspNetCore.Http.HttpResults;

namespace MPDS.API.Models.Domain
{
    public class ReportsParam
    {         
       // public int? UserTypeId { get; set; }
        public long? CoordinatingAgencyId { get; set; }       
        public long? ProviderAgencyId { get; set; }
        public long? GroupId { get; set; }
        public string startDate { get; set; }
        public string endDate { get; set; }
        public string isGamblingRelated { get; set; }
        public string templateId { get; set; }
        public string reportName { get; set; }
        public string fundSourceId { get; set; }  

    }
}
