﻿namespace MPDS.API.Models.Domain
{
    public class ActivityParticipantAgeGroup
    {
        public long? Id { get; set; }
        public long? ActivityId { get; set; }
        public int? ParticipantAgeGroupId { get; set; }
        public int? NoOfAttendees { get; set; }
         
    }
}
