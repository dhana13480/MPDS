﻿namespace MPDS.API.Models.Domain
{
    public class MasterInterventionType
    {
        public int Id { get; set; }
        public string? InterventionType { get; set; }       
        public string? Description { get; set; }
    }
}
