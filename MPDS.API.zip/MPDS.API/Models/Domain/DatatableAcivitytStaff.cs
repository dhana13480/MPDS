﻿namespace MPDS.API.Models.Domain
{
    public class DatatableAcivitytStaff
    {
        public string? staffName { get; set; }// name
        public string? staffStartDt { get; set; }//start dt
        public string? staffEndDt { get; set; }//end dt
        public string? staffUnits { get; set; }//units
        public string? staffId { get; set; }//id
        public string? activityId { get; set; }
    }
}
