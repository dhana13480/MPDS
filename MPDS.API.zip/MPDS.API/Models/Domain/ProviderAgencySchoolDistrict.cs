﻿namespace MPDS.API.Models.Domain
{
    public class ProviderAgencySchoolDistrict
    {
        public int? Id { get; set; }
        public long? ProviderAgencyId { get; set; }
        public int? SchoolDistrictId { get; set; }         
    }
}
