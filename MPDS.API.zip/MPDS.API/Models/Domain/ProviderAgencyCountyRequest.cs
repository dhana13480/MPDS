﻿namespace MPDS.API.Models.Domain
{
    public class ProviderAgencyCountyRequest
    {
         
        public long? ProviderAgencyId { get; set; }        
        //County list should be in csv like 1,2,3,4,5        
        public string? CountyList {  get; set; }

    }
}
