﻿using Microsoft.AspNetCore.Http.HttpResults;
namespace MPDS.API.Models.Domain
{
    public class MasterGrpOptionalData
    {
        public Int32 Id { get; set; }        
        public string? FieldName { get; set; }
        public string? Description { get; set; }

    }
}
