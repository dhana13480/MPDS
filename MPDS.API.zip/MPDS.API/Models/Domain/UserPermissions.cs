﻿using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;
using System.ComponentModel.DataAnnotations;

namespace MPDS.API.Models.Domain
{
    public class UserPermissions
    {
        [Key]
        public short PermissionId { get; set; }        
        public string? Permission { get; set; }
    }
}