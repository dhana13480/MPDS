﻿namespace MPDS.API.Models.Domain
{
    public class ActivityStaff
    {
        public long? Id { get; set; }
        public long? ActivityId { get; set; }
        public long? StaffId { get; set; }
        public int? StrategyId { get; set; }
        public int? Units { get; set; }
        public string? OptionalLocalMBO { get; set; }
        public DateTime? StartDate { get; set;}
        public DateTime? EndDate { get; set; }
    }
}
