﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations.Schema;

namespace MPDS.API.Models.Domain
{
    [Keyless]
    [NotMapped]
    public class OptionalData
    {
        //public int? id { get; set; }
        public MasterServiceDomain? serviceDomain { get; set; }
        public MasterServiceSetting? serviceSetting  { get; set; }
        public MasterIntendedPopulation? intendedPopulation { get; set; }
        
    }
}
