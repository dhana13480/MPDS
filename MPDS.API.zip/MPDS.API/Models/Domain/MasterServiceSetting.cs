﻿namespace MPDS.API.Models.Domain
{
    public class MasterServiceSetting
    {
        public int id { get; set; }
        public string? code { get; set; }
        public string? serviceSetting { get; set; }
        public string? description { get; set; }
    }
}
