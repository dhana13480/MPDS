﻿namespace MPDS.API.Models.Domain
{
    public class PESRByFundSourceReportResult
    {
        public int? id { get; set; }
        public long? ProviderAgencyId { get; set; }
        public string? ProviderAgency { get; set; }
        public int? StrategyId { get; set; }
        public string? Strategy { get; set; }
        public int? InterventionTypeId { get; set; }
        public string? InterventionType { get; set; }
        public long? GroupCount { get; set; }
        public int? Units { get; set; }
        public int? UnitsAllEBP { get; set; }
        public int? NewAttendeesPopulation { get; set; }
        public int? NewAttendeesIndividual { get; set; }
        public int? FundingSource { get; set; }
    }
}
