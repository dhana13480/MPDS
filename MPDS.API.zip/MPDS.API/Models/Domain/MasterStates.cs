﻿using Microsoft.AspNetCore.Http.HttpResults;
namespace MPDS.API.Models.Domain
{
    public class MasterStates
    {
        /// <summary>
        /// Primary Key
        /// </summary>
        public short Id { get; set; }

        /// <summary>
        /// State Name
        /// </summary>
        public string State { get; set; } = null!;

        /// <summary>
        /// State Description
        /// </summary>
        public string Description { get; set; } = null!;

        /// <summary>
        /// Unique Key of Service State from old database(used for migration)
        /// </summary>
        public int? TempOldId { get; set; }

        //public virtual ICollection<CoordinatingAgency> CoordinatingAgencies { get; set; } = new List<CoordinatingAgency>();

        //public virtual ICollection<ProviderAgency> ProviderAgencies { get; set; } = new List<ProviderAgency>();
        // public virtual ICollection<User> Users { get; set; } = new List<User>();
    }
}
