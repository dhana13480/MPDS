﻿namespace MPDS.API.Models.Domain
{
    public class ActivityReportResult
    {

        public long? PIHPId { get; set; }
        public long? ProviderId { get; set; }
        public long? GroupId { get; set; }
        public string? PIHP { get; set; }
        public string? Provider { get; set; }
        public string? Group { get; set; }
        public string? ProgramName { get; set; }
        public int? GroupMinActivities { get; set; }
        public int? GroupMaxActivities { get; set; }
        public string? GroupNoteText { get; set; }
        public string? Group_Type { get; set; }
        public string? FundingSource { get; set; }
        public string? ServiceDomain { get; set; }
        public string? ProgramType { get; set; }
        public string? EBPServiceType { get; set; }
        public string? InterventionType { get; set; }
        public string? ServicePopulation { get; set; }
        public bool YATRelated { get; set; }
        public bool IsGamblingRelated { get; set; }
        public int? RemainingIncompleteAttendees { get; set; }
        public long? ProgramNameId { get; set; }
        public string? ActivityName { get; set; }
        public string? PrimaryStrategy { get; set; }
        public string? ActivityStartDate { get; set; }
        public string? ActivityStartTime { get; set; }
        public string? ActivityEndDate { get; set; }
        public string? ActivityEndTime { get; set; }
        public int? ActivityDuration { get; set; }
        public int? ActivityUnits { get; set; }

        public string? ActivityCreationDate { get; set; }
        public int? TotalAttendees { get; set; }
        public int? NewMaleAttendees { get; set; }
        public int? NewFemaleAttendees { get; set; }
        public int? NewTransManAttendees { get; set; }
        public int? NewTransWomanAttendees { get; set; }
        public int? NewGenderNonConformingAttendees { get; set; }
        public int? NewOtherAttendees { get; set; }
        public int? NumberCompletingEvent { get; set; }
        public int? EstimatedNumberReached { get; set; }
        public int? ActivityRecordNumber { get; set; }
        public bool ActivityVerified { get; set; }
        public string? ActivityVerifiedOn { get; set; }
        public string? ActivityVerifiedBy { get; set; }
        public int? NumberOriginalItems { get; set; }
        public int? NumberBrochures { get; set; }
        public int? IndirectSpeakingEngagementCount { get; set; }
        public int? IndirectSpeakingEngagementReach { get; set; }
        public bool? SchoolBased { get; set; }
        public string? strSchoolBased { get; set; }
        public string? LocationZipCode { get; set; }
        public string? SchoolDistrict { get; set; }
        public string? County { get; set; }
        public string? ServiceSetting { get; set; }
        public string? ActivityNotes { get; set; }
        public int? AmericanIndianAlaskanNative { get; set; }
        public int? HawaiianPacificIslander { get; set; }
        public int? White { get; set; }
        public int? Asian { get; set; }
        public int? AfricanAmerican { get; set; }
        public int? MultiRacial { get; set; }
        public int? UnknownOther { get; set; }
        public long? ActivityId { get; set; }
        public int? ZeroTo5 { get; set; }
        public int? SixTo12 { get; set; }
        public int? ThirteenTo17 { get; set; }
        public int? EighteenTo20 { get; set; }
        public int? TwentyOneTo24 { get; set; }
        public int? TwentyFiveTo44 { get; set; }
        public int? FortyFiveTo64 { get; set; }
        public int? SixtyFiveTo74 { get; set; }
        public int? SeventyFivePlus { get; set; }
        public int? HispanicLatinoEthnicity { get; set; }
        public int? ArabAmericanCanadianEthnicity { get; set; }
        public int? NotListed { get; set; }
    }
}
