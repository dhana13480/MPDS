﻿namespace MPDS.API.Models.Domain
{
    public class GroupsSearchInput
    {
        public long? GroupId { get; set; }
        public long? ProviderAgencyId { get; set; }//mandatory
        public long? CoordinatingAgencyId { get; set; }// mandatory
        public string? GroupName { get; set; }
        public string? Status { get; set; }
        public bool? IsActive { get; set; }
        public bool? IsDeleted { get; set; }
        public int? count { get; set; }
        public int? pageNumber { get; set; }
        public short sortOrder { get; set; }
        public short sortId { get; set; }
        public long?  ProgramNameId { get; set; }
        public bool? IsGamblingRelated { get; set; }
        public int? userTypeId { get; set; }
        public long userCoordinatingAgencyId { get; set; }
        public long userProviderAgencyId { get; set; }
        public string? permissions { get; set; }
    }
}
