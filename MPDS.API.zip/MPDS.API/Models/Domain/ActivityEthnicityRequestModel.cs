﻿namespace MPDS.API.Models.Domain
{
    public class ActivityEthnicityRequestModel
    {
        public int id { get;set; }
        public long ActivityId { get; set; }
        public int HispanicLatinoEthnicity { get; set; }
        public int ArabAmericanCanadianEthnicity { get; set; }
        public int NotListed { get; set; }
        

    }
}
