﻿namespace MPDS.API.Models.Domain
{
    public class MasterUserType
    {
        public short Id { get; set; }
        public string? Type { get; set; }        
    }
}
