﻿namespace MPDS.API.Models.Domain
{
    public class Enums
    {
        public enum FundingSourceSortBy
        {
            SOURCE = 1,
            DESCRIPTION,
            STATUS
        }

        public enum CountySortBy
        {
            COUNTY = 1,
            DESCRIPTION,
            STATUS
        }

        public enum StaffSortBy
        {

            FIRSTNAME = 1,
            MIDDLENAME,
            LASTNAME,
            EMAIL,
            OFFICEPHONE,
            StaffType,
            IsActive
        }

        public enum UserSortBy
        {

            FIRSTNAME = 1,
            LASTNAME,
            EMAIL,
            OFFICEPHONE,
            USERNAME,
            USERTYPE,
            ISACTIVE

        }

        public enum SchoolDistrictSortBy
        {
            SCHOOLDISTRICT = 1,
            DESCRIPTION,
            STATUS,
            COUNTY_NAME
        }

        public enum UserType
        {
            AUDITOR = 1,
            SUPER_ADMIN,
            PIHP_REGION,
            PROVIDER_AGENCY
        }

        public enum StaffType
        {
            COORDINATING_AGENCY = 1,
            PROVIDER_AGENCY
        }

        public enum GroupOptionalData
        {
            LOCAL_MBO = 1,
            EBP_CYCLE,
            SERVICE_SETTING,
            INTENTED_POPULATION,
            EBP_OTHER_SERVICE_TYPE,
        }

        public enum ActivityOptionalData
        {
            NUMBER_OF_ORIGINAL_ITEMS_CREATED = 1,
            NUMBER_OF_BROCHURES_DISTRIBUTED,
            INDIRECT_SPEAKING_ENGAGEMENT_REACH,
            INDIRECT_SPEAKING_ENGAGEMENT_COUNT,
            SCHOOL_DISTRICT_ID,
            COUNTY_ID,
            LOCATION_ZIP_CODE,
            IS_SCHOOL_BASED_ACTIVITY,
            SERVICE_SETTING_ID
        }

        public enum GroupSortBy
        {
            NAME = 1,
            STATUS,
            GROUP_TYPE,
            PROGRAM_TYPE,
            ACTIVITY_COUNT
        }

        public enum EBPServiceTypeSortBy
        {
            TYPE = 1,
            DESCRIPTION,
            STATUS
        }

        public enum ProviderAgencySortBy
        {
            NAME = 1,
            LICENSE_NUMBER,
            PHONE,
            STATUS
        }

        public enum CoordinatingAgencySortBy
        {
            NAME = 1,
            PHONE,
            STATUS
        }

        public enum ActivitySortBy
        {
            START_DATE = 1,
            GROUP_NAME,
            ACTIVITY_NAME,
            END_DATE,
            RECORD_NUMBER,
            IS_VERIFIED
        }

        public enum ActivityDataFileSortBy
        {

            PIHP = 1,
            PA,
            GROUP,
            MIN_ACTIVITY_COUNT,
            MAX_ACTIVITY_COUNT,
            GROUP_NOTE,
            GROUP_TYPE,
            FUNDING_SOURCE,
            SERVICE_DOMAIN,
            PROGRAM_TYPE,
            EBP_SERVICE_TYPE,
            INTERVENTION_TYPE,
            SERVICE_POPULATION,
            YAT_RELATED,
            ACTIVITY_NAME,
            ACTIVITY_PRIMARY_STRATEGY,
            ACTIVITY_START_DATE,
            ACTIVITY_START_TIME,
            ACTIVITY_END_DATE,
            ACTIVITY_END_TIME,
            ACTIVITY_DURATION,
            ACTIVITY_UNITS,
            ACTIVITY_CREATION_DATE
        }

        public enum SortOrder
        {
            DESC = 0,
            ASC
        }

        public enum GroupType
        {
            ONE_TIME = 1,
            ONGOING_SEQUENTIAL,
            ONGOING_OTHER
        }

        public enum InterventionType
        {
            UNIVERSAL_INDIRECT = 1,
            UNIVERSAL_DIRECT = 2,
            INDICATED = 3,
            SELECTIVE = 5

        }

        public enum UserTypeId
        {
            Auditor = 1,
            Super_Admin = 2,
            Coordinating_Agency = 3,
            Provider_Agency = 4
        }

        public enum Permissions
        {
            MANAGE_STAFF = 1,
            MANAGE_COORDINATING_AGENCY = 2,
            MANAGE_ACTIVITY = 3,
            MANAGE_GROUP = 4,
            MANAGE_USER = 5,
            REPORTS = 6,
            MANAGE_PROVIDER_AGENCY = 7,
            VERIFY_ACTIVITY = 8,
            MANAGE_PROFILE = 9,
            MANAGE_APPLICATION_SETTING = 10,
            MANAGE_MASTER_DATA = 11,
            DELETE_ACTIVITY = 12,
            DELETE_GROUP = 13,
            MANAGE_NOTIFICATIONS = 14
        }

        public enum ActivityReportHeaderGroup
        {
            BASIC = 1,
            GROUP,
            ACTIVITY
        }

        public enum NotificationType
        {
            ALL = 1,
            PIHP,
            PA,
            BOTH
        }

        public enum NotificationSortBy
        {
            TITLE = 1,
            CONTENT,
            START_DATE,
            END_DATE,
            ATTACHMENT_COUNT

        }
    }
}
