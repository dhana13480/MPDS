﻿namespace MPDS.API.Models.Domain
{
    public class viewRemainingIncompleteAttendees
    {
        public int Id { get; set; }
        public long GroupId { get; set; }
        public int? GroupType { get; set; }
        public int? RemainingIncompleteAttendees { get; set;}
    }
}
