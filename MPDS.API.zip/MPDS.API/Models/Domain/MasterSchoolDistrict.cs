﻿using Microsoft.AspNetCore.Http.HttpResults;
namespace MPDS.API.Models.Domain
{
    public class MasterSchoolDistrict
    {
        public int Id { get; set; }        
        public string? SchoolDistrict { get; set; }
        public string? Description { get; set; }
        public bool? IsActive { get; set; }
        public int? CountyId { get; set;}

    }
}
