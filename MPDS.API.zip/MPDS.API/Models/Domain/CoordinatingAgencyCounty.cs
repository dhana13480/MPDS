﻿namespace MPDS.API.Models.Domain
{
    public class CoordinatingAgencyCounty
    {
        public int? Id { get; set; }
        public long? CoordinatingAgencyId { get; set; }
        public int? CountyId { get; set; }
        //public string? County {  get; set; }
    }
}
