﻿using Microsoft.AspNetCore.Http.HttpResults;

namespace MPDS.API.Models.Domain
{
    public class Staff
    {
        public long Id { get; set; }

        /// <summary>
        /// Key in Old Database(used for migration)
        /// </summary>
        public Guid? UKeyOld { get; set; }

        /// <summary>
        /// First Name of Staff Member
        /// </summary>
        public string FirstName { get; set; } = null!;

        /// <summary>
        /// Middle Name of Staff Member
        /// </summary>
        public string MiddleName { get; set; } = null!;

        /// <summary>
        /// Last Name Of Staff Member
        /// </summary>
        public string LastName { get; set; } = null!;

        /// <summary>
        /// Coordinating Agency Id  to which Staff Member is linked(Foreign Key to CoordinatingAgency)
        /// </summary>
        public long? CoordinatingAgencyId { get; set; }

        /// <summary>
        /// Provider Agency Id to which Staff Member is linked(Foreign Key to Provider Agency)
        /// </summary>
        public long? ProviderAgencyId { get; set; }

        /// <summary>
        /// Tenure Start Date
        /// </summary>
        public DateTime? EffectiveFrom { get; set; }

        /// <summary>
        /// Tenure End Date 
        /// </summary>
        public DateTime? EffectiveTo { get; set; }

        /// <summary>
        /// If Staff Member is active or inactive in the system
        /// </summary>
        public bool IsActive { get; set; }

        /// <summary>
        /// Email Id of Staff Member
        /// </summary>
        public string Email { get; set; } = null!;

        /// <summary>
        /// Cell Phone of Staff Member
        /// </summary>
        public string CellPhone { get; set; } = null!;

        /// <summary>
        /// Office Phone of Staff Member
        /// </summary>
        public string OfficePhone { get; set; } = null!;

        /// <summary>
        /// Home Phone of Staff Member
        /// </summary>
        public string HomePhone { get; set; } = null!;

        /// <summary>
        /// Fax Number of Staff Member
        /// </summary>
        public string Fax { get; set; } = null!;

        /// <summary>
        /// Address1  of Staff Member
        /// </summary>
        public string Address1 { get; set; } = null!;

        /// <summary>
        /// Address2 of Staff Member
        /// </summary>
        public string Address2 { get; set; } = null!;

        /// <summary>
        /// City Of Staff Member
        /// </summary>
        public string City { get; set; } = null!;

        /// <summary>
        /// State of Staff Member
        /// </summary>
        public short State { get; set; }

        /// <summary>
        /// Zip of Staff Member
        /// </summary>
        public string Zip { get; set; } = null!;

        /// <summary>
        /// Additional Comments/Notes related to staff Member
        /// </summary>
        public string Comments { get; set; } = null!;

        /// <summary>
        /// Id of User who created the Staff Member
        /// </summary>
        public long CreatedBy { get; set; }

        /// <summary>
        /// Date when Staff Member was created
        /// </summary>
        public DateTime CreationDate { get; set; }

        /// <summary>
        /// User who last updated Staff Member
        /// </summary>
        public long? UpdatedBy { get; set; }

        /// <summary>
        /// Date when Staff Member was last updated
        /// </summary>
        public DateTime? UpdationDate { get; set; }

        /// <summary>
        /// Staff Type of Staff Member(Foreign Key to Master_StaffType)
        /// </summary>
        public short StaffType { get; set; }

        public bool IsDeleted { get; set; }

        //public virtual CoordinatingAgency? CoordinatingAgency { get; set; }
        //public virtual ProviderAgency? ProviderAgency { get; set; }

    }
}
