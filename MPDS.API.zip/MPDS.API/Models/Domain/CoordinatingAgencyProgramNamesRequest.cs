﻿namespace MPDS.API.Models.Domain
{
    public class CoordinatingAgencyProgramNamesRequest
    {
        public long CoordinatingAgencyId { get; set; }
        public string? ProgramNameListCSV { get; set; }
    }
}
