﻿namespace MPDS.API.Models.Domain
{
    public class UserSearchInputParameters
    {
        public short? searchByType { get; set; }
        public string? searchByLastName { get; set; }
        public string? searchByUserName { get; set; }
        public string? searchByEmail { get; set; }
        public long? coordinatingAgencyId { get; set; }
        public long? providerAgencyId { get; set; }

        public int? userTypeId { get; set; }
        public long userCoordinatingAgencyId { get; set; }
        public long userProviderAgencyId { get; set; }
        public string? permissions { get; set; }

    }
}
