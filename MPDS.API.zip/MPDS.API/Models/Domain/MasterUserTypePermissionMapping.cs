﻿using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;

namespace MPDS.API.Models.Domain
{
    public class MasterUserTypePermissionMapping
    {

        public int Id { get; set; }
        public int UserTypeId { get; set; }
        public short PermissionId { get; set; }
    }
}