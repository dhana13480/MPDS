﻿using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;

namespace MPDS.API.Models.Domain
{
    public class ActivityReportParam
    {
        public long? CoordinatingAgencyId { get; set; }
        public long? ProviderAgencyId { get; set; }
        public long? GroupId { get; set; }
        public bool isGamblingRelated { get; set; }
        public string? StartDate { get; set; }
        public string? EndDate { get; set; }
        public int? templateId { get; set; }

    }
}