﻿namespace MPDS.API.Models.Domain
{
    public class CoordinatingAgencyOptionalData
    {
        public int? Id { get; set; }
        public long? CoordinatingAgencyId { get; set; }
        //School Dist list should be in csv like 1,2,3,4,5        
        public int? OptionalDataId { get; set; }
    }
}
