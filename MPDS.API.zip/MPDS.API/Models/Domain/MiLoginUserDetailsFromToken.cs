﻿namespace MPDS.API.Models.Domain
{
    public class MiLoginUserDetailsFromToken
    {
        public string? firstname { get; set; }    
        public string? lastname { get; set; }
        public string? mail { get; set; }
        public string? miloginusername { get; set; }
        

    }
}
