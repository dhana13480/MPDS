﻿namespace MPDS.API.Models.Domain
{
    public class ActivityParticipantAgeGroupModel
    {/*
       ZeroTo5 = 1,
            SixTo12 = 2,
            ThirteenTo17 = 3,            
            EighteenTo20 = 4,
            TwentyOneTo24 = 5,
            TwentyFiveTo44 = 6,
            FortyFiveTo64 = 7,
            SixtyFiveTo74 = 8,
            SeventyFivePlus = 9
      */
        public int Id { get; set; }
        public int ZeroTo5 { get; set; }
        public int SixTo12 { get; set; }
        public int ThirteenTo17 { get; set; }        
        public int EighteenTo20 { get; set; }
        public int TwentyOneTo24 { get; set; }
        public int TwentyFiveTo44 { get; set; }
        public int FortyFiveTo64 { get; set; }
        public int SixtyFiveTo74 { get; set; }
        public int SeventyFivePlus { get; set; }
        public long ActivityId { get; set; }
        public int TotalAgeGrp { get; set; }
    }
}
