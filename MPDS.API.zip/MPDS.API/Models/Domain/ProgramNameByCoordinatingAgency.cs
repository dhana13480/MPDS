﻿using Microsoft.AspNetCore.Http.HttpResults;
namespace MPDS.API.Models.Domain
{
    public class ProgramNameByCoordinatingAgency
    {
        public int? id { get; set; }
        public long? coordinatingAgencyId { get; set; }
        public int? programNameId { get; set; }
        public string? programName { get; set; }  

    }
}
