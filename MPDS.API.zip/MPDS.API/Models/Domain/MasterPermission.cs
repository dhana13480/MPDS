﻿using Microsoft.AspNetCore.Http.HttpResults;
namespace MPDS.API.Models.Domain
{
    public class MasterPermission
    {
        public short Id { get; set; }        
        public string? Permission { get; set; }
        
         
    }
}
