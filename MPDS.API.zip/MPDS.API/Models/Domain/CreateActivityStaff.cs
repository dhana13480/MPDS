﻿namespace MPDS.API.Models.Domain
{
    public class CreateActivityStaff
    {
       // public long? Id { get; set; }
        public int? activityId { get; set; }
        public string? activityOptionalLocalMBO { get; set; }
        public string? activityStaffEndDate { get; set; }
        public long? activityStaffId { get; set; }
        public string? activityStaffStartDate { get; set; }
        public int? activityStrategyId { get; set; }
        public int? Units { get; set; }
        
        
        
         
    }
}
