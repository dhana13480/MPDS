﻿namespace MPDS.API.Models.Domain
{
    public class funcCalculateActivityUnits
    {
        public int Minutes { get; set; }    
    }
}
