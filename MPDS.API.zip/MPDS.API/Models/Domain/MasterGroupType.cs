﻿using Microsoft.AspNetCore.Http.HttpResults;
namespace MPDS.API.Models.Domain
{
    public class MasterGroupType
    {
        public int Id { get; set; }
        public string? GroupType { get; set; }
        public string? Description { get; set; }

    }
}
