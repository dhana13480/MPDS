﻿using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;

namespace MPDS.API.Models.Domain
{
    public class PESRReportParam
    {
        public string? CoordinatingAgencyIds { get; set; }
        public string? ProviderAgencyIds { get; set; }
        //public long? GroupId { get; set; }
        public bool isGamblingRelated { get; set; }
        public string? StartDate { get; set; }
        public string? EndDate { get; set; }
        public string? FundingSourceIds { get; set; }

    }
}