﻿namespace MPDS.API.Models.Domain
{
    public class ActivityCountyRequestModel
    { 
       
        public long ActivityId { get; set; }
        public string? CountyListCSV { get; set; }
        //public bool isChecked { get; set; }

    }
}
