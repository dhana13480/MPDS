﻿using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;

namespace MPDS.API.Models.Domain
{
    public class Activities
    {

        public long? Id { get; set; }
        public string? ActivityName { get; set; }
        public long? GroupId { get; set; }
        //public DateTime? StartDate { get; set; }
        //public DateTime? EndDate { get; set; }
        public int? TotalAttendees { get; set; }
        public int? NewMaleAttendees { get; set; }
        public int? NewFemaleAttendees { get; set; }
        public int? MasterStrategyEmployed { get; set; }
        public int? EstimatePeopleReached { get; set; }
        public int? AttendeesCompletingGroup { get; set; }
        public long? ActivityOptionalDataId { get; set; }
        public bool? IsActive { get; set; }
        public bool? IsDeleted { get; set; }
        public bool? IsTobaccoRelated { get; set; }
        public bool? IsFirstActivityInGroup { get; set; }
        public bool? IsVerified { get; set; }
        public int? RecordNumber { get; set; }
        public string? VerifiedOn { get; set; }
        public string? VerifiedByName { get; set; }
        public string? Comments { get; set; }
        public string? VerifyComments { get; set; }
        public long? CreatedBy { get; set; }
        public string? CreationDate { get; set; }
        public long? UpdatedBy { get; set; }
        public string? UpdationDate { get; set; }
        public int? OrderNumber { get; set; }
        //public long GroupId { get;set; }        
        public long? ProviderAgencyId { get; set; }
        public long? CoordinatingAgencyId { get; set;}
        public string? StartDate { get; set; }
        public string? EndDate { get; set; }
        public string? Status { get; set; }
        public int? count { get; set; }
        public int? pageNumber { get; set; }
        public short? SortOrder { get; set; }
        public short? SortId { get; set; }
        public string? GroupName { get; set; }
        public int? PrimaryStrategyEmployedId { get; set; }
        public int? ServicePopulationId { get; set; }
        public int? FundingSourceId { get; set; }
    }
}