﻿using Microsoft.Data.SqlClient;
using System.Text.RegularExpressions;

namespace MPDS.API.Models.Domain
{
    public class ActivitiesSPInput
    {
        public long? GroupId { get; set; }// mandatory
        public long? ProviderAgencyId { get; set; }//mandatory
        public long? CoordinatingAgencyId { get; set; }
        public string? CreationDate { get; set; }
        public string? StartDate { get; set; }
        public string? EndDate { get; set; }
        public int? RecordNumber { get; set; }
        public string? Status { get; set; }
        public bool? IsActive { get; set; }
        public bool? IsDeleted { get; set; }
        public int? Verified { get; set; }
        public int? count { get; set; }
        public int? pageNumber { get; set; }
        public short sortOrder { get; set; }
        public short sortId { get; set; }
        public long? ActivityId { get; set; }
        public int? userTypeId { get; set; }
        public long userCoordinatingAgencyId { get; set; }
        public long userProviderAgencyId { get; set; }
        public string? permissions { get; set; }
    }
}
