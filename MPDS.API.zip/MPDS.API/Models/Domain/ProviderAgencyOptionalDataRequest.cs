﻿namespace MPDS.API.Models.Domain
{
    public class ProviderAgencyOptionalDataRequest
    {
        public long? ProviderAgencyId { get; set; }
        //School Dist list should be in csv like 1,2,3,4,5        
        public string? OptionalDataList { get; set; }
    }
}
