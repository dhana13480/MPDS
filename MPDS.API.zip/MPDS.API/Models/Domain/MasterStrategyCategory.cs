﻿namespace MPDS.API.Models.Domain
{
    public class MasterStrategyCategory
    {
        public int Id { get; set; }
        public string? StrategyCategory { get; set; }         
        public string? Description { get; set; }
        
    }
}
