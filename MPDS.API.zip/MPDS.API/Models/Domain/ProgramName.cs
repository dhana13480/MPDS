﻿namespace MPDS.API.Models.Domain
{
    public class ProgramName
    {
        public string? Name { get; set; }
        public int Id { get;set; }
    
    }
}
