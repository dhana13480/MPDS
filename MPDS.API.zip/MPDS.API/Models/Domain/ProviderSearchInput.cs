﻿namespace MPDS.API.Models.Domain
{
    public class ProviderSearchInput
    {        
        public string? Name { get; set; }
        public string? Status { get; set; }
        public int? userTypeId { get; set; }
        public int coordinatingAgencyId { get; set; }
        public int providerAgencyId { get; set; }
        public string? permissions { get; set; }
    }
}
