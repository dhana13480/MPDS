﻿namespace MPDS.API.Models.Domain
{
    public class ActivityRace
    {
        public long? Id { get; set; }
        public long? ActivityId { get; set; }
        public int? RaceId { get; set; }
        public int? NoOfAttendees { get; set; }
    }
}
