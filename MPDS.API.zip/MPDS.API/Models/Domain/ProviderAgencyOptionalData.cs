﻿namespace MPDS.API.Models.Domain
{
    public class ProviderAgencyOptionalData
    {
        public int? Id { get; set; }
        public long? ProviderAgencyId { get; set; }
        //School Dist list should be in csv like 1,2,3,4,5        
        public int? OptionalDataId { get; set; }
    }
}
