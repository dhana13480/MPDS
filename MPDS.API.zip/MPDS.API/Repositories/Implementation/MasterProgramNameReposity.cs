﻿using Microsoft.EntityFrameworkCore;
using MPDS.API.Data;
using MPDS.API.Models.Domain;
using MPDS.API.Repositories.Interface;
namespace MPDS.API.Repositories.Implementation
{
    public class MasterProgramNameRepository : IMasterProgramNameRepository
    {
        private readonly MPDSDbContext dbContext;
        public MasterProgramNameRepository(MPDSDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        public async Task<IEnumerable<MasterProgramName>> GetAllAsync()
        {
            try
            {
                return await dbContext.Master_ProgramName.Where (p=>p.DeactivatedDate.Equals(null)). OrderBy(p=> p.Name).ToListAsync();
            }
            catch (Exception ex)
            {
                throw;
            }
        }
       
        public async Task<MasterProgramName?> GetById(int id)
        {
            return await dbContext.Master_ProgramName.FirstOrDefaultAsync(x => x.Id == id);
        }
        public async Task<MasterProgramName?> UpdateAsync(MasterProgramName programName)
        {
            var existingprogramName = await dbContext.Master_ProgramName.FirstOrDefaultAsync(x => x.Id == programName.Id);
            if (existingprogramName != null)
            {
                programName.CreationDate = existingprogramName.CreationDate;
                programName.CreatedBy = existingprogramName.CreatedBy;

                dbContext.Entry(existingprogramName).CurrentValues.SetValues(programName);
                await dbContext.SaveChangesAsync();
                return programName;
            }
            return null;
        }
        public async Task<MasterProgramName> CreateAsync(MasterProgramName programName)
        {
            await dbContext.Master_ProgramName.AddAsync(programName);
            await dbContext.SaveChangesAsync();
            return programName;        
        }

    }
}
