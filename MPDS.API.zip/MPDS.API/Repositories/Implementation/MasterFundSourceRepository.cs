﻿using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.EntityFrameworkCore;
using MPDS.API.Data;
using MPDS.API.Models.Domain;
using MPDS.API.Models.DTO;
using MPDS.API.Repositories.Interface;

namespace MPDS.API.Repositories.Implementation
{
    public class MasterFundSourceRepository : IMasterFundSourceRepository
    {
        private readonly MPDSDbContext dbContext;
        public MasterFundSourceRepository(MPDSDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        public async Task<MasterFundingSource> CreateAsync(MasterFundingSource fund)
        {
            if (fund != null)
            {
                await dbContext.Master_FundingSource.AddAsync(fund);
                await dbContext.SaveChangesAsync();
                return fund;
            }
            else return null;
        }
        
        public async Task<IEnumerable<MasterFundingSource>> GetAllAsync()
        {
            return await dbContext.Master_FundingSource.Where(f=>f.IsActive).OrderBy(f => f.FundingSource).ToListAsync();
        }
        public async Task<MasterFundingSource?> GetById(int id)
        {
            return await dbContext.Master_FundingSource.FirstOrDefaultAsync(x => x.Id == id);
        }

        public async Task<MasterFundingSource?> UpdateAsync(MasterFundingSource fund)
        {
            var existingFund = await dbContext.Master_FundingSource.FirstOrDefaultAsync(x => x.Id == fund.Id);
            if (existingFund != null)
            {
                fund.CreatedBy = existingFund.CreatedBy;
                fund.CreationDate= existingFund.CreationDate;
                fund.UpdationDate = DateTime.Now;
                dbContext.Entry(existingFund).CurrentValues.SetValues(fund);
                await dbContext.SaveChangesAsync();
                return fund;
            }
            return null;

        }

    }
}
