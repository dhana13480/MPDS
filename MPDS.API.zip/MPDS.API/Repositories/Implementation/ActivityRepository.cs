﻿using Azure.Core;
using Microsoft.AspNetCore.Mvc.ApplicationModels;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Query.Internal;
using MPDS.API.Data;
using MPDS.API.Models.Domain;
using MPDS.API.Models.DTO;
using MPDS.API.Repositories.Interface;
using System.ComponentModel;
using System;
using System.Diagnostics;
using System.Globalization;
using System.Text.RegularExpressions;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;
using static System.Runtime.InteropServices.JavaScript.JSType;
using System.Collections.Generic;
using static System.Net.Mime.MediaTypeNames;
using MPDS.API.Utilities;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using Microsoft.AspNetCore.Http.HttpResults;

namespace MPDS.API.Repositories.Implementation
{
    public class ActivityRepository : IActivityRepository
    {
        private readonly MPDSDbContext dbContext;
        public ActivityRepository(MPDSDbContext dbContext)
        {
            this.dbContext = dbContext;
        }
        public static DateTime DateTimeFormatToDate(string dt)
        {
            try
            {
                var culture = System.Globalization.CultureInfo.CurrentCulture;
                return DateTime.ParseExact(dt, "MM/dd/yyyy", culture);
            }
            catch (Exception)
            {
                return DateTime.MinValue;
            }

        }
        public static string DateTimeToDateString(DateTime dt)
        {
            try
            {
                if (dt == DateTime.MinValue)
                    return string.Empty;

                return dt.Date.ToShortDateString();
            }
            catch (Exception)
            {
                return string.Empty; ;
            }
        }
        public static int CalculateActivityUnits(DateTime? startdt, DateTime? enddt)
        {
            int minutes = 0;
            int units = 0;
            try
            {
                if ((startdt is not null) && (enddt is not null))
                {
                    var diffOfDates = (int)enddt.Value.Subtract(startdt.Value).TotalMinutes;

                    minutes = diffOfDates;

                    int remainder = 0;
                    if (minutes == 0) return 0;
                    if (minutes <= 7)
                        units = minutes;
                    if ((minutes > 7) && (minutes <= 15))
                        units = 1;
                    if (minutes > 15)
                    {
                        units = minutes / 15;
                        remainder = minutes % 15;
                        if (remainder > 7)
                            units = units + 1;
                    }
                }
                return units;
            }
            catch (Exception)
            {
                return units;
            }
        }
        public static string DateTimeToTimeString(DateTime dt)
        {
            try
            {
                return dt.Date.ToShortTimeString();
            }
            catch (Exception)
            {
                return null;
            }
        }

        public async Task<ActivitiesDto> CreateAsync(ActivitiesDto activity)
        {

            //Optional Data

            if ((activity.numberOfOriginalItemsCreated != null)
                || (activity.numberOfOriginalItemsCreated > 0)
                || (activity.numberOfBrochuresDistributed != null)
                || (activity.numberOfBrochuresDistributed > 0)
            || (activity.IndirectSpeakingEngagementReach != null)
            || (activity.IndirectSpeakingEngagementReach > 0)
            || (activity.IndirectSpeakingEngagementCount != null)
            || (activity.IndirectSpeakingEngagementCount > 0)
            || (activity.IsSchoolBasedActivity != null)
            || (activity.SchoolDistrictId != null)
            || (activity.SchoolDistrictId > 0)
            || (activity.CountyId != null)
            || (activity.CountyId > 0)
            || (activity.ServiceSettingId != null)
            || (activity.ServiceSettingId > 0)
            || (activity.LocationZipCode != null)
            )
            {
                if (activity.IndirectSpeakingEngagementReach == 0)
                    activity.IndirectSpeakingEngagementReach = null;
                if (activity.numberOfBrochuresDistributed == 0)
                    activity.numberOfBrochuresDistributed = null;
                if (activity.SchoolDistrictId == 0)
                    activity.SchoolDistrictId = null;
                if (activity.CountyId == 0)
                    activity.CountyId = null;
                if (activity.ServiceSettingId == 0)
                    activity.ServiceSettingId = null;

                var activityOptionalDataDetails = new ActivityOptionalData
                {
                    numberOfOriginalItemsCreated = activity.numberOfOriginalItemsCreated,
                    numberOfBrochuresDistributed = activity.numberOfBrochuresDistributed,
                    IndirectSpeakingEngagementReach = activity.IndirectSpeakingEngagementReach,
                    IndirectSpeakingEngagementCount = activity.IndirectSpeakingEngagementCount,
                    IsSchoolBasedActivity = (activity.IsSchoolBasedActivity.Equals("Yes")) ? true : false,
                    SchoolDistrictId = activity.SchoolDistrictId,
                    CountyId = activity.CountyId,
                    ServiceSettingId = activity.ServiceSettingId,
                    LocationZipCode = activity.LocationZipCode
                };

                await dbContext.Activity_OptionalData.AddAsync(activityOptionalDataDetails);
                await dbContext.SaveChangesAsync();
                activity.ActivityOptionalDataId = activityOptionalDataDetails.Id;
            }

            var activityDetails = new ActivityTable
            {
                ActivityName = activity.ActivityName,
                GroupId = activity.GroupId,
                StartDate = activity.StartDate,
                EndDate = activity.EndDate,
                TotalAttendees = activity.TotalAttendees,
                NewMaleAttendees = activity.NewMaleAttendees,
                NewFemaleAttendees = activity.NewFemaleAttendees,
                NewTransManAttendees = activity.NewTransManAttendees,
                NewTransWomanAttendees = activity.NewTransWomanAttendees,
                NewGenderNonConformingAttendees = activity.NewGenderNonConformingAttendees,
                NewOtherAttendees = activity.NewOtherAttendees,
                MasterStrategyEmployed = activity.PrimaryStrategyEmployedId,
                EstimatePeopleReached = activity.EstimatePeopleReached,
                AttendeesCompletingGroup = activity.AttendeesCompletingGroup,
                ActivityOptionalDataId = activity.ActivityOptionalDataId,
                IsActive = true,
                IsDeleted = false,
                IsTobaccoRelated = activity.IsTobaccoRelated,
                IsFirstActivityInGroup = activity.IsFirstActivityInGroup,
                IsVerified = activity.IsVerified,
                VerifiedBy = activity.VerifiedBy,
                RecordNumber = activity.RecordNumber,
                OrderNumber = activity.OrderNumber,
                VerifiedByName = activity.VerifiedByName,
                VerifyComments = activity.VerifyComments,
                Comments = activity.Comments,
                CreatedBy = activity.CreatedBy,
                CreationDate = DateTime.Now,
                UpdatedBy = activity.UpdatedBy,
                UpdationDate = DateTime.Now,
                FundingSource = activity.FundingSourceId,
                ServicePopulation = activity.ServicePopulationId,
                TotalPeopleReached = activity.TotalPeopleReached,
                TotalImpressions = activity.TotalImpressions,
                MethodsUsed = activity.MethodsUsed,
                SocialMediaUsed = activity.SocialMediaUsed,
                TotalPSA = activity.TotalPSA,
            };

            await dbContext.Activity.AddAsync(activityDetails);
            try
            {
                await dbContext.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                //return ("Internal Server Error " + ex.Message);
            }


            //Activity Staff -- need to move it to separate method as many  to one  staff - Activity
            try
            {
                if (activity.StaffId > 0)
                {
                    var activityStaff = new ActivityStaff
                    {
                        ActivityId = activityDetails.Id,
                        StaffId = activity.StaffId,
                        StrategyId = activity.StrategyId,
                        Units = activity.Units,
                        OptionalLocalMBO = activity.OptionalLocalMBO,
                        StartDate = activity.ActivityStaffStartDate,
                        EndDate = activity.ActivityStaffEndDate
                    };
                    await dbContext.Activity_Staff.AddAsync(activityStaff);
                    await dbContext.SaveChangesAsync();
                    activity.ActivityStaffId = activityStaff.Id;
                }
            }
            catch (Exception ex)
            {
                //return BadRequest("Error creating Staff - " + ex.Message);

            }

            activity.Id = activityDetails.Id;

            return activity;
        }

        public async Task<ActivitiesDto> UpdateAsync(ActivitiesDto activity)
        {
            //Activity table
            var activityDetails = new ActivityTable
            {
                Id = activity.Id,
                ActivityName = activity.ActivityName,
                GroupId = activity.GroupId,
                StartDate = activity.StartDate,
                EndDate = activity.EndDate,
                TotalAttendees = activity.TotalAttendees,
                NewMaleAttendees = activity.NewMaleAttendees,
                NewFemaleAttendees = activity.NewFemaleAttendees,
                NewTransManAttendees = activity.NewTransManAttendees,
                NewTransWomanAttendees = activity.NewTransWomanAttendees,
                NewGenderNonConformingAttendees = activity.NewGenderNonConformingAttendees,
                NewOtherAttendees = activity.NewOtherAttendees,
                MasterStrategyEmployed = activity.PrimaryStrategyEmployedId,
                EstimatePeopleReached = activity.EstimatePeopleReached,
                AttendeesCompletingGroup = activity.AttendeesCompletingGroup,
                ActivityOptionalDataId = activity.ActivityOptionalDataId,
                IsActive = true,
                IsDeleted = false,
                IsTobaccoRelated = activity.IsTobaccoRelated,
                IsFirstActivityInGroup = activity.IsFirstActivityInGroup,
                IsVerified = activity.IsVerified,
                VerifiedBy = activity.VerifiedBy,
                RecordNumber = activity.RecordNumber,
                OrderNumber = activity.OrderNumber,
                VerifiedByName = activity.VerifiedByName,
                VerifyComments = activity.VerifyComments,
                VerifiedOn = activity.VerifiedOn,
                Comments = activity.Comments,
                CreationDate = activity.CreationDate,
                CreatedBy = activity.CreatedBy,
                UpdatedBy = activity.UpdatedBy,
                UpdationDate = activity.UpdationDate,
                FundingSource = activity.FundingSourceId,
                TotalPeopleReached = activity.TotalPeopleReached,
                TotalImpressions = activity.TotalImpressions,
                MethodsUsed = activity.MethodsUsed,
                SocialMediaUsed = activity.SocialMediaUsed,
                TotalPSA = activity.TotalPSA,
    };

            var existingActivity = await dbContext.Activity.FirstOrDefaultAsync(x => x.Id == activity.Id);
            if (existingActivity != null)
            {
                if (existingActivity.VerifyComments != "")
                    activityDetails.VerifyComments = existingActivity.VerifyComments + activity.VerifyComments;
                dbContext.Entry(existingActivity).CurrentValues.SetValues(activityDetails);
                await dbContext.SaveChangesAsync();

            }


            //Optional Data
            var activityOptionalDataDetails = new ActivityOptionalData
            {
                Id = activity.ActivityOptionalDataId,
                numberOfOriginalItemsCreated = activity.numberOfOriginalItemsCreated,
                numberOfBrochuresDistributed = activity.numberOfBrochuresDistributed,
                IndirectSpeakingEngagementReach = activity.IndirectSpeakingEngagementReach,
                IndirectSpeakingEngagementCount = activity.IndirectSpeakingEngagementCount,
                IsSchoolBasedActivity = (activity.IsSchoolBasedActivity.Equals("Yes")) ? true : false,
                SchoolDistrictId = activity.SchoolDistrictId,
                CountyId = activity.CountyId,
                ServiceSettingId = activity.ServiceSettingId,
                LocationZipCode = activity.LocationZipCode
            };
            var existingOptionalData = await dbContext.Activity_OptionalData.FirstOrDefaultAsync(x => x.Id == activity.ActivityOptionalDataId);
            if (existingOptionalData != null)
            {
                dbContext.Entry(existingOptionalData).CurrentValues.SetValues(activityOptionalDataDetails);
                await dbContext.SaveChangesAsync();
            }
            return activity;

        }
        public async Task<ActivityStaff> AddStaffForActivity(ActivityStaff activityStaff)
        {
            await dbContext.Activity_Staff.AddAsync(activityStaff);
            await dbContext.SaveChangesAsync();
            return activityStaff;
        }


    
        public async Task<int> GetActivityTotalAttendees(long id)
        {
            var query = from ac in dbContext.Activity
                        where ac.Id == id
                        select new
                        {
                            ac.TotalAttendees
                        };

            var list = await query.ToListAsync().ConfigureAwait(false);
            //todo
            return 0;

        }

        public async Task<ActivitiesDto> GetById(long id)
        //in complete.. not using.. to be cleaned up
        {
            var query = from A in dbContext.Activity
                        join AG in dbContext.ActivityGroup on A.GroupId equals AG.Id
                        join PA in dbContext.ProviderAgency on AG.ProviderAgencyId equals PA.Id
                        join U in dbContext.Users on A.VerifiedBy equals U.Id
                        join AOD in dbContext.Activity_OptionalData on A.ActivityOptionalDataId equals AOD.Id
                        where

                          (A.IsDeleted.Equals(false))

                        select new
                        {
                            A.Id,
                            A.ActivityName,
                            AG.CoordinatingAgencyId,
                            ProviderAgencyId = PA.Id,
                            A.GroupId,
                            GroupName = AG.Name,
                            A.StartDate,
                            A.EndDate,
                            A.TotalAttendees,
                            A.NewMaleAttendees,
                            A.NewFemaleAttendees,
                            A.NewTransManAttendees,
                            A.NewTransWomanAttendees,
                            A.NewGenderNonConformingAttendees,
                            A.NewOtherAttendees,
                            A.MasterStrategyEmployed,
                            A.EstimatePeopleReached,
                            A.AttendeesCompletingGroup,
                            A.ActivityOptionalDataId,
                            A.IsVerified,
                            VerifiedByName = U.UserName,
                            A.VerifyComments,
                            A.OrderNumber,
                            AOD.numberOfOriginalItemsCreated,
                            AOD.numberOfBrochuresDistributed,
                            AOD.IndirectSpeakingEngagementReach,
                            AOD.IndirectSpeakingEngagementCount,
                            AOD.IsSchoolBasedActivity,
                            AOD.SchoolDistrictId,
                            AOD.CountyId,
                            AOD.LocationZipCode,
                            AOD.ServiceSettingId,
                            A.RecordNumber,
                            A.Comments,
                            A.CreationDate,
                            A.IsActive,
                            A.IsDeleted,
                            A.FundingSource,
                            A.TotalPeopleReached,
                            A.TotalImpressions,
                            A.MethodsUsed,
                            A.SocialMediaUsed,
                            A.TotalPSA,
                        };


            var list = await query.FirstOrDefaultAsync(x => x.Id == id);

            return null;



        }
        public async Task<IEnumerable<ActivitiesDto>> GetAllAsync(ActivitiesSPInput inputparam)
        {
            try
            {
                if (inputparam != null)
                {
                    var paramGroupId = new SqlParameter("@GroupId", inputparam.GroupId);
                    var paramProviderAgencyId = new SqlParameter("@ProviderAgencyId", inputparam.ProviderAgencyId);
                    //var paramCoordinatingAgencyId = new SqlParameter("@CoordinatingAgencyId", inputparam.CoordinatingAgencyId);
                    var paramCreationDate = new SqlParameter("@CreationDate", inputparam.CreationDate);
                    var paramStartDate = new SqlParameter("@StartDate", inputparam.StartDate);
                    var paramEndDate = new SqlParameter("@EndDate", inputparam.EndDate);
                    var paramRecordNumber = new SqlParameter("@RecordNumber", inputparam.RecordNumber);


                    try
                    {
                        var query = from A in dbContext.Activity
                                    join AG in dbContext.ActivityGroup on A.GroupId equals AG.Id
                                    join PA in dbContext.ProviderAgency on AG.ProviderAgencyId equals PA.Id

                                    join U in dbContext.Users on A.VerifiedBy equals U.Id
                                       into UTemp
                                    from subgroupU in UTemp.DefaultIfEmpty()
                                    join AOD in dbContext.Activity_OptionalData on A.ActivityOptionalDataId equals AOD.Id
                                        into AODTemp
                                    from subgroupAOD in AODTemp.DefaultIfEmpty()
                                    where
                                      (A.IsDeleted.Equals(false))
                                    orderby A.ActivityName


                                    select new
                                    {
                                        AG.ProgramNameId,
                                        A.Id,
                                        A.ActivityName,
                                        CoordinatingAgencyId=PA.CoordinatingAgencyId,
                                        ProviderAgencyId = PA.Id,
                                        A.GroupId,
                                        GroupName = AG.Name,
                                        A.StartDate,
                                        A.EndDate,
                                        A.TotalAttendees,
                                        A.NewMaleAttendees,
                                        A.NewFemaleAttendees,
                                        A.NewTransManAttendees,
                                        A.NewTransWomanAttendees,
                                        A.NewGenderNonConformingAttendees,
                                        A.NewOtherAttendees,
                                        A.MasterStrategyEmployed,
                                        A.EstimatePeopleReached,
                                        A.AttendeesCompletingGroup,
                                        A.ActivityOptionalDataId,
                                        A.IsVerified,
                                        A.VerifiedByName,
                                        A.VerifyComments,
                                        A.VerifiedOn,
                                        A.VerifiedBy,
                                        A.OrderNumber,
                                        subgroupAOD.numberOfOriginalItemsCreated,
                                        subgroupAOD.numberOfBrochuresDistributed,
                                        subgroupAOD.IndirectSpeakingEngagementReach,
                                        subgroupAOD.IndirectSpeakingEngagementCount,
                                        subgroupAOD.IsSchoolBasedActivity,
                                        subgroupAOD.SchoolDistrictId,
                                        subgroupAOD.CountyId,
                                        subgroupAOD.LocationZipCode,
                                        subgroupAOD.ServiceSettingId,
                                        A.RecordNumber,
                                        A.Comments,
                                        A.CreationDate,
                                        A.IsActive,
                                        A.IsDeleted,
                                        A.FundingSource,
                                        A.ServicePopulation,
                                        A.IsFirstActivityInGroup,
                                        A.TotalPeopleReached,
                                        A.TotalImpressions,
                                        A.MethodsUsed,
                                        A.SocialMediaUsed,
                                        A.TotalPSA
                                    };

                        if (inputparam.GroupId > 0)
                        {
                            query = query.Where(x => x.GroupId.Equals(inputparam.GroupId));
                        }

                        if (inputparam.ProviderAgencyId > 0)
                        {
                            query = query.Where(x => x.ProviderAgencyId.Equals(inputparam.ProviderAgencyId));
                        }
                        else
                        if (inputparam.CoordinatingAgencyId > 0)
                        {
                            query = query.Where(x => x.CoordinatingAgencyId.Equals(inputparam.CoordinatingAgencyId));
                        }

                        if (inputparam.RecordNumber > 0)
                        {
                            query = query.Where(x => x.RecordNumber.Equals(inputparam.RecordNumber));
                        }

                        if (inputparam.CreationDate != null)
                            if (inputparam.CreationDate != "")
                            {
                                query = query.Where(x => x.CreationDate.Value.Date.Equals(DateTimeFormatToDate(inputparam.CreationDate)));
                            }

                        if (inputparam.StartDate != null)
                            if (inputparam.StartDate != "")
                            {
                                query = query.Where(x => x.StartDate.Value.Date.Equals(DateTimeFormatToDate(inputparam.StartDate)));
                            }
                        if (inputparam.EndDate != null)
                            if (inputparam.EndDate != "")
                            {
                                query = query.Where(x => x.EndDate.Value.Date.Equals(DateTimeFormatToDate(inputparam.EndDate)));
                            }
                        if (inputparam.ActivityId != null)
                        {
                            if (inputparam.ActivityId > 0)
                            {
                                query = query.Where(x => x.Id.Equals(inputparam.ActivityId));
                            }
                        }
                        var list = await query.ToListAsync().ConfigureAwait(false);
                        return list
                            .Select(x => new ActivitiesDto()
                            {
                                Id = x.Id,
                                ProviderAgencyId = x.ProviderAgencyId,
                                CoordinatingAgencyId = x.CoordinatingAgencyId,
                                ActivityName = x.ActivityName,
                                GroupId = x.GroupId,
                                GroupName = x.GroupName,
                                StartDate = x.StartDate,
                                EndDate = x.EndDate,
                                RecordNumber = x.RecordNumber,
                                OrderNumber = x.OrderNumber,
                                ActivityOptionalDataId = x.ActivityOptionalDataId,
                                IsActive = x.IsActive,
                                Status = x.IsVerified.Equals(true) ? "Verified" : "Pending",
                                ProgramNameId = x.ProgramNameId,
                                TotalAttendees = x.TotalAttendees,
                                NewMaleAttendees = x.NewMaleAttendees,
                                NewFemaleAttendees = x.NewFemaleAttendees,
                                NewTransManAttendees = x.NewTransManAttendees,
                                NewTransWomanAttendees = x.NewTransWomanAttendees,
                                NewGenderNonConformingAttendees = x.NewGenderNonConformingAttendees,
                                NewOtherAttendees = x.NewOtherAttendees,
                                MasterStrategyEmployed = x.MasterStrategyEmployed,
                                EstimatePeopleReached = x.EstimatePeopleReached,
                                AttendeesCompletingGroup = x.AttendeesCompletingGroup,
                                IsVerified = x.IsVerified,
                                VerifiedByName = x.VerifiedByName,
                                VerifyComments = x.VerifyComments,
                                VerifiedOn = x.VerifiedOn,
                                VerifiedBy = x.VerifiedBy,
                                numberOfOriginalItemsCreated = x.numberOfOriginalItemsCreated,
                                numberOfBrochuresDistributed = x.numberOfBrochuresDistributed,
                                IndirectSpeakingEngagementReach = x.IndirectSpeakingEngagementReach,
                                IndirectSpeakingEngagementCount = x.IndirectSpeakingEngagementCount,
                                Comments = x.Comments,
                                FundingSourceId = x.FundingSource,
                                ServicePopulationId = x.ServicePopulation,
                                PrimaryStrategyEmployedId = x.MasterStrategyEmployed,
                                IsFirstActivityInGroup = x.IsFirstActivityInGroup,
                                TotalPeopleReached = x.TotalPeopleReached,
                                TotalImpressions = x.TotalImpressions,
                                MethodsUsed = x.MethodsUsed,
                                SocialMediaUsed = x.SocialMediaUsed,
                                TotalPSA = x.TotalPSA,
                            }).ToList();

                    }
                    catch (Exception)
                    {
                        throw;
                    }
                }
                return null;
                // return await dbContext.Activity.Take(100).ToListAsync();
            }
            catch (Exception ex)
            {
                throw;
            }
        }



        public async Task<IEnumerable<ActivityRace?>> GetRaceByActivityId(long id)
        {
            try
            {
                var query = from ac in dbContext.Activity_Race
                            where ac.ActivityId == id
                            select new
                            {
                                ac.Id,
                                ac.ActivityId,
                                ac.RaceId,
                                ac.NoOfAttendees
                            };
                var list = await query.ToListAsync().ConfigureAwait(false);
                return list
                    .Select(x => new ActivityRace()
                    {
                        Id = x.Id,
                        ActivityId = x.ActivityId,
                        RaceId = x.RaceId,
                        NoOfAttendees = x.NoOfAttendees
                    }).ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<IEnumerable<ActivityEthnicity?>> GetEthnicityByActivityId(long id)
        {
            try
            {
                var query = from ac in dbContext.Activity_Ethnicity
                            where ac.ActivityId == id
                            select new
                            {
                                ac.Id,
                                ac.ActivityId,
                                ac.EthnicityId,
                                ac.NoOfAttendees
                            };
                var list = await query.ToListAsync().ConfigureAwait(false);
                return list
                    .Select(x => new ActivityEthnicity()
                    {
                        Id = x.Id,
                        ActivityId = x.ActivityId,
                        EthnicityId = x.EthnicityId,
                        NoOfAttendees = x.NoOfAttendees
                    }).ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<IEnumerable<ActivityParticipantAgeGroup?>> GetParticipantAgeGroupByActivityId(long id)
        {
            try
            {
                var query = from ac in dbContext.Activity_ParticipantAgeGroup
                            where ac.ActivityId == id
                            select new
                            {
                                ac.Id,
                                ac.ActivityId,
                                ac.ParticipantAgeGroupId,
                                ac.NoOfAttendees
                            };
                var list = await query.ToListAsync().ConfigureAwait(false);
                return list
                    .Select(x => new ActivityParticipantAgeGroup()
                    {
                        Id = x.Id,
                        ActivityId = x.ActivityId,
                        ParticipantAgeGroupId = x.ParticipantAgeGroupId,
                        NoOfAttendees = x.NoOfAttendees
                    }).ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }
        public async Task<ActivityStaff> CreateActivityStaff(ActivityStaff staff)
        {
            await dbContext.Activity_Staff.AddAsync(staff);
            await dbContext.SaveChangesAsync();
            return staff;
        }
        public async Task<IEnumerable<DatatableAcivitytStaff?>> GetActivityStaffByActivityId(long id)
        {
            try
            {
                var query = from ac in dbContext.Activity_Staff
                            join s in dbContext.Staff on ac.StaffId equals s.Id
                            where ac.ActivityId == id
                            select new
                            {
                                staffName = s.FirstName + " " + s.LastName,
                                staffStartDt = ac.StartDate,
                                staffEndDt = ac.EndDate,
                                staffUnits = ac.Units,
                                staffId = ac.StaffId,
                                activityId = ac.ActivityId,
                            };
                var list = await query.ToListAsync().ConfigureAwait(false);
                return list
                    .Select(x => new DatatableAcivitytStaff()
                    {
                        staffName = x.staffName,
                        staffStartDt = x.staffStartDt.ToString(),
                        staffEndDt = x.staffEndDt.ToString(),
                        staffUnits = x.staffUnits.ToString(),
                        staffId = x.staffId.ToString(),
                        activityId = x.activityId.ToString(),

                    }).ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<IEnumerable<ActivityStaff?>> GetStaffByActivityId(long id)
        {
            try
            {
                var query = from ac in dbContext.Activity_Staff
                            where ac.ActivityId == id
                            select new
                            {
                                ac.Id,
                                ac.ActivityId,
                                ac.StaffId,
                                ac.StrategyId,
                                ac.Units,
                                ac.OptionalLocalMBO,
                                ac.StartDate,
                                ac.EndDate
                            };
                var list = await query.ToListAsync().ConfigureAwait(false);
                return list
                    .Select(x => new ActivityStaff()
                    {
                        Id = x.Id,
                        ActivityId = x.ActivityId,
                        StaffId = x.StaffId,
                        StrategyId = x.StrategyId,
                        Units = x.Units,
                        OptionalLocalMBO = x.OptionalLocalMBO,
                        StartDate = x.StartDate,
                        EndDate = x.EndDate
                    }).ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<IEnumerable<ActivityOptionalData>> GetOptionalDataById(long optionalDataIdid)
        {

            try
            {
                var query = from ac in dbContext.Activity_OptionalData
                            where ac.Id == optionalDataIdid
                            select new
                            {
                                ac.Id,
                                ac.numberOfOriginalItemsCreated,
                                ac.numberOfBrochuresDistributed,
                                ac.IsSchoolBasedActivity,
                                ac.IndirectSpeakingEngagementReach,
                                ac.IndirectSpeakingEngagementCount,
                                ac.SchoolDistrictId,
                                ac.CountyId,
                                ac.LocationZipCode,
                                ac.ServiceSettingId,
                            };
                var list = await query.ToListAsync().ConfigureAwait(false);
                return list
                    .Select(x => new ActivityOptionalData()
                    {
                        Id = x.Id,
                        numberOfOriginalItemsCreated = x.numberOfOriginalItemsCreated,
                        numberOfBrochuresDistributed = x.numberOfBrochuresDistributed,
                        IsSchoolBasedActivity = x.IsSchoolBasedActivity,
                        IndirectSpeakingEngagementReach = x.IndirectSpeakingEngagementReach,
                        IndirectSpeakingEngagementCount = x.IndirectSpeakingEngagementCount,
                        SchoolDistrictId = x.SchoolDistrictId,
                        CountyId = x.CountyId,
                        LocationZipCode = x.LocationZipCode,
                        ServiceSettingId = x.ServiceSettingId,

                    }).ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<ActivityRace?> CreateActivityRace(ActivityRace activity)
        {
            //Race
            if (activity is not null)
                if (activity.RaceId != null)
                {
                    if ((activity.RaceId > 0) && (activity.NoOfAttendees > 0))
                    {
                        var activityRace = new ActivityRace
                        {
                            ActivityId = activity.ActivityId,
                            RaceId = activity.RaceId,
                            NoOfAttendees = activity.NoOfAttendees
                        };

                        await dbContext.Activity_Race.AddAsync(activityRace);
                        await dbContext.SaveChangesAsync();
                        return activityRace;
                    }
                }
            return activity;
        }

        public async Task<ActivityEthnicity?> CreateActivityEthnicity(ActivityEthnicity activity)
        {
            //Ethnicity
            if (activity is not null)
                if (activity.EthnicityId != null)
                {
                    if ((activity.EthnicityId > 0) && (activity.NoOfAttendees > 0))
                    {
                        var activityEthnicity = new ActivityEthnicity
                        {
                            ActivityId = activity.ActivityId,
                            EthnicityId = activity.EthnicityId,
                            NoOfAttendees = activity.NoOfAttendees
                        };

                        await dbContext.Activity_Ethnicity.AddAsync(activityEthnicity);
                        await dbContext.SaveChangesAsync();
                        return activityEthnicity;
                    }
                }
            return activity;
        }

        public Task<ActivityOptionalData> CreateActivityOptionalData(ActivityOptionalData activityOptionalData)
        {
            throw new NotImplementedException();
        }

        public async Task<ActivityParticipantAgeGroup> CreateActivityParticipantAgeGroup(ActivityParticipantAgeGroup activity)
        {
            //Ethnicity
            if (activity is not null)
                if (activity.ParticipantAgeGroupId != null)
                {
                    if ((activity.ParticipantAgeGroupId > 0) && (activity.NoOfAttendees > 0))
                    {
                        var activityParticipantAgeGroup = new ActivityParticipantAgeGroup
                        {
                            ActivityId = activity.ActivityId,
                            ParticipantAgeGroupId = activity.ParticipantAgeGroupId,
                            NoOfAttendees = activity.NoOfAttendees
                        };

                        await dbContext.Activity_ParticipantAgeGroup.AddAsync(activityParticipantAgeGroup);
                        await dbContext.SaveChangesAsync();
                        return activityParticipantAgeGroup;
                    }
                }
            return activity;
        }

        public Task<ActivityStaff> CreateActivityStaffRace(ActivityStaff activityStaff)
        {
            throw new NotImplementedException();
        }

        public async Task<ActivityRace> UpdateActivityRace(ActivityRace activity)
        {
            //Race
            var existingActivity = await dbContext.Activity_Race.FirstOrDefaultAsync(x => (x.ActivityId == activity.ActivityId && x.RaceId == activity.RaceId));
            if (existingActivity != null)
            {
                if (activity.Id != null)
                {
                    activity.Id = existingActivity.Id;
                    dbContext.Entry(existingActivity).CurrentValues.SetValues(activity);
                    await dbContext.SaveChangesAsync();
                }
                else
                {
                    if (activity.RaceId != null)
                    {
                        if ((activity.RaceId > 0) && (activity.NoOfAttendees > 0))
                        {
                            var activityRace = new ActivityRace
                            {
                                ActivityId = activity.ActivityId,
                                RaceId = activity.RaceId,
                                NoOfAttendees = activity.NoOfAttendees
                            };

                            await dbContext.Activity_Race.AddAsync(activityRace);
                            await dbContext.SaveChangesAsync();
                            return activityRace;
                        }
                    }
                }
            }
            else
            {
                if (activity.RaceId != null)
                {
                    if ((activity.RaceId > 0) && (activity.NoOfAttendees > 0))
                    {
                        var activityRace = new ActivityRace
                        {
                            ActivityId = activity.ActivityId,
                            RaceId = activity.RaceId,
                            NoOfAttendees = activity.NoOfAttendees
                        };

                        await dbContext.Activity_Race.AddAsync(activityRace);
                        await dbContext.SaveChangesAsync();
                        return activityRace;
                    }
                }
            }
            return activity;
        }

        public async Task<ActivityEthnicity> UpdateActivityEthnicity(ActivityEthnicity activity)
        {
            //Ethnicity
            var existingActivity = await dbContext.Activity_Ethnicity.FirstOrDefaultAsync(x => (x.ActivityId == activity.ActivityId && x.EthnicityId == activity.EthnicityId));
            if (existingActivity != null)
            {
                if (activity.Id != null)
                {
                    activity.Id = existingActivity.Id;
                    dbContext.Entry(existingActivity).CurrentValues.SetValues(activity);
                    await dbContext.SaveChangesAsync();
                }
                else
                {
                    if ((activity.EthnicityId > 0) && (activity.NoOfAttendees > 0))
                    {
                        var activityEthnicity = new ActivityEthnicity
                        {
                            ActivityId = activity.ActivityId,
                            EthnicityId = activity.EthnicityId,
                            NoOfAttendees = activity.NoOfAttendees
                        };

                        await dbContext.Activity_Ethnicity.AddAsync(activityEthnicity);
                        await dbContext.SaveChangesAsync();
                        return activityEthnicity;
                    }
                }
            }
            else
            {
                if (activity.EthnicityId != null)
                {
                    if ((activity.EthnicityId > 0) && (activity.NoOfAttendees > 0))
                    {
                        var activityEthnicity = new ActivityEthnicity
                        {
                            ActivityId = activity.ActivityId,
                            EthnicityId = activity.EthnicityId,
                            NoOfAttendees = activity.NoOfAttendees
                        };

                        await dbContext.Activity_Ethnicity.AddAsync(activityEthnicity);
                        await dbContext.SaveChangesAsync();
                        return activityEthnicity;
                    }
                }
            }
            return activity;
        }

        public async Task<ActivityOptionalData> UpdateActivityOptionalData(ActivityOptionalData activity)
        {
            //OptionalData
            var existingActivity = await dbContext.Activity_OptionalData.FirstOrDefaultAsync(x => x.Id == activity.Id);
            if (existingActivity != null)
            {
                activity.Id = existingActivity.Id;
                dbContext.Entry(existingActivity).CurrentValues.SetValues(activity);
                await dbContext.SaveChangesAsync();
            }
            return activity;
        }

        public async Task<ActivityParticipantAgeGroup> UpdateActivityParticipantAgeGroup(ActivityParticipantAgeGroup activity)
        {
            //ParticipantAgeGroup
            var existingActivity = await dbContext.Activity_ParticipantAgeGroup.FirstOrDefaultAsync(x => (x.ActivityId == activity.ActivityId && x.ParticipantAgeGroupId == activity.ParticipantAgeGroupId));
            if (existingActivity != null)
            {
                if (activity.Id == null)
                {
                    if ((activity.ParticipantAgeGroupId > 0) && (activity.NoOfAttendees > 0))
                    {
                        var activityParticipantAgeGroup = new ActivityParticipantAgeGroup
                        {
                            ActivityId = activity.ActivityId,
                            ParticipantAgeGroupId = activity.ParticipantAgeGroupId,
                            NoOfAttendees = activity.NoOfAttendees
                        };

                        await dbContext.Activity_ParticipantAgeGroup.AddAsync(activityParticipantAgeGroup);
                        await dbContext.SaveChangesAsync();
                        return activityParticipantAgeGroup;
                    }
                }
                else
                {
                    activity.Id = existingActivity.Id;
                    dbContext.Entry(existingActivity).CurrentValues.SetValues(activity);
                    await dbContext.SaveChangesAsync();
                }
            }
            else
            {
                if ((activity.ParticipantAgeGroupId > 0) && (activity.NoOfAttendees > 0))
                {
                    var activityParticipantAgeGroup = new ActivityParticipantAgeGroup
                    {
                        ActivityId = activity.ActivityId,
                        ParticipantAgeGroupId = activity.ParticipantAgeGroupId,
                        NoOfAttendees = activity.NoOfAttendees
                    };

                    await dbContext.Activity_ParticipantAgeGroup.AddAsync(activityParticipantAgeGroup);
                    await dbContext.SaveChangesAsync();
                    return activityParticipantAgeGroup;
                }
            }
            return activity;
        }

        public async Task<ActivityStaff> UpdateActivityStaff(ActivityStaff activity)
        {
            //ParticipantAgeGroup
            var existingActivity = await dbContext.Activity_Staff.FirstOrDefaultAsync(x => (x.Id == activity.ActivityId && x.StaffId == activity.StaffId));
            if (existingActivity != null)
            {
                activity.Id = existingActivity.Id;
                dbContext.Entry(existingActivity).CurrentValues.SetValues(activity);
                await dbContext.SaveChangesAsync();
            }
            return activity;
        }

        public async Task<IEnumerable<PESRReportResult>> GetPESRReportData(PESRReportParam PESRInputParam)
        {
            var paramCoordinatingAgencyId = new SqlParameter("@CoordinatingAgencyIds", PESRInputParam.CoordinatingAgencyIds);
            var paramProviderAgencyId = new SqlParameter("@ProviderAgencyIds", PESRInputParam.CoordinatingAgencyIds);
            var paramStartDate = new SqlParameter("@StartDate", PESRInputParam.StartDate);
            var paramEndDate = new SqlParameter("@EndDate", PESRInputParam.EndDate);
            var paramFundingSourceIds = new SqlParameter("@FundingSourceIds", PESRInputParam.FundingSourceIds);
            var paramIsGamblingRelated = new SqlParameter("@IsGamblingRelated", PESRInputParam.isGamblingRelated);
            var list = dbContext.Report_PESR.FromSqlRaw("Report_PESR @StartDate,@EndDate,@CoordinatingAgencyIds,@ProviderAgencyIds,@FundingSourceIds,@IsGamblingRelated", paramStartDate, paramEndDate, paramCoordinatingAgencyId, paramProviderAgencyId, paramFundingSourceIds, paramIsGamblingRelated).AsEnumerable().ToList();
            return list;
        }
        public async Task<IEnumerable<PESRByFundSourceReportResult>> GetPESRByFundSourceReportData(PESRReportParam PESRInputParam)
        {
            var paramCoordinatingAgencyId = new SqlParameter("@CoordinatingAgencyIds", PESRInputParam.CoordinatingAgencyIds);
            var paramProviderAgencyId = new SqlParameter("@ProviderAgencyIds", PESRInputParam.CoordinatingAgencyIds);
            var paramStartDate = new SqlParameter("@StartDate", PESRInputParam.StartDate);
            var paramEndDate = new SqlParameter("@EndDate", PESRInputParam.EndDate);
            var paramFundingSourceIds = new SqlParameter("@FundingSourceIds", PESRInputParam.FundingSourceIds);
            var paramIsGamblingRelated = new SqlParameter("@IsGamblingRelated", PESRInputParam.isGamblingRelated);
            var list = dbContext.Report_PESRByFundingSource.FromSqlRaw("Report_PESR_ByFundingSource @StartDate,@EndDate,@CoordinatingAgencyIds,@ProviderAgencyIds,@FundingSourceIds,@IsGamblingRelated", paramStartDate, paramEndDate, paramCoordinatingAgencyId, paramProviderAgencyId, paramFundingSourceIds, paramIsGamblingRelated).AsEnumerable().ToList();
            return list;
        }
        public async Task<IEnumerable<ActivityReportResult>> GetActivityReportData(ActivityReportParam inputparam)
        {
            try
            {
                if (inputparam != null)
                {
                    try
                    {
                        var query = from A in dbContext.Activity
                                    join AG in dbContext.ActivityGroup on A.GroupId equals AG.Id
                                    join PA in dbContext.ProviderAgency on AG.ProviderAgencyId equals PA.Id
                                    join CA in dbContext.CoordinatingAgency on PA.CoordinatingAgencyId equals CA.Id
                                    join U in dbContext.Users on A.VerifiedBy equals U.Id

                                    join AOD in dbContext.Activity_OptionalData on A.ActivityOptionalDataId equals AOD.Id into AODTemp
                                    from AODsubgroup in AODTemp.DefaultIfEmpty()

                                    join MPN in dbContext.Master_ProgramName on AG.ProgramNameId equals MPN.Id into mpnTemp
                                    from MPNsubgroup in mpnTemp.DefaultIfEmpty()
                                    join M_GT in dbContext.Master_GroupType on AG.GroupType equals M_GT.Id into M_GTTemp
                                    from M_GTsubgroup in M_GTTemp.DefaultIfEmpty()
                                    join M_FS in dbContext.Master_FundingSource on AG.FundingSource equals M_FS.Id into M_FSTemp
                                    from M_FSsubgroup in M_FSTemp.DefaultIfEmpty()
                                    join M_SD in dbContext.Master_ServiceDomain on AG.ServiceDomain equals M_SD.id into M_SDTemp
                                    from M_SDsubgroup in M_SDTemp.DefaultIfEmpty()
                                    join M_PT in dbContext.Master_ProgramType on AG.ProgramType equals M_PT.Id into M_PTTemp
                                    from M_PTsubgroup in M_PTTemp.DefaultIfEmpty()
                                    join M_EBP in dbContext.Master_EBPServiceType on AG.EBPServiceType equals M_EBP.Id into M_EBPTemp
                                    from M_EBPsubgroup in M_EBPTemp.DefaultIfEmpty()
                                    join M_IT in dbContext.Master_InterventionType on AG.InterventionType equals M_IT.Id into M_ITTemp
                                    from M_ITsubgroup in M_ITTemp.DefaultIfEmpty()
                                    join M_SP in dbContext.Master_ServicePopulation on AG.ServicePopulation equals M_SP.Id into M_SPTemp
                                    from M_SPsubgroup in M_SPTemp.DefaultIfEmpty()
                                    join remaining in dbContext.vRemainingIncompleteAttendees on AG.Id equals remaining.GroupId into remainingTemp
                                    from remainingSubgroup in remainingTemp.DefaultIfEmpty()
                                    join M_Strategy in dbContext.Master_Strategy on A.MasterStrategyEmployed equals M_Strategy.Id into M_StrategyTemp
                                    from M_StrategySubgroup in M_StrategyTemp.DefaultIfEmpty()

                                    join AOD_SD in dbContext.Master_SchoolDistrict on AODsubgroup.SchoolDistrictId equals AOD_SD.Id into AOD_SDTemp
                                    from AOD_SDSubgroup in AOD_SDTemp.DefaultIfEmpty()
                                    join AOD_County in dbContext.Master_County on AODsubgroup.CountyId equals AOD_County.Id into AOD_CountyTemp
                                    from AOD_CountySubgroup in AOD_CountyTemp.DefaultIfEmpty()

                                    join AOD_SS in dbContext.Master_ServiceSetting on AODsubgroup.ServiceSettingId equals AOD_SS.id into AOD_SSTemp
                                    from AOD_SSSubgroup in AOD_SSTemp.DefaultIfEmpty()
                                    join RaceJoin in dbContext.vActivityRaceAttendees on A.Id equals RaceJoin.ActivityId into RaceJoinTemp
                                    from RaceJoinSubgroup in RaceJoinTemp.DefaultIfEmpty()
                                    join AgeJoin in dbContext.vActivityAgeAttendees on A.Id equals AgeJoin.ActivityId into AgeJoinTemp
                                    from AgeJoinSubgroup in AgeJoinTemp.DefaultIfEmpty()
                                    join EthnicityJoin in dbContext.vActivityEthnicityAttendees on A.Id equals EthnicityJoin.ActivityId into EthnicityJoinTemp
                                    from EthnicityJoinSubgroup in EthnicityJoinTemp.DefaultIfEmpty()

                                    where (A.IsDeleted.Equals(false)) && (AG.IsDeleted.Equals(false)) && (CA.IsActive.Equals(true))

                                    select new
                                    {
                                        ActivityId = A.Id,
                                        PIHPId = CA.Id,
                                        ProviderId = PA.Id,
                                        GroupId = AG.Id,
                                        PIHP = CA.Name,
                                        Provider = PA.Name,
                                        Group = AG.Name,
                                        ProgramName = (AG.ProgramNameId == -2 ? AG.OtherProgramName : MPNsubgroup.Name), //Add else MPN.Name
                                        GroupMinActivities = AG.MinActivityCount,
                                        GroupMaxActivities = AG.MaxActivityCount,
                                        GroupNoteText = AG.Comments,
                                        Group_Type = M_GTsubgroup.GroupType,
                                        FundingSource = M_FSsubgroup.FundingSource,
                                        ServiceDomain = M_SDsubgroup.serviceDomain,
                                        ProgramType = M_PTsubgroup.ProgramType,
                                        EBPServiceType = M_EBPsubgroup.EBPServiceType,
                                        InterventionType = M_ITsubgroup.InterventionType,
                                        ServicePopulation = M_SPsubgroup.Code + " - " + M_SPsubgroup.ServicePopulation,
                                        YATRelated = AG.IsYATRelated,
                                        IsGamblingRelated = AG.IsGamblingRelated,
                                        RemainingIncompleteAttendees = remainingSubgroup.RemainingIncompleteAttendees,
                                        AG.ProgramNameId,
                                        ActivityName = A.ActivityName + " #" + A.OrderNumber.ToString(),
                                        PrimaryStrategy = M_StrategySubgroup.Code + " - " + M_StrategySubgroup.Strategy,
                                        ActivityStartDate = DateTimeToDateString(A.StartDate ?? DateTime.MinValue),
                                        ActivityStartTime = DateTimeToTimeString(A.StartDate ?? DateTime.MinValue),
                                        ActivityEndDate = DateTimeToDateString(A.EndDate ?? DateTime.MinValue),
                                        ActivityEndTime = DateTimeToTimeString(A.EndDate ?? DateTime.MinValue),
                                        ActivityDuration = EF.Functions.DateDiffMinute(A.StartDate, A.EndDate),
                                        ActivityUnits = CalculateActivityUnits(A.StartDate, A.EndDate),
                                        A.StartDate,
                                        A.EndDate,
                                        A.TotalAttendees,
                                        A.NewMaleAttendees,
                                        A.NewFemaleAttendees,
                                        NewTransManAttendees = A.NewTransManAttendees ?? 0,
                                        NewTransWomanAttendees = A.NewTransWomanAttendees ?? 0,
                                        NewGenderNonConformingAttendees = A.NewGenderNonConformingAttendees ?? 0,
                                        NewOtherAttendees = A.NewOtherAttendees ?? 0,
                                        NumberCompletingEvent = A.AttendeesCompletingGroup,
                                        EstimatedNumberReached = A.EstimatePeopleReached,
                                        ActivityVerified = A.IsVerified ?? false,
                                        ActivityVerifiedBy = "", // TODO  U.UserName,
                                        ActivityRecordNumber = A.RecordNumber,
                                        ActivityVerifiedOn = DateTimeToDateString(A.VerifiedOn ?? DateTime.MinValue),
                                        ActivityCreationDate = DateTimeToDateString(A.CreationDate ?? DateTime.MinValue),
                                        NumberOriginalItems = AODsubgroup.numberOfOriginalItemsCreated,
                                        NumberBrochures = AODsubgroup.numberOfBrochuresDistributed,
                                        IndirectSpeakingEngagementCount = AODsubgroup.IndirectSpeakingEngagementCount,
                                        IndirectSpeakingEngagementReach = AODsubgroup.IndirectSpeakingEngagementReach,
                                        strSchoolBased = AODsubgroup.IsSchoolBasedActivity ? "Yes" : "No",
                                        LocationZipCode = AODsubgroup.LocationZipCode,
                                        SchoolDistrict = AOD_SDSubgroup.SchoolDistrict,
                                        County = AOD_CountySubgroup.County,
                                        ServiceSetting = AOD_SSSubgroup.serviceSetting,
                                        ActivityNotes = A.Comments,
                                        WhiteAttendees = RaceJoinSubgroup.White,
                                        MultiRacialAttendees = RaceJoinSubgroup.MultiRacial,
                                        UnknownRaceAttendees = RaceJoinSubgroup.UnknownOther,
                                        IndianAlaskanAttendees = RaceJoinSubgroup.AmericanIndianAlaskanNative,
                                        AfricanAmericanAttendees = RaceJoinSubgroup.AfricanAmerican,
                                        AsianAttendees = RaceJoinSubgroup.Asian,
                                        HawaiianAttendees = RaceJoinSubgroup.HawaiianPacificIslander,
                                        ZeroTo5 = AgeJoinSubgroup.ZeroTo5,
                                        SixTo12 = AgeJoinSubgroup.SixTo12,
                                        ThirteenTo17 = AgeJoinSubgroup.ThirteenTo17,
                                        EighteenTo20 = AgeJoinSubgroup.EighteenTo20,
                                        TwentyOneTo24 = AgeJoinSubgroup.TwentyOneTo24,
                                        TwentyFiveTo44 = AgeJoinSubgroup.TwentyFiveTo44,
                                        FortyFiveTo64 = AgeJoinSubgroup.FortyFiveTo64,
                                        SixtyFiveTo74 = AgeJoinSubgroup.SixtyFiveTo74,
                                        SeventyFivePlus = AgeJoinSubgroup.SeventyFivePlus,
                                        HispanicLatinoEthnicity = EthnicityJoinSubgroup.HispanicLatinoEthnicity,
                                        ArabAmericanCanadianEthnicity = EthnicityJoinSubgroup.ArabAmericanCanadianEthnicity,
                                        NotListed = EthnicityJoinSubgroup.NotListed,


                                    };

                        if (inputparam.GroupId > 0)
                        {
                            query = query.Where(x => x.GroupId.Equals(inputparam.GroupId));
                        }
                        if (inputparam.CoordinatingAgencyId > 0)
                        {
                            query = query.Where(x => x.PIHPId.Equals(inputparam.CoordinatingAgencyId));
                        }
                        if (inputparam.ProviderAgencyId > 0)
                        {
                            query = query.Where(x => x.ProviderId.Equals(inputparam.ProviderAgencyId));
                        }
                        if (inputparam.StartDate != null)
                            if (inputparam.StartDate != "")
                            {
                                query = query.Where(x => x.StartDate.Value.Date >= (DateTimeFormatToDate(inputparam.StartDate)));
                            }
                        if (inputparam.EndDate != null)
                            if (inputparam.EndDate != "")
                            {
                                query = query.Where(x => x.EndDate.Value.Date <= (DateTimeFormatToDate(inputparam.EndDate)));
                            }

                        var list = await query.ToListAsync().ConfigureAwait(false);
                        return list
                            .Select(x => new ActivityReportResult()
                            {
                                ActivityId = x.ActivityId,
                                PIHPId = x.PIHPId,
                                ProviderId = x.ProviderId,
                                GroupId = x.GroupId,
                                PIHP = x.PIHP,
                                Provider = x.Provider,
                                Group = x.Group,
                                ProgramName = x.ProgramName,
                                GroupMinActivities = x.GroupMinActivities,
                                GroupMaxActivities = x.GroupMaxActivities,
                                GroupNoteText = x.GroupNoteText,
                                Group_Type = x.Group_Type,
                                FundingSource = x.FundingSource,
                                ServiceDomain = x.ServiceDomain,
                                ProgramType = x.ProgramType,
                                EBPServiceType = x.EBPServiceType,
                                InterventionType = x.InterventionType,
                                ServicePopulation = x.ServicePopulation,
                                YATRelated = x.YATRelated,
                                IsGamblingRelated = x.IsGamblingRelated ?? false,
                                RemainingIncompleteAttendees = x.RemainingIncompleteAttendees,
                                ProgramNameId = x.ProgramNameId,
                                ActivityName = x.ActivityName,
                                PrimaryStrategy = x.PrimaryStrategy,
                                ActivityStartDate = x.ActivityStartDate,
                                ActivityStartTime = x.ActivityStartTime,
                                ActivityEndDate = x.ActivityEndDate,
                                ActivityEndTime = x.ActivityEndTime,
                                ActivityDuration = x.ActivityDuration,
                                ActivityUnits = x.ActivityUnits,
                                ActivityCreationDate = x.ActivityCreationDate,
                                TotalAttendees = x.TotalAttendees,
                                NewMaleAttendees = x.NewMaleAttendees,
                                NewFemaleAttendees = x.NewFemaleAttendees,
                                NewTransManAttendees = x.NewTransManAttendees,
                                NewTransWomanAttendees = x.NewTransWomanAttendees,
                                NewGenderNonConformingAttendees = x.NewGenderNonConformingAttendees,
                                NewOtherAttendees = x.NewOtherAttendees,
                                NumberCompletingEvent = x.NumberCompletingEvent,
                                EstimatedNumberReached = x.EstimatedNumberReached,
                                ActivityRecordNumber = x.ActivityRecordNumber,
                                ActivityVerified = x.ActivityVerified,
                                ActivityVerifiedOn = x.ActivityVerifiedOn,
                                ActivityVerifiedBy = x.ActivityVerifiedBy,
                                NumberOriginalItems = x.NumberOriginalItems,
                                NumberBrochures = x.NumberBrochures,
                                IndirectSpeakingEngagementCount = x.IndirectSpeakingEngagementCount,
                                IndirectSpeakingEngagementReach = x.IndirectSpeakingEngagementReach,
                                SchoolBased = false, // x.SchoolBased, TODO .. use the strSchoolBased
                                strSchoolBased = x.strSchoolBased,
                                LocationZipCode = x.LocationZipCode,
                                SchoolDistrict = x.SchoolDistrict,
                                County = x.County,
                                ServiceSetting = x.ServiceSetting,
                                ActivityNotes = x.ActivityNotes,
                                White = x.WhiteAttendees,
                                MultiRacial = x.MultiRacialAttendees,
                                UnknownOther = x.UnknownRaceAttendees,
                                AmericanIndianAlaskanNative = x.IndianAlaskanAttendees,
                                AfricanAmerican = x.AfricanAmericanAttendees,
                                Asian = x.AsianAttendees,
                                HawaiianPacificIslander = x.HawaiianAttendees,
                                ZeroTo5 = x.ZeroTo5,
                                SixTo12 = x.SixTo12,
                                ThirteenTo17 = x.ThirteenTo17,
                                EighteenTo20 = x.EighteenTo20,
                                TwentyOneTo24 = x.TwentyOneTo24,
                                TwentyFiveTo44 = x.TwentyFiveTo44,
                                FortyFiveTo64 = x.FortyFiveTo64,
                                SixtyFiveTo74 = x.SixtyFiveTo74,
                                SeventyFivePlus = x.SeventyFivePlus,
                                HispanicLatinoEthnicity = x.HispanicLatinoEthnicity,
                                ArabAmericanCanadianEthnicity = x.ArabAmericanCanadianEthnicity,
                                NotListed = x.NotListed,


                            }).ToList();

                    }
                    catch (Exception ex)
                    {
                        throw;
                    }
                }
                return null;
                // return await dbContext.Activity.Take(100).ToListAsync();
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public async Task<PagedList<ActivitiesDto>> GetActivitiesByGroupId(long longGroupId)
        // PagedList<ActivitiesDto> IActivityRepository.GetAllAsyncPaginated(ActivitiesSPInput inputparam, UserParams userParams)
        {



            try
            {
                var query = from A in dbContext.Activity
                            join AG in dbContext.ActivityGroup on A.GroupId equals AG.Id
                            join PA in dbContext.ProviderAgency on AG.ProviderAgencyId equals PA.Id
                            join U in dbContext.Users on A.VerifiedBy equals U.Id
                            join AOD in dbContext.Activity_OptionalData on A.ActivityOptionalDataId equals AOD.Id
                            where

                              (A.IsDeleted.Equals(false))

                            select new
                            {
                                AG.ProgramNameId,
                                A.Id,
                                A.ActivityName,
                                AG.CoordinatingAgencyId,
                                ProviderAgencyId = PA.Id,
                                A.GroupId,
                                GroupName = AG.Name,
                                A.StartDate,
                                A.EndDate,
                                A.TotalAttendees,
                                A.NewMaleAttendees,
                                A.NewFemaleAttendees,
                                A.NewTransManAttendees,
                                A.NewTransWomanAttendees,
                                A.NewGenderNonConformingAttendees,
                                A.NewOtherAttendees,
                                A.MasterStrategyEmployed,
                                A.EstimatePeopleReached,
                                A.AttendeesCompletingGroup,
                                A.ActivityOptionalDataId,
                                A.IsVerified,
                                VerifiedByName = U.UserName,
                                A.VerifyComments,
                                A.OrderNumber,
                                AOD.numberOfOriginalItemsCreated,
                                AOD.numberOfBrochuresDistributed,
                                AOD.IndirectSpeakingEngagementReach,
                                AOD.IndirectSpeakingEngagementCount,
                                AOD.IsSchoolBasedActivity,
                                AOD.SchoolDistrictId,
                                AOD.CountyId,
                                AOD.LocationZipCode,
                                AOD.ServiceSettingId,
                                A.RecordNumber,
                                A.Comments,
                                A.CreationDate,
                                A.IsActive,
                                A.IsDeleted,
                                A.TotalPeopleReached,
                                A.TotalImpressions,
                                A.MethodsUsed,
                                A.SocialMediaUsed
                            };


                query = query.Where(x => x.GroupId.Equals(longGroupId)).OrderBy(x => x.ActivityName);


                // return await PagedList<ActivitiesDto>.CreateAsync(query, userParams.PageNumber, userParams.PageSize);
                var list = query

                    .Select(x => new ActivitiesDto()
                    {
                        Id = x.Id,
                        ProviderAgencyId = x.ProviderAgencyId,
                        CoordinatingAgencyId = x.CoordinatingAgencyId,
                        ActivityName = x.ActivityName,
                        GroupId = x.GroupId,
                        GroupName = x.GroupName,
                        StartDate = x.StartDate,
                        EndDate = x.EndDate,
                        RecordNumber = x.RecordNumber,
                        OrderNumber = x.OrderNumber,
                        ActivityOptionalDataId = x.ActivityOptionalDataId,
                        IsActive = x.IsActive,
                        Status = x.IsActive.Equals(true) ? "Verified" : "Pending",
                        ProgramNameId = x.ProgramNameId,
                        TotalAttendees = x.TotalAttendees,
                        NewMaleAttendees = x.NewMaleAttendees,
                        NewFemaleAttendees = x.NewFemaleAttendees,
                        NewTransManAttendees = x.NewTransManAttendees,
                        NewTransWomanAttendees = x.NewTransWomanAttendees,
                        NewGenderNonConformingAttendees = x.NewGenderNonConformingAttendees,
                        NewOtherAttendees = x.NewOtherAttendees,
                        MasterStrategyEmployed = x.MasterStrategyEmployed,
                        EstimatePeopleReached = x.EstimatePeopleReached,
                        AttendeesCompletingGroup = x.AttendeesCompletingGroup,
                        IsVerified = x.IsVerified,
                        VerifiedByName = x.VerifiedByName,
                        VerifyComments = x.VerifyComments,
                        numberOfOriginalItemsCreated = x.numberOfOriginalItemsCreated,
                        numberOfBrochuresDistributed = x.numberOfBrochuresDistributed,
                        IndirectSpeakingEngagementReach = x.IndirectSpeakingEngagementReach,
                        IndirectSpeakingEngagementCount = x.IndirectSpeakingEngagementCount,
                        Comments = x.Comments

                    }).ToList();
                //return await PagedList<ActivitiesDto>.CreateAsync(query, userParams.PageNumber, userParams.PageSize);
                return PagedList<ActivitiesDto>.Create(list, 1, 50);
            }
            catch (Exception)
            {
                throw;
            }



            //var list = await query.ToListAsync().ConfigureAwait(false);

            return null;
            // return await dbContext.Activity.Take(100).ToListAsync();

        }
        public async Task<bool> IsGroupTypeOneTimeAndExists(long groupId)
        {
            var query = from A in dbContext.Activity
                        join AG in dbContext.ActivityGroup on A.GroupId equals AG.Id
                        where (AG.Id == groupId) && (A.IsDeleted.Equals(false)) && (AG.IsDeleted.Equals(false)) && (AG.GroupType == 1)

                        select A.Id;

            var activityId = query.Select(x=>x.Value).FirstOrDefault();
            if ((long)activityId > 0)
                return true;
            return false;
        }
        public async Task<bool> isActivityNameAlreadyExists(string activityName)
        {
            try
            {
                var query = dbContext.Activity.Where(a => a.ActivityName.Equals(activityName));

                var list = query

                    .Select(x => new ActivitiesDto()
                    {
                        Id = x.Id
                    }).ToList();

                if (list.Count > 0) return true;
            }

            catch (Exception)
            {
                return false;
            }

            return false;
        }

        public async Task<PagedList<ActivitiesDto>> GetAllAsyncPaginated(ActivitiesSPInput inputparam, UserParams userParams)
        {
            try
            {
                if (inputparam != null)
                {
                    try
                    {
                        var query = from A in dbContext.Activity
                                    join AG in dbContext.ActivityGroup on A.GroupId equals AG.Id

                                    join PA in dbContext.ProviderAgency on AG.ProviderAgencyId equals PA.Id

                                    join U in dbContext.Users on A.VerifiedBy equals U.Id into AOUTemp
                                    from AOUsubgroup in AOUTemp.DefaultIfEmpty()

                                    join AOD in dbContext.Activity_OptionalData on A.ActivityOptionalDataId equals AOD.Id
                                    //into AODTemp from AODsubgroup in AODTemp.DefaultIfEmpty()
                                    where

                                      (A.IsDeleted.Equals(false))
                                    orderby (A.ActivityName)

                                    select new
                                    {
                                        AG.ProgramNameId,
                                        A.Id,
                                        A.ActivityName,
                                        AG.CoordinatingAgencyId,
                                        ProviderAgencyId = PA.Id,
                                        A.GroupId,
                                        GroupName = AG.Name,
                                        A.StartDate,
                                        A.EndDate,
                                        A.TotalAttendees,
                                        A.NewMaleAttendees,
                                        A.NewFemaleAttendees,
                                        A.NewTransManAttendees,
                                        A.NewTransWomanAttendees,
                                        A.NewGenderNonConformingAttendees,
                                        A.NewOtherAttendees,
                                        A.MasterStrategyEmployed,
                                        A.EstimatePeopleReached,
                                        A.AttendeesCompletingGroup,
                                        A.ActivityOptionalDataId,
                                        A.IsVerified,
                                        A.VerifiedByName,
                                        A.VerifyComments,
                                        A.VerifiedOn,
                                        A.VerifiedBy,
                                        A.OrderNumber,
                                        AOD.numberOfOriginalItemsCreated,
                                        AOD.numberOfBrochuresDistributed,
                                        AOD.IndirectSpeakingEngagementReach,
                                        AOD.IndirectSpeakingEngagementCount,
                                        AOD.IsSchoolBasedActivity,
                                        AOD.SchoolDistrictId,
                                        AOD.CountyId,
                                        AOD.LocationZipCode,
                                        AOD.ServiceSettingId,
                                        A.RecordNumber,
                                        A.Comments,
                                        A.CreationDate,
                                        A.IsActive,
                                        A.IsDeleted
                                    };
                        if (inputparam.Verified > 0)
                        {
                            if (inputparam.Verified == 1)
                                query = query.Where(x => x.IsVerified.Equals(false));
                            else
                                query = query.Where(x => x.IsVerified.Equals(true));
                        }
                        if (inputparam.GroupId > 0)
                        {
                            query = query.Where(x => x.GroupId.Equals(inputparam.GroupId));
                        }
                        else
                        {
                            if (inputparam.CoordinatingAgencyId > 0)
                            {
                                query = query.Where(x => x.CoordinatingAgencyId.Equals(inputparam.CoordinatingAgencyId));
                            }
                            if (inputparam.ProviderAgencyId > 0)
                            {
                                query = query.Where(x => x.ProviderAgencyId.Equals(inputparam.ProviderAgencyId));
                            }
                        }
                        if (inputparam.RecordNumber > 0)
                        {
                            query = query.Where(x => x.RecordNumber.Equals(inputparam.RecordNumber));
                        }

                        if (inputparam.CreationDate != null)
                            if ((inputparam.CreationDate != "") && (inputparam.CreationDate != "string"))
                            {
                                query = query.Where(x => x.CreationDate.Value.Date.Equals(DateTimeFormatToDate(inputparam.CreationDate)));
                            }

                        if (inputparam.StartDate != null)
                            if ((inputparam.StartDate != "") && (inputparam.StartDate != "string"))
                            {
                                query = query.Where(x => x.StartDate.Value.Date.Equals(DateTimeFormatToDate(inputparam.StartDate)));
                            }
                        if (inputparam.EndDate != null)
                            if ((inputparam.EndDate != "") && (inputparam.EndDate != "string"))
                            {
                                query = query.Where(x => x.EndDate.Value.Date.Equals(DateTimeFormatToDate(inputparam.EndDate)));
                            }
                        if (inputparam.ActivityId != null)
                        {
                            if (inputparam.ActivityId > 0)
                            {
                                query = query.Where(x => x.Id.Equals(inputparam.ActivityId));
                            }
                        }
                        if (inputparam.userTypeId == 4)
                        {
                            if (inputparam.userProviderAgencyId > 0)
                                query = query.Where(x => x.ProviderAgencyId.Equals(inputparam.userProviderAgencyId));
                        }
                        if (inputparam.userTypeId == 3)
                        {
                            if (inputparam.userCoordinatingAgencyId > 0)
                                query = query.Where(x => x.CoordinatingAgencyId.Equals(inputparam.userCoordinatingAgencyId));
                        }
                        query = query.OrderBy(a => a.ActivityName);
                        // return await PagedList<ActivitiesDto>.CreateAsync(query, userParams.PageNumber, userParams.PageSize);
                        var list = query

                            .Select(x => new ActivitiesDto()
                            {
                                Id = x.Id,
                                ProviderAgencyId = x.ProviderAgencyId,
                                CoordinatingAgencyId = x.CoordinatingAgencyId,
                                ActivityName = x.ActivityName,
                                GroupId = x.GroupId,
                                GroupName = x.GroupName,
                                StartDate = x.StartDate,
                                EndDate = x.EndDate,
                                RecordNumber = x.RecordNumber,
                                OrderNumber = x.OrderNumber,
                                ActivityOptionalDataId = x.ActivityOptionalDataId,
                                IsActive = x.IsActive,
                                Status = x.IsVerified.Equals(true) ? "Verified" : "Pending",
                                ProgramNameId = x.ProgramNameId,
                                TotalAttendees = x.TotalAttendees,
                                NewMaleAttendees = x.NewMaleAttendees,
                                NewFemaleAttendees = x.NewFemaleAttendees,
                                NewTransManAttendees = x.NewTransManAttendees,
                                NewTransWomanAttendees = x.NewTransWomanAttendees,
                                NewGenderNonConformingAttendees = x.NewGenderNonConformingAttendees,
                                NewOtherAttendees = x.NewOtherAttendees,
                                MasterStrategyEmployed = x.MasterStrategyEmployed,
                                EstimatePeopleReached = x.EstimatePeopleReached,
                                AttendeesCompletingGroup = x.AttendeesCompletingGroup,
                                IsVerified = x.IsVerified,
                                VerifiedByName = x.VerifiedByName,
                                VerifyComments = x.VerifyComments,
                                VerifiedBy = x.VerifiedBy,
                                numberOfOriginalItemsCreated = x.numberOfOriginalItemsCreated,
                                numberOfBrochuresDistributed = x.numberOfBrochuresDistributed,
                                IndirectSpeakingEngagementReach = x.IndirectSpeakingEngagementReach,
                                IndirectSpeakingEngagementCount = x.IndirectSpeakingEngagementCount,
                                Comments = x.Comments

                            }).ToList();
                        //return await PagedList<ActivitiesDto>.CreateAsync(query, userParams.PageNumber, userParams.PageSize);
                        return PagedList<ActivitiesDto>.Create(list, userParams.PageNumber, userParams.PageSize);
                    }
                    catch (Exception)
                    {
                        throw;
                    }



                    //var list = await query.ToListAsync().ConfigureAwait(false);

                }
                return null;
                // return await dbContext.Activity.Take(100).ToListAsync();
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public IEnumerable<ActivitiesDto> GetAllAsyncPagedList(ActivitiesSPInput ActivityInputParam, UserParams userParams)
        {
            throw new NotImplementedException();
        }
    }


}
