﻿using Microsoft.EntityFrameworkCore;
using MPDS.API.Data;
using MPDS.API.Models.Domain;
using MPDS.API.Repositories.Interface;

namespace MPDS.API.Repositories.Implementation
{
    public class MasterIntendedPopulationRepository : IMasterIntendedPopulationRepository
    {
        private readonly MPDSDbContext dbContext;

        public MasterIntendedPopulationRepository(MPDSDbContext dbContext)
        {
            this.dbContext = dbContext;
        }
        public async Task<MasterIntendedPopulation> CreateAsync(MasterIntendedPopulation masterIntendedPopulation)
        {
            await dbContext.Master_IntendedPopulation.AddAsync(masterIntendedPopulation);
            await dbContext.SaveChangesAsync();
            return masterIntendedPopulation;
        }

        public async Task<MasterIntendedPopulation?> DeleteAsync(int id)
        {
            var existingmasterIntendedPopulation = await dbContext.Master_IntendedPopulation.FirstOrDefaultAsync(c => c.id == id);
            if (existingmasterIntendedPopulation is null)
            {
                return null;
            }
            dbContext.Master_IntendedPopulation.Remove(existingmasterIntendedPopulation);
            await dbContext.SaveChangesAsync();
            return existingmasterIntendedPopulation;

        }

        public async Task<IEnumerable<MasterIntendedPopulation>> GetAllSync()
        {
            return await dbContext.Master_IntendedPopulation.ToListAsync();
        }

        public async Task<MasterIntendedPopulation?> GetById(int id)
        {
            return await dbContext.Master_IntendedPopulation.FirstOrDefaultAsync(x => x.id == id);
        }

        public async Task<MasterIntendedPopulation?> UpdateAsync(MasterIntendedPopulation masterIntendedPopulation)
        {
            var existingmasterIntendedPopulation = await dbContext.Master_IntendedPopulation.FirstOrDefaultAsync(x => x.id == masterIntendedPopulation.id);
            if (existingmasterIntendedPopulation != null)
            {
                dbContext.Entry(existingmasterIntendedPopulation).CurrentValues.SetValues(masterIntendedPopulation);
                await dbContext.SaveChangesAsync();
                return masterIntendedPopulation;
            }
            return null;

        }
    }
}
