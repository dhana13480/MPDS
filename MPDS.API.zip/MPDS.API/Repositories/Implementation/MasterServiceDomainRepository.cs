﻿using Microsoft.EntityFrameworkCore;
using MPDS.API.Data;
using MPDS.API.Models.Domain;
using MPDS.API.Repositories.Interface;

namespace MPDS.API.Repositories.Implementation
{
    public class MasterServiceDomainRepository : IMasterServiceDomainRepository
    {
        private readonly MPDSDbContext dbContext;

        public MasterServiceDomainRepository(MPDSDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        public Task<MasterServiceDomain> CreateAsync(MasterServiceDomain category)
        {
            throw new NotImplementedException();
        }

        public Task<MasterServiceDomain?> DeleteAsync(int id)
        {
            throw new NotImplementedException();
        }

        public async Task<IEnumerable<MasterServiceDomain>> GetAllSync()
        {
            return await dbContext.Master_ServiceDomain.ToListAsync();
        }

        public Task<MasterServiceDomain?> GetById(int id)
        {
            throw new NotImplementedException();
        }

        public Task<MasterServiceDomain?> UpdateAsync(MasterServiceDomain category)
        {
            throw new NotImplementedException();
        }
    }
}
