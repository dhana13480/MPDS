﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Query.Internal;
using MPDS.API.Data;
using MPDS.API.Models.Domain;
using MPDS.API.Models.DTO;
using MPDS.API.Repositories.Interface;
using MPDS.API.Utilities;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;

namespace MPDS.API.Repositories.Implementation
{
    public class StaffRepository : IStaffRepository
    {
        private readonly MPDSDbContext dbContext;
        public StaffRepository(MPDSDbContext dbContext)
        {
            this.dbContext = dbContext;
        }


        public async Task<Staff> CreateAsync(Staff staff)
        {
            await dbContext.Staff.AddAsync(staff);
            await dbContext.SaveChangesAsync();
            return staff;
        }
        public async Task<ActivityStaff> CreateActivityStaff(ActivityStaff staff)
        {
            await dbContext.Activity_Staff.AddAsync(staff);
            await dbContext.SaveChangesAsync();
            return staff;
        }
        public Task<Staff?> DeleteAsync(int id)
        {
            throw new NotImplementedException();
        }

        public async Task<List<Staff>> GetAllByPihpRegionId(long PihpRegionId)
        {
            var innerGroupJoinQuery2 =
   from staff in dbContext.Staff
   join pihp in dbContext.CoordinatingAgency on staff.CoordinatingAgencyId equals pihp.Id into prodGroup
   from prod2 in prodGroup
   where prod2.Id == PihpRegionId
   select new
   {
       staff.Id,
       staff.FirstName,
       staff.MiddleName,
       staff.LastName,
       staff.Email,
       staff.ProviderAgencyId,
       staff.StaffType,
       staff.OfficePhone,
       staff.IsActive

   };

            var list = await innerGroupJoinQuery2.ToListAsync().ConfigureAwait(false);
            return list
                .Select(r => new Staff()
                {
                    Id = r.Id,
                    FirstName = r.FirstName,
                    MiddleName = r.MiddleName,
                    LastName = r.LastName,
                    ProviderAgencyId = r.ProviderAgencyId,
                    StaffType = r.StaffType,
                    Email = r.Email,
                    OfficePhone = r.OfficePhone,
                    IsActive = r.IsActive

                }).ToList();
        }

        public async Task<List<StaffDto>> GetStaffByActivityId(long ActivityId)
        {
            if (ActivityId <= 0)
                return null;

            var innerGroupJoinQuery2 =
            from actstaff in dbContext.Activity_Staff
            where (actstaff.ActivityId == ActivityId)
            join staff in dbContext.Staff on actstaff.StaffId equals staff.Id

            select new
            {
                staff.Id,
                staff.FirstName,
                staff.MiddleName,
                staff.LastName,
                staff.Email,
                staff.ProviderAgencyId,
                staff.CoordinatingAgencyId,
                staff.StaffType,
                staff.OfficePhone,
                staff.IsActive,
                StaffStartDate = actstaff.StartDate,
                StaffEndtDate = actstaff.EndDate,
                actstaff.StrategyId,

            }

  ;

            var list = await innerGroupJoinQuery2.ToListAsync().ConfigureAwait(false);
            return list
                .Select(r => new StaffDto()
                {
                    Id = r.Id,
                    FirstName = r.FirstName,
                    MiddleName = r.MiddleName,
                    LastName = r.LastName,
                    Email = r.Email,
                    ProviderAgencyId = r.ProviderAgencyId,
                    CoordinatingAgencyId = r.CoordinatingAgencyId,
                    StaffType = r.StaffType,
                    OfficePhone = r.OfficePhone,
                    IsActive = r.IsActive,
                    StaffStartDate = r.StaffStartDate,
                    StaffEndDate = r.StaffEndtDate,
                    StrategyId = r.StrategyId,

                }).ToList();
        }

        public async Task<List<Staff>> GetStaffByCoordinatingAgencyAndProviderId(long PihpRegionId, long ProviderAgencyId)
        {

            var innerGroupJoinQuery2 =
            from staff in dbContext.Staff
            where (((staff.ProviderAgencyId == ProviderAgencyId) && (staff.StaffType == 2))
            || ((staff.CoordinatingAgencyId == PihpRegionId) && (staff.StaffType == 1)))
            && (staff.IsActive == true)
            && (staff.IsDeleted == false)

            //    from staff in dbContext.Staff
            //join pa in dbContext.ProviderAgency on staff.ProviderAgencyId equals pa.Id into prodGroup from prod2 in prodGroup
            //where (prod2.Id == ProviderAgencyId && staff.StaffType==1)  

            select new
            {
                staff.Id,
                staff.FirstName,
                staff.MiddleName,
                staff.LastName,
                staff.Email,
                staff.ProviderAgencyId,
                staff.CoordinatingAgencyId,
                staff.StaffType,
                staff.OfficePhone,
                staff.IsActive

            }

  ;

            var list = await innerGroupJoinQuery2.ToListAsync().ConfigureAwait(false);
            return list
                .Select(r => new Staff()
                {
                    Id = r.Id,
                    FirstName = r.FirstName,
                    MiddleName = r.MiddleName,
                    LastName = r.LastName,
                    ProviderAgencyId = r.ProviderAgencyId,
                    CoordinatingAgencyId = r.CoordinatingAgencyId,
                    StaffType = r.StaffType,
                    Email = r.Email,
                    OfficePhone = r.OfficePhone,
                    IsActive = r.IsActive

                }).ToList();
        }

        public async Task<List<Staff>> GetStaffByProviderId(long ProviderAgencyId)
        {
            var innerGroupJoinQuery2 =
   from staff in dbContext.Staff
   join pihp in dbContext.ProviderAgency on staff.ProviderAgencyId equals pihp.Id into prodGroup
   from prod2 in prodGroup
   where prod2.Id == ProviderAgencyId
   select new
   {
       staff.Id,
       staff.FirstName,
       staff.MiddleName,
       staff.LastName,
       staff.Email,
       staff.ProviderAgencyId,
       staff.StaffType,
       staff.OfficePhone,
       staff.IsActive

   };

            var list = await innerGroupJoinQuery2.ToListAsync().ConfigureAwait(false);
            return list
                .Select(r => new Staff()
                {
                    Id = r.Id,
                    FirstName = r.FirstName,
                    MiddleName = r.MiddleName,
                    LastName = r.LastName,
                    ProviderAgencyId = r.ProviderAgencyId,
                    StaffType = r.StaffType,
                    Email = r.Email,
                    OfficePhone = r.OfficePhone,
                    IsActive = r.IsActive

                }).ToList();
        }
        public async Task<IEnumerable<Staff>> GetAllAsync()
        {
            try
            {
                return await dbContext.Staff.Take(5).ToListAsync();
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public async Task<PagedList<Staff>> GetAllStaffAsyncPagelist(UserParams userParams, UserSearchInputParameters inputparam)
        {
            try
            {
                var query = dbContext.Staff.AsNoTracking();
                if (inputparam.userTypeId == 4)
                {
                    if (inputparam.userProviderAgencyId > 0)
                        query = query.Where(x => x.ProviderAgencyId.Equals(inputparam.userProviderAgencyId));
                }
                else if (inputparam.userTypeId == 3)
                {
                    if (inputparam.userCoordinatingAgencyId > 0)
                        query = query.Where(x => x.CoordinatingAgencyId.Equals(inputparam.userCoordinatingAgencyId));
                }

                if (inputparam.searchByUserName != null)
                    query = query.Where(x => x.FirstName.Contains(inputparam.searchByUserName));
                if (inputparam.searchByLastName != null)
                    query = query.Where(x => x.FirstName.Contains(inputparam.searchByLastName));

                query = query.OrderBy(s => s.LastName);
                return await PagedList<Staff>.CreateAsync(query, userParams.PageNumber, userParams.PageSize);
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public async Task<Staff?> GetByStaffId(long id)
        {
            return await dbContext.Staff.FirstOrDefaultAsync(x => x.Id == id);
        }

        public async Task<Staff?> UpdateAsync(Staff staff)
        {
            try
            {
                var existingStaff = await dbContext.Staff.FirstOrDefaultAsync(x => x.Id == staff.Id);
                if (existingStaff != null)
                {

                    dbContext.Entry(existingStaff).CurrentValues.SetValues(staff);

                    await dbContext.SaveChangesAsync();
                    return staff;
                }
            }
            catch (Exception ex)
            {
                return null;
            }
            return null;
        }


    }
}
