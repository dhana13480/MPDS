﻿using Microsoft.EntityFrameworkCore;
using MPDS.API.Data;
using MPDS.API.Models.Domain;
using MPDS.API.Repositories.Interface;

namespace MPDS.API.Repositories.Implementation
{
    public class MasterStatesRepository : IMasterStatesRepository
    {
        private readonly MPDSDbContext dbContext;
        public MasterStatesRepository(MPDSDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        public Task<MasterStates> CreateAsync(MasterStates masterStates)
        {
            throw new NotImplementedException();
        }

        public Task<MasterStates?> DeleteAsync(int id)
        {
            throw new NotImplementedException();
        }

       
        public async Task<IEnumerable<MasterStates>> GetAllAsync()
        {
            try
            {
                return await dbContext.Master_State.ToListAsync();
            }
            catch (Exception ex)
            {
                throw;
            }
        }

            //public async Task<MasterStates?> GetById(int id)
            //{
            //    return await dbContext.Master_State.FirstOrDefaultAsync(x => x.Id == id);
            //}
        public Task<MasterStates?> UpdateAsync(MasterStates masterStates)
        {
            throw new NotImplementedException();
        }
    }
}
