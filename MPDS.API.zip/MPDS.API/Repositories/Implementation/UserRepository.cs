﻿using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Query.Internal;
using MPDS.API.Data;
using MPDS.API.Models.Domain;
using MPDS.API.Models.DTO;
using MPDS.API.Repositories.Interface;
using System.Numerics;
using System;
using System.Threading.Tasks;
using System.Xml.Linq;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;
using MPDS.API.Utilities;
using System.Security;

namespace MPDS.API.Repositories.Implementation
{
    public class UserRepository : IUserRepository
    {
        private readonly MPDSDbContext dbContext;
        public UserRepository(MPDSDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        public async Task<Users> AddNewUser(Users user)
        {
            try
            {
                if (user == null)
                    return null;

                await dbContext.Users.AddAsync(user);
                await dbContext.SaveChangesAsync();
            }
            catch (Exception ex)
            {

                return null;
            }
           
          /*
            var paramFirstName = new SqlParameter("@FirstName", user.FirstName);            
            var paramMiddleName = new SqlParameter("@MiddleName", user.MiddleName);
            var paramLastName = new SqlParameter("@LastName", user.LastName);
            var paramPassword = new SqlParameter("@Password", HashUtility.SHA512Hash(user.Password??""));
            var paramIsActive = new SqlParameter("@IsActive", true);
            var paramUserTypeId = new SqlParameter("@UserTypeId", user.UserTypeId);
            var paramCoordinatingAgencyId = new SqlParameter("@CoordinatingAgencyId", user.CoordinatingAgencyId);
            var paramProviderAgencyId = new SqlParameter("@ProviderAgencyId", user.ProviderAgencyId);
            var paramPermissions = new SqlParameter("@Permissions", user.Permissions);
            var paramUserName = new SqlParameter("@UserName", user.UserName);
            var paramEmail = new SqlParameter("@Email", user.Email);
            var paramPhone = new SqlParameter("@Phone", user.Phone);
            var paramAddress1 = new SqlParameter("@Address1", user.Address1);
            var paramAddress2 = new SqlParameter("@Address2", user.Address2);
            var paramStateId = new SqlParameter("@StateId", user.StateId);
            var paramCity = new SqlParameter("@City", user.City);
            var paramZip = new SqlParameter("@Zip", user.Zip);
            var paramComments = new SqlParameter("@Comments", user.Comments);
            var paramCreatedBy = new SqlParameter("@CreatedBy", user.CreatedBy);
            var paramcsvProviderAgencies = new SqlParameter("@csvProviderAgencyIds", user.csvProviderAgencies);
            var paramcsvCoordinatingAgencyIds = new SqlParameter("@csvCoordinatingAgencyIds", user.csvCoordinatingAgencies);

            var list = dbContext.Users.FromSqlRaw("AddNewUser @FirstName, @MiddleName, @LastName, @Password, @IsActive, @UserTypeId, @providerAgencyId, @CoordinatingAgencyId, @Permissions, @UserName, @Email, @Phone, @Address1,@Address2, @City, @StateId, @Zip, @Comments, @CreatedBy, @csvProviderAgencyIds, @csvCoordinatingAgencyIds", 
                paramFirstName, paramMiddleName, paramLastName, paramPassword, paramIsActive, paramUserTypeId,  paramProviderAgencyId, paramCoordinatingAgencyId, paramPermissions, paramUserName, paramEmail, paramPhone, paramAddress1, paramAddress2, paramCity, paramStateId,  paramZip, paramComments, paramCreatedBy, paramcsvProviderAgencies, paramcsvCoordinatingAgencyIds
                ).AsEnumerable().Take(1).ToList();*/


            return user;
        }

        public async Task<Users?> RemoveUser(int id)
        {
            var existingUser = await dbContext.Users.FirstOrDefaultAsync(c => c.Id == id);
            if (existingUser is null)
            {
                return null;
            }
            dbContext.Users.Remove(existingUser);
            await dbContext.SaveChangesAsync();
            return existingUser;
        }

        public async Task<IEnumerable<Users>> GetAllUsers(UserSearchInputParameters userSearchInputParameters)
        {
            try
            {
                if (userSearchInputParameters == null)
                {
                    userSearchInputParameters.searchByType = -1;
                    userSearchInputParameters.searchByLastName = "";
                    userSearchInputParameters.searchByUserName = "";
                    userSearchInputParameters.searchByEmail = "";
                    userSearchInputParameters.coordinatingAgencyId = -1;
                    userSearchInputParameters.providerAgencyId = -1;
                }
                if ((userSearchInputParameters.searchByType == null) || (userSearchInputParameters.searchByType == 0))
                    userSearchInputParameters.searchByType = -1;
                if ((userSearchInputParameters.searchByLastName == null) || (userSearchInputParameters.searchByLastName == string.Empty))
                    userSearchInputParameters.searchByLastName = "";

                if ((userSearchInputParameters.searchByUserName == null) || (userSearchInputParameters.searchByUserName == string.Empty))
                    userSearchInputParameters.searchByUserName = "";

                if ((userSearchInputParameters.searchByEmail == null) || (userSearchInputParameters.searchByEmail == string.Empty))
                    userSearchInputParameters.searchByEmail = "";

                if ((userSearchInputParameters.coordinatingAgencyId == null) || (userSearchInputParameters.coordinatingAgencyId == 0))
                    userSearchInputParameters.coordinatingAgencyId = -1;
                if ((userSearchInputParameters.providerAgencyId == null) || (userSearchInputParameters.providerAgencyId == 0))
                    userSearchInputParameters.providerAgencyId = -1;

                var paramSearchByType = new SqlParameter("@searchByType", userSearchInputParameters.searchByType);
                var paramSearchByLastName = new SqlParameter("@searchByLastName", userSearchInputParameters.searchByLastName);
                var paramSearchByUserName = new SqlParameter("@searchByUserName", userSearchInputParameters.searchByUserName);
                var paramSearchByEmail = new SqlParameter("@searchByEmail", userSearchInputParameters.searchByEmail);
                var paramCoordinatingAgencyId = new SqlParameter("@coordinatingAgencyId", userSearchInputParameters.coordinatingAgencyId);
                var paramProviderAgencyId = new SqlParameter("@providerAgencyId", userSearchInputParameters.providerAgencyId);


                var list = dbContext.Users.FromSqlRaw("GetAllMPDSUsers @searchByType, @searchByLastName,@searchByUserName,@searchByEmail,@coordinatingAgencyId, @providerAgencyId", paramSearchByType, paramSearchByLastName, paramSearchByUserName, paramSearchByEmail, paramCoordinatingAgencyId, paramProviderAgencyId).AsEnumerable().ToList();
                return list;
            }
            catch (Exception ex)
            {
                return null;
            }

        }
        public async Task<PagedList<Users>> GetAllUsersPaginated(UserParams userParams, UserSearchInputParameters userSearchInputParameters)
        {
            try
            {
                if (userSearchInputParameters == null)
                {
                    userSearchInputParameters.searchByType = -1;
                    userSearchInputParameters.searchByLastName = "";
                    userSearchInputParameters.searchByUserName = "";
                    userSearchInputParameters.searchByEmail = "";
                    userSearchInputParameters.coordinatingAgencyId = -1;
                    userSearchInputParameters.providerAgencyId = -1;
                }
                if ((userSearchInputParameters.searchByType == null) || (userSearchInputParameters.searchByType == 0))
                    userSearchInputParameters.searchByType = -1;
                if ((userSearchInputParameters.searchByLastName == null) || (userSearchInputParameters.searchByLastName == string.Empty))
                    userSearchInputParameters.searchByLastName = "";

                if ((userSearchInputParameters.searchByUserName == null) || (userSearchInputParameters.searchByUserName == string.Empty))
                    userSearchInputParameters.searchByUserName = "";

                if ((userSearchInputParameters.searchByEmail == null) || (userSearchInputParameters.searchByEmail == string.Empty))
                    userSearchInputParameters.searchByEmail = "";

                if ((userSearchInputParameters.coordinatingAgencyId == null) || (userSearchInputParameters.coordinatingAgencyId == 0))
                    userSearchInputParameters.coordinatingAgencyId = -1;
                if ((userSearchInputParameters.providerAgencyId == null) || (userSearchInputParameters.providerAgencyId == 0))
                    userSearchInputParameters.providerAgencyId = -1;
                
                var query = dbContext.Users.AsNoTracking();

                if ((userSearchInputParameters.searchByLastName != null) && (userSearchInputParameters.searchByLastName != string.Empty) && (userSearchInputParameters.searchByLastName != "string"))
                    query = query.Where(x => x.LastName.Contains(userSearchInputParameters.searchByLastName));
                if ((userSearchInputParameters.searchByUserName != null) && (userSearchInputParameters.searchByUserName != string.Empty) && (userSearchInputParameters.searchByUserName != "string"))
                    query = query.Where(x => x.UserName.Contains(userSearchInputParameters.searchByUserName));
                if ((userSearchInputParameters.searchByEmail != null) && (userSearchInputParameters.searchByEmail != string.Empty) && (userSearchInputParameters.searchByEmail != "string"))
                    query = query.Where(x => x.Email.Contains(userSearchInputParameters.searchByEmail));
                if ((userSearchInputParameters.searchByType != null) && (userSearchInputParameters.searchByType > 0)  )
                    query = query.Where(x => x.UserTypeId == userSearchInputParameters.searchByType);
                if (userSearchInputParameters.userTypeId != 2)
                {
                    if (userSearchInputParameters.userTypeId == 3)
                        if ((userSearchInputParameters.coordinatingAgencyId != null) && (userSearchInputParameters.coordinatingAgencyId > 0))
                            query = query.Where(x => x.CoordinatingAgencyId == userSearchInputParameters.coordinatingAgencyId);
                    if (userSearchInputParameters.userTypeId == 4)
                        if ((userSearchInputParameters.providerAgencyId != null) && (userSearchInputParameters.providerAgencyId > 0))
                            query = query.Where(x => x.ProviderAgencyId == userSearchInputParameters.providerAgencyId);
                }
                return await PagedList<Users>.CreateAsync(query.OrderBy(x=>x.LastName), userParams.PageNumber, userParams.PageSize);

            }
            catch (Exception ex)
            {
                return null;
            }

        }

        public Task<Users?> GetUsersEmailByCAPA(short notificationTypeId, string csvCoordinatingAGencyIds, string csvProviderAgencyIds)
        {
            throw new NotImplementedException();
        }

        public async Task<Users?> UpdateUser(Users user)
        {
            var existingUser = await dbContext.Users.FirstOrDefaultAsync(x => x.Id == user.Id);
            if (existingUser != null)
            {
                dbContext.Entry(existingUser).CurrentValues.SetValues(user);
                await dbContext.SaveChangesAsync();
                return user;
            }
            return null;
        }

        public async Task<IEnumerable<UserPermissions>> GetPermissionsByUserType(int userTypeId)
        {
            //var paramUserTypeId = new SqlParameter("@UserTypeId", userTypeId);
            //var listSP = dbContext.GetPermissionsByUserType.FromSqlRaw("GetPermissionsByUserType @UserTypeId", paramUserTypeId).AsEnumerable().Take(100).ToList();

            var permissionListQuery =
            from mup in dbContext.Master_UserType_Permission_Mapping
            join mu in dbContext.Master_UserType on mup.UserTypeId equals mu.Id
            join mp in dbContext.Master_Permission on mup.PermissionId equals mp.Id  
            where mup.UserTypeId == userTypeId

             select new
             {
                 PermissionId = mup.PermissionId,
                 Permission = mp.Permission
             };

            var list = await permissionListQuery.ToListAsync().ConfigureAwait(false);
            
                return list
                    .Select(r => new UserPermissions()
                    {
                        PermissionId = r.PermissionId,
                        Permission = r.Permission
                    }).ToList();
            
        }
        public async Task<Users?> GetByUserId(long id)
        {
            return await dbContext.Users.FirstOrDefaultAsync(x => x.Id == id);
        }

        public async Task<IEnumerable<Users>> ValidateLogin(string username, string password)
        {
            try
            {
                var paramUserName = new SqlParameter("@UserName", username);
                var paramPassword = new SqlParameter("@password", password);
                var list = dbContext.Users.FromSqlRaw("ValidateMPDSLogin @UserName, @password", paramUserName, paramPassword).AsEnumerable().Take(1).ToList();
                return list;
            }
            catch (Exception ex)
            {

                return null;
            }

        }
        public async Task<IEnumerable<Users>> GetMPDSUserByMiLoginEmail(string email)
        {
            try
            {
                var paramUserEmail = new SqlParameter("@email", email);
                
                var list = dbContext.Users.FromSqlRaw("GetMPDSUserByMiLoginEmail @email", paramUserEmail).AsEnumerable().Take(1).ToList();
                return list;
            }
            catch (Exception ex)
            {               
                return null;
            }

        }
    }
}
