﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Query.Internal;
using MPDS.API.Data;
using MPDS.API.Models.Domain;
using MPDS.API.Models.DTO;
using MPDS.API.Repositories.Interface;
using MPDS.API.Utilities;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;

namespace MPDS.API.Repositories.Implementation
{
    public class ReportRepository : IReportRepository
    {
        private readonly MPDSDbContext dbContext;
        public ReportRepository(MPDSDbContext dbContext)
        {
            this.dbContext = dbContext;
        }
        public Task<Staff?> DeleteAsync(int id)
        {
            throw new NotImplementedException();
        }

    }
}
