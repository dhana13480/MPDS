﻿using Microsoft.EntityFrameworkCore;
using MPDS.API.Data;
using MPDS.API.Models.Domain;
using MPDS.API.Repositories.Interface;

namespace MPDS.API.Repositories.Implementation
{
    public class MasterStrategyRepository : IMasterStrategyRepository
    {
        private readonly MPDSDbContext dbContext;

        public MasterStrategyRepository(MPDSDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        public Task<MasterStrategy> CreateAsync(MasterStrategy strategy)
        {
            throw new NotImplementedException();
        }

        public Task<MasterStrategy?> DeleteAsync(int id)
        {
            throw new NotImplementedException();
        }

        public async Task<IEnumerable<MasterStrategy>> GetAllSync()
        {
            return await dbContext.Master_Strategy.ToListAsync();
        }

        public Task<MasterStrategy?> GetById(int id)
        {
            throw new NotImplementedException();
        }

        public Task<MasterStrategy?> UpdateAsync(MasterStrategy strategy)
        {
            throw new NotImplementedException();
        }
    }
}
