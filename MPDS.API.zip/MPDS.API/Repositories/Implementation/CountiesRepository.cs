﻿using Microsoft.EntityFrameworkCore;
using MPDS.API.Data;
using MPDS.API.Models.Domain;
using MPDS.API.Models.DTO;
using MPDS.API.Repositories.Interface;

namespace MPDS.API.Repositories.Implementation
{
    public class CountiesRepository : ICountiesRepository
    {
        private readonly MPDSDbContext dbContext;
        public CountiesRepository(MPDSDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        public async Task<Counties> CreateAsync(Counties county)
        {
            await dbContext.Master_County.AddAsync(county);
            await dbContext.SaveChangesAsync();
            return county;
        }

        public async Task<IEnumerable<Counties>> GetAllAsync()
        {
            try
            {
                return await dbContext.Master_County.OrderBy(c=>c.County).ToListAsync();
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public async Task<Counties?> GetById(int id)
        {
            return await dbContext.Master_County.FirstOrDefaultAsync(x => x.Id == id);
        }

        public async Task<Counties?> UpdateAsync(Counties county)
        {
            var existingCounty = await dbContext.Master_ProgramName.FirstOrDefaultAsync(x => x.Id == county.Id);
            if (existingCounty != null)
            {
                dbContext.Entry(existingCounty).CurrentValues.SetValues(county);
                await dbContext.SaveChangesAsync();
                return county;
            }
            return null;

        }

        public async Task<IEnumerable<ProviderAgencyCountyDto>> GetByProviderAgencyId(int id)
        {
            try
            {               
                var query = from pac in dbContext.ProviderAgency_County
                            join mc in dbContext.Master_County
                            on pac.CountyId equals mc.Id
                            where pac.ProviderAgencyId == id
                            orderby mc.County
                            select new
                            {
                                pac.Id,
                                pac.ProviderAgencyId,
                                pac.CountyId,
                                mc.County
                            };
                var list = await query.ToListAsync().ConfigureAwait(false);
                return list
                    .Select(x=> new ProviderAgencyCountyDto()
                    {
                        Id = x.Id,
                        ProviderAgencyId = x.ProviderAgencyId,
                        CountyId = x.CountyId,
                        CountyName = x.County
                    }) .ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
