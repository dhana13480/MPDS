﻿using Microsoft.EntityFrameworkCore;
using MPDS.API.Data;
using MPDS.API.Models.Domain;
using MPDS.API.Repositories.Interface;

namespace MPDS.API.Repositories.Implementation
{
    public class MasterStrategyCategoryRepository : IMasterStrategyCategoryRepository
    {
        private readonly MPDSDbContext dbContext;

        public MasterStrategyCategoryRepository(MPDSDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        public Task<MasterStrategyCategory> CreateAsync(MasterStrategyCategory strategy)
        {
            throw new NotImplementedException();
        }

        public Task<MasterStrategyCategory?> DeleteAsync(int id)
        {
            throw new NotImplementedException();
        }

        public async Task<IEnumerable<MasterStrategyCategory>> GetAllSync()
        {
            return await dbContext.Master_StrategyCategory.ToListAsync();
        }

        public Task<MasterStrategyCategory?> GetById(int id)
        {
            throw new NotImplementedException();
        }

        public Task<MasterStrategyCategory?> UpdateAsync(MasterStrategyCategory strategy)
        {
            throw new NotImplementedException();
        }
    }
}
