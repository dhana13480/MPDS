﻿using Microsoft.EntityFrameworkCore;
using MPDS.API.Data;
using MPDS.API.Models.Domain;
using MPDS.API.Repositories.Interface;

namespace MPDS.API.Repositories.Implementation
{
    public class ProgramNameRepository : IProgramNamesRepository
    {
        private readonly MPDSDbContext dbContext;
        public ProgramNameRepository(MPDSDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        public async Task<MasterProgramName> CreateAsync(MasterProgramName programName)
        {
            await dbContext.Master_ProgramName.AddAsync(programName);
            await dbContext.SaveChangesAsync();
            return programName;
            //throw new NotImplementedException();
        }

     
        public async Task<List<ProgramNameByCoordinatingAgency>> GetByCoordinatingAgencyId(long CoordinatingAgencyId)
        {
            try
            {
                var query = from pac in dbContext.CoordinatingAgency_ProgramNames
                            join m_pn in dbContext.Master_ProgramName
                            on pac.ProgramNameId equals m_pn.Id
                            where pac.CoordinatingAgencyId == CoordinatingAgencyId
                            select new
                            {
                                pac.Id,
                                pac.ProgramNameId,
                                pac.CoordinatingAgencyId,
                                m_pn.Name
                            };
                var list = await query.ToListAsync();

                return list
                    .Select(x => new ProgramNameByCoordinatingAgency()
                    {
                        id = x.Id,
                        coordinatingAgencyId = x.CoordinatingAgencyId,
                        programNameId = x.ProgramNameId,
                        programName = x.Name
                    })
                 
                    .ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }

        public Task<IEnumerable<MasterProgramName>> GetByProviderAgencyId(int id)
        {
            throw new NotImplementedException();
        }

        

       

        public async Task<IEnumerable<MasterProgramName>> GetAllAsync()
        {
            try
            {
                return await dbContext.Master_ProgramName.ToListAsync();
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public async Task<MasterProgramName?> GetById(int id)
        {
            return await dbContext.Master_ProgramName.FirstOrDefaultAsync(x => x.Id == id);
        }
        public async Task<MasterProgramName?> UpdateAsync(MasterProgramName programName)
        {
            var existingprogramName = await dbContext.Master_ProgramName.FirstOrDefaultAsync(x => x.Id == programName.Id);
            if (existingprogramName != null)
            {
                dbContext.Entry(existingprogramName).CurrentValues.SetValues(programName);
                await dbContext.SaveChangesAsync();
                return programName;
            }
            return null;

        }
    }

       
    }
