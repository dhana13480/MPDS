﻿using Microsoft.EntityFrameworkCore;
using MPDS.API.Controllers;
using MPDS.API.Data;
using MPDS.API.Models.Domain;
using MPDS.API.Repositories.Interface;
namespace MPDS.API.Repositories.Implementation
{
    public class MasterProgramTypeRepository : IMasterProgramTypeRepository
    {
        private readonly MPDSDbContext dbContext;
        public MasterProgramTypeRepository(MPDSDbContext dbContext)
        {
            this.dbContext = dbContext;
        }
        public async Task<IEnumerable<MasterProgramType>> GetAllASync()
        {
            try
            {
                return await dbContext.Master_ProgramType.ToListAsync();
            }
            catch (Exception ex)
            {
                throw;
            }
        }


        public async Task<MasterProgramType?> GetById(int id)
        {
            return await dbContext.Master_ProgramType.FirstOrDefaultAsync(x => x.Id == id);
        }






    }
}
