﻿using Azure.Core;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Query.Internal;
using MPDS.API.Data;
using MPDS.API.Models.Domain;
using MPDS.API.Models.DTO;
using MPDS.API.Repositories.Interface;
using MPDS.API.Utilities;
using System;
using System.Xml.Linq;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;

namespace MPDS.API.Repositories.Implementation
{
    public class ActivityGroupRepository : IActivityGroupRepository
    {
        /*

        */
        private readonly MPDSDbContext dbContext;
        public ActivityGroupRepository(MPDSDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        public async Task<ActivityGroup> CheckForDuplicateGroup(string groupName, long coordinatingAgencyId, long providerAgencyId)
        {
            //check for duplicate group first
            return await dbContext.ActivityGroup.FirstOrDefaultAsync(x => (x.Name == groupName) && (x.CoordinatingAgencyId == coordinatingAgencyId) && (x.ProviderAgencyId == providerAgencyId));          
           
        }

        public async Task<ActivityGroup> CreateAsync(ActivityGroup activityGroup)
        {
            await dbContext.ActivityGroup.AddAsync(activityGroup);
            await dbContext.SaveChangesAsync();
            return activityGroup;
        }

        public async Task<ActivityGroup?> DeleteGroupAndActivity(long id)
        {
            var existingGroup = await dbContext.ActivityGroup.FirstOrDefaultAsync(x => x.Id == id);
            if (existingGroup != null)
            {
                //existingGroup.IsActive = false;
                existingGroup.IsDeleted = true;
                await dbContext.SaveChangesAsync();

                 
                var existingActivityList = await dbContext.Activity.Where(x=>x.GroupId == id).ToListAsync().ConfigureAwait(false);

                if (dbContext is not null)
                
                foreach (var activity in existingActivityList)
                {
                        activity.IsDeleted = true; await dbContext.SaveChangesAsync();
                } 
            }
            return existingGroup;
        }

        public Task<ActivityGroupSPOut?> DeleteAsync(long id)
        {
            throw new NotImplementedException();
        }

        /*  public async Task<IEnumerable<ActivityGroup>> GetAllAsync()
          {
              var param = new SqlParameter("@CoordinatingAgencyId", -1);
              // var ActivityGroups = dbContext.ActivityGroup.FromSqlRaw("GetAllGroups @CoordinatingAgencyId", param).AsEnumerable().Take(10).ToList();
              return dbContext.ActivityGroup.FromSqlRaw("GetAllActivityGroups @CoordinatingAgencyId", param).AsEnumerable().Take(100).ToList();
          }*/
        public async Task<IEnumerable<ProgramName?>> GetProgramNameByGroupId(long id)
        {
            var query = from M_PG in dbContext.Master_ProgramName
                        join AG in dbContext.ActivityGroup on M_PG.Id equals AG.ProgramNameId
                        where
                             (AG.Id.Equals(id))
                        select new
                        {
                            M_PG.Id,
                            M_PG.Name
                        };

            var list = await query.ToListAsync().ConfigureAwait(false);

            return list
                    .Select(x => new ProgramName()
                    {
                        Id = x.Id,
                        Name = x.Name
                    }).ToList();
        }
        public async Task<IEnumerable<MasterProgramName?>> GetProgramNameByCoordinatingAgencyId(long id)
        {
            var param = new SqlParameter("@id", id);
            return dbContext.Master_ProgramName.FromSqlRaw("GetAllProgramNamesByCoordinatingAgency @id", param).AsEnumerable().ToList();            
        }
        public async Task<IEnumerable<ActivityGroup>> GetAllAsync(GroupsSearchInput inputparam)
        {
            //var param = new SqlParameter("@CoordinatingAgencyId", -1);          
            //return dbContext.ActivityGroup.FromSqlRaw("GetAllActivityGroups @CoordinatingAgencyId", param).AsEnumerable().Take(100).ToList();
            try
            {
                var query = //from A in dbContext.Activity
                            from AG in dbContext.ActivityGroup
                            join M_GT in dbContext.Master_GroupType on AG.GroupType equals M_GT.Id
                            join M_PT in dbContext.Master_ProgramType on AG.ProgramType equals M_PT.Id
                            join PA in dbContext.ProviderAgency on AG.ProviderAgencyId equals PA.Id
                            join CA in dbContext.CoordinatingAgency on AG.CoordinatingAgencyId equals CA.Id
                            join MPN in dbContext.Master_ProgramName on AG.ProgramNameId equals MPN.Id into mpnTemp
                            from subgroup in mpnTemp.DefaultIfEmpty()

                            where

                              (AG.IsDeleted.Equals(false)) && (AG.IsActive.Equals(true))

                            select new
                            {

                                AG.Id,
                                AG.Name,
                                strGroupType = M_GT.GroupType,
                                strProgramType = M_PT.ProgramType,
                                ProviderAgencyStatus = PA.IsActive,
                                CoordinatingAgencyStatus = CA.IsActive,
                                ActivityCount = (from A in dbContext.Activity
                                                 where A.GroupId.Equals(AG.Id) && A.IsDeleted.Equals(false)
                                                 select A).Count(),
                                ProgramName = (AG.ProgramNameId == -2 ? AG.OtherProgramName : subgroup.Name), //Add else MPN.Name

                                AG.CoordinatingAgencyId,
                                ProviderAgencyId = PA.Id,
                                AG.ProgramNameId,
                                AG.Comments,
                                AG.CreatedBy,
                                AG.UpdatedBy,
                                AG.EBPServiceType,
                                AG.GroupOptionalDataId,
                                AG.GroupType,
                                AG.ProgramType,
                                AG.InterventionType,
                                AG.IsDeleted,
                                AG.IsGamblingRelated,
                                AG.IsYATRelated,
                                AG.MinActivityCount,
                                AG.MaxActivityCount,
                                AG.OtherProgramName,
                                AG.ServiceDomain,
                                AG.ServiceLocation
                                //Row_Numb = null
                            };

                if (inputparam.GroupId > 0)
                {
                    query = query.Where(x => x.Id.Equals(inputparam.GroupId));
                }
                if (inputparam.CoordinatingAgencyId > 0)
                {
                    query = query.Where(x => x.CoordinatingAgencyId.Equals(inputparam.CoordinatingAgencyId));
                }
                if (inputparam.ProviderAgencyId > 0)
                {
                    query = query.Where(x => x.ProviderAgencyId.Equals(inputparam.ProviderAgencyId));
                }
                if (inputparam.GroupName is not null)
                    if (!inputparam.GroupName.Equals("string"))
                        if (inputparam.GroupName.Length > 0)
                        {
                            query = query.Where(x => x.Name.Contains(inputparam.GroupName));
                        }

                if (inputparam.userTypeId == 3)
                {
                    if (inputparam.userCoordinatingAgencyId > 0)
                        query = query.Where(x => x.CoordinatingAgencyId.Equals(inputparam.userCoordinatingAgencyId));
                }
                if (inputparam.userTypeId == 4)
                {
                    if (inputparam.userProviderAgencyId > 0)
                        query = query.Where(x => x.ProviderAgencyId.Equals(inputparam.userProviderAgencyId));
                }

                var list = await query.ToListAsync().ConfigureAwait(false);

                return list
                    .Select(x => new ActivityGroup()
                    {
                        Id = x.Id,
                        Name = x.Name,
                        strGroupType = x.strGroupType,
                        strProgramType = x.strProgramType,
                        ProviderAgencyStatus = x.ProviderAgencyStatus,
                        CoordinatingAgencyStatus = x.CoordinatingAgencyStatus,
                        ActivityCount = x.ActivityCount,
                        ProgramName = x.ProgramName,
                        CoordinatingAgencyId = x.CoordinatingAgencyId,
                        ProviderAgencyId = x.ProviderAgencyId,
                        ProgramNameId = x.ProgramNameId,
                        Comments = x.Comments,
                        CreatedBy = x.CreatedBy,
                        UpdatedBy = x.UpdatedBy,
                        EBPServiceType = x.EBPServiceType,
                        GroupOptionalDataId = x.GroupOptionalDataId,
                        GroupType = x.GroupType,
                        ProgramType = x.ProgramType,
                        InterventionType = x.InterventionType,
                        IsDeleted = x.IsDeleted,
                        IsGamblingRelated = x.IsGamblingRelated,
                        IsYATRelated = x.IsYATRelated,
                        MinActivityCount = x.MinActivityCount,
                        MaxActivityCount = x.MaxActivityCount,
                        OtherProgramName = x.OtherProgramName,
                        ServiceDomain = x.ServiceDomain,
                        ServiceLocation = x.ServiceLocation,

                    }).ToList();

            }
            catch (Exception)
            {
                throw;
            }
        }
        public async Task<PagedList<ActivityGroup>> GetAllAsyncPaginated(GroupsSearchInput inputparam, UserParams userParams)
        {
            try
            {
                var query = dbContext.ActivityGroup.AsNoTracking();

                if (inputparam.GroupId > 0)
                {
                    query = query.Where(x => x.Id.Equals(inputparam.GroupId));
                }

                if (inputparam.ProviderAgencyId > 0)
                {
                    query = query.Where(x => x.ProviderAgencyId.Equals(inputparam.ProviderAgencyId));
                }
                else
                 if (inputparam.CoordinatingAgencyId > 0)
                {
                    query = query.Where(x => x.CoordinatingAgencyId.Equals(inputparam.CoordinatingAgencyId));
                }
                if (inputparam.ProgramNameId > 0)
                {
                    query = query.Where(x => x.ProgramNameId.Equals(inputparam.ProgramNameId));
                }
                if ((inputparam.Status != null) && (inputparam.Status != string.Empty) && (inputparam.Status != "All"))
                {
                    if (inputparam.Status.Equals("Active"))
                        query = query.Where(x => x.IsActive.Equals(true));
                    if (inputparam.Status.Equals("Inactive"))
                        query = query.Where(x => x.IsActive.Equals(false));

                }
                if ((inputparam.IsActive != null) && (inputparam.Status != string.Empty) && (inputparam.Status != "All"))
                {
                    if (inputparam.IsActive.Equals("Active"))
                        query = query.Where(x => x.IsActive.Equals(true));
                    if (inputparam.IsActive.Equals("Inactive"))
                        query = query.Where(x => x.IsActive.Equals(false));

                }
                if (inputparam.GroupName is not null)
                    if (!inputparam.GroupName.Equals("string"))
                        if (inputparam.GroupName.Length > 0)
                        {
                            query = query.Where(x => x.Name.Contains(inputparam.GroupName));
                        }

                if (inputparam.userTypeId == 4)
                {
                    if (inputparam.userProviderAgencyId > 0)
                        query = query.Where(x => x.ProviderAgencyId.Equals(inputparam.userProviderAgencyId));
                }
                if (inputparam.userTypeId == 3)
                {
                    if (inputparam.userCoordinatingAgencyId > 0)
                        query = query.Where(x => x.CoordinatingAgencyId.Equals(inputparam.userCoordinatingAgencyId));
                }
                query = query.OrderBy(p => p.Name);
                return await PagedList<ActivityGroup>.CreateAsync(query, userParams.PageNumber, userParams.PageSize);
            }
            catch (Exception)
            {
                throw;
            }
        }
        // public Task<IEnumerable<ActivityGroup?>> GetbyCoordinatingAgency(long id)
        public async Task<IEnumerable<ActivityGroup>> GetbyCoordinatingAgency(long coordinatingAgencyId)
        {
            var param = new SqlParameter("@CoordinatingAgencyId", coordinatingAgencyId);
            // var ActivityGroups = dbContext.ActivityGroup.FromSqlRaw("GetAllGroups @CoordinatingAgencyId", param).AsEnumerable().Take(10).ToList();
            return dbContext.ActivityGroup.FromSqlRaw("GetAllActivityGroups @CoordinatingAgencyId", param).AsEnumerable().ToList();
        }

        public async Task<IEnumerable<ActivityGroup?>> GetbyProviderAgency(long coordinatingAgencyId, long providerAgencyId)
        {
            var query = dbContext.ActivityGroup.AsNoTracking();
            if (providerAgencyId > 0)
            {
                query = query.Where(x => x.ProviderAgencyId.Equals(providerAgencyId));
            } 
            else
            if (coordinatingAgencyId > 0)
            {
                query = query.Where(x => x.CoordinatingAgencyId.Equals(coordinatingAgencyId));
            }

            
            var list = await query.OrderBy(a=>a.Name).ToListAsync().ConfigureAwait(false);

            return list
                .Select(x => new ActivityGroup()
                {
                    Id = x.Id,
                    Name = x.Name,
                    strGroupType = x.strGroupType,
                    strProgramType = x.strProgramType,
                    ProviderAgencyStatus = x.ProviderAgencyStatus,
                    CoordinatingAgencyStatus = x.CoordinatingAgencyStatus,
                    ActivityCount = x.ActivityCount,
                    ProgramName = x.ProgramName,
                    CoordinatingAgencyId = x.CoordinatingAgencyId,
                    ProviderAgencyId = x.ProviderAgencyId,
                    ProgramNameId = x.ProgramNameId,
                    Comments = x.Comments,
                    CreatedBy = x.CreatedBy,
                    UpdatedBy = x.UpdatedBy,
                    EBPServiceType = x.EBPServiceType,
                    GroupOptionalDataId = x.GroupOptionalDataId,
                    GroupType = x.GroupType,
                    ProgramType = x.ProgramType,
                    InterventionType = x.InterventionType,
                    IsDeleted = x.IsDeleted,
                    IsGamblingRelated = x.IsGamblingRelated,
                    IsYATRelated = x.IsYATRelated,
                    MinActivityCount = x.MinActivityCount,
                    MaxActivityCount = x.MaxActivityCount,
                    OtherProgramName = x.OtherProgramName,
                    ServiceDomain = x.ServiceDomain,
                    ServiceLocation = x.ServiceLocation,

                }).ToList();

            ////////////////////
            //var paramCoordinatingAgencyId = new SqlParameter("@CoordinatingAgencyId", coordinatingAgencyId);
            //var paramProviderAgencyId = new SqlParameter("@ProviderAgencyId", providerAgencyId);
            //// var ActivityGroups = dbContext.ActivityGroup.FromSqlRaw("GetAllGroups @CoordinatingAgencyId", param).AsEnumerable().Take(10).ToList();
            //return dbContext.ActivityGroup.FromSqlRaw("GetAllActivityGroups @CoordinatingAgencyId, @ProviderAgencyId", paramCoordinatingAgencyId, paramProviderAgencyId).AsEnumerable().ToList();
        }
        public async Task<IEnumerable<ActivityGroup?>> GetbyProviderAgencyId(long providerAgencyId)
        {
            var paramProviderAgencyId = new SqlParameter("@ProviderAgencyId", providerAgencyId);
            return dbContext.ActivityGroup.FromSqlRaw("GetAllActivityGroups   @ProviderAgencyId", paramProviderAgencyId).AsEnumerable().ToList();
        }
        public async Task<IEnumerable<ActivityGroup>> GetbyGroupName(string name)
        {
            var param = new SqlParameter("@Name", name);
            // var ActivityGroups = dbContext.ActivityGroup.FromSqlRaw("GetAllGroups @CoordinatingAgencyId", param).AsEnumerable().Take(10).ToList();
            return dbContext.ActivityGroup.FromSqlRaw("GetAllActivityGroups @Name", param).AsEnumerable().ToList();
        }


        public async Task<ActivityGroup> UpdateAsync(ActivityGroup activityGroup)
        {
            var existingActivityGroup = await dbContext.ActivityGroup.FirstOrDefaultAsync(x => x.Id == activityGroup.Id);
            if (existingActivityGroup != null)
            {
                dbContext.Entry(existingActivityGroup).CurrentValues.SetValues(activityGroup);
                await dbContext.SaveChangesAsync();
                return activityGroup;
            }
            return null;
        }

        
        public async Task<ActivityGroup?> GetByActivityGroupId(long id)
        {
            return await dbContext.ActivityGroup.FirstOrDefaultAsync(x => x.Id == id);
        }

       
    }
}
