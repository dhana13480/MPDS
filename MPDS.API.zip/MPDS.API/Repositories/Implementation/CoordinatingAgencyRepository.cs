﻿using Azure.Core;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.EntityFrameworkCore;
using MPDS.API.Data;
using MPDS.API.Models.Domain;
using MPDS.API.Models.DTO;
using MPDS.API.Repositories.Interface;
using MPDS.API.Utilities;
using System.Collections;
using System.Xml.Linq;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;

namespace MPDS.API.Repositories.Implementation
{
    public class CoordinatingAgencyRepository : ICoordinatingAgencyRepository
    {
        private readonly MPDSDbContext dbContext;
        public CoordinatingAgencyRepository(MPDSDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        public async Task<CoordinatingAgency> CreateAsync(CoordinatingAgency coordinatingAgency)
        {
            await dbContext.CoordinatingAgency.AddAsync(coordinatingAgency);
            await dbContext.SaveChangesAsync();
            if (coordinatingAgency.Id>0)
            //save Program names 
            {
                string[] programNames = coordinatingAgency.ProgramNames.Split(',');
                foreach (var eachprogramName in programNames)
                {
                    if (eachprogramName != "")
                    {
                        var programNamestxt = new CoordinatingAgencyProgramNames()
                        {
                            CoordinatingAgencyId = coordinatingAgency.Id,
                            ProgramNameId = Convert.ToInt32(eachprogramName)
                        };
                        await dbContext.CoordinatingAgency_ProgramNames.AddAsync(programNamestxt);
                        await dbContext.SaveChangesAsync();
                    }
                }
            }
            return coordinatingAgency;
        }
        public async Task<CoordinatingAgency?> DeActivatePIHPRegion(int id)
        {
            var existingCoordinatingAgency = await dbContext.CoordinatingAgency.FirstOrDefaultAsync(x => x.Id == id);
            if (existingCoordinatingAgency != null)
            {
                existingCoordinatingAgency.IsActive = false;                
                await dbContext.SaveChangesAsync();                 
                return existingCoordinatingAgency;
            }
            return null;
        }
        public async Task<CoordinatingAgency?> DeleteAsync(int id)
        {
            var existingCoordinatingAgency = await dbContext.CoordinatingAgency.FirstOrDefaultAsync(c => c.Id == id);
            if (existingCoordinatingAgency is null)
            {
                return null;
            }
            dbContext.CoordinatingAgency.Remove(existingCoordinatingAgency);
            await dbContext.SaveChangesAsync();
            return existingCoordinatingAgency;
        }

        public async Task<IEnumerable<CoordinatingAgency>> GetAllAsync(UserRoles userRoles)
        {
            try
            {
                 
                if (userRoles.userTypeId <= 2)
                    return await dbContext.CoordinatingAgency.Where(c=>c.IsActive.Equals(true)).ToListAsync();
                if (userRoles.userTypeId == 3)
                    if (userRoles.coordinatingAgencyId > 0)
                        return await dbContext.CoordinatingAgency.Where(c => c.IsActive.Equals(true))
                            .Where(a => a.Id == userRoles.coordinatingAgencyId)
                            .ToListAsync();
                if (userRoles.userTypeId ==4)
                    if (userRoles.providerAgencyId > 0)
                    {
                        var query = from P in dbContext.ProviderAgency
                                    join C in dbContext.CoordinatingAgency on P.CoordinatingAgencyId equals (C.Id)  
                                                                       
                                    select new
                                    {
                                        C.Id,
                                        C.Name,
                                        C.IsActive,
                                        C.OfficePhone,
                                        C.Fax,
                                        C.Address1,
                                        C.Address2,
                                        C.City,
                                        C.State,
                                        C.Zip,
                                        C.Comments,
                                        C.AddressComments,
                                        C.Pc_FirstName,
                                        C.Pc_MiddleName,
                                        C.Pc_LastName,
                                        C.Pc_Email,
                                        C.Pc_OfficePhone,
                                        C.Pc_CellPhone,
                                        C.Pc_Comments,
                                        C.CreatedBy,
                                        C.CreationDate,
                                        C.UpdatedBy,
                                        C.UpdationDate,
                                        C.OptionalData
                                    };
                        var list = await query.Where(c => c.IsActive.Equals(true)).OrderBy(p=> p.Name).ToListAsync().ConfigureAwait(false);
                        return list
                             .Select(C => new CoordinatingAgency()
                             {
                                 Id = C.Id,
                                 Name = C.Name,
                                 IsActive = C.IsActive,
                                 OfficePhone = C.OfficePhone,
                                 Fax = C.Fax,
                                 Address1 = C.Address1,
                                 Address2 = C.Address2,
                                 City = C.City,
                                 State = C.State,
                                 Zip = C.Zip,
                                 Comments = C.Comments,
                                 AddressComments = C.AddressComments,
                                 Pc_FirstName = C.Pc_FirstName,
                                 Pc_MiddleName = C.Pc_MiddleName,
                                 Pc_LastName = C.Pc_LastName,
                                 Pc_Email = C.Pc_Email,
                                 Pc_OfficePhone = C.Pc_OfficePhone,
                                 Pc_CellPhone = C.Pc_CellPhone,
                                 Pc_Comments = C.Pc_Comments,
                                 CreatedBy = C.CreatedBy,
                                 CreationDate = C.CreationDate,
                                 UpdatedBy = C.UpdatedBy,
                                 UpdationDate = C.UpdationDate,
                                 OptionalData = C.OptionalData
                             }).ToList();
                    }
                return null;
            }
            catch (Exception ex)
            {
                throw;
            }

        }

        public async Task<IEnumerable<CoordinatingAgencyCounty?>> GetCountyByCoordinatingAgencyId(long coordinatingAgencyId)
        {
            try
            {
                var query = from CAC in dbContext.CoordinatingAgency_County
                                //join C in dbContext.Master_County on CAC.CountyId equals C.Id
                            where CAC.CoordinatingAgencyId == coordinatingAgencyId
                            select new
                            {
                                CAC.CountyId,
                                CAC.CoordinatingAgencyId,
                                CAC.Id
                                //C.County
                            };
                var list = await query.ToListAsync().ConfigureAwait(false);
                return list
                            .Select(x => new CoordinatingAgencyCounty()
                            {
                                CountyId = x.CountyId,
                                CoordinatingAgencyId = x.CoordinatingAgencyId,
                                Id = x.Id
                                //County = x.County
                            }).ToList();
            }
            catch (Exception ex)
            {
                throw;
            }

        }

        public async Task<CoordinatingAgency?> GetById(int id)
        {
            return await dbContext.CoordinatingAgency.FirstOrDefaultAsync(x => x.Id == id);
        }

        public IEnumerable<CoordinatingAgency?> GetByName(string name = null)
        {
            return dbContext.CoordinatingAgency
                .Where(a => !string.IsNullOrEmpty(a.Name.Trim()))
                .Where(a => name == null || a.Name.ToUpper().Contains(name.ToUpper()))
                .Where(a => a.IsActive.Equals(true))
                .Select(a => new CoordinatingAgency() { Name = a.Name })
                .GroupBy(a => a.Name, (key, group) => new CoordinatingAgency() { Name = key })
                .OrderBy(a => a.Name)
                .ToList();             
        }

        public async Task<CoordinatingAgency?> UpdateAsync(CoordinatingAgency coordinatingAgency)
        {
            var existingCoordinatingAgency = await dbContext.CoordinatingAgency.FirstOrDefaultAsync(x => x.Id == coordinatingAgency.Id);
            if (existingCoordinatingAgency != null)
            {
                dbContext.Entry(existingCoordinatingAgency).CurrentValues.SetValues(coordinatingAgency);
                await dbContext.SaveChangesAsync();
                return coordinatingAgency;
            }
            return null;
        }

        public async Task<CoordinatingAgencyCountyRequest> UpdateCountyListForCoordinatingAgencyId(CoordinatingAgencyCountyRequest request)
        {
            var query = from ac in dbContext.CoordinatingAgency_County
                        where ac.CoordinatingAgencyId == request.CoordinatingAgencyId
                        select new
                        {
                            ac.Id,
                            ac.CoordinatingAgencyId,
                            ac.CountyId
                        };
            var existingCountyList = await query.ToListAsync().ConfigureAwait(false);

            if (existingCountyList is null)
            {
                return null;
            }
            foreach (var county in existingCountyList)
            {
                var coordinatingAgencyCountytxt = new CoordinatingAgencyCounty()
                {
                    Id = county.Id,
                    CoordinatingAgencyId = county.CoordinatingAgencyId,
                    CountyId = Convert.ToInt32(county.CountyId)
                };

                dbContext.CoordinatingAgency_County.Remove(coordinatingAgencyCountytxt);
            }
            await dbContext.SaveChangesAsync();

            string[] counties = request.CountyList.Split(',');
            foreach (var eachCounty in counties)
            {
                var coordinatingAgencyCountytxt = new CoordinatingAgencyCounty()
                {
                    CoordinatingAgencyId = request.CoordinatingAgencyId,
                    CountyId = Convert.ToInt32(eachCounty)
                };
                await dbContext.CoordinatingAgency_County.AddAsync(coordinatingAgencyCountytxt);
                await dbContext.SaveChangesAsync();
            }
            return request;
        }
        public async Task<CoordinatingAgencySchoolDistrictRequest> UpdateSchoolDistrictListForCoordinatingAgencyId(CoordinatingAgencySchoolDistrictRequest request)
        {
            var query = from ac in dbContext.CoordinatingAgency_SchoolDistrict
                        where ac.CoordinatingAgencyId == request.CoordinatingAgencyId
                        select new
                        {
                            ac.Id,
                            ac.CoordinatingAgencyId,
                            ac.SchoolDistrictId
                        };
            var existingSchoolDistList = await query.ToListAsync().ConfigureAwait(false);

            if (existingSchoolDistList is null)
            {
                return null;
            }
            foreach (var existingSchool in existingSchoolDistList)
            {
                var coordinatingAgencySchooltxt = new CoordinatingAgencySchoolDistrict()
                {
                    Id = existingSchool.Id,
                    CoordinatingAgencyId = existingSchool.CoordinatingAgencyId,
                    SchoolDistrictId = Convert.ToInt32(existingSchool.SchoolDistrictId)
                };

                dbContext.CoordinatingAgency_SchoolDistrict.Remove(coordinatingAgencySchooltxt);
            }
            await dbContext.SaveChangesAsync();

            string[] schools = request.SchoolDistList.Split(',');
            foreach (var school in schools)
            {
                var coordinatingAgencySchoolDisttxt = new CoordinatingAgencySchoolDistrict()
                {
                    CoordinatingAgencyId = request.CoordinatingAgencyId,
                    SchoolDistrictId = Convert.ToInt32(school)
                };
                await dbContext.CoordinatingAgency_SchoolDistrict.AddAsync(coordinatingAgencySchoolDisttxt);
                await dbContext.SaveChangesAsync();
            }
            return request;
        }

        public async Task<CoordinatingAgencyOptionalDataRequest> UpdateOptionalDataForCoordinatingAgency(CoordinatingAgencyOptionalDataRequest request)
        {
            var query = from ac in dbContext.CoordinatingAgency_OptionalData
                        where ac.CoordinatingAgencyId == request.CoordinatingAgencyId
                        select new
                        {
                            ac.Id,
                            ac.CoordinatingAgencyId,
                            ac.OptionalDataId
                        };
            var existingOptDistList = await query.ToListAsync().ConfigureAwait(false);

            if (existingOptDistList is null)
            {
                return null;
            }
            foreach (var existingOption in existingOptDistList)
            {
                var coordinatingOptiontxt = new CoordinatingAgencyOptionalData()
                {
                    Id = existingOption.Id,
                    CoordinatingAgencyId = existingOption.CoordinatingAgencyId,
                    OptionalDataId = Convert.ToInt32(existingOption.OptionalDataId)
                };

                dbContext.CoordinatingAgency_OptionalData.Remove(coordinatingOptiontxt);
            }
            await dbContext.SaveChangesAsync();

            string[] options = request.OptionalDataList.Split(',');
            foreach (var option in options)
            {
                var coordinatingAgencyOpttxt = new CoordinatingAgencyOptionalData()
                {
                    CoordinatingAgencyId = request.CoordinatingAgencyId,
                    OptionalDataId = Convert.ToInt32(option)
                };
                await dbContext.CoordinatingAgency_OptionalData.AddAsync(coordinatingAgencyOpttxt);
                await dbContext.SaveChangesAsync();
            }
            return request;
        }

        public async Task<CoordinatingAgencyProgramNamesRequest> UpdateProgramNamesForCoordinatingAgency(CoordinatingAgencyProgramNamesRequest request)
        {
            var query = from ac in dbContext.CoordinatingAgency_ProgramNames
                        where ac.CoordinatingAgencyId == request.CoordinatingAgencyId
                        select new
                        {
                            ac.Id,
                            ac.CoordinatingAgencyId,
                            ac.ProgramNameId
                        };
            var existingProgNamesList = await query.ToListAsync().ConfigureAwait(false);

            if (existingProgNamesList is null)
            {
                return null;
            }
            foreach (var existingProgramNames in existingProgNamesList)
            {
                var coordinatingOptiontxt = new CoordinatingAgencyProgramNames()
                {
                    Id = existingProgramNames.Id,
                    CoordinatingAgencyId = existingProgramNames.CoordinatingAgencyId,
                    ProgramNameId = Convert.ToInt32(existingProgramNames.ProgramNameId)
                };

                dbContext.CoordinatingAgency_ProgramNames.Remove(coordinatingOptiontxt);
            }
            await dbContext.SaveChangesAsync();

            string[] options = request.ProgramNameListCSV.Split(',');
            foreach (var option in options)
            {
                var coordinatingAgencyOpttxt = new CoordinatingAgencyProgramNames()
                {
                    CoordinatingAgencyId = request.CoordinatingAgencyId,
                    ProgramNameId = Convert.ToInt32(option)
                };
                await dbContext.CoordinatingAgency_ProgramNames.AddAsync(coordinatingAgencyOpttxt);
                await dbContext.SaveChangesAsync();
            }
            return request;
        }

       
    }
}
