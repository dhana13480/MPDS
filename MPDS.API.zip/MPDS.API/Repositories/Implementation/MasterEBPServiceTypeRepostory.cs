﻿using Microsoft.EntityFrameworkCore;
using MPDS.API.Data;
using MPDS.API.Models.Domain;
using MPDS.API.Repositories.Interface;

namespace MPDS.API.Repositories.Implementation
{
    public class MasterEBPServiceTypeRepostory: IMasterEBPServiceTypeRepository
    {
        private readonly MPDSDbContext dbContext;
        public MasterEBPServiceTypeRepostory(MPDSDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        public async Task<IEnumerable<MasterEBPServiceType>> GetAllAsync()
        {
            try
            {
                return await dbContext.Master_EBPServiceType.Where(x=>x.IsActive==true).ToListAsync();
            }
            catch (Exception ex)
            {
                throw;
            }
        }
    }
}
