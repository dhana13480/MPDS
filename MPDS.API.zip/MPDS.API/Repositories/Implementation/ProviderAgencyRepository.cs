﻿using Microsoft.EntityFrameworkCore;
using MPDS.API.Data;
using MPDS.API.Models.Domain;
using MPDS.API.Repositories.Interface;
using MPDS.API.Utilities;
using static MPDS.API.Models.Domain.Enums;

namespace MPDS.API.Repositories.Implementation
{
    public class ProviderAgencyRepository : IProviderAgencyRepository
    {
        private readonly MPDSDbContext dbContext;
        public ProviderAgencyRepository(MPDSDbContext dbContext)
        {
            this.dbContext = dbContext;
        }
        public async Task<Models.Domain.ProviderAgency> CreateAsync(Models.Domain.ProviderAgency providerAgency)
        {
            await dbContext.ProviderAgency.AddAsync(providerAgency);
            await dbContext.SaveChangesAsync();
            return providerAgency;
             
        }

        public Task<Models.Domain.ProviderAgency?> DeleteAsync(int id)
        {
            throw new NotImplementedException();
        }
                 
        public async Task<IEnumerable<ProviderAgency>> GetAllAsync()
        {
            try
            {
                return await dbContext.GetAllProviderAgencies
                    .Where(agency => agency.IsActive == true)                   
                    .ToListAsync();
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public async Task<PagedList<ProviderAgency>> GetAllAsyncPaginated(UserParams userParams, ProviderSearchInput inputParam, UserRoles userRoles)
        {
            try
            {
                var query = dbContext.GetAllProviderAgencies
                      //.Where(agency => agency.IsActive == true)
                      .AsNoTracking();
                if ((inputParam.Status != null) && (inputParam.Status != string.Empty) && (inputParam.Status != "All"))
                {
                    if (inputParam.Status.Equals("Active"))
                        query = query.Where(x => x.IsActive ==true);
                    if (inputParam.Status.Equals("InActive"))
                        query = query.Where(x => !x.IsActive == false);
                }
                if (inputParam.Name is not null)
                    if (!inputParam.Name.Equals("string"))
                        if (inputParam.Name.Length > 0)
                        {
                            query = query.Where(x => x.Name.Contains(inputParam.Name));
                        }
                query=query.OrderBy(p=>p.Name);
                if (userRoles.userTypeId is not null)
                {
                    if (userRoles.userTypeId <= 2)
                        return await PagedList<ProviderAgency>.CreateAsync(query, userParams.PageNumber, userParams.PageSize);
                }
                if (userRoles.userTypeId == 3)
                    if (userRoles.coordinatingAgencyId > 0)
                        query = query.Where(x => x.CoordinatingAgencyId== userRoles.coordinatingAgencyId);

                if (userRoles.userTypeId == 4)
                    if (userRoles.providerAgencyId > 0)
                        query = query.Where(x => x.Id == userRoles.providerAgencyId);

               
                return await PagedList<ProviderAgency>.CreateAsync(query, userParams.PageNumber, userParams.PageSize);
            }
            catch (Exception ex)
            {
                throw null;
            }
        }

        public async Task<IEnumerable<ProviderAgency>> GetAllByCoordinatingAgencyId(int id)
        {
            return await dbContext.GetAllProviderAgencies
                .Where(x => x.CoordinatingAgencyId == id)
                .ToListAsync();
        }
        public async Task<ProviderAgency?> GetById(int id)
        {
            return await dbContext.ProviderAgency.FirstOrDefaultAsync(x => x.Id == id);
        }
        

        public async Task<Models.Domain.ProviderAgency?> UpdateAsync(Models.Domain.ProviderAgency providerAgency)
        {
             var existingProviderAgency = await dbContext.ProviderAgency.FirstOrDefaultAsync(x => x.Id == providerAgency.Id);
            if(existingProviderAgency != null)
            {
                dbContext.Entry(existingProviderAgency).CurrentValues.SetValues(providerAgency);
                await dbContext.SaveChangesAsync();
                return providerAgency;
            }
            return null;
        }

        public async Task<ProviderAgencyCountyRequest> UpdateCountyListForProviderAgencyId(ProviderAgencyCountyRequest request)
        {
            var query = from ac in dbContext.ProviderAgency_County
                        where ac.ProviderAgencyId == request.ProviderAgencyId
                        select new
                        {
                            ac.Id,
                            ac.ProviderAgencyId,
                            ac.CountyId
                        };
            var existingCountyList = await query.ToListAsync().ConfigureAwait(false);

            if (existingCountyList is null)
            {
                return null;
            }
            foreach (var county in existingCountyList)
            {
                var providerAgencyCountytxt = new ProviderAgencyCounty()
                {
                    Id = county.Id,
                    ProviderAgencyId = county.ProviderAgencyId,
                    CountyId = Convert.ToInt32(county.CountyId)
                };

                dbContext.ProviderAgency_County.Remove(providerAgencyCountytxt);
            }
            await dbContext.SaveChangesAsync();

            string[] counties = request.CountyList.Split(',');
            foreach (var eachCounty in counties)
            {
                var providerAgencyCountytxt = new ProviderAgencyCounty()
                {
                    ProviderAgencyId = request.ProviderAgencyId,
                    CountyId = Convert.ToInt32(eachCounty)
                };
                await dbContext.ProviderAgency_County.AddAsync(providerAgencyCountytxt);
                await dbContext.SaveChangesAsync();
            }
            return request;
        }

        public async Task<ProviderAgencyOptionalDataRequest> UpdateOptionalDataForProviderAgency(ProviderAgencyOptionalDataRequest request)
        {
            var query = from ac in dbContext.ProviderAgency_OptionalData
                        where ac.ProviderAgencyId == request.ProviderAgencyId
                        select new
                        {
                            ac.Id,
                            ac.ProviderAgencyId,
                            ac.OptionalDataId
                        };
            var existingOptDistList = await query.ToListAsync().ConfigureAwait(false);

            if (existingOptDistList is null)
            {
                return null;
            }
            foreach (var existingOption in existingOptDistList)
            {
                var coordinatingOptiontxt = new ProviderAgencyOptionalData()
                {
                    Id = existingOption.Id,
                    ProviderAgencyId = existingOption.ProviderAgencyId,
                    OptionalDataId = Convert.ToInt32(existingOption.OptionalDataId)
                };

                dbContext.ProviderAgency_OptionalData.Remove(coordinatingOptiontxt);
            }
            await dbContext.SaveChangesAsync();

            string[] options = request.OptionalDataList.Split(',');
            foreach (var option in options)
            {
                var ProviderAgencyOpttxt = new CoordinatingAgencyOptionalData()
                {
                    CoordinatingAgencyId = request.ProviderAgencyId,
                    OptionalDataId = Convert.ToInt32(option)
                };
                await dbContext.CoordinatingAgency_OptionalData.AddAsync(ProviderAgencyOpttxt);
                await dbContext.SaveChangesAsync();
            }
            return request;
        }

        public async Task<ProviderAgencySchoolDistrictRequest> UpdateSchoolDistrictListForProviderAgencyId(ProviderAgencySchoolDistrictRequest request)
        {
            var query = from ac in dbContext.ProviderAgency_SchoolDistrict
                        where ac.ProviderAgencyId == request.ProviderAgencyId
                        select new
                        {
                            ac.Id,
                            ac.ProviderAgencyId,
                            ac.SchoolDistrictId
                        };
            var existingSchoolDistList = await query.ToListAsync().ConfigureAwait(false);

            if (existingSchoolDistList is null)
            {
                return null;
            }
            foreach (var existingSchool in existingSchoolDistList)
            {
                var ProviderAgencySchooltxt = new ProviderAgencySchoolDistrict()
                {
                    Id = existingSchool.Id,
                    ProviderAgencyId = existingSchool.ProviderAgencyId,
                    SchoolDistrictId = Convert.ToInt32(existingSchool.SchoolDistrictId)
                };

                dbContext.ProviderAgency_SchoolDistrict.Remove(ProviderAgencySchooltxt);
            }
            await dbContext.SaveChangesAsync();

            string[] schools = request.SchoolDistList.Split(',');
            foreach (var school in schools)
            {
                var providerAgencySchoolDisttxt = new ProviderAgencySchoolDistrict()
                {
                    ProviderAgencyId = request.ProviderAgencyId,
                    SchoolDistrictId = Convert.ToInt32(school)
                };
                await dbContext.ProviderAgency_SchoolDistrict.AddAsync(providerAgencySchoolDisttxt);
                await dbContext.SaveChangesAsync();
            }
            return request;
        }
    }
}
