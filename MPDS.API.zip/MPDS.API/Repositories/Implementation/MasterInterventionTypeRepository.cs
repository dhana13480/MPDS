﻿using Microsoft.EntityFrameworkCore;
using MPDS.API.Data;
using MPDS.API.Models.Domain;
using MPDS.API.Repositories.Interface;

namespace MPDS.API.Repositories.Implementation
{
    public class MasterInterventionTypeRepository : IMasterInterventionTypeRepository
    {
        private readonly MPDSDbContext dbContext;

        public MasterInterventionTypeRepository(MPDSDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        public Task<MasterInterventionType> CreateAsync(MasterInterventionType setting)
        {
            throw new NotImplementedException();
        }

        public Task<MasterInterventionType?> DeleteAsync(int id)
        {
            throw new NotImplementedException();
        }

        public async Task<IEnumerable<MasterInterventionType>> GetAllSync()
        {
            return await dbContext.Master_InterventionType.ToListAsync();
        }

        public Task<MasterInterventionType?> GetById(int id)
        {
            throw new NotImplementedException();
        }

        public Task<MasterInterventionType?> UpdateAsync(MasterInterventionType serviceSetting)
        {
            throw new NotImplementedException();
        }
    }
}
