﻿using Microsoft.EntityFrameworkCore;
using MPDS.API.Data;
using MPDS.API.Models.Domain;
using MPDS.API.Repositories.Interface;

namespace MPDS.API.Repositories.Implementation
{
    public class MasterServicePopulationRepository : IMasterServicePopulationRepository
    {
        private readonly MPDSDbContext dbContext;

        public MasterServicePopulationRepository(MPDSDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        public Task<MasterServicePopulation> CreateAsync(MasterServicePopulation Population)
        {
            throw new NotImplementedException();
        }

        public Task<MasterServicePopulation?> DeleteAsync(int id)
        {
            throw new NotImplementedException();
        }

        public async Task<IEnumerable<MasterServicePopulation>> GetAllSync()
        {
            return await dbContext.Master_ServicePopulation.ToListAsync();
        }

        public Task<MasterServicePopulation?> GetById(int id)
        {
            throw new NotImplementedException();
        }

        public Task<MasterServicePopulation?> UpdateAsync(MasterServicePopulation servicePopulation)
        {
            throw new NotImplementedException();
        }
    }
}
