﻿using Microsoft.EntityFrameworkCore;
using MPDS.API.Data;
using MPDS.API.Models.Domain;
using MPDS.API.Repositories.Interface;

namespace MPDS.API.Repositories.Implementation
{
    public class MasterGroupTypeRepository : IMasterGroupTypeRepository
    {
        private readonly MPDSDbContext dbContext;
        public MasterGroupTypeRepository(MPDSDbContext dbContext)
        {
            this.dbContext = dbContext;
        }
        public async Task<IEnumerable<MasterGroupType>> GetAllAsync()
        {
            try
            {
                return await dbContext.Master_GroupType.ToListAsync();
            }
            catch (Exception ex)
            {
                throw;
            }
        }
    }
}
