﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Query.Internal;
using MPDS.API.Data;
using MPDS.API.Models.Domain;
using MPDS.API.Models.DTO;
using MPDS.API.Repositories.Interface;
using MPDS.API.Utilities;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;

namespace MPDS.API.Repositories.Implementation
{
    public class DatabaseLoggerService : IDatabaseLoggerService
    {
        private readonly MPDSDbContext dbContext;
        public DatabaseLoggerService(MPDSDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        public async Task<ExceptionLog?> LogInfo(string logText, string controllerMethod, string userId)
        {
            try
            {
                var exceptionLog = new ExceptionLog
                {
                    Message = logText,
                    StackTrace = "",
                    Timestamp = DateTime.UtcNow,
                    Source = controllerMethod,
                    ExceptionType = "Informational",
                    UserId = userId
                };

                dbContext.ExceptionLogs.Add(exceptionLog);
                await dbContext.SaveChangesAsync();
                return exceptionLog;
            }
            catch (Exception ex)
            {
                //dbContext.ExceptionLogs.Add(exceptionLog);
                //await dbContext.SaveChangesAsync();
                //return exceptionLog;
               
                 return null;
            }

        }
        public async Task<ExceptionLog> LogException(Exception ex, string userId)
        {
            var exceptionLog = new ExceptionLog
            {
                Message = ex.Message,
                StackTrace = ex.StackTrace,
                Timestamp = DateTime.UtcNow,
                Source = ex.Source,
                ExceptionType = ex.GetType().Name,
                UserId = userId
            };

            dbContext.ExceptionLogs.Add(exceptionLog);
            await dbContext.SaveChangesAsync();
            return exceptionLog;
        }
    }
}
