﻿using Microsoft.EntityFrameworkCore;
using MPDS.API.Data;
using MPDS.API.Models.Domain;
using MPDS.API.Repositories.Interface;

namespace MPDS.API.Repositories.Implementation
{
    public class ProgramNameByCoordinatingAgencyRepository : IProgramNameByCoordinatingAgencyRepository
    {
        private readonly MPDSDbContext dbContext;
        public ProgramNameByCoordinatingAgencyRepository(MPDSDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        public Task<ProgramNameByCoordinatingAgency> CreateAsync(ProgramNameByCoordinatingAgency programNameByCoordinatingAgency)
        {
            throw new NotImplementedException();
        }

        public Task<ProgramNameByCoordinatingAgency?> DeleteAsync(int id)
        {
            throw new NotImplementedException();
        }

        public async Task<IEnumerable<Models.Domain.ProgramNameByCoordinatingAgency>> GetAllAsync()
        {
            //throw new NotImplementedException();
            try
            {
                var query = from pac in dbContext.CoordinatingAgency_ProgramNames
                            join m_pn in dbContext.Master_ProgramName
                            on pac.ProgramNameId equals m_pn.Id

                            select new
                            {
                                pac.Id,
                                pac.ProgramNameId,
                                pac.CoordinatingAgencyId,
                                m_pn.Name
                            };
                var list = await query.ToListAsync();

                return list
                    .Select(x => new ProgramNameByCoordinatingAgency()
                    {
                        id = x.Id,
                        coordinatingAgencyId = x.CoordinatingAgencyId,
                        programNameId = x.ProgramNameId,
                        programName = x.Name
                    }).ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<List<ProgramNameByCoordinatingAgency>> GetByCoordinatingAgencyId(long CoordinatingAgencyId)
        {
            try
            {
                var query = from pac in dbContext.CoordinatingAgency_ProgramNames
                            join m_pn in dbContext.Master_ProgramName
                            on pac.ProgramNameId equals m_pn.Id
                            where pac.CoordinatingAgencyId == CoordinatingAgencyId
                            select new
                            {
                                pac.Id,
                                pac.ProgramNameId,
                                pac.CoordinatingAgencyId,
                                m_pn.Name
                            };
                var list = await query.ToListAsync();

                return list
                    .Select(x => new ProgramNameByCoordinatingAgency()
                    {
                        id = x.Id,
                        coordinatingAgencyId = x.CoordinatingAgencyId,
                        programNameId = x.ProgramNameId,
                        programName = x.Name
                    })
                 
                    .ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }

        public Task<ProgramNameByCoordinatingAgency?> UpdateAsync(ProgramNameByCoordinatingAgency programNameByCoordinatingAgency)
        {
            throw new NotImplementedException();
        }
    }

       
    }
