﻿using Microsoft.EntityFrameworkCore;
using MPDS.API.Controllers;
using MPDS.API.Data;
using MPDS.API.Models.Domain;
using MPDS.API.Repositories.Interface;
namespace MPDS.API.Repositories.Implementation
{
    public class MasterPermissionRepository : IMasterPermissionRepository
    {
        private readonly MPDSDbContext dbContext;
        public MasterPermissionRepository(MPDSDbContext dbContext)
        {
            this.dbContext = dbContext;
        }
        public async Task<IEnumerable<MasterPermission>> GetAllASync()
        {
            try
            {
                return await dbContext.Master_Permission.ToListAsync();
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public async Task<MasterPermission?> GetById(int id)
        {
            return await dbContext.Master_Permission.FirstOrDefaultAsync(x => x.Id == id);
        }
    }
}
