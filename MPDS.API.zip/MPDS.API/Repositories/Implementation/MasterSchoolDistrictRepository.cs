﻿using Microsoft.EntityFrameworkCore;
using MPDS.API.Data;
using MPDS.API.Models.Domain;
using MPDS.API.Repositories.Interface;

namespace MPDS.API.Repositories.Implementation
{
    public class MasterSchoolDistrictRepository : IMasterSchoolDistrictRepository
    {
        private readonly MPDSDbContext dbContext;
        public MasterSchoolDistrictRepository(MPDSDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        public Task<MasterSchoolDistrict> CreateAsync(MasterSchoolDistrict masterSchoolDistrict)
        {
            throw new NotImplementedException();
        }

        public Task<MasterSchoolDistrict?> DeleteAsync(int id)
        {
            throw new NotImplementedException();
        }

        public async Task<IEnumerable<MasterSchoolDistrict>> GetAllAsync()
        {
            try
            {
                return await dbContext.Master_SchoolDistrict.ToListAsync();
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public Task<MasterSchoolDistrict?> UpdateAsync(MasterSchoolDistrict masterSchoolDistrict)
        {
            throw new NotImplementedException();
        }
    }
}
