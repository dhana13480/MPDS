﻿using Microsoft.EntityFrameworkCore;
using MPDS.API.Data;
using MPDS.API.Models.Domain;
using MPDS.API.Repositories.Interface;
namespace MPDS.API.Repositories.Implementation
{
    public class MasterGrpOptionalDataRepository: IMasterGrpOptionalDataRepository
    {
        private readonly MPDSDbContext dbContext;
        public MasterGrpOptionalDataRepository(MPDSDbContext dbContext)
        {
            this.dbContext = dbContext;
        }
        public async Task<IEnumerable<MasterGrpOptionalData>> GetAllSync()
        {
            try
            {
                return await dbContext.Master_GroupOptionalData.ToListAsync();
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public async Task<MasterGrpOptionalData?> GetById(int id)
        {
            return await dbContext.Master_GroupOptionalData.FirstOrDefaultAsync(x => x.Id == id);
        }
    }
}
