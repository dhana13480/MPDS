﻿using Microsoft.EntityFrameworkCore;
using MPDS.API.Data;
using MPDS.API.Models.Domain;
using MPDS.API.Repositories.Interface;

namespace MPDS.API.Repositories.Implementation
{
    public class MasterServiceSettingRepository : IMasterServiceSettingRepository
    {
        private readonly MPDSDbContext dbContext;

        public MasterServiceSettingRepository(MPDSDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        public Task<MasterServiceSetting> CreateAsync(MasterServiceSetting setting)
        {
            throw new NotImplementedException();
        }

        public Task<MasterServiceSetting?> DeleteAsync(int id)
        {
            throw new NotImplementedException();
        }

        public async Task<IEnumerable<MasterServiceSetting>> GetAllSync()
        {
            return await dbContext.Master_ServiceSetting.ToListAsync();
        }

        public Task<MasterServiceSetting?> GetById(int id)
        {
            throw new NotImplementedException();
        }

        public Task<MasterServiceSetting?> UpdateAsync(MasterServiceSetting serviceSetting)
        {
            throw new NotImplementedException();
        }
    }
}
