﻿using MPDS.API.Models.Domain;
namespace MPDS.API.Repositories.Interface
{
    public interface IMasterProgramTypeRepository
    {
        Task<IEnumerable<MasterProgramType>> GetAllASync();
        Task<MasterProgramType?> GetById(int id);
    }
}
