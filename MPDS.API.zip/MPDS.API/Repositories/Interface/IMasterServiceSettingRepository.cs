﻿using MPDS.API.Models.Domain;

namespace MPDS.API.Repositories.Interface
{
    public interface IMasterServiceSettingRepository
    {
        Task<MasterServiceSetting> CreateAsync(MasterServiceSetting serviceSetting);
        Task<IEnumerable<MasterServiceSetting>> GetAllSync();
        Task<MasterServiceSetting?> GetById(int id);
        Task<MasterServiceSetting?> UpdateAsync(MasterServiceSetting serviceSetting);
        Task<MasterServiceSetting?> DeleteAsync(int id);
    }
}
