﻿using MPDS.API.Models.Domain;
namespace MPDS.API.Repositories.Interface
{
    public interface IMasterGrpOptionalDataRepository
    {
        Task<IEnumerable<MasterGrpOptionalData>> GetAllSync();
        Task<MasterGrpOptionalData?> GetById(int id);
    }
}
