﻿using MPDS.API.Models.Domain;
using MPDS.API.Utilities;
namespace MPDS.API.Repositories.Interface
{
    public interface IActivityGroupRepository
    {
        Task<IEnumerable<ActivityGroup?>> GetAllAsync(GroupsSearchInput inputparam);
        Task<PagedList<ActivityGroup>> GetAllAsyncPaginated(GroupsSearchInput inputparam, UserParams userParams);
        Task<IEnumerable<ActivityGroup?>> GetbyCoordinatingAgency(long id);
        Task<IEnumerable<ActivityGroup?>> GetbyProviderAgency(long coordinatingAgencyId, long providerAgencyId);
        Task<IEnumerable<ActivityGroup?>> GetbyProviderAgencyId(long providerAgencyId);
        Task<IEnumerable<ActivityGroup?>> GetbyGroupName(string name);
        Task<ActivityGroup?> DeleteGroupAndActivity(long id);
        Task<ActivityGroup> CreateAsync(ActivityGroup activity);
        Task<ActivityGroup> CheckForDuplicateGroup(string GroupName, long coordinatingAgencyId, long providerAgencyId);
        Task<ActivityGroup?> GetByActivityGroupId(long id);
        Task<IEnumerable<ProgramName?>> GetProgramNameByGroupId(long id);
        Task<IEnumerable<MasterProgramName?>> GetProgramNameByCoordinatingAgencyId(long id);        
        Task<ActivityGroup> UpdateAsync(ActivityGroup activityGroup);         
        Task<ActivityGroupSPOut?> DeleteAsync(long id);
    }
}
