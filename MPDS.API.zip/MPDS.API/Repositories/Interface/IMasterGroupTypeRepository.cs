﻿using MPDS.API.Models.Domain;
namespace MPDS.API.Repositories.Interface
{
    public interface IMasterGroupTypeRepository
    {
        Task<IEnumerable<MasterGroupType>> GetAllAsync();
    }
}
