﻿using MPDS.API.Models.Domain;

namespace MPDS.API.Repositories.Interface
{
    public interface IMasterServiceDomainRepository
    {
        Task<MasterServiceDomain> CreateAsync(MasterServiceDomain category);
        Task<IEnumerable<MasterServiceDomain>> GetAllSync();
        Task<MasterServiceDomain?> GetById(int id);
        Task<MasterServiceDomain?> UpdateAsync(MasterServiceDomain category);
        Task<MasterServiceDomain?> DeleteAsync(int id);
    }
}
