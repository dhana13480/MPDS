﻿using MPDS.API.Models.Domain;
namespace MPDS.API.Repositories.Interface
{
    public interface IProgramNamesRepository
    {
        Task<IEnumerable<MasterProgramName>> GetAllAsync();
        Task<MasterProgramName?> GetById(int id);
        Task<IEnumerable<MasterProgramName>> GetByProviderAgencyId(int id);
        Task<MasterProgramName> CreateAsync(MasterProgramName programName);
        Task<MasterProgramName?> UpdateAsync(MasterProgramName category);
    }
}
