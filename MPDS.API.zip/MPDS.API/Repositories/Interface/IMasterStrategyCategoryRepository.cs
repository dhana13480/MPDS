﻿using MPDS.API.Models.Domain;

namespace MPDS.API.Repositories.Interface
{
    public interface IMasterStrategyCategoryRepository
    {
        Task<MasterStrategyCategory> CreateAsync(MasterStrategyCategory strategy);
        Task<IEnumerable<MasterStrategyCategory>> GetAllSync();
        Task<MasterStrategyCategory?> GetById(int id);
        Task<MasterStrategyCategory?> UpdateAsync(MasterStrategyCategory strategy);
        Task<MasterStrategyCategory?> DeleteAsync(int id);
    }
}
