﻿using MPDS.API.Models.Domain;
using MPDS.API.Models.DTO;

namespace MPDS.API.Repositories.Interface
{
    public interface IMasterFundSourceRepository
    {
        Task<IEnumerable<MasterFundingSource>> GetAllAsync();
        Task<MasterFundingSource?> GetById(int id);
         
        Task<MasterFundingSource> CreateAsync(MasterFundingSource fund);
        Task<MasterFundingSource?> UpdateAsync(MasterFundingSource fund);
    }
}
