﻿using MPDS.API.Models.Domain;

namespace MPDS.API.Repositories.Interface
{
    public interface IMasterStatesRepository
    {
        Task<MasterStates> CreateAsync(MasterStates masterStates);
        Task<IEnumerable<MasterStates>> GetAllAsync();
        //Task<MasterStates?> GetById(int id);
        Task<MasterStates?> UpdateAsync(MasterStates masterStates);
        Task<MasterStates?> DeleteAsync(int id);
    }
}

