﻿using MPDS.API.Models.Domain;
using MPDS.API.Models.DTO;
using MPDS.API.Utilities;

namespace MPDS.API.Repositories.Interface
{
    public interface IStaffRepository
    {
        Task<Staff> CreateAsync(Staff staff);
        Task<ActivityStaff> CreateActivityStaff(ActivityStaff staff);
        Task<IEnumerable<Staff>> GetAllAsync();
        Task<PagedList<Staff>> GetAllStaffAsyncPagelist(UserParams userParams, UserSearchInputParameters userSearchInputParameters);

        Task<List<Staff>> GetAllByPihpRegionId(long PihpRegionId);
        Task<List<Staff>> GetStaffByCoordinatingAgencyAndProviderId(long PihpRegionId, long ProviderAgencyId);
        Task<List<StaffDto>> GetStaffByActivityId(long ActivityId);
        
        Task<List<Staff>> GetStaffByProviderId(long ProviderId);
        Task<Staff?> GetByStaffId(long id);
        Task<Staff?> UpdateAsync(Staff coordinatingAgency);
        Task<Staff?> DeleteAsync(int id);
    }
}
