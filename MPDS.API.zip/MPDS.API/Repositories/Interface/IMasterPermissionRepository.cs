﻿using MPDS.API.Models.Domain;
namespace MPDS.API.Repositories.Interface
{
    public interface IMasterPermissionRepository
    {
        Task<IEnumerable<MasterPermission>> GetAllASync();
        Task<MasterPermission?> GetById(int id);
    }
}
