﻿using MPDS.API.Models.Domain;
namespace MPDS.API.Repositories.Interface
{
    public interface IMasterProgramNameRepository
    {
        Task<IEnumerable<MasterProgramName>> GetAllAsync();
        Task<MasterProgramName?> GetById(int id);
        Task<MasterProgramName?> UpdateAsync(MasterProgramName category);
        Task<MasterProgramName> CreateAsync(MasterProgramName programName);
    }
}
