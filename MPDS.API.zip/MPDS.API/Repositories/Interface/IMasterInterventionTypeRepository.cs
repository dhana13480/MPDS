﻿using MPDS.API.Models.Domain;

namespace MPDS.API.Repositories.Interface
{
    public interface IMasterInterventionTypeRepository
    {
        Task<MasterInterventionType> CreateAsync(MasterInterventionType strategy);
        Task<IEnumerable<MasterInterventionType>> GetAllSync();
        Task<MasterInterventionType?> GetById(int id);
        Task<MasterInterventionType?> UpdateAsync(MasterInterventionType strategy);
        Task<MasterInterventionType?> DeleteAsync(int id);
    }
}
