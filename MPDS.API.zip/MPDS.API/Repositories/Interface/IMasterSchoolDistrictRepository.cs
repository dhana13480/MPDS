﻿using MPDS.API.Models.Domain;
using System.Threading.Tasks;

namespace MPDS.API.Repositories.Interface
{
    public interface IMasterSchoolDistrictRepository
    {
        Task<MasterSchoolDistrict> CreateAsync(MasterSchoolDistrict masterSchoolDistrict);
        Task<IEnumerable<MasterSchoolDistrict>> GetAllAsync();
        //Task<MasterStates?> GetById(int id);
        Task<MasterSchoolDistrict?> UpdateAsync(MasterSchoolDistrict masterSchoolDistrict);
        Task<MasterSchoolDistrict?> DeleteAsync(int id);
    }
}

