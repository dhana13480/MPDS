﻿using MPDS.API.Models.Domain;
using MPDS.API.Utilities;

namespace MPDS.API.Repositories.Interface
{
    public interface ICoordinatingAgencyRepository
    {
        Task<CoordinatingAgency> CreateAsync(CoordinatingAgency coordinatingAgency);
        Task<IEnumerable<CoordinatingAgency>> GetAllAsync(UserRoles userRoles);
        Task<CoordinatingAgency?> GetById(int id);
        Task<IEnumerable<CoordinatingAgencyCounty?>> GetCountyByCoordinatingAgencyId(long id);
        Task<CoordinatingAgencyCountyRequest> UpdateCountyListForCoordinatingAgencyId(CoordinatingAgencyCountyRequest request);
        Task<CoordinatingAgencySchoolDistrictRequest> UpdateSchoolDistrictListForCoordinatingAgencyId(CoordinatingAgencySchoolDistrictRequest request);
        Task<CoordinatingAgencyOptionalDataRequest> UpdateOptionalDataForCoordinatingAgency(CoordinatingAgencyOptionalDataRequest request);
        Task<CoordinatingAgencyProgramNamesRequest> UpdateProgramNamesForCoordinatingAgency(CoordinatingAgencyProgramNamesRequest request);

        IEnumerable<CoordinatingAgency?> GetByName(string name);
        Task<CoordinatingAgency?> UpdateAsync(CoordinatingAgency coordinatingAgency);
        Task<CoordinatingAgency?> DeleteAsync(int id);
        Task<CoordinatingAgency?> DeActivatePIHPRegion(int id);
    }
}
