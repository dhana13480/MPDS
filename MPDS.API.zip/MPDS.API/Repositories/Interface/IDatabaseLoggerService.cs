﻿using MPDS.API.Models.Domain;
using MPDS.API.Models.DTO;

namespace MPDS.API.Repositories.Interface
{
    public interface IDatabaseLoggerService
    {
        Task<ExceptionLog> LogException(Exception ex, string userId);
        Task<ExceptionLog?> LogInfo(string logText, string controllerMethod, string userId);
    }
}
