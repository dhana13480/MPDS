﻿using MPDS.API.Models.Domain;

namespace MPDS.API.Repositories.Interface
{
    public interface IProgramNameByCoordinatingAgencyRepository
    {
        Task<ProgramNameByCoordinatingAgency> CreateAsync(ProgramNameByCoordinatingAgency programNameByCoordinatingAgency);
        Task<IEnumerable<ProgramNameByCoordinatingAgency>> GetAllAsync();
        Task<List<ProgramNameByCoordinatingAgency>> GetByCoordinatingAgencyId(long PCoordinatingAgencyId);        
        Task<ProgramNameByCoordinatingAgency?> UpdateAsync(ProgramNameByCoordinatingAgency programNameByCoordinatingAgency);
        Task<ProgramNameByCoordinatingAgency?> DeleteAsync(int id);
    }
}
