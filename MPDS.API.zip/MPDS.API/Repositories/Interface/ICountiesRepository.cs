﻿using MPDS.API.Models.Domain;
using MPDS.API.Models.DTO;

namespace MPDS.API.Repositories.Interface
{
    public interface ICountiesRepository
    {
        Task<IEnumerable<Counties>> GetAllAsync();
        Task<Counties?> GetById(int id);
        Task<IEnumerable<ProviderAgencyCountyDto>> GetByProviderAgencyId(int id);
        Task<Counties> CreateAsync(Counties county);
        Task<Counties?> UpdateAsync(Counties category);
    }
}
