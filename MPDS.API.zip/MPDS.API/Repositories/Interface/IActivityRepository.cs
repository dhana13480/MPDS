﻿using MPDS.API.Models.Domain;
using MPDS.API.Models.DTO;
using MPDS.API.Utilities;

namespace MPDS.API.Repositories.Interface
{
    public interface IActivityRepository
    {
        Task<IEnumerable<ActivitiesDto>> GetAllAsync(ActivitiesSPInput ActivityInputParam);
        Task<PagedList<ActivitiesDto>> GetAllAsyncPaginated(ActivitiesSPInput ActivityInputParam, UserParams userParams);
        Task<bool> isActivityNameAlreadyExists(string activityName);
        Task<bool> IsGroupTypeOneTimeAndExists(long groupId);
        Task<PagedList<ActivitiesDto>> GetActivitiesByGroupId(long groupId);
        
        //PagedList<ActivitiesDto> GetAllAsyncPaginated(ActivitiesSPInput ActivityInputParam, UserParams userParams);
        IEnumerable<ActivitiesDto> GetAllAsyncPagedList(ActivitiesSPInput ActivityInputParam, UserParams userParams);
        Task<IEnumerable<ActivityReportResult>> GetActivityReportData(ActivityReportParam ActivityReportInputParam);
        Task<IEnumerable<PESRReportResult>> GetPESRReportData(PESRReportParam PESRInputParam);
        Task<IEnumerable<PESRByFundSourceReportResult>> GetPESRByFundSourceReportData(PESRReportParam PESRInputParam);
        Task<ActivitiesDto> GetById(long id);
        //Task<IEnumerable< MasterFundingSource>> GetAllMasterFundingSource();
        Task<int> GetActivityTotalAttendees(long activityId);
        Task<IEnumerable<ActivityRace>> GetRaceByActivityId(long id);
        Task<IEnumerable<ActivityEthnicity>> GetEthnicityByActivityId(long id);
        Task<IEnumerable<ActivityParticipantAgeGroup>> GetParticipantAgeGroupByActivityId(long id);
        Task<IEnumerable<ActivityStaff>> GetStaffByActivityId(long id);
        Task<IEnumerable<DatatableAcivitytStaff>> GetActivityStaffByActivityId(long id);
        Task<ActivityStaff> CreateActivityStaff(ActivityStaff staff);
        Task<IEnumerable<ActivityOptionalData>> GetOptionalDataById(long optionalDataIdid);
        Task<ActivitiesDto> CreateAsync(ActivitiesDto activity);
        Task<ActivityRace> CreateActivityRace(ActivityRace activityRace);
        Task<ActivityRace> UpdateActivityRace(ActivityRace activityRace);
        Task<ActivityEthnicity> CreateActivityEthnicity(ActivityEthnicity activityEthnicity);
        Task<ActivityEthnicity> UpdateActivityEthnicity(ActivityEthnicity activityEthnicity);
        Task<ActivityOptionalData> CreateActivityOptionalData(ActivityOptionalData activityOptionalData);
        Task<ActivityOptionalData> UpdateActivityOptionalData(ActivityOptionalData activityOptionalData);
        Task<ActivityParticipantAgeGroup> CreateActivityParticipantAgeGroup(ActivityParticipantAgeGroup activityParticipantAgeGroup);
        Task<ActivityParticipantAgeGroup> UpdateActivityParticipantAgeGroup(ActivityParticipantAgeGroup activityParticipantAgeGroup);
        Task<ActivityStaff> CreateActivityStaffRace(ActivityStaff activityStaff);
        Task<ActivityStaff> UpdateActivityStaff(ActivityStaff activityStaff);
        Task<ActivitiesDto> UpdateAsync(ActivitiesDto activity);
       

    }
}