﻿using MPDS.API.Models.Domain;

namespace MPDS.API.Repositories.Interface
{
    public interface IMasterStrategyRepository
    {
        Task<MasterStrategy> CreateAsync(MasterStrategy strategy);
        Task<IEnumerable<MasterStrategy>> GetAllSync();
        Task<MasterStrategy?> GetById(int id);
        Task<MasterStrategy?> UpdateAsync(MasterStrategy strategy);
        Task<MasterStrategy?> DeleteAsync(int id);
    }
}
