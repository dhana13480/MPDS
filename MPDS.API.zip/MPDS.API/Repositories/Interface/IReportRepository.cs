﻿using MPDS.API.Models.Domain;
using MPDS.API.Models.DTO;
using MPDS.API.Utilities;

namespace MPDS.API.Repositories.Interface
{
    public interface IReportRepository
    {
        Task<Staff?> DeleteAsync(int id);
    }
}
