﻿using MPDS.API.Models.Domain;
namespace MPDS.API.Repositories.Interface
{
    public interface IMasterEBPServiceTypeRepository
    {
        Task<IEnumerable<MasterEBPServiceType>> GetAllAsync();
    }
}
