﻿using MPDS.API.Models.Domain;

namespace MPDS.API.Repositories.Interface
{
    public interface IMasterServicePopulationRepository
    {
        Task<MasterServicePopulation> CreateAsync(MasterServicePopulation servicePopulation);
        Task<IEnumerable<MasterServicePopulation>> GetAllSync();
        Task<MasterServicePopulation?> GetById(int id);
        Task<MasterServicePopulation?> UpdateAsync(MasterServicePopulation servicePopulation);
        Task<MasterServicePopulation?> DeleteAsync(int id);
    }
}
