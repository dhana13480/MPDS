﻿using MPDS.API.Models.Domain;
using MPDS.API.Utilities;

namespace MPDS.API.Repositories.Interface
{
    public interface IProviderAgencyRepository
    {
        Task<ProviderAgency> CreateAsync(ProviderAgency providerAgency);
        Task<IEnumerable<ProviderAgency>> GetAllAsync();
        Task<PagedList<ProviderAgency>> GetAllAsyncPaginated(UserParams userParams, ProviderSearchInput inputParam, UserRoles userRoles);
        Task<ProviderAgency?> GetById(int id);
        Task<IEnumerable<ProviderAgency>> GetAllByCoordinatingAgencyId(int id);
         
        Task<ProviderAgency?> UpdateAsync(ProviderAgency providerAgency);
        Task<ProviderAgency?> DeleteAsync(int id);
        Task<ProviderAgencyCountyRequest> UpdateCountyListForProviderAgencyId(ProviderAgencyCountyRequest request);
        Task<ProviderAgencySchoolDistrictRequest> UpdateSchoolDistrictListForProviderAgencyId(ProviderAgencySchoolDistrictRequest request);
        Task<ProviderAgencyOptionalDataRequest> UpdateOptionalDataForProviderAgency(ProviderAgencyOptionalDataRequest request);
    }
}
