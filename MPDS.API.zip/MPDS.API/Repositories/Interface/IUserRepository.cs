﻿using MPDS.API.Models.Domain;
using MPDS.API.Utilities;
namespace MPDS.API.Repositories.Interface
{
    public interface IUserRepository
    {
        Task<Users> AddNewUser(Users user);
        Task<Users?> RemoveUser(int id);
        Task<Users?> GetByUserId(long id);
        Task<IEnumerable<Users>> GetAllUsers(UserSearchInputParameters userSearchInputParameters);
        Task<PagedList<Users>> GetAllUsersPaginated(UserParams userParams, UserSearchInputParameters userSearchInputParameters);
        Task<Users?> UpdateUser(Users user);
        Task<IEnumerable<Users>> ValidateLogin(string username, string password);
        Task<IEnumerable<Users>> GetMPDSUserByMiLoginEmail(string email);
        Task<IEnumerable<UserPermissions>> GetPermissionsByUserType(int userTypeId);
        //Task<UserInfo?> GetUsersEmailByCAPA(short notificationTypeId, string csvCoordinatingAGencyIds, string csvProviderAgencyIds);

    }
}
