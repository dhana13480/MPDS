﻿using MPDS.API.Models.Domain;

namespace MPDS.API.Repositories.Interface
{
    public interface IMasterIntendedPopulationRepository
    {
        Task<MasterIntendedPopulation> CreateAsync(MasterIntendedPopulation masterIntendedPopulation);
        Task<IEnumerable<MasterIntendedPopulation>> GetAllSync();
        Task<MasterIntendedPopulation?> GetById(int id);
        Task<MasterIntendedPopulation?> UpdateAsync(MasterIntendedPopulation masterIntendedPopulation);
        Task<MasterIntendedPopulation?> DeleteAsync(int id);
    }
}
