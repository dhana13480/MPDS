/** an interface that defines some environment specific variables so that we can strongly type out environment.ts files */
export interface IEnvironment {
  apiBaseUrl: any;
	production: boolean;
	hmr: boolean;
	ssrsUrl:any;
}
