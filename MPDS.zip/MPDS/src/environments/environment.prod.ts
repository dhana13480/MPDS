import { IEnvironment } from './environment.interface';

export const environment: IEnvironment = {
	production: true,
	hmr: false,
	apiBaseUrl:'https://mpds.state.mi.us/WebApi',
	ssrsUrl:'https://hcv491msqlpdm01.ngds.state.mi.us/ReportServer?/MPDS/Reports/',
};
