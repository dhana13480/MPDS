import 'jquery';
import { enableProdMode } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { AppModule } from './app/app.module';
import { environment } from './environments/environment';
import { bootstrapApplication } from '@angular/platform-browser';

platformBrowserDynamic().bootstrapModule(AppModule)
.catch(err => console.error(err));

if (environment.production) {
  enableProdMode();
}
  // bootstrapApplication(AppComponent, {
  //   providers: [
  //     provideAuth0({
  //       domain: '{yourDomain}',
  //       clientId: '{yourClientId}',
  //       authorizationParams: {
  //         redirect_uri: window.location.origin
  //       }
  //     }),
  //   ]
  // });
 
  
 