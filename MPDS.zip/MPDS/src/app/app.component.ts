import { Component, HostListener } from '@angular/core';
import { UserService } from './core/components/features/users/services/user.service';
 
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'MPDS';
  constructor (private userService: UserService) {}
  // Detect user activity (mouse move, click, or key press)
  @HostListener('window:mousemove')
  @HostListener('window:keydown')
  onUserActivity() {
    this.userService.userActivity();
  }
}
