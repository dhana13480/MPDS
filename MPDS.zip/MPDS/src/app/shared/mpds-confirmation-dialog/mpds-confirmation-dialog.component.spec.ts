import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MpdsConfirmationDialogComponent } from './mpds-confirmation-dialog.component';

describe('MpdsConfirmationDialogComponent', () => {
  let component: MpdsConfirmationDialogComponent;
  let fixture: ComponentFixture<MpdsConfirmationDialogComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [MpdsConfirmationDialogComponent]
    });
    fixture = TestBed.createComponent(MpdsConfirmationDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
