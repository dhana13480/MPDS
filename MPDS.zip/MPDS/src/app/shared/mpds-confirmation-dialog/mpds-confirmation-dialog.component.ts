import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
@Component({
  selector: 'app-mpds-confirmation-dialog',
  templateUrl: './mpds-confirmation-dialog.component.html',
  styleUrls: ['./mpds-confirmation-dialog.component.css'],
  template: `
  <h1 mat-dialog-title>{{ data.title }}</h1>
  <div mat-dialog-content>{{ data.message }}</div>
  <div mat-dialog-actions>
    <button mat-button (click)="onNoClick()">No</button>
    <button mat-button color="primary" (click)="onYesClick()">Yes</button>
  </div>
  `,

})
export class MpdsConfirmationDialogComponent {
  constructor(
    public dialogRef: MatDialogRef<MpdsConfirmationDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: { title: string; message: string }
  ) {}

  onNoClick(): void {
    this.dialogRef.close(false);
  }

  onYesClick(): void {
    this.dialogRef.close(true);
  }
}
