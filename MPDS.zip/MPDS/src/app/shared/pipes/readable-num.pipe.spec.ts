import { ReadableNumPipe } from './readable-num.pipe';

describe('ReadableNumPipe', () => {
  it('create an instance', () => {
    const pipe = new ReadableNumPipe();
    expect(pipe).toBeTruthy();
  });
});
