import { DatePipe } from '@angular/common';
import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'mpdsDate'
})
export class MPDSDatePipe implements PipeTransform {

  public transform(value: any, args?: any): any {
    let preferredDateValue = value;
        if (!!value) {
            const dateValue = new Date(value);
            preferredDateValue = `${dateValue.getUTCMonth() + 1}-${dateValue.getUTCDate()}-${dateValue.getUTCFullYear()}`;
        }
        return new DatePipe("en-US").transform(preferredDateValue, "MM/dd/yyyy");
  }

}
