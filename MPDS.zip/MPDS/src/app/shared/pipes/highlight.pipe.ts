import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'highlight'
})
export class HighlightPipe implements PipeTransform {

  public transform(text: string, search?: string): string {
    let pattern = (search || "").replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, "\\$&");
    pattern = pattern.split(" ").filter((t: string) => {
        return t.length > 0;
    }).join("|");
    let regex = new RegExp(pattern, "gi");

    return search ? text.replace(regex, (match) => `<mark>${match}</mark>`) : text;
}

}
