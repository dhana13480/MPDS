import { Pipe, PipeTransform } from '@angular/core';
import { ZipCodeFormatterService } from 'src/app/core/components/features/services/zip-code-formatter.service';

@Pipe({
  name: 'zipcode'
})
export class ZipCodePipe implements PipeTransform {
  constructor(protected zipCodeFormatterService: ZipCodeFormatterService) {
  }

  public transform(value: string, countryCode: string): string {
      return this.zipCodeFormatterService.formatZipCode(value, countryCode);
  }
}
