import { MPDSDatePipe } from './mpdsdate.pipe';

describe('MPDSDatePipe', () => {
  it('create an instance', () => {
    const pipe = new MPDSDatePipe();
    expect(pipe).toBeTruthy();
  });
});
