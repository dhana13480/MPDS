import { Pipe, PipeTransform } from "@angular/core";

/**
 * Filename: trim.pipe
 * Author: Justin Majeske
 * Date Created: 12/20/2016
 */

@Pipe({ name: "trim" })
export class TrimPipe implements PipeTransform {
    public transform(value: any) {
        if (!value) {
            return "";
        }
        return value.trim();
    }
}
