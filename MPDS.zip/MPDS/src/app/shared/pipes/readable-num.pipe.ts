import { Pipe, PipeTransform } from "@angular/core";

/**
 * Filename: readable-number.pipe  
 */
@Pipe({
    name: "readableNum",
})
export class ReadableNumPipe implements PipeTransform {

    /**
     * This pipe transforms a number into a easily readable, formatted number
     * with commas in the correct spots.
     * @param value of the number being formatted
     * @param argument indicating the number of decimal places, optional
     * @param allows to specify unit or suffix to be appended to the formatted number, optional
     * @returns formatted number with (optional) unit
     */
    public transform(value: number, places: any = 0, prefix?: string, unit?: string): any {
        if (this.isValueInvalid(value)) {
            return null;
        }
        let decimalIndex = String(value).indexOf(".");
        let readableNum = String(value);
        if (decimalIndex === -1) {
            if (places > 0) {
                readableNum += ".";
                for (let i = 0; i < places; i++) {
                    readableNum += "0";
                }
            }
        } else {
            let decimalPlaces = readableNum.substring(decimalIndex + 1).length;
            if (+places === 0) {
                readableNum = readableNum.substring(0, decimalIndex);
            } else if (decimalPlaces < places) {
                for (let i = 0; i < (places - decimalPlaces); i++) {
                    readableNum += "0";
                }
            } else if (decimalPlaces > places) {
                for (let i = 0; i < (decimalPlaces - places); i++) {
                    readableNum = readableNum.substr(0, readableNum.length - 1);
                }
            }
        }
        readableNum = this.formatWithCommas(readableNum, readableNum.indexOf("."));
        if (unit) {
            readableNum += ` ${unit}`;
        }
        if (prefix) {
            readableNum = `${prefix}${readableNum}`;
        }
        return readableNum;
    }

    public formatWithCommas(value: string, decimalIndex: number | any): string {
        let count = 0;
        let readableNum = "";
        decimalIndex = (decimalIndex === -1) ? undefined : decimalIndex;
        let decimalPlaces = value.substr(decimalIndex);
        value.substring(0, decimalIndex).split("").reverse().forEach((element: any) => {
            if (count === 3 && value.substring(0, decimalIndex).length > 3 && element !== "-") {
                readableNum += `,${element}`;
                count = 0;
            } else {
                readableNum += element;
            }
            count++;
        });
        readableNum = readableNum.split("").reverse().join("");
        if (decimalIndex > -1) {
            readableNum += decimalPlaces;
        }
        return readableNum;
    }

    public isValueInvalid(value: any): boolean {
        if (value === null || value === undefined) {
            return true;
        }
        return false;
    }

    public isValueNegative(value: any): boolean {
        return value.indexOf("-") > -1;
    }
}
