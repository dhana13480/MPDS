export class MpdsResponse {
    public contentEncoding?: string;
    public contentType?: string;
    public data: any;
    public error?: string;
    public jsonRequestBehavior?: string;
    public maxJsonLength?: string;
    public recursionLimit?: string;
}
