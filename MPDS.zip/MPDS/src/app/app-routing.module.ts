import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PihpRegionsComponent } from './core/components/features/pihp-regions/pihp-regions-list/pihp-regions.component';
import { AddPihpRegionComponent } from './core/components/features/pihp-regions/add-pihp-region/add-pihp-region.component';
import { EditPihpRegionComponent } from './core/components/features/pihp-regions/edit-pihp-region/edit-pihp-region.component';
import { StaffListComponent } from './core/components/features/staff/staff-list/staff-list.component';
import { LoginComponent } from './core/components/features/login/user-login/login.component';
import { DashboardComponent } from './core/components/features/dashboard/dashboard.component';
import { AddStaffComponent } from './core/components/features/staff/add-staff/add-staff.component';
import { EditStaffComponent } from './core/components/features/staff/edit-staff/edit-staff.component';
import { ProviderAgenciesListComponent } from './core/components/features/provider-agencies/provider-agencies-list/provider-agencies-list.component';
import { AddProviderAgencyComponent } from './core/components/features/provider-agencies/add-provider-agency/add-provider-agency.component';
import { GroupsListComponent } from './core/components/features/groups/groups-list/groups-list.component';
import { AddGroupComponent } from './core/components/features/groups/add-group/add-group.component';
import { EditProviderAgencyComponent } from './core/components/features/provider-agencies/edit-provider-agency/edit-provider-agency.component';
import { ActivityListComponent } from './core/components/features/activities/activity-list/activity-list.component';
import { AddActivityComponent } from './core/components/features/activities/add-activity/add-activity.component';
import { AddParticipantsComponent } from './core/components/features/participants/add-participants/add-participants.component';
import { EditGroupComponent } from './core/components/features/groups/edit-group/edit-group.component';
import { EditActivityComponent } from './core/components/features/activities/edit-activity/edit-activity.component';
import { EditParticipantsComponent } from './core/components/features/participants/edit-participants/edit-participants.component';
import { MainReportsComponent } from './core/components/features/reports/main-reports/main-reports.component';
import { SearchReportsComponent } from './core/components/features/reports/search-reports/search-reports.component';
import { ReportsListComponent } from './core/components/features/reports/reports-list/reports-list.component';
import { UserListComponent } from './core/components/features/users/user-list/user-list.component';
import { AddUserComponent } from './core/components/features/users/add-user/add-user.component';
import { EditUserComponent } from './core/components/features/users/edit-user/edit-user.component';
import { CountyListComponent } from './core/components/features/master-data/counties/county-list/county-list.component';
import { UserSelectionsComponent } from './core/components/features/login/user-selections/user-selections.component';
import { EbpServiceTypeListComponent } from './core/components/features/master-data/ebp-service-types/ebp-service-type-list/ebp-service-type-list.component';
import { SchoolDistrictListComponent } from './core/components/features/master-data/school-districts/school-district-list/school-district-list.component';
import { ProgramNameListComponent } from './core/components/features/master-data/program-names/program-name-list/program-name-list.component';
import { FundingSourceListComponent } from './core/components/features/master-data/funding-sources/funding-source-list/funding-source-list.component';
import { NotFoundComponent } from './core/components/features/error-response/not-found/not-found.component';
import { AccessDeniedComponent } from './core/components/features/error-response/access-denied/access-denied.component';
import { HomeComponent } from './core/components/features/home/home.component';

const routes: Routes = [
  {
    path:'login',
    component: LoginComponent, pathMatch:'full'
  },
  {
    path:'',
    component: HomeComponent, pathMatch:'full'
  },
  {
    path:'Dashboard',
    component: DashboardComponent, pathMatch:'full'
  },
  {
    path:'coordinatingagencies',
    component: PihpRegionsComponent, pathMatch:'full'
  },
  {
    path:'coordinatingagencies/add',
    component: AddPihpRegionComponent, pathMatch:'full'
  },
  {
    path:'coordinatingagencies/edit/:id',
    component: EditPihpRegionComponent, pathMatch:'full'
  },
  {
    path:'staff/:id',
    component: StaffListComponent, pathMatch:'full'
  },
  {
    path:'staff/provideragency/:id',
    component: StaffListComponent, pathMatch:'full'
  },
  {
    path:'staff/coordinatingagency/:id',
    component: StaffListComponent, pathMatch:'full'
  },
  {
    path:'staff/add/:id',
    component: AddStaffComponent, pathMatch:'full'
  },
  {
    path:'staff/edit/:id',
    component: EditStaffComponent, pathMatch:'full'
  },
  {
    path:'staff/all',
    component: StaffListComponent, pathMatch:'full'
  },
  {
    path: 'provideragencies',
    component: ProviderAgenciesListComponent, pathMatch: 'full'
  },
  {
    path: 'provideragenciesByCoordId/:id',
    component: ProviderAgenciesListComponent, pathMatch: 'full'
  },
  {
    path: 'provideragencies/add',
    component: AddProviderAgencyComponent, pathMatch: 'full'
  },
  {
    path: 'provideragencies/edit/:id',
    component: EditProviderAgencyComponent, pathMatch: 'full'
  },
  {
    path: 'groups',
    component: GroupsListComponent, pathMatch: 'full'
  },
  {
    path: 'provideragencyid/:id',
    component: GroupsListComponent, pathMatch: 'full'
  },  
  {
    path: 'groups/add',
    component: AddGroupComponent, pathMatch: 'full'
  },
  {
    path: 'groups/edit/:id',
    component: EditGroupComponent, pathMatch: 'full'
  },
  
  {
    path: 'GetActivitiesByGroupId/:id',
    component: ActivityListComponent, pathMatch: 'full'
  },
  {
    path: 'activities',
    component: ActivityListComponent, pathMatch: 'full'
  },
  {
    path: 'activities/add',
    component: AddActivityComponent, pathMatch: 'full'
  },
  {
    path: 'activities/add/:GroupCAId:/GroupPAId:/GroupGrpId:/GroupProgramNameId',
    component: AddActivityComponent, pathMatch: 'full'
  },
  {
    path: 'activities/edit/:id',
    component: EditActivityComponent, pathMatch: 'full'
  },
  {
    path: 'participants/add/:id',
    component: AddParticipantsComponent, pathMatch: 'full'
  },
  {
    path: 'participants/edit/:id',
    component: EditParticipantsComponent, pathMatch: 'full'
  },
  {
    path: 'reports',
    component: MainReportsComponent, pathMatch: 'full'
  },
  {
    path:'report-params/:id',
    component: SearchReportsComponent, pathMatch:'full'
  },
  {
    path:'reports-list',
    component: ReportsListComponent, pathMatch:'full'
  },
  {
    path:'user-list',
    component: UserListComponent, pathMatch:'full'
  },
  {
    path:'add-user',
    component: AddUserComponent, pathMatch:'full'
  },
  {
    path:'edit-user/:id',
    component: EditUserComponent, pathMatch:'full'
  },
  {
    path:'validate-user/:username/:password',
    component: LoginComponent, pathMatch:'full'
  },
  {
    path:'user-selections/:id',
    component: UserSelectionsComponent, pathMatch:'full'
  },
  {
    path:'counties',
    component: CountyListComponent, pathMatch:'full'
  },
  {
    path:'school-districts',
    component: SchoolDistrictListComponent, pathMatch:'full'
  },
  {
    path:'program-names',
    component: ProgramNameListComponent, pathMatch:'full'
  },
  {
    path:'funding-sources',
    component: FundingSourceListComponent, pathMatch:'full'
  },
  {
    path:'ebpservicetypes',
    component: EbpServiceTypeListComponent, pathMatch:'full'
  },
  {
    path:'404-not-found',
    component: NotFoundComponent, pathMatch:'full'
  },
  {
    path:'access-denied',
    component: AccessDeniedComponent, pathMatch:'full'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
