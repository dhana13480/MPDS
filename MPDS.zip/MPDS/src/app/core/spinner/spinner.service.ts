import { Injectable } from "@angular/core";

import { Subject } from "rxjs";

/**
 * Spinner service taken from angular style guide
 * https://github.com/angular/angular.io/tree/2b7fb868908527ba9fecb2e2c549143694aad363/
 *    public/docs/_examples/style-guide/ts/04-11/app/core/spinner
 */
export interface SpinnerState {
    show: boolean;
}

@Injectable()
export class SpinnerService {
    public spinnerSubject = new Subject<SpinnerState>();
    public spinnerState = this.spinnerSubject.asObservable();

    public show() {
        this.spinnerSubject.next({ show: true } as SpinnerState);
    }

    public hide() {
        this.spinnerSubject.next({ show: false } as SpinnerState);
    }
}
