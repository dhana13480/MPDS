import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { SpinnerService, SpinnerState } from './spinner.service';
import { LoggerService } from '../logger.service';

@Component({
  selector: 'app-spinner',
  templateUrl: './spinner.component.html',
  styleUrls: ['./spinner.component.css']
})
export class SpinnerComponent implements OnDestroy, OnInit {
  public visible = false;
  public spinnerStateChanged: Subscription| any;

  constructor(public loggerService: LoggerService, public spinnerService: SpinnerService) {}

  public ngOnInit() {
      this.spinnerStateChanged = this.spinnerService.spinnerState
          .subscribe((state: SpinnerState) => {
              this.visible = state.show;
          });
  }

  public ngOnDestroy() {
      this.spinnerStateChanged.unsubscribe();
  }
}
