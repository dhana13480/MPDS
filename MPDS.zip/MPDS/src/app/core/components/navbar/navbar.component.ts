import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MiLoginUserModel } from '../features/users/models/milogin-user-model';
import { UserService } from '../features/users/services/user.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent {
  MiLoginUser?: MiLoginUserModel | null;

  constructor(private userService: UserService
    ,private router: Router
    ) {}

  closeWindow() {
    const userConfirmed = window.confirm('Are you sure you want to Sign out from MPDS?');
    
    if (userConfirmed) {
      this.userService.endSession();      
      this.router.navigateByUrl(``);
      // Attempt to close the window
      window.open('', '_self');  // This tricks the browser into allowing the window close
      window.close();  // Forcefully closes the window/tab

    }
  }
  isSessionActive(): boolean {
    return this.userService.isUserAuthenticated();
  }
  getUserTypeId(): number {
   const mpdsUserTypeId = sessionStorage.getItem("MPDSUserTypeId");
    return Number(  sessionStorage.getItem("MPDSUserTypeId") ?? 0)    
  }
  ngOnInit(): void {
    this.userService.user$.subscribe(user => {
      console.log(user)
      this.MiLoginUser = user;
      //sessionStorage.setItem('MiLoginUser');
     // sessionStorage.setItem('MPDSUserId',  this.MiLoginUser?.id.toString());
      //sessionStorage.setItem('MPDSUserTypeId', this.MiLoginUser?.userTypeId.toString());
    });
  }
}
