import { Component, Directive, OnDestroy } from '@angular/core';
import { DatePipe } from '@angular/common';
import { Observable, Subscription } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';
import { ParticipantService } from '../services/participants.service';
import { AddParticipantModel } from '../models/add-participant.model';
import { MatDialog } from '@angular/material/dialog';
import { MpdsConfirmationDialogComponent } from '../../../../../shared/mpds-confirmation-dialog/mpds-confirmation-dialog.component';

@Component({
  selector: 'app-add-participants',
  templateUrl: './add-participants.component.html',
  styleUrls: ['./add-participants.component.css'],
 //template: `<button (click)="openConfirmDialog()">Show Alert</button>`,
})
export class AddParticipantsComponent {
  ServerErrorMessage?: string='';
  id?: string;
  totalAttendees?: string;
  myDateValue?: Date;
  model: AddParticipantModel;
  paramsSubscription?: Subscription;
  private addParticipantAgeGroupSubscription?: Subscription;
  private addParticipantRaceSubscription?: Subscription;
  private addParticipantEthnicitySubscription?: Subscription;
  //state$?: Observable<StatesComponent[]>;

  constructor(
    private router:Router,
    private participantService: ParticipantService,
    private datePipe: DatePipe,
    private route: ActivatedRoute,
    private dialog: MatDialog
  ) {
    this.model = {
      ageGroups: {
        "activityId": 0,
        "zeroTo5": 0,
        "sixTo12": 0,
        "thirteenTo17": 0,
        "eighteenTo20": 0,
        "twentyOneTo24": 0,
        "twentyFiveTo44": 0,
        "fortyFiveTo64": 0,
        "sixtyFiveTo74": 0,
        "seventyFivePlus": 0,
        "totalAgeGrp": 0        
      },
      races: {
        "activityId": 0,
        "americanIndianAlaskanNative": 0,
        "hawaiianPacificIslander": 0,
        "white": 0,
        "asian": 0,
        "africanAmerican": 0,
        "multiRacial": 0,
        "unknownOther": 0,
        "totalRace": 0  
      },
      ethnicities: {
        "activityId": 0,
        "hispanicLatinoEthnicity": 0,
        "arabAmericanCanadianEthnicity": 0,
        "notListed": 0,
        "totalEth": 0  
      }
    }
  }
  openConfirmDialog(): void {
    const dialogRef = this.dialog.open(MpdsConfirmationDialogComponent, {
      width: '300px',
      data: {
        title: 'Confirm Action',
        message: 'Activity and Activity Participants added successfully, do you want to create another Activity?',
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.router.navigateByUrl('/activities/add');
      } else {
        this.router.navigateByUrl('/activities');
      }
    });
  }
  ngOnInit():void{
    this.totalAttendees = sessionStorage.getItem('totalActivityAttendees')!;
    console.log(this.totalAttendees);
    this.paramsSubscription = this.route.paramMap.subscribe({
      next: (params) => {
        if (params.get('id')) {
          this.id = params.get('id')!;       
          console.log(this.id);
          console.log(this.totalAttendees);
          this.model.ageGroups.activityId = parseInt(this.id);
          this.model.ageGroups.totalAgeGrp = parseInt(this.totalAttendees!);

          this.model.ethnicities.activityId = parseInt(this.id);
          this.model.ethnicities.totalEth = parseInt(this.totalAttendees!);

          this.model.races.activityId = parseInt(this.id);
          this.model.races.totalRace = parseInt(this.totalAttendees!);

        }
      },
    });
  }

  calculateTotalAgeGroups (e: Event): void {
   
   // this.model.staffUnits = this.activityService. CalculateUnits( this.model.activityStaffStartDate, this.model.activityStaffEndDate )
   }
 
  onFormSubmit(){
    this.participantService.totalAttendees = this.totalAttendees;
    if(this.model.ageGroups.totalAgeGrp !== (this.model.ageGroups.zeroTo5 + this.model.ageGroups.sixTo12 + this.model.ageGroups.thirteenTo17 + this.model.ageGroups.eighteenTo20 + this.model.ageGroups.twentyOneTo24 + this.model.ageGroups.twentyFiveTo44 + this.model.ageGroups.fortyFiveTo64+this.model.ageGroups.sixtyFiveTo74+ this.model.ageGroups.seventyFivePlus) )    
      {
        this.ServerErrorMessage="The Participants Age group total should match total attendees";
      }
    else 
     
    if(this.model.ageGroups.totalAgeGrp !== (this.model.races.africanAmerican + this.model.races.americanIndianAlaskanNative+ this.model.races.asian+ this.model.races.hawaiianPacificIslander+ this.model.races.multiRacial+ this.model.races.unknownOther+ this.model.races.white ) )    
        {
          this.ServerErrorMessage="The Participants Race total should match total attendees";
        }
    else 
     
      if(this.model.ageGroups.totalAgeGrp !== (this.model.ethnicities.hispanicLatinoEthnicity + this.model.ethnicities.arabAmericanCanadianEthnicity+ this.model.ethnicities.notListed ) )    
          {
            this.ServerErrorMessage="The Participants Ethnicity total should match total attendees";
          }
      else {
    this.addParticipantAgeGroupSubscription = this.participantService.AddParticipantsAgeGroups(this.model.ageGroups)
    .subscribe({
      next:(response) =>{
          console.log('Age Groups Add successful');
      }, 
        
       error: (error) => {
        console.error('Error adding Age Groups:', error);
        this.ServerErrorMessage = error.error ;
      }        
    });

    this.addParticipantRaceSubscription = this.participantService.AddParticipantsRaces(this.model.races)
    .subscribe({
      next:(response) =>{
          console.log('Races Add successful');
      }, 
      error: (error) => {
        console.error('Error adding Races:', error);
        this.ServerErrorMessage = error.error ;
      }
    });

    this.addParticipantEthnicitySubscription = this.participantService.AddParticipantsEthnicities(this.model.ethnicities)
    .subscribe({
      next:(response) =>{
          console.log('Ethnicities Add successful');
          //this.router.navigateByUrl('/activities');
          alert ("Participants Added Successfully")
          //this.openConfirmDialog();
          this.router.navigateByUrl('/activities/add');
      }, 
      error: (error) => {
        console.error('Error adding Ethnicities:', error);
        this.ServerErrorMessage = error.error ;
      }
    });
  
  }}
  
  ngOnDestroy(): void {
    this.addParticipantAgeGroupSubscription?.unsubscribe();
    this.addParticipantRaceSubscription?.unsubscribe();
    this.addParticipantEthnicitySubscription?.unsubscribe();
  }
}
