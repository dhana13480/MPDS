import { Component, Directive, OnDestroy } from '@angular/core';
import { DatePipe } from '@angular/common';
import { Observable, Subscription } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';
import { ParticipantService } from '../services/participants.service';
import { AddParticipantModel } from '../models/add-participant.model';

@Component({
  selector: 'app-edit-participants',
  templateUrl: './edit-participants.component.html',
  styleUrls: ['./edit-participants.component.css']
})
export class EditParticipantsComponent {
  totalAttendees?: string;
  ServerErrorMessage?: string='';
  id?: string;
  myDateValue?: Date;
  model: AddParticipantModel;
  paramsSubscription?: Subscription;
  private updateParticipantAgeGroupSubscription?: Subscription;
  private updateParticipantRaceSubscription?: Subscription;
  private updateParticipantEthnicitySubscription?: Subscription;
  //state$?: Observable<StatesComponent[]>;

  constructor(
    private router:Router,
    private participantService: ParticipantService,
    private datePipe: DatePipe,
    private route: ActivatedRoute
  ) {
    this.model = {
      ageGroups: {
        "activityId": 0,
        "zeroTo5": 0,
        "sixTo12": 0,
        "thirteenTo17": 0,
        "eighteenTo20": 0,
        "twentyOneTo24": 0,
        "twentyFiveTo44": 0,
        "fortyFiveTo64": 0,
        "sixtyFiveTo74": 0,
        "seventyFivePlus": 0,
        "totalAgeGrp":0
      },
      races: {
        "activityId": 0,
        "americanIndianAlaskanNative": 0,
        "hawaiianPacificIslander": 0,
        "white": 0,
        "asian": 0,
        "africanAmerican": 0,
        "multiRacial": 0,
        "unknownOther": 0,
        "totalRace":0
      },
      ethnicities: {
        "activityId": 0,
        "hispanicLatinoEthnicity": 0,
        "arabAmericanCanadianEthnicity": 0,
        "notListed": 0,
        "totalEth":0
      }
    }
  }

  ngOnInit():void{
    this.totalAttendees = sessionStorage.getItem('totalActivityAttendees')!;
    this.model.ageGroups.totalAgeGrp = this.model.ageGroups.zeroTo5 + this.model.ageGroups.sixTo12 + this.model.ageGroups.thirteenTo17 + this.model.ageGroups.eighteenTo20 + this.model.ageGroups.twentyOneTo24 + this.model.ageGroups.twentyFiveTo44 + this.model.ageGroups.fortyFiveTo64+this.model.ageGroups.sixtyFiveTo74+ this.model.ageGroups.seventyFivePlus;
    this.model.ethnicities.totalEth = this.model.ethnicities.hispanicLatinoEthnicity + this.model.ethnicities.arabAmericanCanadianEthnicity+ this.model.ethnicities.notListed;
    this.model.races.totalRace = this.model.races.africanAmerican + this.model.races.americanIndianAlaskanNative+ this.model.races.asian+ this.model.races.hawaiianPacificIslander+ this.model.races.multiRacial+ this.model.races.unknownOther+ this.model.races.white;
 
    this.model.ageGroups.totalAgeGrp = parseInt(this.totalAttendees!); 
    this.model.ethnicities.totalEth = parseInt(this.totalAttendees!); 
    this.model.races.totalRace = parseInt(this.totalAttendees!);
    this.paramsSubscription = this.route.paramMap.subscribe({
      next: (params) => {
        if (params.get('id')) {
          this.id = params.get('id')!;
          this.participantService.GetParticipantsAgeGroupsById(this.id)!.forEach(ageGroup => {
            this.model.ageGroups = ageGroup
            this.model.ageGroups.activityId = parseInt(this.id!)
          });
          this.participantService.GetParticipantsRacesById(this.id)!.forEach(race => {
            this.model.races = race
            this.model.races.activityId = parseInt(this.id!)
          });
          this.participantService.GetParticipantsEthnicitiesById(this.id)!.forEach(ethnicity => {
            this.model.ethnicities = ethnicity
            this.model.ethnicities.activityId = parseInt(this.id!)
          });
        }
      },
    });
  }

onChangeTotals(event: Event)
{
  this.model.ageGroups.totalAgeGrp = this.model.ageGroups.zeroTo5 + this.model.ageGroups.sixTo12 + this.model.ageGroups.thirteenTo17 + this.model.ageGroups.eighteenTo20 + this.model.ageGroups.twentyOneTo24 + this.model.ageGroups.twentyFiveTo44 + this.model.ageGroups.fortyFiveTo64+this.model.ageGroups.sixtyFiveTo74+ this.model.ageGroups.seventyFivePlus;
  this.model.ethnicities.totalEth = this.model.ethnicities.hispanicLatinoEthnicity + this.model.ethnicities.arabAmericanCanadianEthnicity+ this.model.ethnicities.notListed;
  this.model.races.totalRace = this.model.races.africanAmerican + this.model.races.americanIndianAlaskanNative+ this.model.races.asian+ this.model.races.hawaiianPacificIslander+ this.model.races.multiRacial+ this.model.races.unknownOther+ this.model.races.white;
}
  onFormSubmit(){
    console.log(this.model)
    this.participantService.totalAttendees = this.totalAttendees;
    this.model.ageGroups.totalAgeGrp = parseInt(this.totalAttendees!);
    if(this.model.ageGroups.totalAgeGrp !== (this.model.ageGroups.zeroTo5 + this.model.ageGroups.sixTo12 + this.model.ageGroups.thirteenTo17 + this.model.ageGroups.eighteenTo20 + this.model.ageGroups.twentyOneTo24 + this.model.ageGroups.twentyFiveTo44 + this.model.ageGroups.fortyFiveTo64+this.model.ageGroups.sixtyFiveTo74+ this.model.ageGroups.seventyFivePlus) )    
    {
      this.ServerErrorMessage="The Participants Age group total should match total attendees";
    }
  else 
   
  if(this.model.ageGroups.totalAgeGrp !== (this.model.races.africanAmerican + this.model.races.americanIndianAlaskanNative+ this.model.races.asian+ this.model.races.hawaiianPacificIslander+ this.model.races.multiRacial+ this.model.races.unknownOther+ this.model.races.white ) )    
      {
        this.ServerErrorMessage="The Participants Race total should match total attendees";
      }
  else 
   
    if(this.model.ageGroups.totalAgeGrp !== (this.model.ethnicities.hispanicLatinoEthnicity + this.model.ethnicities.arabAmericanCanadianEthnicity + this.model.ethnicities.notListed ) )    
        {
          this.ServerErrorMessage="The Participants Ethnicity total should match total attendees";
        }

       else { 
    this.updateParticipantAgeGroupSubscription = this.participantService.UpdateParticipantsAgeGroups(this.model.ageGroups)
    .subscribe({
      next:(response) =>{
          console.log('Age Groups Update successful');
      }, 
    });

    this.updateParticipantRaceSubscription = this.participantService.UpdateParticipantsRaces(this.model.races)
    .subscribe({
      next:(response) =>{
          console.log('Races Update successful');
      }, 
    });

    this.updateParticipantEthnicitySubscription = this.participantService.UpdateParticipantsEthnicities(this.model.ethnicities)
    .subscribe({
      next:(response) =>{
          console.log('Ethnicities Update successful');
          this.router.navigateByUrl('/activities');
      }, 
    });
  }
}
  ngOnDestroy(): void {
    this.updateParticipantAgeGroupSubscription?.unsubscribe();
    this.updateParticipantRaceSubscription?.unsubscribe();
    this.updateParticipantEthnicitySubscription?.unsubscribe();
  }
}
