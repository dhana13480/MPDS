export interface AddParticipantModel {
    ageGroups: {
        "activityId": number;
        "zeroTo5": number;
        "sixTo12": number;
        "thirteenTo17": number;
        "eighteenTo20": number;
        "twentyOneTo24": number;
        "twentyFiveTo44": number;
        "fortyFiveTo64": number;
        "sixtyFiveTo74": number;
        "seventyFivePlus": number;
        "totalAgeGrp": number;
    },
    races: {
        "activityId": number,
        "americanIndianAlaskanNative": number;
        "hawaiianPacificIslander": number;
        "white": number;
        "asian": number;
        "africanAmerican": number;
        "multiRacial": number;
        "unknownOther": number;
        "totalRace": number;
    },
    ethnicities: {
        "activityId": number,
        "hispanicLatinoEthnicity": number;
        "arabAmericanCanadianEthnicity": number;
        "notListed": number;
        "totalEth": number;
    }
  }