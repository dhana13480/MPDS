import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { AddParticipantModel } from '../models/add-participant.model';
 
 
@Injectable({
  providedIn: 'root'
})
export class ParticipantService {
  totalAttendees?: string;
  storedUserStringified = sessionStorage.getItem('MiLoginUser')!;
    constructor(private http: HttpClient) { }
    
    GetParticipantsAgeGroupsById(id: string) : Observable<AddParticipantModel["ageGroups"]> {
      return this.http.get<AddParticipantModel["ageGroups"]>(`${environment.apiBaseUrl}/api/Activity/ActivityParticipantAgeGroup/${id}`);
    }

    AddParticipantsAgeGroups(model: AddParticipantModel["ageGroups"]) : Observable<void> {
      return this.http.post<void>(`${environment.apiBaseUrl}/api/Activity/AddActivityParticipantAgeGroup/${this.totalAttendees}`, model);
    }

    UpdateParticipantsAgeGroups(model: AddParticipantModel["ageGroups"]) : Observable<AddParticipantModel["ageGroups"]> {
      console.log (`${environment.apiBaseUrl}/api/Activity/UpdateActivityParticipantAgeGrp/${this.totalAttendees}`);
      return this.http.put<AddParticipantModel["ageGroups"]>(`${environment.apiBaseUrl}/api/Activity/UpdateActivityParticipantAgeGrp/${this.totalAttendees}`, model);
    }
    
    GetParticipantsRacesById(id: string) : Observable<AddParticipantModel["races"]> {
      return this.http.get<AddParticipantModel["races"]>(`${environment.apiBaseUrl}/api/Activity/ActivityRace/${id}`);
    }

    AddParticipantsRaces(model: AddParticipantModel["races"]) : Observable<void> {
      return this.http.post<void>(`${environment.apiBaseUrl}/api/Activity/AddActivityRace/${this.totalAttendees}`, model);
    }

    UpdateParticipantsRaces(model: AddParticipantModel["races"]) : Observable<AddParticipantModel["races"]> {
      return this.http.put<AddParticipantModel["races"]>(`${environment.apiBaseUrl}/api/Activity/UpdateActivityRace/${this.totalAttendees}`, model);
    }
    
    GetParticipantsEthnicitiesById(id: string) : Observable<AddParticipantModel["ethnicities"]> {
      return this.http.get<AddParticipantModel["ethnicities"]>(`${environment.apiBaseUrl}/api/Activity/ActivityEthnicity/${id}`);
    }

    AddParticipantsEthnicities(model: AddParticipantModel["ethnicities"]) : Observable<void> {
      return this.http.post<void>(`${environment.apiBaseUrl}/api/Activity/AddActivityEthnicity/${this.totalAttendees}`, model);
    }

    UpdateParticipantsEthnicities(model: AddParticipantModel["ethnicities"]) : Observable<AddParticipantModel["ethnicities"]> {
      return this.http.put<AddParticipantModel["ethnicities"]>(`${environment.apiBaseUrl}/api/Activity/UpdateActivityEthnicity/${this.totalAttendees}`, model);
    }
}