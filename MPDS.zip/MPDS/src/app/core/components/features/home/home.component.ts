import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { UserService } from '../users/services/user.service';
import { MiLoginUserModel } from '../users/models/milogin-user-model';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {
  MiLoginCode: string | null = null;
  paramsSubscription: Subscription | undefined;
  MiLoginUser?: MiLoginUserModel | null;
  isLoading = false;
  ServerErrorMessage?: string='';


  constructor(
    private route: ActivatedRoute,
    private userService: UserService,
    private router: Router
  ) {}


  ngOnInit(): void {
    this.isLoading = true;
    this.userService.user$.subscribe(user => {
      this.MiLoginUser = user;
      this.isLoading = false;
    })


    this.paramsSubscription = this.route.queryParams.subscribe(params => {
      const codeHeader: string = params['code'];
      if (codeHeader) {
        this.userService.ValidateUser(codeHeader).subscribe(user => {
          this.MiLoginUser = user[0];
          this.userService.setUser(user[0]);
          this.router.navigateByUrl(`Dashboard`);
        } 
        )
      } 
      else
      {
        
        //change this to home before any build
        this.router.navigateByUrl(`Dashboard`);
        //this.router.navigateByUrl(`home`);
        /*
        this.userService.ValidateUser(codeHeader).subscribe(user => {
          this.MiLoginUser = user[0];
          this.userService.setUser(user[0]);
        } 
        )*/
      }
      
       
    });
  }

  ngOnDestroy(): void {
    if (this.paramsSubscription) {
      this.paramsSubscription.unsubscribe();
    }
  }
}
