import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MainReportsComponent } from './main-reports.component';

describe('MainReportsComponent', () => {
  let component: MainReportsComponent;
  let fixture: ComponentFixture<MainReportsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [MainReportsComponent]
    });
    fixture = TestBed.createComponent(MainReportsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
