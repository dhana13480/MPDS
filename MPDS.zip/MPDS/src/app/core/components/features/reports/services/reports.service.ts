import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { Report } from '../models/report.model';
import { SearchReportParameters } from '../models/search-report-parameters.model';
import { FormValue } from '../models/form-values.model';
 
 
@Injectable({
  providedIn: 'root'
})
export class ReportService {
  storedUserStringified = sessionStorage.getItem('MiLoginUser')!;
  //private reportServerUrl = 'https://hcv491msqltdm01.ngds.state.mi.us/reports/mpds';
 // private reportServerUrl = 'https://hcv491msqltdm01.ngds.state.mi.us/ReportServer?/MPDS/Reports/';
  private reportsSubject: BehaviorSubject<Report[]> = new BehaviorSubject<Report[]>([]);
  private submittedFormValue?: { 
    groupId: number,
    providerAgencyId: number,
    coordinatingAgencyId: number,     
    startDate: string,
    endDate: string,
    isGamblingRelated: boolean,  
    sortOrder:number,
    sortId:Number, 
    //templateId: 0
    //ReportName: string,
    //fundSourceId: string
  }

  constructor(private http: HttpClient) { }

  getReportUrl(formValue: any): string {
    const params = new URLSearchParams();
  
  if(formValue.coordinatingAgencyId.toString() !== '0')
    params.append('CoordinatingAgencyIds', formValue.coordinatingAgencyId);
  if(formValue.providerAgencyId.toString() !== '0')
    params.append('ProviderAgencyIds', formValue.providerAgencyId);
  if(formValue.groupId.toString() !== '0')
    params.append('GroupIds', formValue.groupId);
  if(formValue.startDate.toString() !== '')
    params.append('StartDate', formValue.startDate);
  if(formValue.endDate.toString() !== '')
    params.append('EndDate', formValue.endDate);
    params.append('IsGamblingRelated', formValue.isGamblingRelated.toString());
  if(formValue.SortOrder > 0)
    params.append('SortOrder', formValue.sortOrder);
  if(formValue.sortId >0 )
    params.append('SortId', formValue.sortId);
      
    
    //params.append('templateId', formValue.templateId.toString());
   // params.append('ReportName', formValue.reportName.toString());
    //params.append('fundSourceId', formValue.fundSourceId.toString());
    //console.log(`${this.reportServerUrl}?${params.toString()}`);
    return `${params.toString()}`;
   // return `${this.reportServerUrl}?/${params.toString()}`;
    //return this.http.post<Report[]>(`${environment.apiBaseUrl}/api/Report`, formValue);
  } 

  getReport(format: string, reportPath: string, params: { [key: string]: string }) {
    const url = `${environment.apiBaseUrl}/api/Report/GetSSRSReport?format=${format}&reportPath=${reportPath}`;
    return this.http.get(`${environment.apiBaseUrl}/api/Report/GetSSRSReport?format=${format}&reportPath=${reportPath}`, {
      responseType: 'blob',
      params
  });
  }
  setSubmittedFormValue(formValue: FormValue): void {
    this.submittedFormValue = formValue;
  }

  getSubmittedFormValue(): FormValue {
    return this.submittedFormValue!;
  }

  setReports(reports: Report[]): void {
    this.reportsSubject.next(reports);
  }

  getReports(): Observable<Report[]> {
    return this.reportsSubject.asObservable();
  }
  
}