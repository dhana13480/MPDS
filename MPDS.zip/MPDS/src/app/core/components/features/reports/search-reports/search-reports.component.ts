import { Component, OnDestroy, OnInit } from '@angular/core';
import { DatePipe } from '@angular/common';
import { Observable, Subscription, BehaviorSubject } from 'rxjs';
import { switchMap, catchError, map } from 'rxjs/operators';
import { ActivatedRoute, Router } from '@angular/router';
import { PihpRegion } from '../../pihp-regions/models/pihp-region.model';
import { PihpregionService } from '../../pihp-regions/services/pihpregion.service';
import { ProviderAgency } from '../../provider-agencies/models/provider-agency.model';
import { ProviderAgencyService } from '../../provider-agencies/services/provideragency.service'; 
import { GroupService } from '../../groups/services/groups.service';
import { Group } from '../../groups/models/group.model';
import { ReportService } from '../services/reports.service';
import { ActivityFundingSourceModel } from '../../activities/models/activity-funding-source.model';
import { ActivityService } from '../../activities/services/activity.service';
@Component({
  selector: 'app-search-reports',
  templateUrl: './search-reports.component.html',
  styleUrls: ['./search-reports.component.css'],
  providers: [DatePipe]
})
export class SearchReportsComponent implements OnInit   {
  id?: string;
  title?: string;
  description?: string;
  myDateValue?: Date;   
  pihpRegionList$?: Observable<PihpRegion[]>;
  groupList$?: Observable<Group[]>;
  selectedPihpRegionId$?: number;  
  providerAgencyList$?: Observable<ProviderAgency[]>;
  paramsSubscription?: Subscription;
  fundingSourceList$?: Observable<ActivityFundingSourceModel[]>
  showFundingSource?: boolean;
  strGamblingRelated?: string; 
  reportPath? : string;  // Path to your SSRS report
  isLoading = false;
  formValue: { 
    groupId: number,
    providerAgencyId: number,
    coordinatingAgencyId: number,     
    startDate: string,
    endDate: string,
    isGamblingRelated: boolean,    
    sortOrder:number,
    sortId:Number,  
    //templateId: 0,
    //ReportName: string,
    fundSourceId: string,
    rptFormat:number,
  } = { 
    groupId: 0,
    providerAgencyId: 0,
    coordinatingAgencyId: 8,     
    startDate: "",
    endDate: "",
    isGamblingRelated: false,  
    sortOrder:0,
    sortId:0, 
    //templateId: 0   ,
    //ReportName: "",
    fundSourceId: "",
    rptFormat:1,
  };
  formSubmitted = false;

  constructor(
    private pihpRegionService: PihpregionService,
    private providerAgencyService: ProviderAgencyService,
    private groupService: GroupService, 
    private reportService: ReportService,   
    private activityService: ActivityService,
    private router:Router,
    private datePipe: DatePipe,
    private route: ActivatedRoute
  ) {}

  ngOnInit():void{
    
    this.pihpRegionList$ = this.pihpRegionService.GetAllCoordinatingAgencies();
    
    this.myDateValue = new Date();

    this.paramsSubscription = this.route.paramMap.subscribe({
      next: (params) => {
        this.id = params.get('id')!;
        if (this.id) {
          switch(this.id) {
            case '12A':
              this.title = 'Form P12A';
              this.description = 'Individual-Based Programs and Strategies – Number of Persons Served by Age, Gender, Race, and Ethnicity';
              break;
            case '12B':
              this.title = 'Form P12B';
              this.description = 'Population-Based Programs and Strategies – Number of Persons Served by Age, Gender, Race, and Ethnicity';
              break;
            case '13':
              this.title = 'Form P13';
              this.description = 'Number of Persons Served by Type of Intervention';
              break;
            case '14':
              this.title = 'Form P14';
              this.description = 'Number of Evidence-Based Programs and Strategies by Type of Intervention';
              break;
            case '15':
              this.title = 'Form P15';
              this.description = 'Total Number of Evidence-Based Programs and Total SAPT BG Dollars Spent on Evidence-Based Programs and Strategies';
              break;
            case 'ActivityData':
              this.title = 'Report - Activity Data File';
              break;
            case 'PESR':
              this.title = 'Report - PESR';
              this.fundingSourceList$ = this.activityService.GetActivityFundingSource();
              this.showFundingSource=true;
              break;
            case 'PESRFund':
              this.title = 'Report - PESR by Funding Source';
              this.fundingSourceList$ = this.activityService.GetActivityFundingSource();
              this.showFundingSource=true;
              break;
            default:
              this.title = "Report"
              break;
          }
        }
      },
    });
  }

  onFormSubmit(){
    this.isLoading = true;
    let i = 0;
    this.providerAgencyList$?.forEach(agency => {
      if(agency[i].id == this.formValue.providerAgencyId){
        this.formValue.providerAgencyId = agency[i].id
      } else {
        i++
      }
    })

    this.formValue.startDate = this.dateFormat(this.formValue.startDate)
    this.formValue.endDate = this.dateFormat(this.formValue.endDate)
    this.strGamblingRelated = this.boolToString(this.formValue.isGamblingRelated) 
    //const reportPath = '/Reports/';  // Path to your SSRS report
    
    if (this.id) {
      switch(this.id) {
        case '12A':
          this.reportPath = 'Report_P12A';              
          break;
        case '12B':
          this.reportPath = 'Report_P12B';
          break;
        case '13':
          this.reportPath = 'Report_P13';              
          break;
        case '14':
          this.reportPath  = 'Report_P14';
          break;
        case '15':
          this.reportPath  = 'Report_P15';
          break;
        case 'ActivityData':
          this.reportPath = 'ActivityDataReport';
          break;
        case 'PESR':
          this.reportPath = 'Report_PESR';
          break;
        case 'PESRFund':
          this.reportPath = 'Report_PESRbyFundingSource';
          break;
        default:
          this.title = "Report_P12A"
          break;
      }
    }

    this.isLoading = true;
    //const format = 'PDF';  // Format of the report (PDF, Excel, etc.)
    const parameters = {  
      "StartDate": this.formValue.startDate?.toString(),
      "EndDate": this.formValue.endDate?.toString(),
      "CoordinatingAgencyIds": this.formValue.coordinatingAgencyId?.toString() ,
      "ProviderAgencyIds": this.formValue.providerAgencyId?.toString(),
      "GroupIds": this.formValue.groupId?.toString(),      
      "IsGamblingRelated": this.formValue.isGamblingRelated, // to do add this parameter to screen      
    };
   
    const reportParams = this.reportService.getReportUrl(this.formValue);
    //SSRS Prod
    //const reportUrl = 'https://hcv491msqlpdm01.ngds.state.mi.us/ReportServer?/MPDS/Reports/'+ this.reportPath + "&" + reportParams + "&rs:format=PDF" ;
    //SSRS QA Dev
    //const reportUrl = 'https://hcv491msqltdm01.ngds.state.mi.us/ReportServer?/MPDS/Reports/'+ this.reportPath + "&" + reportParams + "&rs:format=PDF" 
    //const reportUrl = '/ReportServer?/MPDS/Reports/'+ this.reportPath + "&" + reportParams + "&rs:format=PDF" ;
    //const reportUrl = 'https://mpds-dev.state.mi.us/ReportServer?/MPDS/Reports/'+ this.reportPath + "&" + reportParams + "&rs:format=PDF" 
    this.isLoading = true;
    //hcv491msqlpdm01
    // const reportUrl = '${environment.ssrsUrl}' + this.reportPath + "&" + reportParams + "&rs:format=PDF" ;
    //this.reportService.getReport(this.formValue.rptFormat ===1?'PDF':'EXCEL', this.reportPath?.toString()||'', {StartDate: '@StartDate=' + this.formValue.startDate?.toString(), EndDate: '@EndDate=' + this.formValue.endDate?.toString(), CoordinatingAgencyIds:'@CoordinatingAgencyIds='+this.formValue.coordinatingAgencyId?.toString(), ProviderAgencyIds: '@ProviderAgencyIds='+ this.formValue.providerAgencyId?.toString(),  GroupIds: '@GroupIds='+this.formValue.groupId?.toString(),  IsGamblingRelated: '@IsGamblingRelated=0'}).subscribe(response => {
      this.reportService.getReport(this.formValue.rptFormat ===1?'PDF':'EXCEL', this.reportPath?.toString()||'', {StartDate:   this.formValue.startDate?.toString(), EndDate:this.formValue.endDate?.toString(), CoordinatingAgencyIds: this.formValue.coordinatingAgencyId?.toString()==='0'?'NULL':this.formValue.coordinatingAgencyId?.toString(), ProviderAgencyIds:   this.formValue.providerAgencyId?.toString()==='0'?'NULL':this.formValue.providerAgencyId?.toString(),  GroupIds: this.formValue.groupId?.toString()==='0'?'NULL': this.formValue.groupId?.toString(),  IsGamblingRelated: 'False'}).subscribe(response => {
       
      //const blob = new Blob([response], { type: 'application/pdf' });
      //const blob = new Blob([response], { type: this.formValue.rptFormat === '1' ? 'application/pdf' : 'application/vnd.ms-excel' });
      let blob = new Blob([response], { type: 'application/pdf' });;
      if (this.formValue.rptFormat !== 1)
      {       
          blob = new Blob([response], { type: 'application/vnd.ms-excel' });
      }
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
        a.download = this.reportPath?.toString() ||'report';
        a.href = url;      
        a.click();
        window.URL.revokeObjectURL(url);
         
    });
  
  this.isLoading = false;
  }
  SubmitReport(){
    this.isLoading = true;
  }
  onPihpRegionClick(): void {
    this.isLoading = true;
    this.selectedPihpRegionId$ = this.formValue.coordinatingAgencyId
    this.isLoading = false;
  }

  onProviderAgencyDropdownClick(): void {
    this.isLoading = true;
    this.providerAgencyList$ = this.providerAgencyService.GetProviderAgencyByCoordinatingAgencyId(this.formValue.coordinatingAgencyId.toString())
    this.isLoading = false;
  }

  boolToString(value: boolean) : string{
    if (value) {
      return 'true';
    } else {
      return 'false';
    }
  }

  onGroupDropdownClick(): void {
    this.isLoading = true;
    this.groupList$ = this.groupService.GetGroupsByProviderAgency(this.formValue.coordinatingAgencyId, this.formValue.providerAgencyId)
    this.isLoading = false;
  }

  dateFormat(unformattedDate: string): string {
    const formattedDate = this.datePipe.transform(unformattedDate, 'MM/dd/yyyy');
    return formattedDate || ''; // Return an empty string if formatting fails
  }
  ngOnDestroy(): void {
   // this.getAllActivitiesSubscription?.unsubscribe();
  }
}
