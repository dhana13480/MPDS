export interface FormValue {
    groupId: number,
    providerAgencyId: number,
    coordinatingAgencyId: number,     
    startDate: string,
    endDate: string,
    isGamblingRelated: boolean,  
    sortOrder:number,
    sortId:Number,  
    //templateId: 0,
    //reportName: string,
    //fundSourceId: string
}