import { Component } from '@angular/core';
import { UserService } from '../../users/services/user.service';
import { UserRoles } from '../../enums/user-roles.enum';
import { UserPermissions } from '../../enums/user-permissions.enum';
import { MiLoginUserModel } from '../../users/models/milogin-user-model';

@Component({
  selector: 'app-main-reports',
  templateUrl: './main-reports.component.html',
  styleUrls: ['./main-reports.component.css']
})
export class MainReportsComponent {
  MiLoginUser?: MiLoginUserModel | null;
  userTypeId:number=0;
  userCanRunRports: boolean = false;

constructor( 
  private userService: UserService,) {}

  
  ngOnInit(): void {
    this.userTypeId = Number( sessionStorage.getItem('UserTypeId'));

    this.userService.user$.subscribe(user => {
      this.MiLoginUser = user
      this.checkPermissions(user);     
    })
   
  }
  checkPermissions(user: any): void {
    const userTypeId = user.userTypeId;
    const permissions = user.permissions ? user.permissions.split(',') : [];
  
    if (userTypeId == UserRoles.Super_Admin) 
    {
      this.userCanRunRports = true;
    } else 
    {
      //this.userCanEdit = allowedUserTypes.includes(userTypeId) && requiredPermissions.every(permission => permissions.includes(permission));
      this.userCanRunRports = permissions.includes(UserPermissions.Reports);    
    }
  }
} 