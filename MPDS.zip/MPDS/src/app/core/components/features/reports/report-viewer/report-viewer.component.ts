import { Component, OnInit } from '@angular/core';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';

@Component({
  selector: 'app-report-viewer',
  templateUrl: './report-viewer.component.html',
  styleUrls: ['./report-viewer.component.css']
})
export class ReportViewerComponent implements OnInit {

  source!: SafeResourceUrl;

  constructor(private sanitizer: DomSanitizer) { }
//constructor(private reportService: ReportService) {}

  ngOnInit(): void {
    this.source =
      this.sanitizer.bypassSecurityTrustResourceUrl('');
  }

}
