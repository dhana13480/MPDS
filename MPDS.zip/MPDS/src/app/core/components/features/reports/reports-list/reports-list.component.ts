import { Component, OnInit } from '@angular/core';
import { ReportService } from '../services/reports.service';
import { Report } from '../models/report.model';
import { Observable } from 'rxjs';
import { map } from 'rxjs';
import { FormValue } from '../models/form-values.model';
import { ProviderAgencyService } from '../../provider-agencies/services/provideragency.service';
import { MiLoginUserModel } from '../../users/models/milogin-user-model';
import { UserService } from '../../users/services/user.service';
import { UserRoles } from '../../enums/user-roles.enum';
import { UserPermissions } from '../../enums/user-permissions.enum';

@Component({
  selector: 'app-reports-list',
  templateUrl: './reports-list.component.html',
  styleUrls: ['./reports-list.component.css']
})
export class ReportsListComponent implements OnInit {
  reportsList$?: Observable<Report[]>;
  pihpRegion?: string;
  providerAgency?: string;
  gamblingRelated?: string;
  dateRange?: string;
  submittedFormValue?: FormValue
  MiLoginUser?: MiLoginUserModel | null;
  userTypeId:number=0;
  userCanRunRports: boolean = false;
  sortConfig = {
    column: '',
    direction: 'asc', // default sorting direction
  };

  constructor(private reportService: ReportService, 
    private providerAgencyService: ProviderAgencyService,  
    private userService: UserService,) {}

  ngOnInit(): void {
    this.userTypeId = Number( sessionStorage.getItem('UserTypeId'));

    this.userService.user$.subscribe(user => {
      this.MiLoginUser = user
      this.checkPermissions(user);     
    })
    if (this.userCanRunRports)
    {
    this.reportsList$ = this.reportService.getReports();
    this.submittedFormValue = this.reportService.getSubmittedFormValue()!; 
    this.reportsList$.subscribe(reports => {
      if (reports.length > 0) {
        const firstReport = reports[0];
        this.pihpRegion = firstReport.pihp;

        if (this.submittedFormValue?.providerAgencyId){
          this.providerAgency = firstReport.provider;
        } else {
          this.providerAgency = 'None Selected';
        }

        if (this.submittedFormValue?.isGamblingRelated) {
          this.gamblingRelated = 'Yes';
        }else {
          this.gamblingRelated = 'No';
        }
        this.dateRange = `${this.submittedFormValue!.startDate} - ${this.submittedFormValue!.endDate}`;
      }
    });
  }
  }
  checkPermissions(user: any): void {
    const userTypeId = user.userTypeId;
    const permissions = user.permissions ? user.permissions.split(',') : [];
  
    if (userTypeId == UserRoles.Super_Admin) 
    {
      this.userCanRunRports = true;
    } else 
    {
      //this.userCanEdit = allowedUserTypes.includes(userTypeId) && requiredPermissions.every(permission => permissions.includes(permission));
      this.userCanRunRports = permissions.includes(UserPermissions.Reports);    
    }
  }
  sort(column: string) {
    if (this.sortConfig.column === column) {
      // If the same column is clicked again, toggle the sort direction
      this.sortConfig.direction = this.sortConfig.direction === 'asc' ? 'desc' : 'asc';
    } else {
      // If a new column is clicked, set it as the active column and default to ascending
      this.sortConfig.column = column;
      this.sortConfig.direction = 'asc';
    }

    // Now, sort the data based on the sort configuration
    this.reportsList$ = this.reportsList$?.pipe(
      map((data) => this.sortData(data))
    );
  }

  private sortData(data: Report[]): Report[] {
    const { column, direction } = this.sortConfig;

    if (!column) {
      return data;
    }

    return data.slice().sort((a, b) => {
      const aValue = this.getPropertyValue(a, column);
      const bValue = this.getPropertyValue(b, column);

      
    // For boolean values, explicitly cast to numbers before performing subtraction
    if (typeof aValue === 'boolean') {
      return direction === 'asc' ? (aValue as unknown as number) - (bValue as number) : (bValue as number) - (aValue as unknown as number);
    }


      if (typeof aValue === 'string') {
        return direction === 'asc' ? aValue.localeCompare(bValue) : bValue.localeCompare(aValue);
      } else if (typeof aValue === 'number') {
        return direction === 'asc' ? aValue - bValue : bValue - aValue;
      } else {
        return 0; // Add more cases as needed for other data types
      }
    });
  }

  private getPropertyValue(object: any, column: string): any {
    // Customize this part based on your data structure
    switch (column) {
      case 'groupName':
        return object.groupName;
      case 'activityName':
        return object.activityName;
      case 'recordNumber':
        return object.recordNumber;
      case 'startDate':
        return object.startDate;
      case 'endDate':
        return object.endDate;
      case 'status':
        return object.status;
      default:
        return null;
    }
  }

  // ngOnDestroy(): void {
  //   this.getAllActivitiesSubscription?.unsubscribe();
  // }
}
