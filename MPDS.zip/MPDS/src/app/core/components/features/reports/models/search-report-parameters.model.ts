export interface SearchReportParameters {
    coordinatingAgencyId: number,
    providerAgencyId: number,
    groupId: number,
    isGamblingRelated: boolean,
    startDate: string,
    endDate: string,
    //templateId: number,
    ReportName: string,
    //fundSourceId: string
}