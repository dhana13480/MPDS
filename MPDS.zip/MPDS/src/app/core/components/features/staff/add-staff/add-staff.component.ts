import { Component, Directive, OnDestroy, OnInit } from '@angular/core';
import { Observable, Subscription } from 'rxjs';
import { Router } from '@angular/router';
import { AddRegionStaffRequest } from '../models/add-region-staff.model';
import { StaffService } from '../services/staff.service';
import { PihpRegion } from '../../pihp-regions/models/pihp-region.model';
import { ProviderAgency } from '../../provider-agencies/models/provider-agency.model';
import { ProviderAgencyService } from '../../provider-agencies/services/provideragency.service';
import { PihpregionService } from '../../pihp-regions/services/pihpregion.service';
import { State } from '../../models/states.model';
import { StateService } from '../../services/states.service';
import { UserRoles } from '../../enums/user-roles.enum';

@Component({
  selector: 'app-add-staff',
  templateUrl: './add-staff.component.html',
  styleUrls: ['./add-staff.component.css']
})
export class AddStaffComponent implements OnInit {
  ServerErrorMessage?: string='';
  userTypeId? :number  = Number( sessionStorage.getItem('UserTypeId'));
  pihpregionlist$?: Observable<PihpRegion[]>;
  providerAgencyList$?: Observable<ProviderAgency[]>;
  selectedPihpRegionId$?: number;
  stateList$?: Observable<State[]>;
  model: AddRegionStaffRequest;
  private addStaffRegionSubscription? : Subscription;
  sameAsPihpAddress: boolean = false;
  AddressData$?: {
    address1: string,
    address2: string,
    city: string,
    state: number,
    zip: string,
    comments: string
  };

  constructor(private staffService: StaffService, private router:Router, private pihpregionService: PihpregionService,private providerAgencyService: ProviderAgencyService, private stateService: StateService) {
    this.model = {
      firstName: '',
      middleName: '',
      lastName: '',
      coordinatingAgencyId: 0,
      providerAgencyId: 0, 
      effectiveFrom: new Date(),
      effectiveTo: new Date(),
      isActive: true,
      email: '',
      cellPhone: '',
      officePhone: '',
      homePhone: '',
      fax: '',
      address1: '',
      address2: '',
      city: '',
      state: 30,
      zip: '',
      comments: '',
      createdBy: Number(sessionStorage.getItem("MPDSUserId")),
      creationDate: new Date(),
      updatedBy: Number(sessionStorage.getItem("MPDSUserId")),
      updationDate: new Date(),
      staffType: 0,
      isDeleted: true
    };
  }

  ngOnInit():void{
    this.pihpregionlist$ = this.pihpregionService.GetAllCoordinatingAgencies();
    this.stateList$ = this.stateService.GetAllStates();
  }

  onFormSubmit(newStaffMember: AddRegionStaffRequest){

    this.model = {
      firstName: newStaffMember.firstName || '',
      middleName: newStaffMember.middleName || '',
      lastName: newStaffMember.lastName || '',
      coordinatingAgencyId: newStaffMember.coordinatingAgencyId,
      providerAgencyId: newStaffMember.providerAgencyId,
      effectiveFrom: newStaffMember.effectiveFrom || Date.now(),
      effectiveTo: newStaffMember.effectiveTo || Date.now(),
      isActive: newStaffMember.isActive || true,
      email: newStaffMember.email || '',
      cellPhone: newStaffMember.cellPhone || '',
      officePhone: newStaffMember.officePhone || '',
      homePhone: newStaffMember.homePhone || '',
      fax: newStaffMember.fax || '',
      address1: this.AddressData$?.address1 || newStaffMember.address1,
      address2: this.AddressData$?.address2 || newStaffMember.address2,
      city: this.AddressData$?.city || newStaffMember.city,
      state: this.AddressData$?.state || 30,
      zip: this.AddressData$?.zip || newStaffMember.zip,
      comments: newStaffMember.comments || '',
      createdBy: newStaffMember.createdBy || 17,
      creationDate: newStaffMember.creationDate || Date.now(),
      updatedBy: newStaffMember.updatedBy || 17,
      updationDate: newStaffMember.updationDate || Date.now(),
      staffType: newStaffMember.staffType,
      isDeleted: newStaffMember.isDeleted || true
    };
if (this.userTypeId===UserRoles.Coordinating_Agency)
{
    this.addStaffRegionSubscription = this.staffService.AddStaff(this.model)
    .subscribe({
      next:(response) =>{
        alert("Staff created successfully");
          this.router.navigateByUrl(`/staff/${this.model.coordinatingAgencyId}`);
      },
      error: (error) => {
        // Handle error here
        this.ServerErrorMessage = error.error;
      }
    });
  }
  else  
    {
      this.ServerErrorMessage = "Only User types with Coordinating Agency can add Staff";
    }
  }

  onCheckboxChange(): void {
    // Handle the checkbox change event
    if (this.sameAsPihpAddress) {
      // Call a method to populate the address from PIHP Region
      let coordinatingAgency = this.pihpregionService.GetCoordinatingAgencyById(this.model.coordinatingAgencyId.toString())
      coordinatingAgency.forEach(agency => {
        this.AddressData$ = {
          address1: agency.address1,
          address2: agency.address2,
          city: agency.city,
          state: agency.state,
          zip: agency.zip,
          comments: agency.comments
        }
      })
    } else {
      // Clear the populated address if needed
      this.clearAddress();
    }
  }

  private clearAddress(): void {
    // Implement logic to clear the address fields if needed
    this.AddressData$ = {
      address1: '',
      address2: '',
      city: '',
      state: 30,
      zip: '',
      comments: ''
    }
  }
  onPihpRegionClick(): void {
    this.selectedPihpRegionId$ = this.model.coordinatingAgencyId
  }
  onProviderAgencyDropdownClick(): void {
    this.providerAgencyList$ = this.providerAgencyService.GetProviderAgencyByCoordinatingAgencyId(this.model.coordinatingAgencyId.toString())
  }

  ngOnDestroy(): void {
    this.addStaffRegionSubscription?.unsubscribe();
  }
}
