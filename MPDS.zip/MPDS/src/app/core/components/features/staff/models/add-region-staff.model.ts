export interface AddRegionStaffRequest {
    firstName: string;
    middleName: string;
    lastName: string;
    coordinatingAgencyId: number;
    providerAgencyId: number;
    effectiveFrom: Date;
    effectiveTo: Date;
    isActive: boolean;
    email: string;
    cellPhone: string;
    officePhone: string;
    homePhone: string;
    fax: string;
    address1: string;
    address2: string;
    city: string;
    state: number;
    zip: string;
    comments: string;
    createdBy: number;
    creationDate: Date;
    updatedBy: number;
    updationDate: Date;
    staffType: number;
    isDeleted: boolean;
}