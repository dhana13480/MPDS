import { Component, Directive, OnDestroy, OnInit } from '@angular/core';
import { Observable, Subscription } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';
import { StaffService } from '../services/staff.service';
import { PihpRegion } from '../../pihp-regions/models/pihp-region.model';
import { PihpregionService } from '../../pihp-regions/services/pihpregion.service';
import { State } from '../../models/states.model';
import { StateService } from '../../services/states.service';
import { Staff } from '../models/staff.model';
import { EditRegionStaffRequest } from '../models/edit-region-staff.model';
import { ProviderAgency } from '../../provider-agencies/models/provider-agency.model';
import { ProviderAgencyService } from '../../provider-agencies/services/provideragency.service';
import { UserRoles } from '../../enums/user-roles.enum';
import { UserPermissions } from '../../enums/user-permissions.enum';
import { UserService } from '../../users/services/user.service';
import { MiLoginUserModel } from '../../users/models/milogin-user-model';
@Component({
  selector: 'app-edit-staff',
  templateUrl: './edit-staff.component.html',
  styleUrls: ['./edit-staff.component.css']
})
export class EditStaffComponent {
  id: string | null = null;
  ServerErrorMessage?: string='';
  userTypeId? :number  = Number( sessionStorage.getItem('UserTypeId'));
  pihpregionlist$?: Observable<PihpRegion[]>;
  providerAgency$?: ProviderAgency;
  stateList$?: Observable<State[]>;
  staffMember?: Staff;
  MiLoginUser?: MiLoginUserModel | null;
  userCanEdit: boolean = false;
  paramsSubscription?: Subscription;
  private addStaffRegionSubscription? : Subscription;
  sameAsPihpAddress: boolean = false;
  AddressData$?: {
    address1: string,
    address2: string,
    city: string,
    state: number,
    zip: string,
    comments: string
  };

  formValue: EditRegionStaffRequest = {
    firstName: '',
    middleName: '',
    lastName: '',
    coordinatingAgencyId: 0,
    providerAgencyId: 0, 
    effectiveFrom: new Date(),
    effectiveTo: new Date(),
    isActive: true,
    email: '',
    cellPhone: '',
    officePhone: '',
    homePhone: '',
    fax: '',
    address1: '',
    address2: '',
    city: '',
    state: 30,
    zip: '',
    comments: '',
    createdBy: 0,
    creationDate: new Date(),
    updatedBy: Number(sessionStorage.getItem("MPDSUserId")),
    updationDate: new Date(),
    staffType: 0,
    isDeleted: true
  };

  constructor(private route: ActivatedRoute, 
    private staffService: StaffService, 
    private router:Router, 
    private providerAgencyService: ProviderAgencyService, 
    private pihpregionService: PihpregionService, 
    private stateService: StateService,
    private userService: UserService
  ) {}

  ngOnInit():void{
    this.pihpregionlist$ = this.pihpregionService.GetAllCoordinatingAgencies();
    this.stateList$ = this.stateService.GetAllStates();
    
    this.paramsSubscription = this.route.paramMap.subscribe({
      next: (params) => {
        this.id = params.get('id');
        if (this.id) {
          this.staffService.GetStaffById(this.id).subscribe({
            next: (response) => {
              this.staffMember = response;
              this.providerAgencyService.GetProviderAgencyById(this.staffMember.providerAgencyId.toString()).subscribe(providerAgency => {
                this.providerAgency$ = providerAgency;
              });
  
              // Initialize formValue with the data from Provider Agency
              this.formValue = {
                firstName: this.staffMember.firstName || '',
                middleName: this.staffMember.middleName || '',
                lastName: this.staffMember.lastName || '',
                coordinatingAgencyId: this.staffMember.coordinatingAgencyId || 0,
                providerAgencyId: this.staffMember.providerAgencyId || 0,
                effectiveFrom: this.staffMember.effectiveFrom || new Date(),
                effectiveTo: this.staffMember.effectiveTo || new Date(),
                isActive: this.staffMember.isActive ?? true,
                email: this.staffMember.email || '',
                cellPhone: this.staffMember.cellPhone || '',
                officePhone: this.staffMember.officePhone || '',
                homePhone: this.staffMember.homePhone || '',
                fax: this.staffMember.fax || '',
                address1: this.staffMember.address1 || '',
                address2: this.staffMember.address2 || '',
                city: this.staffMember.city || '',
                state: this.staffMember.state || 30,
                zip: this.staffMember.zip || '',
                comments: this.staffMember.comments || '',
                createdBy: this.staffMember.createdBy,
                creationDate: this.staffMember.creationDate || new Date(),
                updatedBy: Number(sessionStorage.getItem("MPDSUserId")),
                updationDate: this.staffMember.updationDate || new Date(),
                staffType: this.staffMember.staffType || 0,
                isDeleted: this.staffMember.isDeleted ?? true
              };
            },
          });
        }
      },
    });
  }

  onFormSubmit(updatedStaffMember: EditRegionStaffRequest){

    const updateStaffMemberRequest = {
      id: this.staffMember?.id,
      firstName: updatedStaffMember.firstName || '',
      middleName: updatedStaffMember.middleName || '',
      lastName: updatedStaffMember.lastName || '',
      coordinatingAgencyId: updatedStaffMember.coordinatingAgencyId,
      providerAgencyId: updatedStaffMember.providerAgencyId,
      effectiveFrom: updatedStaffMember.effectiveFrom || Date.now(),
      effectiveTo: updatedStaffMember.effectiveTo || Date.now(),
      isActive: updatedStaffMember.isActive || true,
      email: updatedStaffMember.email || '',
      cellPhone: updatedStaffMember.cellPhone || '',
      officePhone: updatedStaffMember.officePhone || '',
      homePhone: updatedStaffMember.homePhone || '',
      fax: updatedStaffMember.fax || '',
      address1: this.AddressData$?.address1 || updatedStaffMember.address1,
      address2: this.AddressData$?.address2 || updatedStaffMember.address2,
      city: this.AddressData$?.city || updatedStaffMember.city,
      state: this.AddressData$?.state || 30,
      zip: this.AddressData$?.zip || updatedStaffMember.zip,
      comments: updatedStaffMember.comments || '',
      createdBy: updatedStaffMember.createdBy || 17,
      creationDate: updatedStaffMember.creationDate || Date.now(),
      updatedBy: updatedStaffMember.updatedBy || 17,
      updationDate: updatedStaffMember.updationDate || Date.now(),
      staffType: updatedStaffMember.staffType,
      isDeleted: updatedStaffMember.isDeleted || true
    };
    console.log(updateStaffMemberRequest)
    if  (this.userTypeId===UserRoles.Coordinating_Agency)
     {
    this.addStaffRegionSubscription = this.staffService.UpdateStaff(updateStaffMemberRequest.id!, updateStaffMemberRequest)
    .subscribe({
      next:(response) =>{
        alert("Staff updated successfully");
        this.router.navigateByUrl(`/staff/${this.formValue.coordinatingAgencyId}`);
      }
    });
  }
    else  
    {
      this.ServerErrorMessage = "Only User types with Coordinating Agency can ad/edit Staff";
    }
  }
 

  getStaffTypeText(staffType: number): string {
    return staffType === 1 ? 'Coordinating Agency' : 'Provider Agency';
  }
  checkPermissions(user: any): void {
    const userTypeId = user.userTypeId;
    const permissions = user.permissions ? user.permissions.split(',') : [];
 
    if (userTypeId == UserRoles.Auditor) {
      this.userCanEdit = false;     
    }
    
    if (userTypeId == UserRoles.Super_Admin) {
      this.userCanEdit = true;       
    } else {
      this.userCanEdit = permissions.includes(UserPermissions.Manage_Staff);      
    }
  }
  onCheckboxChange(): void {
    // Handle the checkbox change event
    if (this.sameAsPihpAddress) {
      // Call a method to populate the address from PIHP Region
      let coordinatingAgency = this.pihpregionService.GetCoordinatingAgencyById(this.formValue.coordinatingAgencyId.toString())
      coordinatingAgency.forEach(agency => {
        this.AddressData$ = {
          address1: agency.address1,
          address2: agency.address2,
          city: agency.city,
          state: agency.state,
          zip: agency.zip,
          comments: agency.comments
        }
      })
    } else {
      // Clear the populated address if needed
      this.clearAddress();
    }
  }

  private clearAddress(): void {
    // Implement logic to clear the address fields if needed
    this.AddressData$ = {
      address1: '',
      address2: '',
      city: '',
      state: 30,
      zip: '',
      comments: ''
    }
  }
  
  ngOnDestroy(): void {
    this.addStaffRegionSubscription?.unsubscribe();
  }
}
