import { HttpClient, HttpResponse } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Injectable } from '@angular/core';
import { Observable, map } from 'rxjs'; 
import { Staff } from '../models/staff.model';
import { AddRegionStaffRequest } from '../models/add-region-staff.model';
import { UserService } from '../../users/services/user.service';
import { EditRegionStaffRequest } from '../models/edit-region-staff.model';
import { StaffItem } from '../../activities/models/staff.model';
 
 
@Injectable({
  providedIn: 'root'
})
export class StaffService {
  tableData: any[] = [];
  storedUserStringified = sessionStorage.getItem('MiLoginUser')!;
  
  totalItems?: number = 0;
  UserPermissionInfo?: {
    userTypeId: number | null,
    coordinatingAgencyId: number | null,
    providerAgencyId: number | null,
    permissions: string | null
  }

  constructor(private http: HttpClient, private userService: UserService) {
    this.userService.user$.subscribe(user => {
      if (user) {
        this.UserPermissionInfo = {
          userTypeId: user.userTypeId||0,
          coordinatingAgencyId: user.coordinatingAgencyId||0,
          providerAgencyId: user.providerAgencyId||0,
          permissions: user.permissions||''
        }
      } 
    })
   }

  GetAllStaffPaginated(pageNumber?: number, pageSize?: number, formValues?: object) {
    const url = `${environment.apiBaseUrl}/api/Staff/GetAllStaffPaginated?PageNumber=${pageNumber}&PageSize=${pageSize}`;

    const fullFormValues = {
      ...formValues,
      userTypeId: this.UserPermissionInfo!.userTypeId,
      userCoordinatingAgencyId: this.UserPermissionInfo!.coordinatingAgencyId,
      userProviderAgencyId: this.UserPermissionInfo!.providerAgencyId,
      permissions: this.UserPermissionInfo!.permissions
    };

    console.log(fullFormValues)
    return this.http.post<Staff[]>(url, fullFormValues, { observe: 'response' }).pipe(
      map((response: HttpResponse<Staff[]>) => {
        const paginationHeader = response.headers.get('Pagination');
        if (paginationHeader) {
          const paginationData = JSON.parse(paginationHeader);
          this.totalItems = paginationData.totalItems;
        }
        return response.body!;
      })
    );
  }

  GetAllStaff() : Observable<Staff[]> {
    return this.http.get<Staff[]>(`${environment.apiBaseUrl}/api/staff`);
  }
  
  GetStaffByActivityId(id:string) : Observable<Staff> {
    return this.http.get<Staff>(`${environment.apiBaseUrl}/api/staff/Activity/${id}`);
  }
  GetStaffById(id:string) : Observable<Staff> {
    return this.http.get<Staff>(`${environment.apiBaseUrl}/api/staff/${id}`);
  }
  
  GetStaffByProviderAgency(id:string) : Observable<Staff[]> {
    return this.http.get<Staff[]>(`${environment.apiBaseUrl}/api/Staff/ProviderAgency/${id}`);
  }
  GetStaffByPIHPRegionAndProviderAgency(cid:number, pid:number) : Observable<Staff[]> {
    return this.http.get<Staff[]>(`${environment.apiBaseUrl}/api/Staff/CoordinatingAgency/${cid}/ProviderAgency/${pid}`);
  }
  
  GetStaffByCoordinatingAgency(id:string) : Observable<Staff[]> {
    return this.http.get<Staff[]>(`${environment.apiBaseUrl}/api/Staff/CoordinatingAgency/${id}`);
  }

  AddStaff(addStaffRequest:AddRegionStaffRequest): Observable<void>{
    return this.http.post<void>(`${environment.apiBaseUrl}/api/staff`, addStaffRequest);
  }

  AddActivityStaff(data:any[], activityId:number): Observable<void>{
    //console.log(data)
   // console.log(`${environment.apiBaseUrl}/api/Activity/ActStaffData/${activityId}`)
    return this.http.post<void>(`${environment.apiBaseUrl}/api/Activity/ActStaffData/${activityId}`, data );
  }

  GetActivityStaff(activityId:number): Observable<any[]>{
    //console.log(data)
   // console.log(`${environment.apiBaseUrl}/api/Activity/ActivityStaffByActivityId/${activityId}`)
    return this.http.get<any[]>(`${environment.apiBaseUrl}/api/Activity/ActivityStaffByActivityId/${activityId}`);
  }
  UpdateStaff(id: number, updateStaffRequest: EditRegionStaffRequest): Observable<Staff> {
    return this.http.put<Staff>(`${environment.apiBaseUrl}/api/Staff/${id}`, updateStaffRequest);
  }
}
