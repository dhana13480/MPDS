import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable, Subscription, of } from 'rxjs';
import { map } from 'rxjs/operators';
import { Staff } from '../models/staff.model';
import { StaffService } from '../services/staff.service';
import { FuncsService } from '../../services/funcs.service';
import { PihpregionService } from '../../pihp-regions/services/pihpregion.service';
import { ProviderAgencyService } from '../../provider-agencies/services/provideragency.service';
import { PihpRegion } from '../../pihp-regions/models/pihp-region.model';
import { ProviderAgency } from '../../provider-agencies/models/provider-agency.model';
import { UserService } from '../../users/services/user.service';
import { MiLoginUserModel } from '../../users/models/milogin-user-model';
import { UserRoles } from '../../enums/user-roles.enum';
import { UserPermissions } from '../../enums/user-permissions.enum';

@Component({
  selector: 'app-staff-list',
  templateUrl: './staff-list.component.html',
  styleUrls: ['./staff-list.component.css']
})
export class StaffListComponent  implements OnInit{
  id: string | null = null;
  paramsSubscription?: Subscription;
  stafflist$?: Observable<Staff[]>;
  pihpRegionList$?: Observable<PihpRegion[]>
  providerAgencyList$?:Observable<ProviderAgency[]>
  MiLoginUser?: MiLoginUserModel | null;
  userCanEdit: boolean = false;
  userTypeId:number=0;
  phone$?: Observable<FuncsService[]>;
  totalItems = 0;
  pageNumber = 1;
  pageSize = 20;
  isLoading = false;
  formValues: {
    searchByLastName: string,
    searchByUserName: string,
    coordinatingAgencyId: number,
    providerAgencyId: number
  } = { 
    searchByLastName: "",
    searchByUserName: "",
    coordinatingAgencyId: 0,
    providerAgencyId: 0
  };
  
  constructor(
    private staffService: StaffService,
    private pihpRegionService: PihpregionService,
    private providerAgencyService: ProviderAgencyService,
    private route: ActivatedRoute,
    private userService: UserService,
    private router: Router,
    private funcs: FuncsService
  ){}

  ngOnInit():void{
    this.userTypeId = Number( sessionStorage.getItem('UserTypeId'));
    this.pihpRegionList$ = this.pihpRegionService.GetAllCoordinatingAgencies();
    this.userService.user$.subscribe(user => {
      this.MiLoginUser = user
      this.checkPermissions(user);      
      //this.loadCoordinatingAgencies() 
    })

    this.paramsSubscription = this.route.paramMap.subscribe({
      next: (params) => {
        this.id = params.get('id');
        if (typeof this.id === 'number') {
          this.isLoading = true
          this.stafflist$ = this.staffService.GetStaffByProviderAgency(this.id);
          this.isLoading = false
        }
        else {
          this.userService.user$.subscribe(user => {
            this.MiLoginUser = user
            this.checkPermissions(user);
            if (user!.userTypeId !== UserRoles.Super_Admin) {
              this.formValues = { 
                searchByLastName: '',
                searchByUserName: '',
                coordinatingAgencyId: user!.coordinatingAgencyId,
                providerAgencyId: user!.providerAgencyId,
              };
              this.loadStaff()
            } else {
              this.loadStaff()
            }
          })
        }
      },
    });
  }

  onFormSubmit() {
    this.loadStaff();
  }

  loadStaff() {
    this.isLoading = true
    this.staffService.GetAllStaffPaginated(this.pageNumber, this.pageSize, this.formValues).subscribe(staff => {
      this.stafflist$ = of(staff);
      this.totalItems = this.staffService.totalItems!;
      this.isLoading = false
    })
  }

  isSessionActive(): boolean {
    return this.userService.isUserAuthenticated();
  }

  checkPermissions(user: any): void {
    const userTypeId = user.userTypeId;
    const permissions = user.permissions ? user.permissions.split(',') : [];

    const allowedUserTypes = [3]; 
    const requiredPermissions = ['1'];

    if (userTypeId == UserRoles.Super_Admin) {
      this.userCanEdit = true;
    } else {
      this.userCanEdit = user.permissions ?.includes(UserPermissions.Manage_Staff);
      //allowedUserTypes.includes(userTypeId) && requiredPermissions.some(permission => permissions.includes(permission));
    }

    if (userTypeId == UserRoles.Auditor) {
      this.userCanEdit = false;
    }
  }

  pageChanged(event: any) {
    if (this.pageNumber !== event.page) {
      this.pageNumber = event.page;
      this.loadStaff();
    }
  }

  
  onProviderAgencyDropdownClick(): void {
    this.providerAgencyList$ = this.providerAgencyService.GetProviderAgencyByCoordinatingAgencyId(this.formValues.coordinatingAgencyId.toString())
  }
  /*
  onProviderAgencyDropdownClick() {
    this.providerAgencyService.GetProviderAgencyByCoordinatingAgencyId(this.formValues.coordinatingAgencyId.toString()).pipe(
      map(agencies => {
        return this.MiLoginUser!.userTypeId === UserRoles.Super_Admin 
          ? agencies 
          : agencies.filter((agency: ProviderAgency) => agency.id === this.MiLoginUser!.providerAgencyId);
      })
    ).subscribe(filteredAgencies => {
      this.providerAgencyList$ = of(filteredAgencies);
      //this.loadStaff();
    });
  }*/
}