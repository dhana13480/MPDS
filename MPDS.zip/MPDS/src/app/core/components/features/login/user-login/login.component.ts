import { Component, OnInit } from '@angular/core';
import { Observable, Subscription } from 'rxjs';
import { Router } from '@angular/router';
import { switchMap, catchError, map } from 'rxjs/operators';
import { of } from 'rxjs';
import { FuncsService } from '../../services/funcs.service';
import { UserLoginService } from '../services/user-login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  userLoginSubscription?: Subscription;
  formSubmitted = false;
  formValue: { 
    username: string, 
    password: string 
  } = { 
    username: '', 
    password: '' 
  };

  constructor(
    private router: Router,
    private funcs: FuncsService,
    private userLoginService: UserLoginService
  ){}

  ngOnInit():void{

  }
    
  onFormSubmit() {
    this.userLoginSubscription = this.userLoginService.ValidateTestUser('avidie1@michigan.gov')
    //this.userLoginSubscription = this.userLoginService.ValidateUser(this.formValue.username, this.formValue.password)
    .subscribe({
      next:(response) =>{
        if (response[0]){
          if (response[0].userTypeId = 2){
            this.router.navigateByUrl(`/user-selections/${response[0].id}`);
          } else {
            this.router.navigateByUrl(`/`);
          }
        } else {
          this.router.navigateByUrl(`/`);
        }
      }, 
      
    });
  }
}
