import { Component } from '@angular/core';
import { Observable, Subscription, forkJoin, map, of } from 'rxjs';
import { ProviderAgency } from '../../provider-agencies/models/provider-agency.model';
import { PihpRegion } from '../../pihp-regions/models/pihp-region.model';
import { PihpregionService } from '../../pihp-regions/services/pihpregion.service';
import { ProviderAgencyService } from '../../provider-agencies/services/provideragency.service';
import { UserService } from '../../users/services/user.service';
import { ActivatedRoute, Router } from '@angular/router';
import { FuncsService } from '../../services/funcs.service';
import { User } from '../../users/models/user.model';

@Component({
  selector: 'app-user-selections',
  templateUrl: './user-selections.component.html',
  styleUrls: ['./user-selections.component.css']
})
export class UserSelectionsComponent {
  id: string | null = null;
  pihpRegionList$?: Observable<PihpRegion[]>;
  providerAgencyList$?: Observable<ProviderAgency[]>;
  signedInUser?: User
  paramsSubscription?: Subscription;

  formValue: {
    selectedRegionId: number,
    selectedAgencyId: number
  } = {
    selectedRegionId: 2,
    selectedAgencyId: 0
  }


  constructor(
    private pihpRegionService: PihpregionService,
    private providerAgencyService: ProviderAgencyService,
    private userService: UserService,
    private router: Router,
    private route: ActivatedRoute,
    private funcs: FuncsService 
  ){}

  ngOnInit():void{
    this.paramsSubscription = this.route.paramMap.subscribe({
      next: (params) => {
        this.id = params.get('id');
        this.userService.GetUserById(this.id!.toString()).forEach(user => {
          this.signedInUser = user
          console.log(this.signedInUser)
        })
      }
    })

    this.pihpRegionList$ = this.pihpRegionService.GetAllCoordinatingAgencies().pipe(
      map(pihpRegions => {
        // Split the CSV string into an array of IDs
        const coordinatingAgenciesIds = this.signedInUser!.csvCoordinatingAgencies?.split(',');
  
        // Filter pihpRegions based on matching IDs
        if (coordinatingAgenciesIds) {
          return pihpRegions.filter(region => coordinatingAgenciesIds.includes(region.id.toString()));
        }
        else {
          return []
        }
      })
    );
  }
    
  onFormSubmit() {
    this.signedInUser!.coordinatingAgencyId = Number(this.formValue.selectedRegionId);
    this.signedInUser!.providerAgencyId = Number(this.formValue.selectedAgencyId);

    const fullUserInformation = {
      ...this.signedInUser!,
      miloginusername: null
    }

    this.userService.setUser(fullUserInformation);

    this.router.navigateByUrl(`/`)
    // this.userService.CreateUser(this.formValue)
    // .subscribe({
    //   next:(response) => {
    //     console.log(response)
    //       this.router.navigateByUrl(`/user-list`);
    //   }, 
    // });
  }

  populateAgencies() {
    console.log(this.formValue.selectedRegionId)
    this.providerAgencyList$ = this.providerAgencyService.GetProviderAgencyByCoordinatingAgencyId(this.formValue.selectedRegionId.toString())
    console.log(this.providerAgencyList$)
  }

  updateAgencies() {
    const checkboxes = document.querySelectorAll<HTMLInputElement>('.agencies');
    const selectedOptions = Array.from(checkboxes)
        .filter(checkbox => checkbox.checked)
        .map(checkbox => checkbox.id);
    this.signedInUser!.csvProviderAgencies = selectedOptions.join(',');
  }
}
