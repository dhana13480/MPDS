import { Component, Directive, OnDestroy } from '@angular/core';
import { DatePipe, Time } from '@angular/common';
import { HttpHeaders } from '@angular/common/http';
import { Observable, Subscription } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';
import { AddActivityRequest } from '../models/add-activity-request.model';
import { ActivityService } from '../services/activity.service';
import { PihpRegion } from '../../pihp-regions/models/pihp-region.model';
import { PihpregionService } from '../../pihp-regions/services/pihpregion.service';
import { Program } from '../../pihp-regions/models/program.model';
import { ProviderAgency } from '../../provider-agencies/models/provider-agency.model';
import { ProviderAgencyService } from '../../provider-agencies/services/provideragency.service';
import { Activity } from '../models/activity.model';
import { GroupService } from '../../groups/services/groups.service';
import { Group } from '../../groups/models/group.model';
import { StaffService } from '../../staff/services/staff.service';
import { Staff } from '../../staff/models/staff.model';
import { MasterServicePopulation } from '../../models/optional-data/master-service-population.model';
import { OptionalDataService } from '../../services/optional-data.service';
import { MasterStrategyEmployed } from '../../models/optional-data/master-strategy-employed.model';
import { ActivityFundingSourceModel } from '../models/activity-funding-source.model';

//import { ParticipantService } from '../../services/participants.service';

@Component({
  selector: 'app-add-activity',
  templateUrl: './add-activity.component.html',
  styleUrls: ['./add-activity.component.css'],
  providers: [DatePipe],
 
})
export class AddActivityComponent {
  myDateValue?: Date;
  model: AddActivityRequest;
  activityList$?: Observable<Activity[]>;
  pihpRegionList$?: Observable<PihpRegion[]>;
  groupList$?: Observable<Group[]>;
  selectedGroupProgram$?: string;
  defaultGroupName$?: string;
  selectedPihpRegionId$?: number;
  diffInMs?:number;
  programList$?: Observable<Program[]>;
  staffList$?: Observable<Staff[]>;
  servicePopulationList$?: Observable<MasterServicePopulation[]>;
  strategyEmployedList$?: Observable<MasterStrategyEmployed[]>;
  fundingSourceList$?: Observable<ActivityFundingSourceModel[]>
  staffIds: number[] = [];
  //staffTableData: any[] = [];
  tableData: any[] = [];
  totalAttendees: string ='';
    // Temporary object to store new row data
    newRow = {
      staffName: '',// name
      staffStartDt: '',//start dt
      staffEndDt: '',//end dt
      staffUnits: '', //units
      staffId: '', //id
      activityId:'',
    };
    MPDSUserId: string ='';
   
    selectedStaffValue: string = '';
    selectedStaffId:string = '';
  providerAgencyList$?: Observable<ProviderAgency[]>;
  private addActivitySubscription?: Subscription;
  private queryParams?: Subscription;
  ServerErrorMessage?: string='';
  totalAttendees$?: string;
  staffSubscription?: Subscription;
  //Parameters from Add Group screen
  GroupCAId?:string='';
  GroupPAId?:string='';
  GroupGrpId?:string='';
  GroupProgramNameId?:string='';
  staff!:  {
    activityId: number,
    activityStrategyId: number,
    activityOptionalLocalMBO: string,
    activityStaffId: number,
    activityStaffStartDate: string,
    activityStaffEndDate: string,
    units: number
  }
  //state$?: Observable<StatesComponent[]>;
   
  constructor(
    private pihpRegionService: PihpregionService,
    private providerAgencyService: ProviderAgencyService,
    private staffService: StaffService,
    private groupService: GroupService,
    private activityService: ActivityService,
    private optionalDataService: OptionalDataService,
    private router:Router,
    private route: ActivatedRoute,
    private datePipe: DatePipe,
    
    //private participantService: ParticipantService,
  ) {
    
    this.model = {
      id: 0,
      
      activityName: this.defaultGroupName$ || "",
      groupId: 0,
      totalAttendees: '',
      newMaleAttendees: 0,
      newFemaleAttendees: 0,
      newTransManAttendees: 0,
      newTransWomanAttendees: 0,
      newGenderNonConformingAttendees: 0,
      newOtherAttendees: 0,
      masterStrategyEmployed: 0,
      estimatePeopleReached: 0,
      attendeesCompletingGroup: 0,
      activityOptionalDataId: 0,
      isActive: true,
      isDeleted: false,
      isTobaccoRelated: false,
      isFirstActivityInGroup: false,
      isVerified: false,
      recordNumber: 0,
      verifiedOn: "",
      verifiedByName: "",
      comments: "",
      verifyComments: "",
      createdBy: Number(  sessionStorage.getItem("MPDSUserId")),
      creationDate: Date.now().toString(),
      updatedBy:  Number(  sessionStorage.getItem("MPDSUserId")),
      updationDate: Date.now().toString(),
      orderNumber: 0,
      providerAgencyId: 0,
      programNameId: 0,
      programName:"",
      coordinatingAgencyId: 0,
      startDate: "",
      endDate: "",
      status: "",
      count: 0,
      pageNumber: 0,
      row_Number: 0,
      sortOrder: 0,
      sortId: 0,
      groupName: "",
      verifiedBy: 0,
      activityOptionalId: 0,
      numberOfOriginalItemsCreated: 0,
      numberOfBrochuresDistributed: 0,
      isSchoolBasedActivity: "",
      indirectSpeakingEngagementReach: 0,
      indirectSpeakingEngagementCount: 0,
      schoolDistrictId: 0,
      countyId: 0,
      locationZipCode: "",
      serviceSettingId: 0,
      activityEthnicityId: 0,
      ethnicityId: 0,
      ethnicityNoOfAttendees: 0,
      activityRaceId: 0,
      raceId: 0,
      raceNoOfAttendees: 0,
      activityParticipantAgeGroupId: 0,
      participantAgeGroupId: 0,
      participantAgeGroupNoOfAttendees: 0,
      activityStaffId: 0,
      staffId: 0,
      strategyId: 0,
      units: 0,
      staffUnits: 0,
      optionalLocalMBO: "",
      activityStaffStartDate: "",
      activityStaffEndDate: "",
      primaryStrategyEmployedId: 0,
      servicePopulationId: 0,
      fundingSourceId: 0,
      totalPeopleReached: 0,
      totalImpressions:0,
      methodsUsed: '',
      socialMediaUsed: '',
      totalPSA:0,
    }
   
  }

  ngOnInit():void{
    this.pihpRegionList$ = this.pihpRegionService.GetAllCoordinatingAgencies();
    this.servicePopulationList$ = this.optionalDataService.GetMasterServicePopulation();
    this.strategyEmployedList$ = this.optionalDataService.GetMasterStrategy();
    this.fundingSourceList$ = this.activityService.GetActivityFundingSource();
    this.myDateValue = new Date();
/*
    this.router.queryParams.subscribe(fromGroupParams =>
         { const GroupCAId = fromGroupParams.get('GroupCAId'); const GroupPAId = fromGroupParams.get('GroupPAId'); const GroupGrpId = fromGroupParams.get('GroupGrpId'); const GroupProgramName = fromGroupParams.get('GroupProgramName');
          console.log(GroupCAId, GroupPAId, GroupGrpId, GroupProgramName); 
          // Use the parameters here
         });
    
         this.paramsSubscription = this.route.paramMap.subscribe({
          next: (params) => {
*/
         this.queryParams = this.route.paramMap.subscribe({
          next: (queryParams) => {
             
            this.GroupCAId =  queryParams.get('GroupCAId')||'';
            this.GroupPAId = queryParams.get('GroupPAId')||'';
            this.GroupGrpId = queryParams.get('GroupGrpId')||'';
            this.GroupProgramNameId=   queryParams.get('GroupProgramNameId')||'';
           
          }
        });
     
            //  coordinatingAgencyId
            //try from Session
            this.GroupCAId =   sessionStorage.getItem("GroupCAId")||'';
            this.GroupPAId =  sessionStorage.getItem("GroupPAId")||'';
            this.GroupGrpId =  sessionStorage.getItem("GroupGrpId")||'';
            this.GroupProgramNameId=   sessionStorage.getItem("GroupProgramNameId")||'';

            this.model.coordinatingAgencyId =  Number(this.GroupCAId||0);
            this.model.providerAgencyId =  Number(this.GroupPAId||0);
            this.model.groupId =  Number(this.GroupGrpId||0);
            this.model.programNameId =  Number(this.GroupProgramNameId||0);

            if(this.model.coordinatingAgencyId>0)
            {
              this.providerAgencyList$ = this.providerAgencyService.GetProviderAgencyByCoordinatingAgencyId(this.model.coordinatingAgencyId.toString())
              this.model.providerAgencyId=  Number(this.GroupPAId||0);
            }

            if(this.model.providerAgencyId>0)
            {
              this.groupList$ = this.groupService.GetGroupsByProviderAgency(this.model.coordinatingAgencyId, this.model.providerAgencyId)

              console.log(this.model.groupId)
              if (this.model.groupId !== 0) {
                this.onGroupSelectionChange(this.model.groupId)
              }
            }
            this.model.groupId = Number(this.GroupGrpId||0);
            this.model.programNameId = Number(this.GroupProgramNameId||0);
            if(this.model.providerAgencyId>0)
              {

}
          
            
          }
       
 
  
  onFormSubmit(){
    let i = 0;
    this.providerAgencyList$?.forEach(agency => {
      this.model.providerAgencyId = agency[i].id
      i++
    })
 
    this.model.startDate = this.dateFormat(this.model.startDate)
    this.model.endDate = this.dateFormat(this.model.endDate)
    this.model.creationDate = this.dateFormat(this.model.creationDate)
    this.model.updationDate = this.dateFormat(Date.now().toString())
    //this.model.activityStaffStartDate = this.dateFormat(this.model.activityStaffStartDate)
    //this.model.activityStaffEndDate = this.dateFormat(this.model.activityStaffEndDate)
    this.model.verifiedOn = '' ;
    this.ServerErrorMessage="";
    this.defaultGroupName$ = this.model.groupName.toString()
 this.model.totalImpressions
    sessionStorage.setItem('totalActivityAttendees', this.model.totalAttendees);
   if(this.model.coordinatingAgencyId<=0)
   {
    this.ServerErrorMessage="Please select a PIHP Region";
   } else
   if (this.model.providerAgencyId<=0)
   {
    this.ServerErrorMessage="Please select a Provider Agency";
   } 
   
   else
   if(this.model.groupId<=0)
   {
    this.ServerErrorMessage="Please select a Group";
   } else
   if (this.model.activityName ==='')
   {
    this.ServerErrorMessage="Please enter an Activity name";
   } else
   if (this.model.startDate ==='')
   {
    this.ServerErrorMessage="Please enter the Start Date for the activity";
    
   }
   //else 
  // if (this.model.startDate) {
   // const stDt = new Date(this.model.startDate);
   // const currentDate = new Date(); 
  //}
  else
   if (this.model.endDate ==='')
   {
    this.ServerErrorMessage="Please enter the End Date for the activity";
   } 
   //else     
   //if (this.model.endDate) {
   // const enDt = new Date(this.model.endDate);
   // const currentDate = new Date();

    // Check if selected date is before current date
     //if ( enDt > currentDate)
    // {
    //  this.ServerErrorMessage="End Date should be less than todays date for the activity";
    // }
  //} 
  else 
   if (this.model.totalAttendees ==='')
   {
    this.ServerErrorMessage="Please enter the total Attendees";
   } else
   if (this.model.primaryStrategyEmployedId<=0)
   {
    this.ServerErrorMessage="Please select Primary Strategy Employed";
   }    else
   if (this.model.attendeesCompletingGroup < 0)
   {
    this.ServerErrorMessage="Please enter attendees completing the group";
   }    
    else      
    if (this.tableData.length <= 0)
    {
     this.ServerErrorMessage="Please add Activity Staff";
     alert("Please add Activity Staff");
    }
    else
    {
    this.addActivitySubscription = this.activityService.CreateActivity(this.model)
     .subscribe({
       next:(response: number) => {
            
          this.staffService.AddActivityStaff(this.tableData, response)
             .subscribe
             ({    
                 next: () => {       
                     this.router.navigateByUrl(`/participants/add/${response}`);
                     console.log("Activity staff added successfully");  
                     alert("Activity created successfully");   
                 },    
                 error: (error) => 
                 {       
                     console.error("Error adding activity staff:", error); 
                     this.ServerErrorMessage = error.error; 
                  } 
                    }
              );
            }           
            ,    
            error: (error) => 
            {       
                //console.error("Error adding activity :", error); 
                //console.log(error.error);
                if(error.error)
                  this.ServerErrorMessage = "Error adding activity :"  + error.error; 
                else
                  this.ServerErrorMessage = "Internal Server Error in Add Activity";                 
            }    
      }
    );
    
   }

  }
   
  onPihpRegionClick(): void {
    this.selectedPihpRegionId$ = this.model.coordinatingAgencyId
  }

  onProviderAgencyDropdownClick(): void {
    this.providerAgencyList$ = this.providerAgencyService.GetProviderAgencyByCoordinatingAgencyId(this.model.coordinatingAgencyId.toString())
  }

  onProgramNameDropdownClick(): void {
    this.programList$ = this.pihpRegionService.GetProgramNamesByCoordinatingAgencyId(this.model.coordinatingAgencyId.toString())
  }

  onGroupDropdownClick(): void {
    this.groupList$ = this.groupService.GetGroupsByProviderAgency(this.model.coordinatingAgencyId, this.model.providerAgencyId)

    console.log(this.model.groupId)
    if (this.model.groupId !== 0) {
      this.onGroupSelectionChange(this.model.groupId)
    }
   
  }
  
  onGroupSelectionChange(groupId: number): void {
    // Fetch the program name associated with the selected group
    if (groupId) {
      this.groupService.GetGroupById(groupId.toString()).subscribe({
        next: (group) => {
            console.log(group.programName)
            console.log(group.name)
            this.model.activityName =group.name;
            this.selectedGroupProgram$ = group.programName;
                   
          },
          error: (error) => {
            console.error('Error fetching group details:', error);
          }
        });
    }
  }

  updateMethodsUsed() {
    const checkboxes = document.querySelectorAll<HTMLInputElement>('.methods-check-input');
    const selectedOptions = Array.from(checkboxes)
        .filter(checkbox => checkbox.checked)
        .map(checkbox => checkbox.id);
    this.model.methodsUsed = selectedOptions.join(',');
  }

  updateSocialMediaUsed() {
    const checkboxes = document.querySelectorAll<HTMLInputElement>('.media-check-input');
    const selectedOptions = Array.from(checkboxes)
        .filter(checkbox => checkbox.checked)
        .map(checkbox => checkbox.id);
    this.model.socialMediaUsed = selectedOptions.join(',');
  }

  onStaffDropdownClick(): void {
    //this.staffList$ = this.staffService.GetStaffByProviderAgency(this.model.providerAgencyId.toString())
    if (this.model.coordinatingAgencyId>0) 
      if (this.model.providerAgencyId>0) 
        {    
          this.staffList$ = this.staffService.GetStaffByPIHPRegionAndProviderAgency(this.model.coordinatingAgencyId, this.model.providerAgencyId)
        }
    this.selectedStaffId =  this.model.activityStaffId.toString();
 
  }
  onChange(event: Event) {
    const target = event.target as HTMLSelectElement;
   // console.log('Selected value:', this.selectedValue);
    console.log('Selected text:', target.options[target.selectedIndex].text);
    this.selectedStaffId =  this.model.activityStaffId.toString();
    this.selectedStaffValue = target.options[target.selectedIndex].text;

    this.newRow.staffStartDt = this.model.startDate;
    this.newRow.staffEndDt = this.model.endDate;
    this.newRow.staffUnits = this.activityService. CalculateUnits( this.newRow.staffStartDt, this.newRow.staffEndDt ).toString()
  }  

  dateFormat(unformattedDate: string): string {
    const formattedDate = this.datePipe.transform(unformattedDate, 'MM/dd/yyyy hh:mm:ss a');
    return formattedDate || ''; // Return an empty string if formatting fails
  }

  /*
  addStaff(): void {
    let i = 1;
    this.staffIds.push(++i);
  }

  removeStaff(index: number): void {
    this.staffIds.splice(index, 1);
  }*/
  //@ViewChild("myStaffId") myStaffId: ElementRef;

  addRow() {
    if (this.newRow.staffStartDt && this.newRow.staffEndDt && this.newRow.staffUnits) {
      this.newRow.staffName=this.selectedStaffValue;
      this.newRow.staffId=this.selectedStaffId;
      const duplicate = this.tableData.some(row => row.staffId === this.newRow.staffId );
      if (!duplicate) {
        const StartDateGood =this.activityService. CheckStaffStartDates( this.model.startDate , this.newRow.staffStartDt);
        const EndDateGood =this.activityService. CheckStaffEndDates( this.model.endDate , this.newRow.staffEndDt);
       
        if((StartDateGood) && (EndDateGood)) {
          if(this.selectedStaffValue!== '')
            if(this.selectedStaffValue!== 'Select')
              this.tableData.push({ ...this.newRow }); // Add new row to table data
        } 
        else
        { 
          alert ("Activity Staff Start End Dates must be within Activity Start and End dates.")        
        }
    }
      this.clearForm(); // Clear form fields after adding the row
    } else {
      alert("Please fill in all Activity Staff fields.");
    }
    console.log("Submitting data:", this.tableData);
  }

  // Function to clear form inputs after adding a row
  clearForm() {
    this.newRow = {
      staffName: '',
      staffStartDt: '',
      staffEndDt: '',
      staffUnits: '',
      staffId:'',
      activityId:'',
    };
  }

  removeRow(index: number) {
    this.tableData.splice(index, 1);  // Remove 1 row at the specified index
    console.log('Row removed successfully');
  }
 

   
  calculateUnits(e: Event): void {   
    this.model.units = this.activityService. CalculateUnits( this.model.startDate, this.model.endDate )   
   }
   
   calculateStaffUnits(e: Event): void {   
    this.newRow.staffUnits = this.activityService. CalculateUnits( this.newRow.staffStartDt, this.newRow.staffEndDt ).toString()
   }
  ngOnDestroy(): void {
    this.addActivitySubscription?.unsubscribe();
  }
}
