export interface getAllActivitiesFormValues {
    groupId: number;
    providerAgencyId: number;
    coordinatingAgencyId: number;
    creationDate: string;
    startDate: string;
    endDate: string;
    recordNumber: number;
    status: string;
    isActive: boolean;
    isDeleted: boolean;
    count: number;
    pageNumber: number;
    sortOrder: number;
    sortId: number;
    activityId: number;
}