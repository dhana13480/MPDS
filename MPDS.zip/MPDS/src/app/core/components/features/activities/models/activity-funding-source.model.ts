export interface ActivityFundingSourceModel {
    id: number,
    fundingSource: string,
    description: string,
    isActive: boolean,
    createdBy: number,
    creationDate: string,
    updatedBy: number,
    updationDate: string
}