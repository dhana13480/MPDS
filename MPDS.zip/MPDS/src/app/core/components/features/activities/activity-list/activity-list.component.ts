import { Component, Directive, OnDestroy, OnInit } from '@angular/core';
import { DatePipe } from '@angular/common';
import { Observable, Subscription, BehaviorSubject, of } from 'rxjs';
import { switchMap, catchError, map, delay, tap } from 'rxjs/operators';
import { Router } from '@angular/router';
import { AddActivityRequest } from '../models/add-activity-request.model';
import { ActivityService } from '../services/activity.service';
import { PihpRegion } from '../../pihp-regions/models/pihp-region.model';
import { PihpregionService } from '../../pihp-regions/services/pihpregion.service';
import { Program } from '../../pihp-regions/models/program.model';
import { ProviderAgency } from '../../provider-agencies/models/provider-agency.model';
import { ProviderAgencyService } from '../../provider-agencies/services/provideragency.service';
import { Activity } from '../models/activity.model';
import { GroupService } from '../../groups/services/groups.service';
import { Group } from '../../groups/models/group.model';
import { MasterServicePopulation } from '../../models/optional-data/master-service-population.model';
import { OptionalDataService } from '../../services/optional-data.service';
import { UserService } from '../../users/services/user.service';
import { MiLoginUserModel } from '../../users/models/milogin-user-model';
import { UserRoles } from '../../enums/user-roles.enum';
import { UserPermissions } from '../../enums/user-permissions.enum';

@Component({
  selector: 'app-activity-list',
  templateUrl: './activity-list.component.html',
  styleUrls: ['./activity-list.component.css'],
  providers: [DatePipe]
})
export class ActivityListComponent implements OnInit, OnDestroy {
  myDateValue?: Date;
  activityList$?: Observable<Activity[]>;
  pihpRegionList$?: Observable<PihpRegion[]>;
  groupList$?: Observable<Group[]>;
  selectedPihpRegionId$?: number;
  programList$?: Observable<Program[]>;
  providerAgencyList$?: Observable<ProviderAgency[]>;
  getAllActivitiesSubscription?: Subscription;
  MiLoginUser?: MiLoginUserModel | null;
  userCanEdit: boolean = false;
  userCanDelete: boolean = false;
  userCanVerify: boolean = false;
  totalItems = 0;
  pageNumber = 1;
  pageSize = 20;
  isLoading = false;
  formValue: { 
    groupId: number,
    providerAgencyId: number,
    coordinatingAgencyId: number,
    creationDate: string,
    startDate: string,
    endDate: string,
    recordNumber: number,
    status: string,
    isActive: boolean,
    isDeleted: boolean,
    Verified:number,
    count: number,
    pageNumber: number,
    sortOrder: number,
    sortId: number,
    activityId: number
  } = { 
    groupId: 0,
    providerAgencyId: 0,
    coordinatingAgencyId: 0,
    creationDate: "",
    startDate: "",
    endDate: "",
    recordNumber: 0,
    status: "",
    isActive: true,
    isDeleted: false,
    Verified: 0,
    count: 0,
    pageNumber: 0,
    sortOrder: 0,
    sortId: 0,
    activityId: 0
  };

  sortConfig = {
    column: '',
    direction: 'asc', // default sorting direction
  };

  formSubmitted = false;

  constructor(
    private pihpRegionService: PihpregionService,
    private providerAgencyService: ProviderAgencyService,
    private groupService: GroupService,
    private activityService: ActivityService, 
    private userService: UserService,
    private optionalDataService: OptionalDataService,
    private router:Router,
    private datePipe: DatePipe
  ) {}

  ngOnInit():void{
        
    this.pihpRegionList$ = this.pihpRegionService.GetAllCoordinatingAgencies();
    this.myDateValue = new Date();
    this.userService.user$.pipe(
      tap(user => {
        this.MiLoginUser = user;
        this.checkPermissions(user);
        if (user!.userTypeId !== UserRoles.Super_Admin) {
          this.formValue.coordinatingAgencyId = user!.coordinatingAgencyId
          this.formValue.providerAgencyId = user!.providerAgencyId
        }
      })
    ).subscribe(() => {
      this.loadActivities()
    });
  }

  onFormSubmit(){
    let i = 0;
    this.providerAgencyList$?.forEach(agency => {
      if(agency[i].id == this.formValue.providerAgencyId){
        this.formValue.providerAgencyId = agency[i].id
      } else {
        i++
      }
    })

    this.formValue.startDate = this.dateFormat(this.formValue.startDate)
    this.formValue.endDate = this.dateFormat(this.formValue.endDate)
    this.formValue.creationDate = this.dateFormat(this.formValue.creationDate)

    this.loadActivities()
  }

  loadActivities() {
    //if (this.formValue.coordinatingAgencyId>0)
  //  {
    this.isLoading = true;
    this.activityService.GetAllActivitiesPaginated(this.pageNumber, this.pageSize, this.formValue).subscribe(users => {
      console.log(users)
      this.activityList$ = of(users);
      this.totalItems = this.activityService.totalItems!;
      this.isLoading = false;
    })
  //  }
  }

  checkPermissions(user: any): void {
    const userTypeId = user.userTypeId;
    const permissions = user.permissions ? user.permissions.split(',') : [];
 
    if (userTypeId == UserRoles.Auditor) {
      this.userCanEdit = false;
      this.userCanDelete = false;
      this.userCanVerify = false;
    }
    if (userTypeId == UserRoles.Super_Admin) {
      this.userCanEdit = true;
      this.userCanDelete = true;
      this.userCanVerify = true;
    } else {
      this.userCanEdit = permissions.includes(UserPermissions.Manage_Activity);
      this.userCanDelete = permissions.includes(UserPermissions.Delete_Actvity);
      this.userCanVerify = permissions.includes(UserPermissions.Verify_Activity);
      //this.userCanEdit = allowedUserTypes.includes(userTypeId) && requiredPermissions.some(permission => permissions.includes(permission));     
      //this.userCanDelete = allowedUserTypes.includes(userTypeId) && requiredPermissions.some(permission => permissions.includes(permission));
      //this.userCanVerify = allowedUserTypes.includes(userTypeId) && requiredPermissions.some(permission => permissions.includes(permission));
    }
  }

  pageChanged(event: any) {
    if (this.pageNumber !== event.page) {
      this.pageNumber = event.page;
      this.activityList$ = this.activityService.GetAllActivitiesPaginated(this.pageNumber, this.pageSize, this.formValue);
    }
  }

  onPihpRegionClick(): void {
    this.selectedPihpRegionId$ = this.formValue.coordinatingAgencyId
  }

  onProviderAgencyDropdownClick(): void {
    this.providerAgencyList$ = this.providerAgencyService.GetProviderAgencyByCoordinatingAgencyId(this.formValue.coordinatingAgencyId.toString())
  }

  onProgramNameDropdownClick(): void {
    this.programList$ = this.pihpRegionService.GetProgramNamesByCoordinatingAgencyId(this.formValue.coordinatingAgencyId.toString())
  }

  onGroupDropdownClick(): void {
    this.groupList$ = this.groupService.GetGroupsByProviderAgency(this.formValue.coordinatingAgencyId, this.formValue.providerAgencyId)
  }

  dateFormat(unformattedDate: string): string {
    const formattedDate = this.datePipe.transform(unformattedDate, 'MM/dd/yyyy');
    return formattedDate || ''; // Return an empty string if formatting fails
  }

  // deactivateRecord(group: UpdateGroupRequest) {
  //   if (group){
  //     group.isActive = false;
  //     console.log(group)
  //     this.groupService.UpdateGroup(group.id.toString(), group)
  //     .subscribe({
  //       next:(response) =>{
  //         console.log(response)
  //         this.router.navigateByUrl('/groups')
  //       }
  //     });
  //   }
  // }

  sort(column: string) {
    if (this.sortConfig.column === column) {
      // If the same column is clicked again, toggle the sort direction
      this.sortConfig.direction = this.sortConfig.direction === 'asc' ? 'desc' : 'asc';
    } else {
      // If a new column is clicked, set it as the active column and default to ascending
      this.sortConfig.column = column;
      this.sortConfig.direction = 'asc';
    }

    // Now, sort the data based on the sort configuration
    this.activityList$ = this.activityList$?.pipe(
      map((data) => this.sortData(data))
    );
  }

  private sortData(data: Activity[]): Activity[] {
    const { column, direction } = this.sortConfig;

    if (!column) {
      return data;
    }

    return data.slice().sort((a, b) => {
      const aValue = this.getPropertyValue(a, column);
      const bValue = this.getPropertyValue(b, column);

      
    // For boolean values, explicitly cast to numbers before performing subtraction
    if (typeof aValue === 'boolean') {
      return direction === 'asc' ? (aValue as unknown as number) - (bValue as number) : (bValue as number) - (aValue as unknown as number);
    }


      if (typeof aValue === 'string') {
        return direction === 'asc' ? aValue.localeCompare(bValue) : bValue.localeCompare(aValue);
      } else if (typeof aValue === 'number') {
        return direction === 'asc' ? aValue - bValue : bValue - aValue;
      } else {
        return 0; // Add more cases as needed for other data types
      }
    });
  }

  private getPropertyValue(object: any, column: string): any {
    // Customize this part based on your data structure
    switch (column) {
      case 'groupName':
        return object.groupName;
      case 'activityName':
        return object.activityName;
      case 'recordNumber':
        return object.recordNumber;
      case 'startDate':
        return object.startDate;
      case 'endDate':
        return object.endDate;
      case 'status':
        return object.status;
      default:
        return null;
    }
  }

  ngOnDestroy(): void {
    this.getAllActivitiesSubscription?.unsubscribe();
  }
}
