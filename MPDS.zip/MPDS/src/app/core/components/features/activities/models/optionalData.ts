export interface optionalData {
    serviceDomain: number;
    intendedPopulation: number;
}