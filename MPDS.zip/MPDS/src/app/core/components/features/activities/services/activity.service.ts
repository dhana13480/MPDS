import { HttpClient, HttpResponse } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Injectable } from '@angular/core';
import { Observable, map } from 'rxjs'; 
import { Activity } from '../models/activity.model';
import { AddActivityRequest} from '../models/add-activity-request.model';
import { UpdateActivityRequest } from '../models/update-activity-request.model';
import { getAllActivitiesFormValues } from '../models/get-all-activities-form-values';
import { ActivityFundingSourceModel } from '../models/activity-funding-source.model';
import { UserService } from '../../users/services/user.service';
 
 
@Injectable({
  providedIn: 'root'
})
export class ActivityService {
  storedUserStringified = sessionStorage.getItem('MiLoginUser')!;
    totalItems?: number = 0;
    totalAttendees$?: string;
    UserPermissionInfo?: {
        userTypeId: number | null,
        coordinatingAgencyId: number | null,
        providerAgencyId: number | null,
        permissions: string | null
    }


    constructor(private http: HttpClient, private userService: UserService) {
        this.userService.user$.subscribe(user => {
            if (user) {
              this.UserPermissionInfo = {
                userTypeId: user.userTypeId||0,
                coordinatingAgencyId: user.coordinatingAgencyId||0,
                providerAgencyId: user.providerAgencyId||0,
                permissions: user.permissions
              }
            }  
          })
     }

    GetAllActivitiesPaginated(pageNumber?: number, pageSize?: number, searchValues?: object) {
        const url = `${environment.apiBaseUrl}/api/Activity/GetAllActivityPaginated?PageNumber=${pageNumber}&PageSize=${pageSize}`;

        const fullSearchValues = {
            ...searchValues,
            userTypeId: this.UserPermissionInfo!.userTypeId||0,
            userCoordinatingAgencyId: this.UserPermissionInfo!.coordinatingAgencyId||0,
            userProviderAgencyId: this.UserPermissionInfo!.providerAgencyId||0,
            permissions: this.UserPermissionInfo!.permissions
        };

        return this.http.post<Activity[]>(url, fullSearchValues, { observe: 'response' }).pipe(
            map((response: HttpResponse<Activity[]>) => {
                const paginationHeader = response.headers.get('Pagination');
                if (paginationHeader) {
                  const paginationData = JSON.parse(paginationHeader);
                  this.totalItems = paginationData.totalItems;
                }
                return response.body!;
            })
        );
    }

    GetActivities(formValues: getAllActivitiesFormValues): Observable<Activity[]>{
        return this.http.post<Activity[]>(`${environment.apiBaseUrl}/api/Activity`, formValues);
    }

    GetActivityById(formValues: getAllActivitiesFormValues): Observable<Activity[]>{
        return this.http.post<Activity[]>(`${environment.apiBaseUrl}/api/Activity`, formValues);
    }

    GetActivitiesByPihpRegion(id:number): Observable<Activity[]>{
        return this.http.get<Activity[]>(`${environment.apiBaseUrl}/api/Activity/coordinatingagency/${id}`);
    }
    GetActivitiesForVerify(): Observable<Activity[]>{
      return this.http.get<Activity[]>(`${environment.apiBaseUrl}/api/Activity/GetActivitiesForVerify()`);
    }

    GetActivitiesByProviderAgency(cid:number, pid:number): Observable<Activity[]>{
        return this.http.get<Activity[]>(`${environment.apiBaseUrl}/api/Activity/coordinatinatingagency/${cid}/provideragency/${pid}`);
    }

    GetActivityFundingSource(): Observable<ActivityFundingSourceModel[]>{
        return this.http.get<ActivityFundingSourceModel[]>(`${environment.apiBaseUrl}/api/FundingSource/GetFundingSource`);
    }

    CreateActivity(model: AddActivityRequest) : Observable<number> {
      
        return this.http.post<number>(`${environment.apiBaseUrl}/api/Activity/AddActivity`, model);
    } 

    UpdateActivity(id:string, updateActivityRequest:UpdateActivityRequest): Observable<Activity>{
    return this.http.put<Activity>(`${environment.apiBaseUrl}/api/Activity/${id}`, updateActivityRequest);
    }
  
    CheckStaffStartDates(ActivityStartDate: string, staffStartDate:string ){
      
      const actStDate = ActivityStartDate;
      const staffStDate = staffStartDate;

      if (actStDate && staffStDate) {
        
        const activityStartDt = new Date(actStDate);
        const staffStartDt = new Date(staffStDate);
        if (staffStartDt >= activityStartDt){
        return true;
        }
        else  return false;
      }
      return false;
    }
    CheckStaffEndDates(ActivityEndDate: string, staffEndDate:string ){
      
      const actEDate = ActivityEndDate;
      const staffEDate = staffEndDate;

      if (actEDate && staffEDate) {
        
        const activityEndDt = new Date(actEDate);
        const staffEndDt = new Date(staffEDate);
        if (staffEndDt <= activityEndDt){
          return true;
        }
        else  return false;
      }
      return false;
    }

    CalculateUnits(startDate: string, endDate:string ){      
        const stDate = startDate;
        const eDate = endDate;
        if (stDate && eDate) {
          
          const start = new Date(stDate);
          const end = new Date(eDate);
          if (start >= end ){
            alert("End Date should be greater that Start Date");
            return 0;
          }   
          if (end > start){
          // Calculate the difference in milliseconds
          const timeDifference = end.getTime() - start.getTime();
          // Convert the difference to days
          return Math.floor(timeDifference / 1000  / 60/30) * 2;
          }
          return 0;
        }  
         else return 0; // Reset if either date is not provided     
       }       
    }
 