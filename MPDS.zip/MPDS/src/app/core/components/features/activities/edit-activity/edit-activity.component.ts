import { Component, Directive, OnDestroy } from '@angular/core';
import { DatePipe } from '@angular/common';
import { Observable, Subscription } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';
import { AddActivityRequest } from '../models/add-activity-request.model';
import { ActivityService } from '../services/activity.service';
import { PihpRegion } from '../../pihp-regions/models/pihp-region.model';
import { PihpregionService } from '../../pihp-regions/services/pihpregion.service';
import { Program } from '../../pihp-regions/models/program.model';
import { ProviderAgency } from '../../provider-agencies/models/provider-agency.model';
import { ProviderAgencyService } from '../../provider-agencies/services/provideragency.service';
import { Activity } from '../models/activity.model';
import { GroupService } from '../../groups/services/groups.service';
import { Group } from '../../groups/models/group.model';
import { StaffService } from '../../staff/services/staff.service';
import { Staff } from '../../staff/models/staff.model';
import { getAllActivitiesFormValues } from '../models/get-all-activities-form-values';
import { UpdateActivityRequest } from '../models/update-activity-request.model';
import { OptionalDataService } from '../../services/optional-data.service';
import { MasterServicePopulation } from '../../models/optional-data/master-service-population.model';
import { MasterStrategyEmployed } from '../../models/optional-data/master-strategy-employed.model';
import { ActivityFundingSourceModel } from '../models/activity-funding-source.model';
import { StaffItem } from '../models/staff.model';
import { UserRoles } from '../../enums/user-roles.enum';
import { UserPermissions } from '../../enums/user-permissions.enum';
import { UserService } from '../../users/services/user.service';
import { MiLoginUserModel } from '../../users/models/milogin-user-model';
@Component({
  selector: 'app-edit-activity',
  templateUrl: './edit-activity.component.html',
  styleUrls: ['./edit-activity.component.css']
})
export class EditActivityComponent {
  socialMediaOptions: string[] = ['Facebook', 'Twitter', 'Instagram', 'LinkedIn', 'X', 'Snapchat'];
  selectedSocialMedia: { [key: string]: boolean } = {};
  selectedSocialMediaString: string = '';
    
  methodsUsedOptions: string[] = ['Billboards', 'TVAdvertisements', 'RadioAdvertisements', 'SocialMedia'];
  selectedMethodsUsed: { [key: string]: boolean } = {};
  selectedMethodsUsedString: string = '';
  MiLoginUser?: MiLoginUserModel | null;

  ServerErrorMessage?: string='';
  id: string | null = null;
  coordinatingAgencyName$?: string;
  providerAgencyName$?: string;
  myDateValue?: Date;
  model: UpdateActivityRequest;
  activity?: Activity[];
  activityList$?: Observable<Activity[]>;
  pihpRegionList$?: Observable<PihpRegion[]>;
  groupList$?: Observable<Group[]>;
  selectedPihpRegionId$?: number;
  selectedFundSourceId$?: number;
  selectedServicePopulationId$?: number;
  selectedMasterStrategyId$?: number;
  selectedStaffValue: string = '';
  selectedStaffId:string = '';
  programList$?: Observable<Program[]>;
  staffList$?: Observable<Staff[]>;
  staff$?: Observable<Staff>;
  staffIds: number[] = [1];
  providerAgencyList$?: Observable<ProviderAgency[]>;
  servicePopulationList$?: Observable<MasterServicePopulation[]>;
  strategyEmployedList$?: Observable<MasterStrategyEmployed[]>;
  fundingSourceList$?: Observable<ActivityFundingSourceModel[]>;
  userTypeId: number= Number( sessionStorage.getItem('UserTypeId'));
  userCanEdit: boolean = false;
  userCanDelete: boolean = false;
  userCanVerify: boolean = false;
  verifiedTextToShow: string='';
  //isFormDirty: boolean=true;
  tableData: any[] = [];
  newRow = {
    staffName: '',// name
    staffStartDt: '',//start dt
    staffEndDt: '',//end dt
    staffUnits: '', //units
    staffId: '', //id
    activityId:'',
  };
  activityStaffList$?: Observable<StaffItem[]>;
  updateActivitySubscription?: Subscription;
  paramsSubscription?: Subscription;
  formValues?: getAllActivitiesFormValues = { 
    groupId: 0,
    providerAgencyId: 0,
    coordinatingAgencyId: 0,
    creationDate: "",
    startDate: "",
    endDate: "",
    recordNumber: 0,
    status: "",
    isActive: true,
    isDeleted: true,
    count: 0,
    pageNumber: 0,
    sortOrder: 0,
    sortId: 0,
    activityId: 0,

  }
  //state$?: Observable<StatesComponent[]>;

  constructor(
    private pihpRegionService: PihpregionService,
    private providerAgencyService: ProviderAgencyService,
    private staffService: StaffService,
    private groupService: GroupService,
    private activityService: ActivityService, 
    private router:Router,
    private userService: UserService,
    private datePipe: DatePipe,
    private route: ActivatedRoute,
    private optionalDataService: OptionalDataService,

  )
  {
   
    
    this.model = {
      id: 0,
      activityName: "",
      groupId: 0,
      totalAttendees: 0,
      newMaleAttendees: 0,
      newFemaleAttendees: 0,
      newTransManAttendees: 0,
      newTransWomanAttendees: 0,
      newGenderNonConformingAttendees: 0,
      newOtherAttendees: 0,
      masterStrategyEmployed: 0,
      estimatePeopleReached: 0,
      attendeesCompletingGroup: 0,
      activityOptionalDataId: 0,
      isActive: true,
      isDeleted: true,
      isTobaccoRelated: false,
      isFirstActivityInGroup: false,
      isVerified: false,
      recordNumber: 0,
      verifiedOn: "",
      verifiedByName: "",
      comments: "",
      verifyComments: "",
      createdBy: 0,
      creationDate: "",
      updatedBy:  Number(  sessionStorage.getItem("MPDSUserId")),
      updationDate: Date.now().toString(),
      orderNumber: 0,
      providerAgencyId: 0,
      programNameId: 0,
      coordinatingAgencyId: 0,
      startDate: "",
      endDate: "",
      status: "",
      count: 0,
      pageNumber: 0,
      row_Number: 0,
      sortOrder: 0,
      sortId: 0,
      groupName: "",
      verifiedBy: 0,
      activityOptionalId: 0,
      numberOfOriginalItemsCreated: 0,
      numberOfBrochuresDistributed: 0,
      isSchoolBasedActivity: "",
      indirectSpeakingEngagementReach: 0,
      indirectSpeakingEngagementCount: 0,
      schoolDistrictId: 0,
      countyId: 0,
      locationZipCode: "",
      serviceSettingId: 0,
      activityEthnicityId: 0,
      ethnicityId: 0,
      ethnicityNoOfAttendees: 0,
      activityRaceId: 0,
      raceId: 0,
      raceNoOfAttendees: 0,
      activityParticipantAgeGroupId: 0,
      participantAgeGroupId: 0,
      participantAgeGroupNoOfAttendees: 0,
      activityStaffId: 0,
      staffId: 0,
      strategyId: 0,
      units: 0,
      optionalLocalMBO: "",
      activityStaffStartDate: "",
      activityStaffEndDate: "",
      primaryStrategyEmployedId: 0,
      servicePopulationId: 0,
      fundingSourceId: 0,
      totalPeopleReached: 0,
      totalImpressions:0,
      methodsUsed: '',
      socialMediaUsed: '',
      totalPSA:0
    }
 
  }
  initializeSocialMediaSelectionFromString(selectionString: string) {
    const selectedArray = selectionString.split(',');
    this.socialMediaOptions.forEach((option) => {
      this.selectedSocialMedia[option] = selectedArray.includes(option);
    });
    this.updateSocialMediaSelectedString(); // Update the string after initial selection
  }
  initializeMethodsUsedSelectionFromString(selectionString: string) {
    const selectedArray = selectionString.split(',');
    this.methodsUsedOptions.forEach((option) => {
      this.selectedMethodsUsed[option] = selectedArray.includes(option);
    });
    this.updateMethodsUsedSelectedString(); // Update the string after initial selection
  }
  // Update the selectedString when checkboxes change
  onCheckboxSocialMediaChange() {
    const selectedArray = this.socialMediaOptions.filter(
      (option) => this.selectedSocialMedia[option]
    );
    this.selectedSocialMediaString = selectedArray.join(',');
  }
  onCheckboxMethodsUsedChange() {
    const selectedArray = this.methodsUsedOptions.filter(
      (option) => this.selectedMethodsUsed[option]
    );
    this.selectedMethodsUsedString = selectedArray.join(',');
  }

  // Optional: call this if you want to reset based on new string values
  updateSocialMediaSelectedString() {
    const selectedArray = this.socialMediaOptions.filter(
      (option) => this.selectedSocialMedia[option]
    );
    this.selectedSocialMediaString = selectedArray.join(',');
  }

  // Optional: call this if you want to reset based on new string values
  updateMethodsUsedSelectedString() {
    const selectedArray = this.methodsUsedOptions.filter(
      (option) => this.selectedMethodsUsed[option]
    );
    this.selectedMethodsUsedString = selectedArray.join(',');
  }

  ngOnInit():void{
    this.userService.user$.subscribe(user => {
      console.log(user)
      this.MiLoginUser = user;
      this.checkPermissions(user);     
    });
 
    this.pihpRegionList$ = this.pihpRegionService.GetAllCoordinatingAgencies();
    this.servicePopulationList$ = this.optionalDataService.GetMasterServicePopulation();
    this.strategyEmployedList$ = this.optionalDataService.GetMasterStrategy();
    this.fundingSourceList$ = this.activityService.GetActivityFundingSource();
    this.userTypeId = Number( sessionStorage.getItem('UserTypeId'));
    this.selectedSocialMediaString = this.model.socialMediaUsed?.toString();
    this.selectedMethodsUsedString = this.model.methodsUsed?.toString();
    this.initializeSocialMediaSelectionFromString(this.model.socialMediaUsed?.toString());
    this.initializeMethodsUsedSelectionFromString(this.model.methodsUsed?.toString());
    
    this.myDateValue = new Date();

    this.paramsSubscription = this.route.paramMap.subscribe({
      next: (params) => {
        this.id = params.get('id');
        if (this.id) {
          this.formValues!.activityId = parseInt(this.id)
          
          this.activityService.GetActivityById(this.formValues!).subscribe({
            next: (response) => {
              const coordinatingAgency = this.pihpRegionService.GetCoordinatingAgencyById(response[0].coordinatingAgencyId?.toString());
              coordinatingAgency.forEach(region => {
                this.coordinatingAgencyName$ = region.name
              })

              const providerAgency = this.providerAgencyService.GetProviderAgencyById(response[0].providerAgencyId?.toString());
              providerAgency.forEach(agency => {
                this.providerAgencyName$ = agency.name
              })
              
             // const staffbyCoPr = this.staffService.GetStaffByPIHPRegionAndProviderAgency(response[0].coordinatingAgencyId.toString(),response[0].providerAgencyId.toString());
              
               this.staffService.GetActivityStaff(this.formValues!.activityId).subscribe(
                (response) => {
                  this.tableData = response;
                },
                (error) => {
                  console.error('Error fetching data', error);
                }
              );
              this.activity = response;
              // Initialize formValue with the data from Provider Agency
              this.model = {
                id: this.activity[0].id || 0,
                activityName: this.activity[0].activityName || "",
                groupId: this.activity[0].groupId || 0,
                totalAttendees: this.activity[0].totalAttendees || 0,
                newMaleAttendees: this.activity[0].newMaleAttendees || 0,
                newFemaleAttendees: this.activity[0].newFemaleAttendees || 0,
                newTransManAttendees: this.activity[0].newTransManAttendees || 0,
                newTransWomanAttendees: this.activity[0].newTransWomanAttendees || 0,
                newGenderNonConformingAttendees: this.activity[0].newGenderNonConformingAttendees || 0,
                newOtherAttendees: this.activity[0].newOtherAttendees || 0,
                masterStrategyEmployed: this.activity[0].masterStrategyEmployed || 0,
                estimatePeopleReached: this.activity[0].estimatePeopleReached || 0,
                attendeesCompletingGroup: this.activity[0].attendeesCompletingGroup || 0,
                activityOptionalDataId: this.activity[0].activityOptionalDataId || 0,
                isActive: this.activity[0].isActive || true,
                isDeleted: this.activity[0].isDeleted || true,
                isTobaccoRelated: this.activity[0].isTobaccoRelated || true,
                isFirstActivityInGroup: this.activity[0].isFirstActivityInGroup || false,
                isVerified: this.activity[0].isVerified ||false,
                recordNumber: this.activity[0].recordNumber || 0,
                verifiedOn: this.activity[0].verifiedOn  || "",
                verifiedByName: this.activity[0].verifiedByName || "",
                comments: this.activity[0].comments || "",
                verifyComments: this.activity[0].verifyComments || "",
                createdBy: this.activity[0].createdBy || 0,
                creationDate: this.activity[0].creationDate || Date.now().toString(),
                updatedBy: this.activity[0].updatedBy || 0,
                updationDate: this.activity[0].updationDate || Date.now().toString(),
                orderNumber: this.activity[0].orderNumber || 0,
                providerAgencyId: this.activity[0].providerAgencyId || 0,
                programNameId: this.activity[0].programNameId || 0,
                coordinatingAgencyId: this.activity[0].coordinatingAgencyId || 0,
                startDate: this.activity[0].startDate || "",
                endDate: this.activity[0].endDate || "",
                status: this.activity[0].status || "",
                count: this.activity[0].count || 0,
                pageNumber: this.activity[0].pageNumber || 0,
                row_Number: this.activity[0].row_Number || 0,
                sortOrder: this.activity[0].sortOrder || 0,
                sortId: this.activity[0].sortId || 0,
                groupName: this.activity[0].groupName || "",
                verifiedBy: this.activity[0].verifiedBy || 0,
                activityOptionalId: this.activity[0].activityOptionalId || 0,
                numberOfOriginalItemsCreated: this.activity[0].numberOfOriginalItemsCreated || 0,
                numberOfBrochuresDistributed: this.activity[0].numberOfBrochuresDistributed || 0,
                isSchoolBasedActivity: this.activity[0].isSchoolBasedActivity || "",
                indirectSpeakingEngagementReach: this.activity[0].indirectSpeakingEngagementReach || 0,
                indirectSpeakingEngagementCount: this.activity[0].indirectSpeakingEngagementCount || 0,
                schoolDistrictId: this.activity[0].schoolDistrictId || 0,
                countyId: this.activity[0].countyId || 0,
                locationZipCode: this.activity[0].locationZipCode || "",
                serviceSettingId: this.activity[0].serviceSettingId || 0,
                activityEthnicityId: this.activity[0].activityEthnicityId || 0,
                ethnicityId: this.activity[0].ethnicityId || 0,
                ethnicityNoOfAttendees: this.activity[0].ethnicityNoOfAttendees || 0,
                activityRaceId: this.activity[0].activityRaceId || 0,
                raceId: this.activity[0].raceId || 0,
                raceNoOfAttendees: this.activity[0].raceNoOfAttendees || 0,
                activityParticipantAgeGroupId: this.activity[0].activityParticipantAgeGroupId || 0,
                participantAgeGroupId: this.activity[0].participantAgeGroupId || 0,
                participantAgeGroupNoOfAttendees: this.activity[0].participantAgeGroupNoOfAttendees || 0,
                activityStaffId: this.activity[0].activityStaffId || 0,
                staffId: 40,
                strategyId: this.activity[0].strategyId || 0,
                units: this.activity[0].units || 0,
                optionalLocalMBO: this.activity[0].optionalLocalMBO || "",
                activityStaffStartDate: this.activity[0].activityStaffStartDate || this.activity[0].startDate,
                activityStaffEndDate: this.activity[0].activityStaffEndDate || this.activity[0].endDate,
                primaryStrategyEmployedId: this.activity[0].primaryStrategyEmployedId || 0,
                servicePopulationId: this.activity[0].servicePopulationId || 0,
                fundingSourceId: this.activity[0].fundingSourceId || 0,
                totalPeopleReached: this.activity[0].totalPeopleReached||0,
                totalImpressions: this.activity[0].totalImpressions||0,
                methodsUsed: this.activity[0].methodsUsed||"",
                socialMediaUsed: this.activity[0].socialMediaUsed|| "",     
                totalPSA:this.activity[0].totalPSA||0,            
              };
              //console.log(this.model.id);
            
              this.initializeSocialMediaSelectionFromString(this.model.socialMediaUsed);
              this.initializeMethodsUsedSelectionFromString(this.model.methodsUsed);
              //this.updateMethodsUsedCheckboxes();
              //this.updateSocialMediaUsedCheckboxes();
              this.model.units = this.activityService. CalculateUnits( this.model.startDate, this.model.endDate );
              if (this.model.isVerified)
                this.verifiedTextToShow = "Verified By: " + this.model.verifiedByName + " on " + this.model.verifiedOn || ''; 
            },
          });
        }
       
        //this.staff$ = this.staffService.GetStaffById(this.model.staffId.toString())
        //this.staff$ = this.staffService.GetStaffByPIHPRegionAndProviderAgency(coordinatingAgencyId.toString(), providerAgencyId.toString())
   
      },
    });
  
  }

  checkPermissions(user: any): void {
    const userTypeId = user.userTypeId;
    const permissions = user.permissions ? user.permissions.split(',') : [];

    if (userTypeId == UserRoles.Auditor) {
      this.userCanEdit = false;
      this.userCanDelete = false;
      this.userCanVerify = false;
    }
    if (userTypeId == UserRoles.Super_Admin) {
      this.userCanEdit = true;
      this.userCanDelete = true;
      this.userCanVerify = true;
    } else {
      this.userCanEdit = permissions.includes(UserPermissions.Manage_Activity);
      this.userCanDelete = permissions.includes(UserPermissions.Delete_Actvity);
      this.userCanVerify = permissions.includes(UserPermissions.Verify_Activity);
      //this.userCanEdit = allowedUserTypes.includes(userTypeId) && requiredPermissions.some(permission => permissions.includes(permission));     
      //this.userCanDelete = allowedUserTypes.includes(userTypeId) && requiredPermissions.some(permission => permissions.includes(permission));
      //this.userCanVerify = allowedUserTypes.includes(userTypeId) && requiredPermissions.some(permission => permissions.includes(permission));
    }
  }
  onFormSubmit(){
    let i = 0;
    this.providerAgencyList$?.forEach(agency => {
      this.model.providerAgencyId = agency[i].id
      i++
    })

    this.model.startDate = this.dateFormat(this.model.startDate)
    this.model.endDate = this.dateFormat(this.model.endDate)
    this.model.creationDate = this.dateFormat(this.model.creationDate)
    this.model.updationDate = this.dateFormat(this.model.updationDate)
    this.model.verifiedOn = this.dateFormat(this.model.verifiedOn)
    this.model.socialMediaUsed = this.selectedSocialMediaString
    this.model.methodsUsed = this.selectedMethodsUsedString
    this.model.updatedBy=  Number(sessionStorage.getItem("MPDSUserId"))
    if (!this.model.isVerified)
    {
      if (this.model.verifyComments!=='')
      {
        this.model.isVerified =true,
        this.model.verifiedBy = this.model.updatedBy,
        this.model.verifiedByName = sessionStorage.getItem('MPDSUserFirstName') + ' ' + sessionStorage.getItem('MPDSUserLastName'),
        this.model.verifyComments =  this.model.verifyComments
      }
    }
    sessionStorage.setItem('totalActivityAttendees', this.model.totalAttendees?.toString());
    console.log(this.model)
    //if(this.model.isVerified)
    if (this.model.activityName ==='')
    {
     this.ServerErrorMessage="Please enter an Activity name";
    } else
    if (this.model.startDate ==='')
   {
    this.ServerErrorMessage="Please enter the Start Date for the activity";    
   } else
   if (this.model.endDate ==='')
   {
    this.ServerErrorMessage="Please enter the End Date for the activity";
   } else
   
    this.updateActivitySubscription = this.activityService.UpdateActivity(this.model.id?.toString(), this.model)
    .subscribe({
      next:(response) => {
        console.log(response)
        alert("Activity updated successfully");
        this.router.navigateByUrl(`/participants/edit/${response}`);
      },
      error: (error) => {
        // Handle error here
        this.ServerErrorMessage = error.error;
      } 
    });
   
  }
   
  onPihpRegionClick(): void {
    this.selectedPihpRegionId$ = this.model.coordinatingAgencyId;
  }

  onProviderAgencyDropdownClick(): void {
    this.providerAgencyList$ = this.providerAgencyService.GetProviderAgencyByCoordinatingAgencyId(this.model.coordinatingAgencyId?.toString())
  }

  onProgramNameDropdownClick(): void {
    this.programList$ = this.pihpRegionService.GetProgramNamesByCoordinatingAgencyId(this.model.coordinatingAgencyId?.toString())
  }

  onGroupDropdownClick(): void {
    this.groupList$ = this.groupService.GetGroupsByProviderAgency(this.model.coordinatingAgencyId, this.model.providerAgencyId)
  }

  onStaffDropdownClick(): void {
    //this.staffList$ = this.staffService.GetStaffByProviderAgency(this.model.providerAgencyId.toString())
    //console.log(this.model.coordinatingAgencyId.toString());
    //console.log(this.model.providerAgencyId.toString());
    this.staffList$ = this.staffService.GetStaffByPIHPRegionAndProviderAgency(this.model.coordinatingAgencyId, this.model.providerAgencyId)
  }
  onChange(event: Event) {
    const target = event.target as HTMLSelectElement;
    //console.log('Selected value:', this.selectedValue);
    //console.log('Selected text:', target.options[target.selectedIndex].text);
    this.selectedStaffId =  this.model.activityStaffId?.toString();
    this.selectedStaffValue = target.options[target.selectedIndex].text;
  }  
  dateFormat(unformattedDate: string): string {
    const formattedDate = this.datePipe.transform(unformattedDate, 'MM/dd/yyyy hh:mm:ss a');
    return formattedDate || ''; // Return an empty string if formatting fails
  }
 

  addRow() {
    if (this.newRow.staffStartDt && this.newRow.staffEndDt && this.newRow.staffUnits) {
      this.newRow.staffName=this.selectedStaffValue;
      this.newRow.staffId=this.selectedStaffId;
      const duplicate = this.tableData.some(row => row.staffId === this.newRow.staffId );
      if (!duplicate) {
        this.tableData.push({ ...this.newRow }); // Add new row to table data
      }
      this.clearForm(); // Clear form fields after adding the row
    } else {
      alert("Please fill in all Activity Staff fields.");
    }
    //console.log("Submitting data:", this.tableData);
  }

  // Function to clear form inputs after adding a row
  clearForm() {
    this.newRow = {
      staffName: '',
      staffStartDt: '',
      staffEndDt: '',
      staffUnits: '',
      staffId:'',
      activityId:'',
    };
  }

  removeRow(index: number) {
    this.tableData.splice(index, 1);  // Remove 1 row at the specified index
    console.log('Row removed successfully');
  }
 verifyActivity(){
  if (this.model.verifyComments !=='')
  {
    this.model.verifyComments = "Verified Comments: [By " + this.model.verifiedByName + Date.now.toString() +  "Comment: " + this.model.verifyComments  ; 
  }
 }
 unVerifyActivity(){
  
 }
 updateMethodsUsed() {
  const checkboxes = document.querySelectorAll<HTMLInputElement>('.methods-check-input');
  const selectedOptions = Array.from(checkboxes)
      .filter(checkbox => checkbox.checked)
      .map(checkbox => checkbox.id);
  this.model.methodsUsed = selectedOptions.join(',')
}

updateSocialMediaUsed() {
  const checkboxes = document.querySelectorAll<HTMLInputElement>('.media-check-input');
  const selectedOptions = Array.from(checkboxes)
      .filter(checkbox => checkbox.checked)
      .map(checkbox => checkbox.id);
  this.model.socialMediaUsed = selectedOptions.join(',');
}
  calculateUnits(e: Event): void {   
    this.model.units = this.activityService. CalculateUnits( this.model.startDate, this.model.endDate )
   }

   calculateStaffUnits(e: Event): void {   
    this.newRow.staffUnits = this.activityService. CalculateUnits( this.newRow.staffStartDt, this.newRow.staffEndDt )?.toString()
   }

  ngOnDestroy(): void {
    this.updateActivitySubscription?.unsubscribe();
  }
}
