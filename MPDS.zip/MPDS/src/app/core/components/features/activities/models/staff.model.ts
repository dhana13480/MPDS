
export interface StaffItem {
  staffName: '';
  staffStartDt: '';
  staffEndDt: '';
  staffUnits: '';
  staffId:'';
  activityId:'';
}
 