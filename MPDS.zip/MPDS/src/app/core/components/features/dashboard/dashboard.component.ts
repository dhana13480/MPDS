import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { UserService } from '../users/services/user.service';
import { MiLoginUserModel } from '../users/models/milogin-user-model';



@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})

export class DashboardComponent implements OnInit, OnDestroy {
  MiLoginCode: string | null = null;
  paramsSubscription: Subscription | undefined;
  MiLoginUser?: MiLoginUserModel | null;
  isLoading = false;
  ServerErrorMessage?: string='';
  constructor(
    private route: ActivatedRoute,
    private userService: UserService,
    private router: Router
  ) {}
  isSessionActive(): boolean {
    return this.userService.isUserAuthenticated();
  }
  ngOnInit(): void {
    this.isLoading = true;
    this.userService.user$.subscribe(user => {
      this.MiLoginUser = user;
      this.isLoading = false;
    })


    this.paramsSubscription = this.route.queryParams.subscribe(params => {
      const codeHeader: string = params['code'];
      if (codeHeader) {
        this.userService.ValidateUser(codeHeader).subscribe(user => {
          this.MiLoginUser = user[0];
          this.userService.setUser(user[0]);
       } 
        )
      } 
      else
      {
        this.userService.ValidateUser(codeHeader).subscribe(user => {
          this.MiLoginUser = user[0];
          this.userService.setUser(user[0]);
        } 
        )
      }
      
       
    });
   /*
    this.paramsSubscription = this.route.queryParams.subscribe(params => {
      const codeHeader: string = params['code'];
      if (codeHeader) {
        this.userService.ValidateUser(codeHeader).subscribe(user => {
          this.MiLoginUser = user[0];
          this.userService.setUser(user[0]);
        })
      } else if (this.MiLoginUser){
        this.router.navigate(['/']);
      } else {
        this.router.navigate(['/login']);
      }
    });
  */
  }

  ngOnDestroy(): void {
    if (this.paramsSubscription) {
      this.paramsSubscription.unsubscribe();
    }
  }
}