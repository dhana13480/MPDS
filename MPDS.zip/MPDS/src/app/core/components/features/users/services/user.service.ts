import { HttpClient, HttpResponse } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, map, tap } from 'rxjs';
import { User } from '../models/user.model';
import { AddUserRequest } from '../models/add-user.model';
import { SearchUserRequest } from '../models/search-user.model';
import { UpdateUserRequest } from '../models/update-user.model';
import { Pagination } from '../../models/pagintation';
import { MiLoginUserModel } from '../models/milogin-user-model'; 
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})

export class UserService {
    private userSubject = new BehaviorSubject<MiLoginUserModel | null>(null);
    user$ = this.userSubject.asObservable();
    totalItems?: number = 0;
    private isAuthenticated = false;
    
    private timeoutHandle: any;
    private timeoutDuration: number = 30 * 60 * 1000; // 30 minutes in milliseconds

    constructor(private http: HttpClient, private router: Router) { } 
    ValidateUser(code: string) {
        return this.http.post<MiLoginUserModel[]>(`${environment.apiBaseUrl}/api/User/GetUserDetailsFromMiLogin/${code}`, {})
    }

    GetAllUsersPaginated(pageNumber?: number, pageSize?: number, searchValues?: SearchUserRequest) {
        const url = `${environment.apiBaseUrl}/api/User/GetAllUsersPaginated?PageNumber=${pageNumber}&PageSize=${pageSize}`;
        return this.http.post<User[]>(url, searchValues, { observe: 'response' }).pipe(
            map((response: HttpResponse<User[]>) => {
                const paginationHeader = response.headers.get('Pagination');
                if (paginationHeader) {
                  const paginationData = JSON.parse(paginationHeader);
                  this.totalItems = paginationData.totalItems;
                }
                return response.body!;
            })
        );
    }

    GetAllUsers(searchValues: SearchUserRequest): Observable<User[]>{
        return this.http.post<User[]>(`${environment.apiBaseUrl}/api/User/GetAllUsers`, searchValues);
    }

    CreateUser(model: AddUserRequest) : Observable<void> {
        return this.http.post<void>(`${environment.apiBaseUrl}/api/User/AddUser`, model);
    }

    UpdateUser(updateUserRequest: UpdateUserRequest): Observable<User>{
    return this.http.put<User>(`${environment.apiBaseUrl}/api/User/EditUser`, updateUserRequest);
    }

    GetUserById(id:string) : Observable<User>{
        return this.http.get<User>(`${environment.apiBaseUrl}/api/User/${id}`);
    }

    DeleteUser(id: string) : Observable<void> {
        return this.http.delete<void>(`${environment.apiBaseUrl}/api/User/${id}`);
    }

    setUser(user: MiLoginUserModel) {
        sessionStorage.setItem('MiLoginUser', JSON.stringify(user));        
        sessionStorage.setItem('MPDSUserId', user.id.toString());        
        sessionStorage.setItem('UserTypeId', user.userTypeId.toString());      
        sessionStorage.setItem('UserEmailId', user.email.toString());        
        sessionStorage.setItem('MPDSUserFirstName', user.firstName.toString());   
        sessionStorage.setItem('MPDSUserLastName', user.lastName.toString());
        sessionStorage.setItem('userCoordinatingAgencyId', user.coordinatingAgencyId?.toString()||'0');   
        sessionStorage.setItem('UserProviderAgencyId', user.providerAgencyId?.toString()|| '0'); 
        sessionStorage.setItem('permissions', user.permissions.toString());
        sessionStorage.setItem('mpdsVersion', user.mpdsVersion?.toString()||'');
           
        //sessionStorage.setItem('MPDSUserEmail', user.email.toString());  
       // sessionStorage.setItem('MPDSUserCoordinatingAgencyId', user.coordinatingAgencyId?.toString());  
        //sessionStorage.setItem('MPDSUserProviderAgencyId', user.providerAgencyId?.toString());  
        this.startSession();
        this.userSubject.next(user);

    }
    startSession() {
        this.isAuthenticated = true;
        this.resetTimeout();
      }
      
    endSession() {
        this.isAuthenticated = false;
        sessionStorage.removeItem('MiLoginUser');
        sessionStorage.removeItem('MPDSUserId');
        sessionStorage.removeItem('UserTypeId');
        sessionStorage.removeItem('UserEmailId');        
        sessionStorage.removeItem('MPDSUserFirstName');   
        sessionStorage.removeItem('MPDSUserLastName');
        sessionStorage.removeItem('userCoordinatingAgencyId');   
        sessionStorage.removeItem('UserProviderAgencyId');
        sessionStorage.removeItem('permissions');
      }

      resetTimeout() {
        // Clear any existing timeout
        if (this.timeoutHandle) {
          clearTimeout(this.timeoutHandle);
        }
    
        // Set the timeout to trigger logout after 30 minutes
        this.timeoutHandle = setTimeout(() => {
          this.logout();
        }, this.timeoutDuration);
      }

      logout() {
        clearTimeout(this.timeoutHandle);
        // Clear user session data, etc.
        console.log('Session expired. Logging out...');
        this.router.navigateByUrl(``);
        window.open('', '_self');  // This tricks the browser into allowing the window close
        window.close();  // Forcefully closes the window/tab
      }
      userActivity() {
        this.resetTimeout();
      }
      
      isUserAuthenticated(): boolean {
        return this.isAuthenticated;
      }
}
