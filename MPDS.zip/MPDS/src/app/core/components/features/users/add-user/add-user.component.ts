import { Component, OnInit } from '@angular/core';
import { Observable, forkJoin } from 'rxjs';
import { PihpregionService } from '../../pihp-regions/services/pihpregion.service';
import { PihpRegion } from '../../pihp-regions/models/pihp-region.model';
import { FuncsService } from '../../services/funcs.service';
import { Router } from '@angular/router';
import { switchMap, catchError, map } from 'rxjs/operators';
import { of } from 'rxjs';
import { ProviderAgency } from '../../provider-agencies/models/provider-agency.model';
import { ProviderAgencyService } from '../../provider-agencies/services/provideragency.service';
import { UserService } from '../services/user.service';
import { AddUserRequest } from '../models/add-user.model';
import { UserRoles } from '../../enums/user-roles.enum';
import { UserPermissions } from '../../enums/user-permissions.enum';
@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})
export class AddUserComponent {
  pihpRegionList$?: Observable<PihpRegion[]>;
  providerAgencyList$?: Observable<ProviderAgency[]>;
  selectedPihpRegionId$?: number;
  selectedProviderAgencyId$?:number;
  ServerErrorMessage?: string='';
  formValue: AddUserRequest = { 
    id: 0,
    firstName: "",
    middleName: "",
    lastName: "",
    password: "",
    isActive: true,
    userTypeId: 0,
    coordinatingAgencyId: 0,
    providerAgencyId: 0,
    permissions: "",
    userName: "",
    email: "",
    phone: "",
    address1: "",
    address2: "",
    city: "",
    stateId: 0,
    zip: "",
    comments: "",
    isPasswordResetRequired: false,
    isDeleted: false,
    hashingAlgorithm: "",
    csvProviderAgencies: "",
    csvCoordinatingAgencies: "",
    createdBy: Number(sessionStorage.getItem("MPDSUserId")),
    updatedBy: Number(sessionStorage.getItem("MPDSUserId")),
  };

  sortConfig = {
    column: '',
    direction: 'asc', // default sorting direction
  };

  constructor(
    private pihpRegionService: PihpregionService,
    private providerAgencyService: ProviderAgencyService,
    private userService: UserService,
    private router: Router,
    private funcs: FuncsService 
  ){}

  ngOnInit():void{
    this.pihpRegionList$ = this.pihpRegionService.GetAllCoordinatingAgencies();
    this.providerAgencyList$ = this.providerAgencyService.GetAllProviderAgencies()
    
  }
    
  onFormSubmit() {
    if(this.formValue.firstName==='')
    {
      this.ServerErrorMessage="Please enter user first name";
    } else
    if(this.formValue.lastName==='')
    {
      this.ServerErrorMessage="Please enter user last name";
    }else
    if(this.formValue.lastName==='')
    {
      this.ServerErrorMessage="Please enter user last name";
    }else
    if(this.formValue.userTypeId === 0)
    {
      this.ServerErrorMessage="Please User Type";
    }else
    if(this.formValue.email==='')
    {
      this.ServerErrorMessage="Please enter user email";
    }else
    if(this.formValue.address1==='')
    {
      this.ServerErrorMessage="Please enter user Address 1";
    }else
    if(this.formValue.city==='')
    {
      this.ServerErrorMessage="Please enter user City";
    }else
    if(this.formValue.zip==='')
    {
      this.ServerErrorMessage="Please enter user Zip";
    }
    else
    if(this.formValue.userTypeId === UserRoles.Coordinating_Agency)
      { 
        if(this.selectedPihpRegionId$ === 0)
          this.ServerErrorMessage="Please select a user PIHP region";
      }
    else
    if(this.formValue.userTypeId === UserRoles.Provider_Agency)
      { if(this.selectedProviderAgencyId$ === 0)
          this.ServerErrorMessage="Please select a user Provider Agency";
      }
    else
     
    if(this.formValue.stateId===0)
    {  
      this.formValue.stateId = 30;
    } else
    {
    console.log(this.formValue)
    this.userService.CreateUser(this.formValue)
    .subscribe({
      next:(response) => {
        console.log(response)
        alert ('User added successfully!')
          this.router.navigateByUrl(`/user-list`);
      }, 
      error: (error) => {
        // Handle error here
        this.ServerErrorMessage = error.error;}
    });
  }}

  updatePermissions() {
    const checkboxes = document.querySelectorAll<HTMLInputElement>('.permissions');
    const selectedOptions = Array.from(checkboxes)
        .filter(checkbox => checkbox.checked)
        .map(checkbox => checkbox.value);
    this.formValue.permissions = selectedOptions.join(',');
  }

  updateRegions() {
    const checkboxes = document.querySelectorAll<HTMLInputElement>('.regions');
    const selectedOptions = Array.from(checkboxes)
        .filter(checkbox => checkbox.checked)
        .map(checkbox => checkbox.id);
    this.formValue.csvCoordinatingAgencies = selectedOptions.join(',');

    // Create an array of Observables for each call to GetProviderAgencyByCoordinatingAgencyId
    const observables = selectedOptions.map(option => this.providerAgencyService.GetProviderAgencyByCoordinatingAgencyId(option));

    // Use forkJoin to wait for all observables to complete and then concatenate the results
    forkJoin(observables).subscribe(providerAgenciesArray => {
      // Concatenate the arrays of provider agencies into a single array
      let combinedProviderAgencies: ProviderAgency[] = [];
      for (const providerAgencies of providerAgenciesArray) {
        combinedProviderAgencies = combinedProviderAgencies.concat(providerAgencies);
      }
      this.providerAgencyList$ = of(combinedProviderAgencies);
    });
  }

  updateAgencies() {
    const checkboxes = document.querySelectorAll<HTMLInputElement>('.agencies');
    const selectedOptions = Array.from(checkboxes)
        .filter(checkbox => checkbox.checked)
        .map(checkbox => checkbox.id);
    this.formValue.csvProviderAgencies = selectedOptions.join(',');
  }

  /*onPihpRegionDropdownClick() {
    this.formValue.providerAgencyId = 0;
  }*/
  onPihpRegionClick(): void {
    this.selectedPihpRegionId$ = this.formValue.coordinatingAgencyId
  }
  onProviderAgencyDropdownClick(): void {  
    this.selectedProviderAgencyId$ = this.formValue.providerAgencyId
  }
}
