export interface User {
  id: number;
  firstName: string;
  middleName: string;
  lastName: string;
  userName: string;
  password: string;
  fullName: string;
  email: string;
  phone: string;
  userTypeId: number;
  coordinatingAgencyId: number;
  coordinatingAgency: string;
  providerAgencyId: number;
  providerAgency: string;
  permissions: string;
  address1: string;
  address2: string;
  city: string;
  stateId: number;
  zip: string;
  comments: string;
  isActive: boolean;
  coordinatingAgencyStatus: boolean;
  paStatus: boolean;
  isPasswordResetRequired: boolean;
  isDeleted: boolean;
  createdBy: number;
  creationDate: string;
  updatedBy: number;
  updationDate: string;
  hashingAlgorithm: string | null;
  csvProviderAgencies: string;
  csvCoordinatingAgencies: string;  
  mpdsEnvironment: string|null;
  mpdsVersion: string|null
}