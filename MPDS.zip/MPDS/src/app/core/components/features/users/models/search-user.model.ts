export interface SearchUserRequest {
    searchByType: number;
    searchByLastName: string;
    searchByUserName: string;
    searchByEmail: string;
    coordinatingAgencyId: number;
    providerAgencyId: number;
  }