export interface AddUserRequest {
  id: number;
  firstName: string;
  middleName: string;
  lastName: string;
  userName: string;
  password: string;
  isActive: boolean;
  userTypeId: number;
  coordinatingAgencyId: number;
  providerAgencyId: number;
  permissions: string;
  email: string;
  phone: string;
  address1: string;
  address2: string;
  city: string;
  stateId: number;
  zip: string;
  comments: string;
  isPasswordResetRequired: boolean;
  isDeleted: boolean;
  hashingAlgorithm: string;
  csvProviderAgencies: string;
  csvCoordinatingAgencies: string;
  createdBy:number;
  updatedBy:number;
}