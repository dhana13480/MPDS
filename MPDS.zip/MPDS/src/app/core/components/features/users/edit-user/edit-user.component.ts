import { Component, OnInit } from '@angular/core';
import { Observable, Subscription, forkJoin } from 'rxjs';
import { PihpregionService } from '../../pihp-regions/services/pihpregion.service';
import { PihpRegion } from '../../pihp-regions/models/pihp-region.model';
import { FuncsService } from '../../services/funcs.service';
import { ActivatedRoute, Router } from '@angular/router';
import { switchMap, catchError, map } from 'rxjs/operators';
import { of } from 'rxjs';
import { ProviderAgency } from '../../provider-agencies/models/provider-agency.model';
import { ProviderAgencyService } from '../../provider-agencies/services/provideragency.service';
import { UserService } from '../services/user.service';
import { UpdateUserRequest } from '../models/update-user.model';
import { UserRoles } from '../../enums/user-roles.enum';
import { UserPermissions } from '../../enums/user-permissions.enum';
@Component({
  selector: 'app-edit-user',
  templateUrl: './edit-user.component.html',
  styleUrls: ['./edit-user.component.css']
})
export class EditUserComponent {
  id: string | null = null;
  pihpRegionList$?: Observable<PihpRegion[]>;
  providerAgencyList$?: Observable<ProviderAgency[]>;
  coordinatingAgencyName?: string;
  providerAgencyName?: string;
  paramsSubscription?: Subscription;
  editUserSubscription?: Subscription;

  formValue: UpdateUserRequest  = { 
    id: 0,
    fullName:"",
    firstName: "",
    middleName: "",
    lastName: "",
    password: "",
    isActive: true,
    userTypeId: 0,
    coordinatingAgencyId: 0,
    providerAgencyId: 0,
    permissions: "",
    userName: "",
    email: "",
    phone: "",
    address1: "",
    address2: "",
    city: "",
    stateId: 0,
    zip: "",
    comments: "",
    isPasswordResetRequired: false,
    isDeleted: false,
    createdBy: 0,
    updatedBy:  Number(sessionStorage.getItem("MPDSUserId")),
    creationDate: "",
    updationDate: "",
    hashingAlgorithm: "",
    csvProviderAgencies: "",
    csvCoordinatingAgencies: ""
  };

  sortConfig = {
    column: '',
    direction: 'asc', // default sorting direction
  };

  constructor(
    private pihpRegionService: PihpregionService,
    private providerAgencyService: ProviderAgencyService,
    private userService: UserService,
    private router: Router,
    private route: ActivatedRoute,
    private funcs: FuncsService 
  ){}

  ngOnInit():void{
    this.pihpRegionList$ = this.pihpRegionService.GetAllCoordinatingAgencies();
    this.paramsSubscription = this.route.paramMap.subscribe({
      next: (params) => {
        this.id = params.get('id');
        if (this.id) {
          this.userService.GetUserById(this.id).subscribe({
            next: (response) => {
              if (response.coordinatingAgencyId !== null) {
                this.pihpRegionService.GetCoordinatingAgencyById(response.coordinatingAgencyId.toString()).forEach(region => {
                  this.coordinatingAgencyName = region.name;
                })
              } else {
                this.coordinatingAgencyName = "N/A"
              }

              if (response.providerAgencyId) {
                this.providerAgencyService.GetProviderAgencyById(response.providerAgencyId.toString()).forEach(agency => {
                  this.providerAgencyName = agency.name;
                })
              } else {
                this.providerAgencyName = "N/A"
              }
  
              // Initialize formValue with the data from Provider Agency
              this.formValue = {
                id: response.id,
                fullName: response.fullName,
                firstName: response.firstName,
                middleName: response.middleName,
                lastName: response.lastName,
                password: response.password,
                isActive: response.isActive,
                userTypeId: response.userTypeId,
                coordinatingAgencyId: response.coordinatingAgencyId,
                providerAgencyId: response.providerAgencyId,
                permissions: response.permissions,
                userName: response.userName,
                email: response.email,
                phone: response.phone,
                address1: response.address1,
                address2: response.address2,
                city: response.city,
                stateId: response.stateId,
                zip: response.zip,
                comments: response.comments,
                isPasswordResetRequired: response.isPasswordResetRequired,
                isDeleted: response.isDeleted,
                createdBy: response.createdBy || 0,
                updatedBy: Number(sessionStorage.getItem("MPDSUserId")) || 0,
                creationDate: response.creationDate,
                updationDate: response.updationDate,
                hashingAlgorithm: response.hashingAlgorithm!,
                csvProviderAgencies: response.csvProviderAgencies,
                csvCoordinatingAgencies: response.csvCoordinatingAgencies
            };
            },
          });
        }
      },
    });

  }
    
  onFormSubmit() {
    console.log(this.formValue)
    this.editUserSubscription =  this.userService.UpdateUser(this.formValue)
    .subscribe({
      next:(response) =>{
        console.log(response)
        this.router.navigateByUrl('/user-list')
      }
    });
    
  }

  onPihpRegionDropdownClick() {
    this.formValue.providerAgencyId = 0;
  }

  onProviderAgencyDropdownClick(): void {
    this.providerAgencyList$ = this.providerAgencyService.GetProviderAgencyByCoordinatingAgencyId(this.formValue.coordinatingAgencyId.toString())
  }

  updatePermissions() {
    const checkboxes = document.querySelectorAll<HTMLInputElement>('.permissions');
    const selectedOptions = Array.from(checkboxes)
        .filter(checkbox => checkbox.checked)
        .map(checkbox => checkbox.value);
    this.formValue.permissions = selectedOptions.join(',');
  }

  updateRegions() {
    const checkboxes = document.querySelectorAll<HTMLInputElement>('.regions');
    const selectedOptions = Array.from(checkboxes)
        .filter(checkbox => checkbox.checked)
        .map(checkbox => checkbox.id);
    this.formValue.csvCoordinatingAgencies = selectedOptions.join(',');

    // Create an array of Observables for each call to GetProviderAgencyByCoordinatingAgencyId
    const observables = selectedOptions.map(option => this.providerAgencyService.GetProviderAgencyByCoordinatingAgencyId(option));

    // Use forkJoin to wait for all observables to complete and then concatenate the results
    forkJoin(observables).subscribe(providerAgenciesArray => {
      // Concatenate the arrays of provider agencies into a single array
      let combinedProviderAgencies: ProviderAgency[] = [];
      for (const providerAgencies of providerAgenciesArray) {
        combinedProviderAgencies = combinedProviderAgencies.concat(providerAgencies);
      }
      this.providerAgencyList$ = of(combinedProviderAgencies);
    });
  }

  updateAgencies() {
    const checkboxes = document.querySelectorAll<HTMLInputElement>('.agencies');
    const selectedOptions = Array.from(checkboxes)
        .filter(checkbox => checkbox.checked)
        .map(checkbox => checkbox.id);
    this.formValue.csvProviderAgencies = selectedOptions.join(',');
  }
}
