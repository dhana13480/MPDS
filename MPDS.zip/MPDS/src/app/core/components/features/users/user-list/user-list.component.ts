import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { GroupService } from '../../groups/services/groups.service';
import { PihpregionService } from '../../pihp-regions/services/pihpregion.service';
import { Group } from '../../groups/models/group.model';
import { PihpRegion } from '../../pihp-regions/models/pihp-region.model';
import { FuncsService } from '../../services/funcs.service';
import { Router } from '@angular/router';
import { switchMap, catchError, map, delay } from 'rxjs/operators';
import { of } from 'rxjs';
import { ProviderAgency } from '../../provider-agencies/models/provider-agency.model';
import { ProviderAgencyService } from '../../provider-agencies/services/provideragency.service';
import { UpdateGroupRequest } from '../../groups/models/update-group-request.model';
import { Program } from '../../pihp-regions/models/program.model';
import { User } from '../models/user.model';
import { UserService } from '../services/user.service';
import { UpdateUserRequest } from '../models/update-user.model';
import { MiLoginUserModel } from '../../users/models/milogin-user-model';
import { UserRoles } from '../../enums/user-roles.enum';
import { UserPermissions } from '../../enums/user-permissions.enum';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css']
})
export class UserListComponent {
  userList$?: Observable<User[]>;
  pihpRegionList$?: Observable<PihpRegion[]>;
  programList$?: Observable<Program[]>;
  providerAgencyList$?: Observable<ProviderAgency[]>;
  phone$?: Observable<FuncsService[]>;
  MiLoginUser?: MiLoginUserModel | null;
  tempUser?: User;
  formSubmitted = false;
  totalItems = 0;
  pageNumber = 1;
  pageSize = 20;
  isLoading = false;
  userCanEdit: boolean = false;
  userCanDelete: boolean = false;
  userTypeId:number=0;
  formValue: {
    searchByType: number;
    searchByLastName: string;
    searchByUserName: string;
    searchByEmail: string;
    coordinatingAgencyId: number;
    providerAgencyId: number;
    userTypeId: number;
  } = { 
    searchByType: 0,
    searchByLastName: "",
    searchByUserName: "",
    searchByEmail: "",
    coordinatingAgencyId: 0,
    providerAgencyId: 0,
    userTypeId:0
  };

  sortConfig = {
    column: '',
    direction: 'asc', // default sorting direction
  };

  constructor(
    private userService: UserService,
    private pihpRegionService: PihpregionService,
    private providerAgencyService: ProviderAgencyService,
    private router: Router,
    private funcs: FuncsService 
  ){}
  isSessionActive(): boolean {
    return this.userService.isUserAuthenticated();
  }
  ngOnInit():void{
    this.userTypeId = Number( sessionStorage.getItem('UserTypeId'));
    this.formValue.userTypeId = this.userTypeId;

    this.userService.user$.subscribe(user => {
      console.log(user)
      this.MiLoginUser = user;   
      this.checkPermissions(user);      
      if(user!.coordinatingAgencyId>0)
        {
          this.formValue.coordinatingAgencyId = user!.coordinatingAgencyId;
        }
        if(user!.providerAgencyId>0)
        {
          this.formValue.providerAgencyId = user!.providerAgencyId;
        }
    });
    this.loadUsers()
    this.pihpRegionList$ = this.pihpRegionService.GetAllCoordinatingAgencies();
  }

  checkPermissions(user: any): void {
    const userTypeId = user.userTypeId;
    const permissions = user.permissions ? user.permissions.split(',') : [];

    //const allowedUserTypes = [3]; 
    //const requiredPermissions = ['1'];

    if (userTypeId == UserRoles.Super_Admin) {
      this.userCanEdit = true;
    } else {
      this.userCanEdit = user.permissions ?.includes(UserPermissions.Manage_Staff);
      //allowedUserTypes.includes(userTypeId) && requiredPermissions.some(permission => permissions.includes(permission));
     
    }

    if (userTypeId == UserRoles.Auditor) {
      this.userCanEdit = false;
    }
  }
  onFormSubmit() {
    this.loadUsers();
  }

  loadUsers() {
    this.isLoading = true;
    this.userService.GetAllUsersPaginated(this.pageNumber, this.pageSize, this.formValue).subscribe(users => {
      this.userList$ = of(users);
      this.totalItems = this.userService.totalItems!;
      this.isLoading = false
    })
  }

  pageChanged(event: any) {
    if (this.pageNumber !== event.page) {
      this.pageNumber = event.page;
      this.userList$ = this.userService.GetAllUsersPaginated(this.pageNumber, this.pageSize, this.formValue);
    }
  }

  onPihpRegionDropdownClick() {
    this.formValue.providerAgencyId = 0;
  }

  onProviderAgencyDropdownClick(): void {
    this.providerAgencyList$ = this.providerAgencyService.GetProviderAgencyByCoordinatingAgencyId(this.formValue.coordinatingAgencyId.toString())
  }

  onStatusChange(user: User) {
    if (user){
      console.log(user)
      user.isActive = !user.isActive;
      
      let updatedUser: UpdateUserRequest = {
        id: user.id,
        firstName: user.firstName,
        middleName: user.middleName || "",
        lastName: user.lastName,
        userName: user.userName,
        password: user.password,
        fullName: user.fullName,
        isActive: user.isActive,
        userTypeId: user.userTypeId,
        coordinatingAgencyId: user.coordinatingAgencyId,
        providerAgencyId: user.providerAgencyId,
        permissions: user.permissions,
        email: user.email,
        phone: user.phone,
        address1: user.address1,
        address2: user.address2,
        city: user.city,
        stateId: user.stateId,
        zip: user.zip,
        comments: user.comments,
        isPasswordResetRequired: user.isPasswordResetRequired,
        isDeleted: user.isDeleted,
        createdBy: user.createdBy || 0,
        updatedBy: user.updatedBy || 0,
        creationDate: user.creationDate,
        updationDate: user.updationDate,
        hashingAlgorithm: user.hashingAlgorithm || "",
        csvProviderAgencies: user.csvProviderAgencies,
        csvCoordinatingAgencies: user.csvCoordinatingAgencies
      } 
      
      this.userService.UpdateUser(updatedUser)
      .subscribe({
        next:(response) =>{
          console.log(response)
        }
      });
    }
  }

  deleteUserRecord(id: string) {
    this.userService.DeleteUser(id)
    .subscribe({
      next:(response) =>{
        console.log(response)
        this.userList$ = this.userList$!.pipe(
          map(users => users.filter(user => user.id.toString() !== id))
        );
        this.router.navigateByUrl('/user-list')
      }
    });
  }

  sort(column: string) {
    if (this.sortConfig.column === column) {
      // If the same column is clicked again, toggle the sort direction
      this.sortConfig.direction = this.sortConfig.direction === 'asc' ? 'desc' : 'asc';
    } else {
      // If a new column is clicked, set it as the active column and default to ascending
      this.sortConfig.column = column;
      this.sortConfig.direction = 'asc';
    }

    // Now, sort the data based on the sort configuration
    this.userList$ = this.userList$?.pipe(
      map((data) => this.sortData(data))
    );
  }

  private sortData(data: User[]): User[] {
    const { column, direction } = this.sortConfig;

    if (!column) {
      return data;
    }

    return data.slice().sort((a, b) => {
      const aValue = this.getPropertyValue(a, column);
      const bValue = this.getPropertyValue(b, column);

      
    // For boolean values, explicitly cast to numbers before performing subtraction
    if (typeof aValue === 'boolean') {
      return direction === 'asc' ? (aValue as unknown as number) - (bValue as number) : (bValue as number) - (aValue as unknown as number);
    }


      if (typeof aValue === 'string') {
        return direction === 'asc' ? aValue.localeCompare(bValue) : bValue.localeCompare(aValue);
      } else if (typeof aValue === 'number') {
        return direction === 'asc' ? aValue - bValue : bValue - aValue;
      } else {
        return 0; // Add more cases as needed for other data types
      }
    });
  }

  private getPropertyValue(object: any, column: string): any {
    // Customize this part based on your data structure
    switch (column) {
      case 'firstName':
        return object.firstName;
      case 'lastName':
        return object.lastName;
      case 'userName':
        return object.userName;
      case 'email':
        return object.email;
      case 'officePhone':
        return object.officePhone;
      case 'userType':
        return object.userType;
      case 'status':
        return object.status;
      default:
        return null;
    }
  }
}
