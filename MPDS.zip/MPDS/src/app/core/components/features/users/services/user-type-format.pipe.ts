import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'userTypeFormat'
})
export class UserTypeFormatPipe implements PipeTransform {

  transform(number:any) {
    switch (number) {
        case 1:
          return 'Admin';
        case 2:
          return 'Super Admin';
        case 3:
          return 'Coordinating Agency';
        case 4:
          return 'Provider Agency';
        default:
          return 'Unknown';
      }
  }     
}
