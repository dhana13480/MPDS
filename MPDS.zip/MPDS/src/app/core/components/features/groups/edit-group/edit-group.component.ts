import { Component, Directive, OnDestroy } from '@angular/core';
import { Observable, Subscription } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';
import { AddGroupRequest } from '../models/add-group-request.model';
import { GroupService } from '../services/groups.service';
import { PihpRegion } from '../../pihp-regions/models/pihp-region.model';
import { PihpregionService } from '../../pihp-regions/services/pihpregion.service';
import { Program } from '../../pihp-regions/models/program.model';
import { ProviderAgency } from '../../provider-agencies/models/provider-agency.model';
import { ProviderAgencyService } from '../../provider-agencies/services/provideragency.service';
import { Group } from '../models/group.model';
import { StateService } from '../../services/states.service';
import { State } from '../../models/states.model';
import { UpdateGroupRequest } from '../models/update-group-request.model';
import { MasterIntendedPopulation } from '../../models/optional-data/master-intended-population.model';
import { MasterServiceDomain } from '../../models/optional-data/master-service-domain.model';
import { MasterServiceSetting } from '../../models/optional-data/master-service-setting.model';
import { OptionalDataService } from '../../services/optional-data.service';

@Component({
  selector: 'app-edit-group',
  templateUrl: './edit-group.component.html',
  styleUrls: ['./edit-group.component.css']
})
export class EditGroupComponent {
  coordinatingAgencyName$?: string;
  providerAgencyName$?: string;
  id: string | null = null;
  model: UpdateGroupRequest;
  groupList$?: Observable<Group[]>;
  group?: Group;
  pihpRegionList$?: Observable<PihpRegion[]>;
  selectedPihpRegionId$?: number;
  programList$?: Observable<Program[]>;
  providerAgencyList$?: Observable<ProviderAgency[]>;
  stateList$?: Observable<State[]>;
  intendedPopulationList$?: Observable<MasterIntendedPopulation[]>;
  serviceDomainList$?: Observable<MasterServiceDomain[]>;
  serviceSettingList$?: Observable<MasterServiceSetting[]>;
  paramsSubscription?: Subscription;
  editGroupSubscription?: Subscription;
  ServerErrorMessage?: string='';

  constructor(
    private pihpRegionService: PihpregionService,
    private providerAgencyService: ProviderAgencyService,
    private groupService: GroupService, 
    private stateService: StateService,
    private optionalDataService: OptionalDataService,
    private router:Router,
    private route: ActivatedRoute
  ) {
    this.model = {
      id: 0,
      name: "",
      isActive: true,
      groupType: 0,
      programType: 0,
      strGroupType: "",
      strProgramType: "",
      providerAgencyStatus: true,
      coordinatingAgencyStatus: true,
      activityCount: 0,
      programName: "",
      row_Numb: 0,
      coordinatingAgencyId: 0,
      providerAgencyId: 0,
      programNameId: 0,
      isYATRelated: false,
      isGamblingRelated: false,
      minActivityCount: 1,
      maxActivityCount: 0,
      interventionType: 0,
      serviceDomain: 0,
      serviceLocation: 0,
      ebpServiceType: 0,
      comments: "",
      groupOptionalDataId: 0,
      isDeleted: true,
      createdBy: 0,
      updatedBy: 0,
      otherProgramName: ""
      // optionalData: {
      //   serviceDomain: {
      //     id:0,
      //     code: "",
      //     serviceDomain: "",
      //     description: ""
      //   },
      //   serviceSetting: {
      //     id:0,
      //     code: "",
      //     serviceSetting: "",
      //     description: ""
      //   },
      //   intendedPopulation: {
      //     id:0,
      //     code: "",
      //     intendedPopulation: "",
      //     description: ""
      //   }
      // }
    }
  }

  ngOnInit():void{
    this.stateList$ = this.stateService.GetAllStates();
    this.intendedPopulationList$ = this.optionalDataService.GetMasterIntendedPopulation();
    this.serviceDomainList$ = this.optionalDataService.GetMasterServiceDomain();
    this.serviceSettingList$ = this.optionalDataService.GetMasterServiceSetting();
    this.paramsSubscription = this.route.paramMap.subscribe({
      next: (params) => {
        this.id = params.get('id');
        if (this.id) {
          this.groupService.GetGroupById(this.id).subscribe({
            next: (response) => {
              const coordinatingAgency = this.pihpRegionService.GetCoordinatingAgencyById(response.coordinatingAgencyId.toString());
              coordinatingAgency.forEach(region => {
                this.coordinatingAgencyName$ = region.name
              })

              const providerAgency = this.providerAgencyService.GetProviderAgencyById(response.providerAgencyId.toString());
              providerAgency.forEach(agency => {
                this.providerAgencyName$ = agency.name
              })

              this.group = response;
              console.log(this.group)
              // Initialize formValue with the data from Provider Agency
              this.model = {
                id: this.group.id || 0,
                name: this.group.name || "",
                isActive: this.group.isActive || true,
                groupType: this.group.groupType || 0,
                programType: this.group.programType || 0,
                strGroupType: this.group.strGroupType || "",
                strProgramType: this.group.strProgramType || "",
                providerAgencyStatus: this.group.providerAgencyStatus || true,
                coordinatingAgencyStatus: this.group.coordinatingAgencyStatus || true,
                activityCount: this.group.activityCount || 0,
                programName: this.group.programName || "",
                row_Numb: this.group.row_Numb || 0,
                coordinatingAgencyId: this.group.coordinatingAgencyId || 0,
                providerAgencyId: this.group.providerAgencyId || 0,
                programNameId: this.group.programNameId || 0,
                isYATRelated: this.group.isYATRelated || false,
                isGamblingRelated: this.group.isGamblingRelated || false,
                minActivityCount: this.group.minActivityCount || 1,
                maxActivityCount: this.group.maxActivityCount || 0,
                interventionType: this.group.interventionType || 0,
                serviceDomain: 0,
                serviceLocation: this.group.serviceLocation || 0,
                ebpServiceType: this.group.ebpServiceType || 0,
                comments: this.group.comments || "",
                groupOptionalDataId: this.group.groupOptionalDataId || 0,
                isDeleted: this.group.isDeleted || true,
                createdBy: this.group.createdBy || 0,
                updatedBy: this.group.updatedBy || 0,
                otherProgramName: this.group.otherProgramName || ""
                // optionalData: {
                //   serviceDomain: {
                //     id: this.group.optionalData.serviceDomain.id || 0,
                //     code: this.group.optionalData.serviceDomain.code || "",
                //     serviceDomain: this.group.optionalData.serviceDomain.serviceDomain || "",
                //     description: this.group.optionalData.serviceDomain.description || ""
                //   },
                //   serviceSetting: {
                //     id: this.group.optionalData.serviceSetting.id || 0,
                //     code: this.group.optionalData.serviceSetting.code || "",
                //     serviceSetting: this.group.optionalData.serviceSetting.serviceSetting || "",
                //     description: this.group.optionalData.serviceSetting.description || ""
                //   },
                //   intendedPopulation: {
                //     id: this.group.optionalData.intendedPopulation.id || 0,
                //     code: this.group.optionalData.intendedPopulation.code || "",
                //     intendedPopulation: this.group.optionalData.intendedPopulation.intendedPopulation || "",
                //     description: this.group.optionalData.intendedPopulation.description || ""
                //   }
                // }
              };
            },
          });
        }
      },
    });
  }




  onFormSubmit(){
    const updateGroupRequest: UpdateGroupRequest = {
      id: this.model?.id ?? 0,
      name: this.model?.name ?? "",
      isActive: this.model?.isActive ?? true,
      groupType: this.model?.groupType ?? 0,
      programType: this.model?.programType ?? 0,
      strGroupType: this.model?.strGroupType ?? "",
      strProgramType: this.model?.strProgramType ?? "",
      providerAgencyStatus: this.model?.providerAgencyStatus ?? true,
      coordinatingAgencyStatus: this.model?.coordinatingAgencyStatus ?? true,
      activityCount: this.model?.activityCount ?? 0,
      programName: this.model?.programName ?? "",
      row_Numb: this.model?.row_Numb ?? 0,
      coordinatingAgencyId: this.model?.coordinatingAgencyId ?? 0,
      providerAgencyId: this.model?.providerAgencyId ?? 0,
      programNameId: this.model?.programNameId ?? 0,
      isYATRelated: this.model?.isYATRelated ?? false,
      isGamblingRelated: this.model?.isGamblingRelated ?? false,
      minActivityCount: this.model?.minActivityCount ?? 1,
      maxActivityCount: this.model?.maxActivityCount ?? 0,
      interventionType: this.model?.interventionType ?? 0,
      serviceDomain: 0,
      serviceLocation: this.model?.serviceLocation ?? 0,
      ebpServiceType: this.model?.ebpServiceType ?? 0,
      comments: this.model?.comments ?? "",
      groupOptionalDataId: this.model?.groupOptionalDataId ?? 0,
      isDeleted: this.model?.isDeleted ?? true,
      createdBy: this.model?.createdBy ?? 0,
      updatedBy: Number(sessionStorage.getItem("MPDSUserId")) ?? 0,
      otherProgramName: this.model?.otherProgramName ?? "",
      // optionalData: {
      //   serviceDomain: {
      //     id: this.model?.optionalData?.serviceDomain?.id ?? 0,
      //     code: this.model?.optionalData?.serviceDomain?.code ?? "",
      //     serviceDomain: this.model?.optionalData?.serviceDomain?.serviceDomain ?? "",
      //     description: this.model?.optionalData?.serviceDomain?.description ?? ""
      //   },
      //   serviceSetting: {
      //     id: this.model?.optionalData?.serviceSetting?.id ?? 0,
      //     code: this.model?.optionalData?.serviceSetting?.code ?? "",
      //     serviceSetting: this.model?.optionalData?.serviceSetting?.serviceSetting ?? "",
      //     description: this.model?.optionalData?.serviceSetting?.description ?? ""
      //   },
      //   intendedPopulation: {
      //     id: this.model?.optionalData?.intendedPopulation?.id ?? 0,
      //     code: this.model?.optionalData?.intendedPopulation?.code ?? "",
      //     intendedPopulation: this.model?.optionalData?.intendedPopulation?.intendedPopulation ?? "",
      //     description: this.model?.optionalData?.intendedPopulation?.description ?? ""
      //   }
      // }
    };
  
    if(this.id){
      console.log(updateGroupRequest)
      this.editGroupSubscription =  this.groupService.UpdateGroup(updateGroupRequest.id.toString(), updateGroupRequest)
      .subscribe({
        next:(response) =>{
          console.log("group updated successfully")
          alert("Group updated successfully");
          this.router.navigateByUrl('/groups')
        },
        error: (error) => {
          // Handle error here
          this.ServerErrorMessage = error.error;
        }
      });
    }
  }

  onPihpRegionClick(): void {
    console.log(this.model.coordinatingAgencyId)
    this.selectedPihpRegionId$ = this.model.coordinatingAgencyId
  }

  onProviderAgencyDropdownClick(): void {
    this.providerAgencyList$ = this.providerAgencyService.GetProviderAgencyByCoordinatingAgencyId(this.model.coordinatingAgencyId.toString())
  }

  onProgramNameDropdownClick(): void {
    this.programList$ = this.pihpRegionService.GetProgramNamesByCoordinatingAgencyId(this.model.coordinatingAgencyId.toString())
  }

  ngOnDestroy(): void {
    this.paramsSubscription?.unsubscribe();
  }
}
