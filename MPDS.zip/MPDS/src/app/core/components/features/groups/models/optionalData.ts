import { MasterIntendedPopulation } from "../../models/optional-data/master-intended-population.model";
import { MasterServiceDomain } from "../../models/optional-data/master-service-domain.model";
import { MasterServiceSetting } from "../../models/optional-data/master-service-setting.model";

export interface optionalData {
    serviceDomain: MasterServiceDomain;
    serviceSetting: MasterServiceSetting;
    intendedPopulation: MasterIntendedPopulation;
}