import { Component, Directive, OnDestroy } from '@angular/core';
import { Observable, Subscription } from 'rxjs';
import { Router } from '@angular/router';
import { AddGroupRequest } from '../models/add-group-request.model';
import { GroupService } from '../services/groups.service';
import { PihpRegion } from '../../pihp-regions/models/pihp-region.model';
import { PihpregionService } from '../../pihp-regions/services/pihpregion.service';
import { Program } from '../../pihp-regions/models/program.model';
import { ProviderAgency } from '../../provider-agencies/models/provider-agency.model';
import { ProviderAgencyService } from '../../provider-agencies/services/provideragency.service';
import { Group } from '../models/group.model';
import { OptionalDataService } from '../../services/optional-data.service';
import { MasterIntendedPopulation } from '../../models/optional-data/master-intended-population.model';
import { MasterServiceDomain } from '../../models/optional-data/master-service-domain.model';
import { MasterServiceSetting } from '../../models/optional-data/master-service-setting.model';

@Component({
  selector: 'app-add-group',
  templateUrl: './add-group.component.html',
  styleUrls: ['./add-group.component.css']
})
export class AddGroupComponent implements OnDestroy {
  model: AddGroupRequest;
  groupList$?: Observable<Group[]>;
  pihpRegionList$?: Observable<PihpRegion[]>;
  programList$?: Observable<Program[]>;
  providerAgencyList$?: Observable<ProviderAgency[]>;
  intendedPopulationList$?: Observable<MasterIntendedPopulation[]>;
  serviceDomainList$?: Observable<MasterServiceDomain[]>;
  serviceSettingList$?: Observable<MasterServiceSetting[]>;
  selectedPihpRegionId$?: number;
  selectedProviderAgencyId$?: number;
  ServerErrorMessage?: string='';
  selectedRegionObj?: PihpRegion
  isServiceDomainRegion?: boolean;
  private addGroupSubscription? : Subscription;
  //state$?: Observable<StatesComponent[]>;

  constructor(
    private pihpRegionService: PihpregionService,
    private providerAgencyService: ProviderAgencyService,
    private groupService: GroupService, 
    private optionalDataService: OptionalDataService,
    private router:Router
  ) {
    this.model= {
      id: 0,
      name: "",
      isActive: true,
      groupType: 0,
      programType: 0,
      strGroupType: "",
      strProgramType: "",
      providerAgencyStatus: true,
      coordinatingAgencyStatus: true,
      activityCount: 0,
      programName: "",
      row_Numb: 0,
      coordinatingAgencyId: 0,
      providerAgencyId: 0,
      programNameId: 0,
      isYATRelated: false,
      isGamblingRelated: false,
      minActivityCount: 1,
      maxActivityCount: 0,
      interventionType: 0,
      serviceLocation: 0,
      ebpServiceType: 0,
      comments: "",
      groupOptionalDataId: 0,
      isDeleted: false,
      createdBy:    Number(sessionStorage.getItem("MPDSUserId")),
      updatedBy:    Number(sessionStorage.getItem("MPDSUserId")),
      otherProgramName: "",
      optionalData: {
        serviceDomain: {
          id:0,
          code: "",
          serviceDomain: "",
          description: ""
        },
        serviceSetting: {
          id:0,
          code: "",
          serviceSetting: "",
          description: ""
        },
        intendedPopulation: {
          id:0,
          code: "",
          intendedPopulation: "",
          description: ""
        }
      }
    }
  }

  ngOnInit():void{
    this.pihpRegionList$ = this.pihpRegionService.GetAllCoordinatingAgencies();
    this.intendedPopulationList$ = this.optionalDataService.GetMasterIntendedPopulation();
    this.serviceDomainList$ = this.optionalDataService.GetMasterServiceDomain();
    this.serviceSettingList$ = this.optionalDataService.GetMasterServiceSetting();

    sessionStorage.removeItem('GroupCAId');
    sessionStorage.removeItem('GroupPAId');
    sessionStorage.removeItem('GroupGrpId');
    sessionStorage.removeItem('GroupProgramNameId');
  }


  onFormSubmit(){
    let i = 0;
    this.providerAgencyList$?.forEach(agency => {
      this.model.providerAgencyId = agency[i].id
      i++
    })
    //console.log(this.model);  
    if (this.model.groupType === 1)
    {
     this.model.maxActivityCount=1;
    }
    sessionStorage.setItem('GroupCAId', this.model.coordinatingAgencyId.toString());
    sessionStorage.setItem('GroupPAId', this.model.providerAgencyId.toString());
    //sessionStorage.setItem('GroupGrpId', Number(response).toString() );
    sessionStorage.setItem('GroupProgramNameId', this.model.programNameId.toString());
     this.addGroupSubscription = this.groupService.CreateGroup(this.model)
     .subscribe({
       next:(response) =>{
          // console.log('Group Add successful');
           alert("Group created successfully");
           //this.router.navigateByUrl('/groups');
          // this.router.navigateByUrl('Activityadd',this.model.coordinatingAgencyId, this.model.providerAgencyId, this.model.id, this.mode);
          //sessionStorage.setItem('GroupCAId', this.model.coordinatingAgencyId.toString());
          //sessionStorage.setItem('GroupPAId', this.model.providerAgencyId.toString());
          sessionStorage.setItem('GroupGrpId', Number(response).toString() );
          //sessionStorage.setItem('GroupProgramNameId', this.model.programNameId.toString());
          this.router.navigate(['activities/add'], { queryParams: { GroupCAId: this.model.coordinatingAgencyId, GroupPAId: this.model.providerAgencyId, GroupGrpId: response, GroupProgramNameId: this.model.programNameId } });
       }, 
       error: (error) => {
        // Handle error here
        this.ServerErrorMessage = error.error;
        this.model.coordinatingAgencyId =  Number(sessionStorage.getItem('GroupCAId'));
        this.model.providerAgencyId =  Number(sessionStorage.getItem('GroupPAId'));
        //this.model.coordinatingAgencyId =  Number(sessionStorage.getItem('GroupGrpId'));
        this.model.programNameId =  Number(sessionStorage.getItem('GroupProgramNameId')); 
      }
     });
  }
  onChangeGroupType(event: Event) {
    const target = event.target as HTMLSelectElement;
    // console.log('Selected value:', this.selectedValue);
     console.log('Selected text:', target.options[target.selectedIndex].text);
     if (target.options[target.selectedIndex].text === 'OneTime')
     {
      this.model.maxActivityCount=1;
     }
  }
  onPihpRegionClick(): void {
    console.log(this.model.coordinatingAgencyId)
    if (this.model.coordinatingAgencyId !== 0 ) {
      this.pihpRegionService.GetCoordinatingAgencyById(this.model.coordinatingAgencyId.toString()).forEach(region => {
        console.log(region)
        this.selectedPihpRegionId$ = region.id
        this.selectedRegionObj = region
         if (region.optionalData) {
           const optionalDataArray = region.optionalData.split(','); // Split the CSV string into an array
           if (optionalDataArray.includes('serviceDomain')) {
             this.isServiceDomainRegion = true;
           } else {
             console.log('serviceDomain not found in optionalData');
           }
         }
      })
    }
  }

 
  onProviderAgencyDropdownClick(): void {
    this.providerAgencyList$ = this.providerAgencyService.GetProviderAgencyByCoordinatingAgencyId(this.model.coordinatingAgencyId.toString())
  }
  onProgramNameDropdownClick(): void {
    //this.programList$ = this.pihpRegionService.GetProgramNamesByCoordinatingAgencyId(this.model.coordinatingAgencyId.toString())
    this.programList$=this.pihpRegionService.GetProgramNames()
  }

  ngOnDestroy(): void {
    this.addGroupSubscription?.unsubscribe();
  }
}
