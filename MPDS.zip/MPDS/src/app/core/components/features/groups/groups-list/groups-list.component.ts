import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { GroupService } from '../services/groups.service';
import { PihpregionService } from '../../pihp-regions/services/pihpregion.service';
import { Group } from '../models/group.model';
import { PihpRegion } from '../../pihp-regions/models/pihp-region.model';
import { FuncsService } from '../../services/funcs.service';
import { Router } from '@angular/router';
import { switchMap, catchError, map, delay, tap } from 'rxjs/operators';
import { of } from 'rxjs';
import { ProviderAgency } from '../../provider-agencies/models/provider-agency.model';
import { ProviderAgencyService } from '../../provider-agencies/services/provideragency.service';
import { UpdateGroupRequest } from '../models/update-group-request.model';
import { Program } from '../../pihp-regions/models/program.model';
import { MiLoginUserModel } from '../../users/models/milogin-user-model';
import { UserService } from '../../users/services/user.service';
import { UserRoles } from '../../enums/user-roles.enum';
import { UserPermissions } from '../../enums/user-permissions.enum';

@Component({
  selector: 'app-groups-list',
  templateUrl: './groups-list.component.html',
  styleUrls: ['./groups-list.component.css']
})
export class GroupsListComponent {
  groupList$?: Observable<Group[]>;
  pihpRegionList$?: Observable<PihpRegion[]>;
  programList$?: Observable<Program[]>;
  providerAgencyList$?: Observable<ProviderAgency[]>;
  phone$?: Observable<FuncsService[]>;
  MiLoginUser?: MiLoginUserModel | null;
  userCanEdit: boolean = false;
  userCanDelete: boolean = false;
  formSubmitted = false;
  totalItems = 0;
  pageNumber = 1;
  pageSize = 20;
  isLoading = false;

  formValue: { 
    coordinatingAgencyId: number, 
    groupName:string, 
    providerAgencyId:number, 
    status: string,
    programNameId: number
  } = { 
    coordinatingAgencyId: 2, 
    groupName:'', 
    providerAgencyId:0, 
    status: 'All',
    programNameId: 0
  };

  sortConfig = {
    column: '',
    direction: 'asc', // default sorting direction
  };

  constructor(
    private groupService: GroupService,
    private pihpRegionService: PihpregionService,
    private providerAgencyService: ProviderAgencyService,
    private router: Router,
    private userService: UserService,
    private funcs: FuncsService 
  ){}

  ngOnInit():void{
    this.userService.user$.pipe(
      tap(user => {
        console.log(user)
        this.MiLoginUser = user;
        this.checkPermissions(user);
        if (user!.userTypeId !== UserRoles.Super_Admin) {
          this.formValue = { 
            coordinatingAgencyId: user!.coordinatingAgencyId||0, 
            groupName: '', 
            providerAgencyId: user!.providerAgencyId||0, 
            status: 'All',
            programNameId: 0
          };
        }
      }),
      switchMap(user => 
        this.pihpRegionService.GetAllCoordinatingAgencies().pipe(
          map(agencies => 
            user!.userTypeId === UserRoles.Super_Admin 
            ? 
            agencies 
            : agencies.filter(agency => agency.id === user!.coordinatingAgencyId)
          )
        )
      )
    ).subscribe(filteredAgencies => {
      this.pihpRegionList$ = of(filteredAgencies);
      this.loadGroups();
    });
  }
    
  deleteItem(item: number, name: string) {
    if (confirm('Are you sure you want to delete the group: ' + name +'? This will also delete all the activities linked to this group.')) {
     
      this.groupService.DeleteGroup(item.toString())
      .subscribe({
        next:(response) =>{
          this.loadGroups();
        }
      });
    }
  }
  onFormSubmit() {
    this.loadGroups();
  }

  loadGroups() {
    this.isLoading = true
    console.log(this.formValue)
    this.groupService.GetAllGroupsPaginated(this.pageNumber, this.pageSize, this.formValue).subscribe(groups => {
      this.groupList$ = of(groups);
      this.totalItems = this.groupService.totalItems!;
      this.isLoading = false
    })
  }

  checkPermissions(user: any): void {
    const userTypeId = user.userTypeId;
    const permissions = user.permissions ? user.permissions.split(',') : [];
 
    if ((userTypeId == UserRoles.Super_Admin)||(userTypeId == UserRoles.Coordinating_Agency)||(userTypeId == UserRoles.Provider_Agency))  {
      this.userCanEdit = true;
    } else {
      //this.userCanEdit = allowedUserTypes.includes(userTypeId) && requiredPermissions.every(permission => permissions.includes(UserPermissions.Manage_Coordinating_Agency));     
      this.userCanEdit = permissions.includes(UserPermissions.Manage_Group);
    }
    if (userTypeId == UserRoles.Super_Admin)  {
      this.userCanDelete = true;
    } else {
      //this.userCanEdit = allowedUserTypes.includes(userTypeId) && requiredPermissions.every(permission => permissions.includes(UserPermissions.Manage_Coordinating_Agency));     
      this.userCanDelete = permissions.includes(UserPermissions.Delete_Group);
    }
    

  }

  pageChanged(event: any) {
    if (this.pageNumber !== event.page) {
      this.pageNumber = event.page;
      this.groupList$ = this.groupService.GetAllGroupsPaginated(this.pageNumber, this.pageSize, this.formValue);
    }
  }

  onPihpRegionDropdownClick() {
    this.formValue.providerAgencyId = 0;
  }

  onProviderAgencyDropdownClick(): void {
    this.providerAgencyService.GetProviderAgencyByCoordinatingAgencyId(this.formValue.coordinatingAgencyId.toString()).pipe(
      map(agencies => {
        return this.MiLoginUser!.userTypeId === UserRoles.Super_Admin 
          ? agencies 
          : agencies.filter((agency: ProviderAgency) => agency.id === this.MiLoginUser!.providerAgencyId);
      })
    ).subscribe(filteredAgencies => {
      this.providerAgencyList$ = of(filteredAgencies);
      //this.loadGroups();
    });
  }

  onProgramNameDropdownClick(): void {
    this.programList$ = this.pihpRegionService.GetProgramNamesByCoordinatingAgencyId(this.formValue.coordinatingAgencyId.toString())
  }

  deactivateRecord(group: UpdateGroupRequest) {
    if (group){
      group.isActive = false;
      console.log(group)
      this.groupService.UpdateGroup(group.id.toString(), group)
      .subscribe({
        next:(response) =>{
          this.loadGroups();
        }
      });
    }
  }

  sort(column: string) {
    if (this.sortConfig.column === column) {
      // If the same column is clicked again, toggle the sort direction
      this.sortConfig.direction = this.sortConfig.direction === 'asc' ? 'desc' : 'asc';
    } else {
      // If a new column is clicked, set it as the active column and default to ascending
      this.sortConfig.column = column;
      this.sortConfig.direction = 'asc';
    }

    // Now, sort the data based on the sort configuration
    this.groupList$ = this.groupList$?.pipe(
      map((data) => this.sortData(data))
    );
  }

  private sortData(data: Group[]): Group[] {
    const { column, direction } = this.sortConfig;

    if (!column) {
      return data;
    }

    return data.slice().sort((a, b) => {
      const aValue = this.getPropertyValue(a, column);
      const bValue = this.getPropertyValue(b, column);

      
    // For boolean values, explicitly cast to numbers before performing subtraction
    if (typeof aValue === 'boolean') {
      return direction === 'asc' ? (aValue as unknown as number) - (bValue as number) : (bValue as number) - (aValue as unknown as number);
    }


      if (typeof aValue === 'string') {
        return direction === 'asc' ? aValue.localeCompare(bValue) : bValue.localeCompare(aValue);
      } else if (typeof aValue === 'number') {
        return direction === 'asc' ? aValue - bValue : bValue - aValue;
      } else {
        return 0; // Add more cases as needed for other data types
      }
    });
  }

  private getPropertyValue(object: any, column: string): any {
    // Customize this part based on your data structure
    switch (column) {
      case 'name':
        return object.name;
      case 'programName':
        return object.programName;
      case 'officePhone':
        return object.officePhone;
      case 'isActive':
        return object.isActive;
      case 'activityCount':
        return object.activityCount;
      case 'programType':
        return object.programType;
      case 'groupType':
        return object.groupType;
      default:
        return null;
    }
  }
}
