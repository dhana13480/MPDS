import { HttpClient, HttpResponse } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Injectable } from '@angular/core';
import { Observable, map } from 'rxjs'; 
import { Group } from '../models/group.model';
import { AddGroupRequest} from '../models/add-group-request.model';
import { UpdateGroupRequest } from '../models/update-group-request.model';
import { UserService } from '../../users/services/user.service';
 
 
@Injectable({
  providedIn: 'root'
})
export class GroupService {
  storedUserStringified = sessionStorage.getItem('MiLoginUser')!;
 

    totalItems?: number = 0;
    UserPermissionInfo?: {
      userTypeId: number | null,
      coordinatingAgencyId: number | null,
      providerAgencyId: number | null,
      permissions: string | null
    }

    constructor(private http: HttpClient, private userService: UserService) {
        this.userService.user$.subscribe(user => {
          if (user) {
            this.UserPermissionInfo = {
              userTypeId: user.userTypeId,
              coordinatingAgencyId: user.coordinatingAgencyId,
              providerAgencyId: user.providerAgencyId,
              permissions: user.permissions
            }
          }  
        })
     }

    GetAllGroupsPaginated(pageNumber?: number, pageSize?: number, searchValues?: object) {
        const url = `${environment.apiBaseUrl}/api/ActivityGroup/GetAllGroupsPaginated?PageNumber=${pageNumber}&PageSize=${pageSize}`;

        const fullSearchValues = {
          ...searchValues,
          userTypeId: this.UserPermissionInfo!.userTypeId||0,
          userCoordinatingAgencyId: this.UserPermissionInfo!.coordinatingAgencyId||0,
          userProviderAgencyId: this.UserPermissionInfo!.providerAgencyId||0,
          permissions: this.UserPermissionInfo!.permissions
        };
        console.log(fullSearchValues)
        return this.http.post<Group[]>(url, fullSearchValues, { observe: 'response' }).pipe(
            map((response: HttpResponse<Group[]>) => {
                const paginationHeader = response.headers.get('Pagination');
                if (paginationHeader) {
                  const paginationData = JSON.parse(paginationHeader);
                  this.totalItems = paginationData.totalItems;
                }
                return response.body!;
            })
        );
    }

    GetGroupById(id:string): Observable<Group>{
        return this.http.get<Group>(`${environment.apiBaseUrl}/api/ActivityGroup/${id}`);
    }

    GetGroupsByPihpRegion(id:number): Observable<Group[]>{
        return this.http.get<Group[]>(`${environment.apiBaseUrl}/api/ActivityGroup/coordinatingagency/${id}`);
    }

    GetGroupsByProviderAgency(cid:number, pid:number): Observable<Group[]>{
        return this.http.get<Group[]>(`${environment.apiBaseUrl}/api/ActivityGroup/coordinatingagency/${cid}/provideragency/${pid}`);
    }

    // GetGroupByProgramName(id:string): Observable<PihpRegion>{
    //     return this.http.get<PihpRegion>(`${environment.apiBaseUrl}/api/CoordinatingAgencies/${id}`);
    // }

    CreateGroup(model: AddGroupRequest) : Observable<void> {    
        return this.http.post<void>(`${environment.apiBaseUrl}/api/ActivityGroup/AddGroup`, model);
    } 

    DeleteGroup(id:string): Observable<Group[]>{
      return this.http.post<Group[]>(`${environment.apiBaseUrl}/api/ActivityGroup/DeleteGroupAndActivity/${id}`, id);
    }

    UpdateGroup(id:string, updateGroupRequest:UpdateGroupRequest): Observable<Group>{
    return this.http.put<Group>(`${environment.apiBaseUrl}/api/ActivityGroup/${id}`, updateGroupRequest);
    }
  
}