import { optionalData } from "./optionalData";

export interface UpdateGroupRequest {
    id: number;
    name: string;
    isActive: boolean;
    groupType: number;
    programType: number;
    strGroupType: string;
    strProgramType: string;
    providerAgencyStatus: boolean;
    coordinatingAgencyStatus: boolean;
    activityCount: number;
    programName: string;
    row_Numb: number;
    coordinatingAgencyId: number;
    providerAgencyId: number;
    programNameId: number;
    isYATRelated: boolean;
    isGamblingRelated: boolean;
    minActivityCount: number;
    maxActivityCount: number;
    interventionType: number;
    serviceDomain: number;
    serviceLocation: number;
    ebpServiceType: number;
    comments: string;
    groupOptionalDataId: number;
    isDeleted: boolean;
    createdBy: number;
    updatedBy: number;
    otherProgramName: string;
    //optionalData: optionalData;
}