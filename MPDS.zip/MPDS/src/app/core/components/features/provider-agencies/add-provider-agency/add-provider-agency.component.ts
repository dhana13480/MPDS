import { Component, Directive, ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { Observable, Subscription } from 'rxjs';
import { Router } from '@angular/router';
import { DatePipe } from '@angular/common';
import { AddRegionStaffRequest } from '../..//staff/models/add-region-staff.model';
import { StaffService } from '../../staff/services/staff.service';
import { PihpRegion } from '../../pihp-regions/models/pihp-region.model';
import { PihpregionService } from '../../pihp-regions/services/pihpregion.service';
import { State } from '../../models/states.model';
import { StateService } from '../../services/states.service';
import { ProviderAgency } from '../models/provider-agency.model';
import { ProviderAgencyService } from '../services/provideragency.service';
import { AddProviderAgencyRequest } from '../models/add-provider-agency.model';
import { CountyService } from '../../services/counties.service';
import { SchoolDistrictService } from '../../services/school-districts.service';
import { County } from '../../models/county.model';
import { SchoolDistrict } from '../../models/school-district.model';

@Component({
  selector: 'app-add-provider-agency',
  templateUrl: './add-provider-agency.component.html',
  styleUrls: ['./add-provider-agency.component.css']
})
export class AddProviderAgencyComponent {
  pihpregionlist$?: Observable<PihpRegion[]>;
  stateList$?: Observable<State[]>;
  countyList$?: Observable<County[]>
  schoolDistrictList$?: Observable<SchoolDistrict[]>;
  model: AddProviderAgencyRequest;
  private addProviderAgencySubscription? : Subscription;
  sameAsPihpAddress: boolean = false;
  ServerErrorMessage?: string='';
  AddressData$?: {
    address1: string,
    address2: string,
    city: string,
    state: number,
    zip: string,
    comments: string
  } | undefined;

  constructor(
    private ProviderAgencyService: ProviderAgencyService, 
    private router:Router, 
    private pihpregionService: PihpregionService, 
    private stateService: StateService, 
    private countyService: CountyService,
    private schoolDistrictService: SchoolDistrictService,
    private datePipe: DatePipe
  ) {
    this.model = {
      name: '',
      coordinatingAgencyId: 0,
      license: '',
      daysAllowedForDataEntry: 0,
      isActive: true,
      officePhone: '',
      fax: '',
      address1: '',
      address2: '',
      city: '',
      state: 30,
      zip: '',
      comments: '',
      addressComments: '',
      createdBy:   Number(sessionStorage.getItem("MPDSUserId")),
      creationDate: Date.now().toString(),
      updatedBy:   Number(sessionStorage.getItem("MPDSUserId")),
      optionalData: '',
      counties: '',
      schoolDistricts: '',
      //updationDate: new Date(),
    };
  }

  ngOnInit():void{
    this.pihpregionlist$ = this.pihpregionService.GetAllCoordinatingAgencies();
    this.stateList$ = this.stateService.GetAllStates();
    this.countyList$ = this.countyService.GetAllCounties();
    this.schoolDistrictList$ = this.schoolDistrictService.GetAllSchoolDistricts();
    this.model.state=30;
  }

  onFormSubmit(newProviderAgency: AddProviderAgencyRequest){

    this.model = {
      name: newProviderAgency.name || '',
      coordinatingAgencyId: newProviderAgency.coordinatingAgencyId || 0,
      license: newProviderAgency.license || '',
      daysAllowedForDataEntry: newProviderAgency.daysAllowedForDataEntry || 0,
      isActive: newProviderAgency.isActive || true,
      officePhone: newProviderAgency.officePhone || '',
      fax: newProviderAgency.fax || '',
      address1: this.AddressData$?.address1 || newProviderAgency.address1 || '',
      address2: this.AddressData$?.address2 || newProviderAgency.address2 || '',
      city: this.AddressData$?.city || newProviderAgency.city || '',
      state: this.AddressData$?.state || newProviderAgency.state || 0,
      zip: this.AddressData$?.zip || newProviderAgency.zip || '',
      comments: newProviderAgency.comments || '',
      addressComments: '',
      createdBy: newProviderAgency.createdBy || 17,
      creationDate: this.dateFormat(this.model.creationDate),
      updatedBy: newProviderAgency.updatedBy || 17,
      optionalData: newProviderAgency.optionalData || '',
      counties: this.model.counties,
      schoolDistricts: this.model.schoolDistricts
      //updationDate: newProviderAgency.updationDate || new Date()
    };

    console.log(this.model)

    this.addProviderAgencySubscription = this.ProviderAgencyService.CreateProviderAgency(this.model)
    .subscribe({
      next:(response) =>{
        console.log(response)
        alert("Provider Agency created successfully");
        this.router.navigateByUrl(`/provideragencies`);
      },
      error: (error) => {
        // Handle error here
        this.ServerErrorMessage = error.error;
      }
    });
  }

  onCheckboxChange(event: Event): void {
    const checkAllCheckbox = (event.target as HTMLInputElement).checked;
    const checkboxes = document.querySelectorAll('.school-districts') as NodeListOf<HTMLInputElement>;
    const selectedIds: number[] = [];

    checkboxes.forEach((checkbox: HTMLInputElement) => {
      checkbox.checked = checkAllCheckbox;
      if (checkAllCheckbox) {
        selectedIds.push(parseInt(checkbox.id, 10));
      }
    });

    this.model.schoolDistricts = selectedIds.join(',');
  }

  dateFormat(unformattedDate: string): string {
    const formattedDate = this.datePipe.transform(unformattedDate, 'MM/dd/yyyy');
    return formattedDate || ''; // Return an empty string if formatting fails
  }

  private clearAddress(): void {
    // Implement logic to clear the address fields if needed
    this.AddressData$ = {
      address1: '',
      address2: '',
      city: '',
      state: 30,
      zip: '',
      comments: ''
    }
  }

  updateOptionalData() {
    const checkboxes = document.querySelectorAll<HTMLInputElement>('.optional-data');
    const selectedOptions = Array.from(checkboxes)
        .filter(checkbox => checkbox.checked)
        .map(checkbox => checkbox.id);
    this.model.optionalData = selectedOptions.join(',');
  }

  updateCounties() {
    const checkboxes = document.querySelectorAll<HTMLInputElement>('.counties');
    const selectedOptions = Array.from(checkboxes)
        .filter(checkbox => checkbox.checked)
        .map(checkbox => checkbox.id);
    this.model.counties = selectedOptions.join(',');
  }

  updateSchoolDistricts() {
    const checkboxes = document.querySelectorAll<HTMLInputElement>('.school-districts');
    const selectedOptions = Array.from(checkboxes)
        .filter(checkbox => checkbox.checked)
        .map(checkbox => checkbox.id);
    this.model.schoolDistricts = selectedOptions.join(',');
  }
  
  ngOnDestroy(): void {
    this.addProviderAgencySubscription?.unsubscribe();
  }
}
