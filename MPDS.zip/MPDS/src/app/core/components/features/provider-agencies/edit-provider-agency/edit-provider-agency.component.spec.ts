import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditProviderAgencyComponent } from './edit-provider-agency.component';

describe('EditProviderAgencyComponent', () => {
  let component: EditProviderAgencyComponent;
  let fixture: ComponentFixture<EditProviderAgencyComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [EditProviderAgencyComponent]
    });
    fixture = TestBed.createComponent(EditProviderAgencyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
