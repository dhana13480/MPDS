import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Injectable } from '@angular/core';
import { Observable, map } from 'rxjs';
import { ProviderAgency } from '../models/provider-agency.model';
import { AddProviderAgencyRequest } from '../models/add-provider-agency.model';
import { UpdateProviderAgencyRequest } from '../models/update-provider-agency.model';
import { UserService } from '../../users/services/user.service';
import { MiLoginUserModel } from '../../users/models/milogin-user-model';
 
 
@Injectable({
  providedIn: 'root'
})
export class ProviderAgencyService {
  storedUserStringified = sessionStorage.getItem('MiLoginUser')!;
 
  totalItems?: number = 0;
  UserPermissionInfo?: {
    userTypeId: number | 0,
    coordinatingAgencyId: number | 0,
    providerAgencyId: number | 0,
    permissions: string | null
  }

  constructor(private http: HttpClient, private userService: UserService) {
    this.userService.user$.subscribe(user => {
      if (user) {
        this.UserPermissionInfo = {
          userTypeId: user.userTypeId||0,
          coordinatingAgencyId: user.coordinatingAgencyId||0,
          providerAgencyId: user.providerAgencyId||0,
          permissions: user.permissions||''
        }
      } 
    })
  }

  GetAllProviderAgenciesPaginated(pageNumber?: number, pageSize?: number, formValues?: object) {
    const url = `${environment.apiBaseUrl}/api/ProviderAgency/GetAllProviderAgenciesPaginated?PageNumber=${pageNumber}&PageSize=${pageSize}`;

    const fullFormValues = {
      ...formValues,
      userTypeId: this.UserPermissionInfo!.userTypeId||0,
      coordinatingAgencyId: this.UserPermissionInfo!.coordinatingAgencyId||0,
      providerAgencyId: this.UserPermissionInfo!.providerAgencyId||0,
      permissions: this.UserPermissionInfo!.permissions
    };
    return this.http.post<ProviderAgency[]>(url, fullFormValues, { observe: 'response' }).pipe(
      map((response: HttpResponse<ProviderAgency[]>) => {
        const paginationHeader = response.headers.get('Pagination');
        if (paginationHeader) {
          const paginationData = JSON.parse(paginationHeader);
          this.totalItems = paginationData.totalItems;
        }
        return response.body!;
      })
    );
  }

  GetAllCoordinatingAgencies() : Observable<ProviderAgency[]> { 
    return this.http.get<ProviderAgency[]>(`${environment.apiBaseUrl}/api/ProviderAgency`);
  }

  GetCoordinatingAgencyById(id:string): Observable<ProviderAgency>{
    return this.http.get<ProviderAgency>(`${environment.apiBaseUrl}/api/ProviderAgency/${id}`);
  }

  GetProviderAgencyById(id:string): Observable<ProviderAgency>{
    return this.http.get<ProviderAgency>(`${environment.apiBaseUrl}/api/ProviderAgency/${id}`);
  }
 
  GetProviderAgencyByCoordinatingAgencyId(id:string): Observable<ProviderAgency[]>{
    return this.http.get<ProviderAgency[]>(`${environment.apiBaseUrl}/api/ProviderAgency/coordinatingagency/${id}`);
  }
  GetAllProviderAgencies(): Observable<ProviderAgency[]>{
    return this.http.get<ProviderAgency[]>(`${environment.apiBaseUrl}/api/ProviderAgency`);
  }
   
  CreateProviderAgency(model: AddProviderAgencyRequest) : Observable<void> {
    console.log(model)
    return this.http.post<void>(`${environment.apiBaseUrl}/api/ProviderAgency`, model);
  } 

  UpdateProviderAgency(id:number, UpdateProviderAgencyRequest: UpdateProviderAgencyRequest): Observable<ProviderAgency>{
    console.log(UpdateProviderAgencyRequest)
    return this.http.put<ProviderAgency>(`${environment.apiBaseUrl}/api/ProviderAgency/${id}`, UpdateProviderAgencyRequest);
  }
  
}
