import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProviderAgenciesListComponent } from './provider-agencies-list.component';

describe('ProviderAgenciesListComponent', () => {
  let component: ProviderAgenciesListComponent;
  let fixture: ComponentFixture<ProviderAgenciesListComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ProviderAgenciesListComponent]
    });
    fixture = TestBed.createComponent(ProviderAgenciesListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
