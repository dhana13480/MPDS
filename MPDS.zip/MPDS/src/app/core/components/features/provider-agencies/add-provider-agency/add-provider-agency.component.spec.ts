import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddProviderAgencyComponent } from './add-provider-agency.component';

describe('AddProviderAgencyComponent', () => {
  let component: AddProviderAgencyComponent;
  let fixture: ComponentFixture<AddProviderAgencyComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AddProviderAgencyComponent]
    });
    fixture = TestBed.createComponent(AddProviderAgencyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
