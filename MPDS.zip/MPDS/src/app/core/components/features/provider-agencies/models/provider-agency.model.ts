export interface ProviderAgency {
    id: number;
    name: string;
    coordinatingAgencyId: number;
    license: string;
    daysAllowedForDataEntry: number;
    isActive: boolean;
    officePhone: string;
    fax: string;
    address1: string;
    address2: string;
    city: string;
    state: number;
    zip: string;
    comments: string;
    addressComments: string;
    createdBy: number;
    creationDate: Date;
    updatedBy: number;
    //updationDate: Date;
    optionalData: string;
    counties: string;
    schoolDistricts: string;
}