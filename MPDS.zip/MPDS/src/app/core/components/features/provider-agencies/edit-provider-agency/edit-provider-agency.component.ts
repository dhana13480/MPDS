import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ProviderAgencyService } from '../services/provideragency.service';
import { Subscription, Observable } from 'rxjs';
import { State } from '../../models/states.model';
import { StateService } from '../../services/states.service';
import { ProviderAgency } from '../models/provider-agency.model';
import { UpdateProviderAgencyRequest } from '../models/update-provider-agency.model';
import { County } from '../../models/county.model';
import { SchoolDistrict } from '../../models/school-district.model';
import { CountyService } from '../../services/counties.service';
import { SchoolDistrictService } from '../../services/school-districts.service';
import { PihpregionService } from '../../pihp-regions/services/pihpregion.service';

@Component({
  selector: 'app-edit-provider-agency',
  templateUrl: './edit-provider-agency.component.html',
  styleUrls: ['./edit-provider-agency.component.css']
})
export class EditProviderAgencyComponent implements OnInit, OnDestroy {
  id: string | null = null;
  paramsSubscription?: Subscription;
  editProviderAgencySubscription?: Subscription;
  providerAgency?: ProviderAgency;
  stateList$?: Observable<State[]>;
  countyList$?: Observable<County[]>;
  selectedCountyIds: number[] = [];
  schoolDistrictList$?: Observable<SchoolDistrict[]>;
  selectedSchoolDistrictIds: number[] = [];
  correspondingPihpRegionName?: string;
  formValue:  { 
    name: string;
    coordinatingAgencyId: number;
    license: string;
    daysAllowedForDataEntry: number;
    isActive: boolean;
    officePhone: string;
    fax: string;
    address1: string;
    address2: string;
    city: string;
    state: number;
    zip: string;
    comments: string;
    addressComments: string;
    createdBy: number;
    //creationDate: number;
    updatedBy: number;
    //updationDate: number;
    optionalData: string;
    counties: string;
    schoolDistricts: string;
  } = {
    name: '',
    coordinatingAgencyId: 0,
    license: '',
    daysAllowedForDataEntry: 0,
    isActive: true,
    officePhone: '',
    fax: '',
    address1: '',
    address2: '',
    city: '',
    state: 0,
    zip: '',
    comments: '',
    addressComments: '',
    createdBy: 0,
    //creationDate: Date.now(),
    updatedBy: Number(sessionStorage.getItem("MPDSUserId")),
    //updationDate: Date.now()
    optionalData: '',
    counties: '',
    schoolDistricts: ''
  };
  
  constructor (
    private route: ActivatedRoute,
    private providerAgencyService: ProviderAgencyService,
    private pihpRegionService: PihpregionService,
    private router: Router,
    private countyService: CountyService,
    private schoolDistrictService: SchoolDistrictService,
    private stateService: StateService
  ) {
  }

  ngOnInit(): void {
    this.stateList$ = this.stateService.GetAllStates();
    this.countyList$ = this.countyService.GetAllCounties();
    this.schoolDistrictList$ = this.schoolDistrictService.GetAllSchoolDistricts();


    this.paramsSubscription = this.route.paramMap.subscribe({
      next: (params) => {
        this.id = params.get('id');
        if (this.id) {
          this.providerAgencyService.GetProviderAgencyById(this.id).subscribe({
            next: (response) => {
              this.providerAgency = response;
              console.log(this.providerAgency)
              this.selectedCountyIds = this.providerAgency.counties ? this.providerAgency.counties.split(',').map(Number) : []
              this.selectedSchoolDistrictIds = this.providerAgency.schoolDistricts ? this.providerAgency.schoolDistricts.split(',').map(Number) : []
              if (!this.providerAgency.optionalData) {
                this.providerAgency.optionalData = ''
              }

              this.pihpRegionService.GetCoordinatingAgencyById(this.providerAgency.coordinatingAgencyId.toString()).subscribe(agency => {
                this.correspondingPihpRegionName = agency.name
              })
  
              // Initialize formValue with the data from Provider Agency
              this.formValue = {
                name: this.providerAgency.name,
                coordinatingAgencyId: this.providerAgency.coordinatingAgencyId,
                license: this.providerAgency.license,
                daysAllowedForDataEntry: this.providerAgency.daysAllowedForDataEntry,
                isActive: this.providerAgency.isActive,
                officePhone: this.providerAgency.officePhone,
                fax: this.providerAgency.fax,
                address1: this.providerAgency.address1,
                address2: this.providerAgency.address2,
                city: this.providerAgency.city,
                state: this.providerAgency.state,
                zip: this.providerAgency.zip,
                comments: this.providerAgency.comments,
                addressComments: this.providerAgency.addressComments,
                createdBy: this.providerAgency.createdBy,
                //creationDate: this.providerAgency.creationDate,
                updatedBy: this.providerAgency.updatedBy,
                //updationDate: Date.now()
                optionalData: this.providerAgency.optionalData,
                counties: this.providerAgency.counties,
                schoolDistricts: this.providerAgency.schoolDistricts
              };
            },
          });
        }
      },
    });
  }

  ngOnDestroy(): void {
    this.paramsSubscription?.unsubscribe();
    this.editProviderAgencySubscription?.unsubscribe();  
  }

  onFormSubmit():void{
    const updateProviderAgencyRequest: UpdateProviderAgencyRequest = {
      id: this.providerAgency!.id,
      name: this.formValue?.name ?? '',
      coordinatingAgencyId: this.formValue?.coordinatingAgencyId ?? 0,
      license: this.formValue?.license ?? '',
      daysAllowedForDataEntry: this.formValue?.daysAllowedForDataEntry ?? 0,
      isActive: this.formValue?.isActive ?? true,
      officePhone: this.formValue?.officePhone ?? '',
      fax: this.formValue?.fax ?? '',
      address1: this.formValue?.address1 ?? '',
      address2: this.formValue?.address2 ?? '',
      city: this.formValue?.city ?? '',
      state: this.formValue?.state ?? 0,
      zip: this.formValue?.zip ?? '',
      comments: this.formValue?.comments ?? '',
      addressComments: this.formValue?.addressComments ?? '',
      createdBy: this.formValue?.createdBy ?? 0,
      updatedBy: Number(sessionStorage.getItem("MPDSUserId")) ?? 0,
      optionalData: this.formValue?.optionalData ?? '',
      counties: this.formValue?.counties ?? '',
      schoolDistricts: this.formValue?.schoolDistricts ?? ''
    };
  
    if(this.id){
      console.log(updateProviderAgencyRequest)
      this.editProviderAgencySubscription =  this.providerAgencyService.UpdateProviderAgency(updateProviderAgencyRequest.id, updateProviderAgencyRequest)
      .subscribe({
        next:(response) =>{
          alert("Provider Agency updated successfully")
          this.router.navigateByUrl('/provideragencies')
        }
      });
    }
  }

  updateOptionalData() {
    const checkboxes = document.querySelectorAll<HTMLInputElement>('.form-check-input');
    const selectedOptions = Array.from(checkboxes)
        .filter(checkbox => checkbox.checked)
        .map(checkbox => checkbox.id);
    this.formValue.optionalData = selectedOptions.join(',');
  }

  updateCounties() {
    const checkboxes = document.querySelectorAll<HTMLInputElement>('.counties');
    const selectedOptions = Array.from(checkboxes)
        .filter(checkbox => checkbox.checked)
        .map(checkbox => checkbox.id);
    this.formValue.counties = selectedOptions.join(',');
  }

  updateSchoolDistricts() {
    const checkboxes = document.querySelectorAll<HTMLInputElement>('.school-districts');
    const selectedOptions = Array.from(checkboxes)
        .filter(checkbox => checkbox.checked)
        .map(checkbox => checkbox.id);
    this.formValue.schoolDistricts = selectedOptions.join(',');
  }
}
