export interface AddProviderAgencyRequest {
  name: string;
  coordinatingAgencyId: number;
  license: string;
  daysAllowedForDataEntry: number;
  isActive: boolean;
  officePhone: string;
  fax: string;
  address1: string;
  address2: string;
  city: string;
  state: number;
  zip: string;
  comments: string;
  addressComments: string;
  createdBy: number;
  creationDate: string;
  updatedBy: number;
  //updationDate: string;
  optionalData: string;
  counties: string;
  schoolDistricts: string;
}