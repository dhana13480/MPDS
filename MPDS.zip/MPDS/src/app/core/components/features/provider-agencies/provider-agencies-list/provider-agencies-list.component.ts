import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { FuncsService } from '../../services/funcs.service';
import { Router } from '@angular/router';
import { switchMap, catchError, map } from 'rxjs/operators';
import { of } from 'rxjs';
import { ProviderAgencyService } from '../services/provideragency.service';
import { ProviderAgency } from '../models/provider-agency.model';
import { UpdateProviderAgencyRequest } from '../models/update-provider-agency.model';
import { MiLoginUserModel } from '../../users/models/milogin-user-model';
import { UserService } from '../../users/services/user.service';
import { UserRoles } from '../../enums/user-roles.enum';
import { UserPermissions } from '../../enums/user-permissions.enum';

@Component({
  selector: 'app-provider-agencies-list',
  templateUrl: './provider-agencies-list.component.html',
  styleUrls: ['./provider-agencies-list.component.css']
})
export class ProviderAgenciesListComponent {
  providerAgencyList$?: Observable<ProviderAgency[]>;
  phone$?: Observable<FuncsService[]>;
  MiLoginUser?: MiLoginUserModel | null;
  userTypeId:number=0;
  userCanEdit: boolean = false;
  formSubmitted = false;
  formValue: { 
    name: string, 
    status: string 
  } = {
    name: '',
    status: 'All'
  };
  sortConfig = {
    column: '',
    direction: 'asc', // default sorting direction
  };
  totalItems = 0;
  pageNumber = 1;
  pageSize = 20;
  isLoading = false;

  constructor(
    private ProviderAgencyService: ProviderAgencyService,
    private router: Router,
    private userService: UserService,
    private funcs: FuncsService 
    ){}
  ngOnInit():void{
    this.userTypeId = Number( sessionStorage.getItem('UserTypeId'));

    this.userService.user$.subscribe(user => {
      this.MiLoginUser = user
      this.checkPermissions(user);
      if (user!.userTypeId !== UserRoles.Super_Admin) 
      {
        if(user!.coordinatingAgencyId>0)
        {          
          this.ProviderAgencyService.GetProviderAgencyByCoordinatingAgencyId(user!.coordinatingAgencyId.toString()).subscribe(agency => 
          {
                 
          this.loadProviderAgencies();
          });
        } else
        if(user!.providerAgencyId>0)
        {          
          this.ProviderAgencyService.GetProviderAgencyById(user!.providerAgencyId.toString()).subscribe(agency => 
          {
            this.formValue = {
              name: agency.name,
              status: 'All'
            };        
          this.loadProviderAgencies();
          });
        }
      } 
      //usertype id = 2
      else 
      { 
        this.loadProviderAgencies();
      }
    })
  }
    
  onFormSubmit() {
    this.loadProviderAgencies();
  }

  loadProviderAgencies() {
    this.isLoading = true
    this.ProviderAgencyService.GetAllProviderAgenciesPaginated(this.pageNumber, this.pageSize, this.formValue!).subscribe(agencies => {
      this.providerAgencyList$= of(agencies);
      this.totalItems = this.ProviderAgencyService.totalItems!;
      this.isLoading = false
    })
  }

  checkPermissions(user: any): void {
    const userTypeId = user.userTypeId;
    const permissions = user.permissions ? user.permissions.split(',') : [];

    //const allowedUserTypes = [3]; 
    //const requiredPermissions = ['7'];

    if ((userTypeId == UserRoles.Super_Admin) ||(userTypeId == UserRoles.Coordinating_Agency) || (userTypeId == UserRoles.Provider_Agency)) 
    {
      this.userCanEdit = true;
    } else 
    {
      //this.userCanEdit = allowedUserTypes.includes(userTypeId) && requiredPermissions.every(permission => permissions.includes(permission));
      this.userCanEdit = permissions.includes(UserPermissions.Manage_Provider_Agency);    
    }
  }

  pageChanged(event: any) {
    if (this.pageNumber !== event.page) {
      this.pageNumber = event.page;
      this.providerAgencyList$ = this.ProviderAgencyService.GetAllProviderAgenciesPaginated(this.pageNumber, this.pageSize, this.formValue);
    }
  }

  deactivateRecord(agency: UpdateProviderAgencyRequest) {
    if (agency){
      if (confirm('Are you sure you want to deactivate this Provider Agency '  + agency.name)) {
      agency.isActive = false;
      this.ProviderAgencyService.UpdateProviderAgency(agency.id, agency)
      .subscribe({
        next:(response) =>{
          this. loadProviderAgencies();
        }
      });
    }}
  }

  sort(column: string) {
    if (this.sortConfig.column === column) {
      // If the same column is clicked again, toggle the sort direction
      this.sortConfig.direction = this.sortConfig.direction === 'asc' ? 'desc' : 'asc';
    } else {
      // If a new column is clicked, set it as the active column and default to ascending
      this.sortConfig.column = column;
      this.sortConfig.direction = 'asc';
    }

    // Now, sort the data based on the sort configuration
    this.providerAgencyList$ = this.providerAgencyList$?.pipe(
      map((data) => this.sortData(data))
    );
  }

  private sortData(data: ProviderAgency[]): ProviderAgency[] {
    const { column, direction } = this.sortConfig;

    if (!column) {
      return data;
    }

    return data.slice().sort((a, b) => {
      const aValue = this.getPropertyValue(a, column);
      const bValue = this.getPropertyValue(b, column);

      
    // For boolean values, explicitly cast to numbers before performing subtraction
    if (typeof aValue === 'boolean') {
      return direction === 'asc' ? (aValue as unknown as number) - (bValue as number) : (bValue as number) - (aValue as unknown as number);
    }


      if (typeof aValue === 'string') {
        return direction === 'asc' ? aValue.localeCompare(bValue) : bValue.localeCompare(aValue);
      } else if (typeof aValue === 'number') {
        return direction === 'asc' ? aValue - bValue : bValue - aValue;
      } else {
        return 0; // Add more cases as needed for other data types
      }
    });
  }

  private getPropertyValue(object: any, column: string): any {
    // Customize this part based on your data structure
    switch (column) {
      case 'name':
        return object.name;
      case 'officePhone':
        return object.officePhone;
      case 'isActive':
        return object.isActive;
      // Add more cases for other columns
      default:
        return null;
    }
  }
}
