import { AfterViewInit, Component, OnInit } from '@angular/core';
import { State } from '../models/states.model';
import { StateService } from '../services/states.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-states',
  templateUrl: './states.component.html',
  styleUrls: ['./states.component.css']
})
export class StatesComponent implements OnInit{

 // stateModel: States[];
  isLoaded = false;
  stateList$?: Observable<State[]>;

  constructor(private _stateService: StateService){}   
   
    ngOnInit(): void {
      this.stateList$=this._stateService.GetAllStates();
    }
}
