import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { State } from '../models/states.model';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { County } from '../models/county.model';
import { SchoolDistrict } from '../models/school-district.model';

@Injectable({
  providedIn: 'root'
})
export class SchoolDistrictService {

 
  constructor(private http: HttpClient) { }
  
  GetAllSchoolDistricts() : Observable<SchoolDistrict[]> { 
    return this.http.get<SchoolDistrict[]>(`${environment.apiBaseUrl}/MasterSchoolDistrict`);
  }
}