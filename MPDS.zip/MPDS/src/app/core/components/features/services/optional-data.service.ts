import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { MasterServiceDomain } from '../models/optional-data/master-service-domain.model';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { MasterServicePopulation } from '../models/optional-data/master-service-population.model';
import { MasterServiceSetting } from '../models/optional-data/master-service-setting.model';
import { MasterIntendedPopulation } from '../models/optional-data/master-intended-population.model';
import { MasterStrategyEmployed } from '../models/optional-data/master-strategy-employed.model';

@Injectable({
  providedIn: 'root'
})
export class OptionalDataService {

    constructor(private http: HttpClient) { }

    GetMasterServiceDomain(): Observable<MasterServiceDomain[]>{
        return this.http.get<MasterServiceDomain[]>(`${environment.apiBaseUrl}/api/MasterServiceDomain`);
    }

    GetMasterServicePopulation(): Observable<MasterServicePopulation[]>{
        return this.http.get<MasterServicePopulation[]>(`${environment.apiBaseUrl}/api/MasterServicePopulation`);
    }

    GetMasterServiceSetting(): Observable<MasterServiceSetting[]>{
        return this.http.get<MasterServiceSetting[]>(`${environment.apiBaseUrl}/api/MasterServiceSetting`);
    }

    GetMasterIntendedPopulation(): Observable<MasterIntendedPopulation[]>{
        return this.http.get<MasterIntendedPopulation[]>(`${environment.apiBaseUrl}/api/MasterIntendedPopulation`);
    }

    GetMasterStrategy(): Observable<MasterStrategyEmployed[]>{
        return this.http.get<MasterStrategyEmployed[]>(`${environment.apiBaseUrl}/api/MasterStrategy`);
    }
}