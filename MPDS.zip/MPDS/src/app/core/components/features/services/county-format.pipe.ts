import { Pipe, PipeTransform } from '@angular/core';
import { CountyService } from '../master-data/counties/services/county.service';

@Pipe({
  name: 'countyFormat'
})
export class CountyFormatPipe implements PipeTransform {

    constructor(
        private countyService: CountyService
    ) {}

  transform(countyId:number) {
    this.countyService.GetCountyById(countyId.toString())
    .subscribe({
      next:(response) => {
        return response.county;
      }
    });
  }     
}