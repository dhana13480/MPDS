import { Injectable } from "@angular/core";

/**
 * Filename: zip-code-formatter.service.ts
 * Author: Anthony Wolf
 * Date Created: 05/08/2017
 */
@Injectable()
export class ZipCodeFormatterService {
    public formatZipCode(value: string, countryCode: string): string {
        if (!value) {
            return value;
        }

        let valTrimmed = value.trim();

        switch (countryCode) {
            case "USA":
                let usaRegex = /\d{9}/g;
                let usaMatches = usaRegex.exec(valTrimmed);
                if (usaMatches && usaMatches.length === 1) {
                    return valTrimmed.substr(0, 5) + "-" + valTrimmed.substr(5, 4);
                } else {
                    return value;
                }
            case "CAN":
                let canadaRegex = /([A-Z]|[a-z])\d([A-Z]|[a-z])\d([A-Z]|[a-z])\d/g;
                let canadaMatches = canadaRegex.exec(valTrimmed);
                if (canadaMatches && canadaMatches.length === 1) {
                    return valTrimmed.substr(0, 3) + " " + valTrimmed.substr(3, 3);
                } else {
                    return value;
                }
            case "DE":
                break;
            case "MEX":
                break;
            case "AUS":
                break;
            default:
                break;
        }

        return value;
    }
}
