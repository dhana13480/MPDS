import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { State } from '../models/states.model';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { County } from '../models/county.model';

@Injectable({
  providedIn: 'root'
})
export class CountyService {

 
  constructor(private http: HttpClient) { }
  
  GetAllCounties() : Observable<County[]> { 
    return this.http.get<County[]>(`${environment.apiBaseUrl}/api/County`);
  }
}