import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { State } from '../models/states.model';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { County } from '../models/county.model';
import { ProgramName } from '../models/program-name.model';

@Injectable({
  providedIn: 'root'
})
export class ProgramNameService {

 
  constructor(private http: HttpClient) { }
  
  GetAllProgramNames() : Observable<ProgramName[]> { 
    return this.http.get<ProgramName[]>(`${environment.apiBaseUrl}/api/MasterProgramName`);
  }
}