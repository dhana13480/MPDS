import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'booleanFormat'
})
export class BooleanFormatPipe implements PipeTransform {

  transform(booleanText:boolean) {
    if (booleanText)
      return 'Active';
    return 'Inactive';
  }     
}
