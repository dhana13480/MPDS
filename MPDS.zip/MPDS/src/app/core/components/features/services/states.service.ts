import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { State } from '../models/states.model';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class StateService {

 
  constructor(private http: HttpClient) { }
  GetAllStates() : Observable<State[]> { 
    return this.http.get<State[]>(`${environment.apiBaseUrl}/api/state`);
  }
}
