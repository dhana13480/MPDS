import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class FuncsService {

  constructor() { }
  formatPhoneNumber(phoneNumber: string) {
    var cleaned = ('' + phoneNumber).replace(/\D/g, '');
    var match = cleaned.match(/^(\d{3})(\d{3})(\d{4})$/);
    if (match) {
      return '(' + match[1] + ') ' + match[2] + '-' + match[3];
    }
    return null;
  }
  formatBoolean(booleanText: boolean){
    if (booleanText)
      return 'Active';
    return 'Inactive';
  }
}
