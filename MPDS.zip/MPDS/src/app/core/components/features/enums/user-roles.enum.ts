export enum UserRoles {
    Auditor = 1,
    Super_Admin = 2,
    Coordinating_Agency = 3,
    Provider_Agency = 4
  }
