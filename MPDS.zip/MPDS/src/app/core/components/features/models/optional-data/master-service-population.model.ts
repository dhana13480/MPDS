export interface MasterServicePopulation {
    id:number;
    code: string;
    servicePopulation: string;
    description: string;
}