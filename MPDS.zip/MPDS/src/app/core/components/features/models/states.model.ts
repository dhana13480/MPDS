export interface State {
    id:number;
    description: string;
}