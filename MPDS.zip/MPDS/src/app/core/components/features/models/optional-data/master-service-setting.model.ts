export interface MasterServiceSetting {
    id:number;
    code: string;
    serviceSetting: string;
    description: string;
}