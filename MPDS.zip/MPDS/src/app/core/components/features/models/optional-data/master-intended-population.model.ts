export interface MasterIntendedPopulation {
    id:number;
    code: string;
    intendedPopulation: string;
    description: string;
}