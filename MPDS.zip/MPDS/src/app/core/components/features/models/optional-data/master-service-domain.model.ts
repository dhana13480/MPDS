export interface MasterServiceDomain {
    id:number;
    code: string;
    serviceDomain: string;
    description: string;
}