export interface ProgramName {
    id: number;
    name: string;
    description: string;
    deactivatedB: number;
    createdBy: number;
    creationDate: Date;
    updatedBy: number;
    updationDate: Date;
    deactivatedDate: Date;
    coordinatingAgencyId?: number;
    programNameId?: number;
    programName?: string;
}