export interface County {
    id: number;
    coordinatingAgencyId: number;
    countyId: number;
    county?: string;
    description?: string,
    isActive?: boolean,
    createdBy?: number,
    creationDate?: Date,
    updatedBy?: number,
    updationDate?: Date
}