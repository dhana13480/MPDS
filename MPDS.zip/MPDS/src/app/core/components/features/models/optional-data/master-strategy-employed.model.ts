export interface MasterStrategyEmployed {
    id: number,
    code: string,
    strategy: string,
    description: string,
    categoryId: number
}