import { TestBed } from '@angular/core/testing';

import { CalculateUnitsService } from './calculate-units.service';

describe('CalculateUnitsService', () => {
  let service: CalculateUnitsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CalculateUnitsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
