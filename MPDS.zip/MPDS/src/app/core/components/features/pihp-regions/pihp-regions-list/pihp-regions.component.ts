import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { PihpregionService } from '../services/pihpregion.service';
import { PihpRegion } from '../models/pihp-region.model';
import { FuncsService } from '../../services/funcs.service';
import { Router } from '@angular/router';
import { switchMap, catchError, map } from 'rxjs/operators';
import { of } from 'rxjs';
import { MiLoginUserModel } from '../../users/models/milogin-user-model';
import { UserService } from '../../users/services/user.service';
import { UserRoles } from '../../enums/user-roles.enum';
import { UserPermissions } from '../../enums/user-permissions.enum';
import { BooleanFormatPipe } from '../../services/boolean-format.pipe';

@Component({
  selector: 'app-pihp-regions',
  templateUrl: './pihp-regions.component.html',
  styleUrls: ['./pihp-regions.component.css']
})
export class PihpRegionsComponent  implements OnInit{
  pihpregionlist$?: Observable<PihpRegion[]>;
  phone$?: Observable<FuncsService[]>;
  formSubmitted = false;
  userTypeId:number=0;
  formValue: { 
    name: string, 
    status: string 
  } = { 
    name: '', 
    status: 'All' 
  };
  MiLoginUser?: MiLoginUserModel | null;
  userCanEdit: boolean = false;
  sortConfig = {
    column: '',
    direction: 'asc', // default sorting direction
  };

  constructor(
    private pihpregionService: PihpregionService,
    private router: Router,
    private userService: UserService,
    private funcs: FuncsService
    ){}
  ngOnInit():void{
    this.userTypeId = Number( sessionStorage.getItem('UserTypeId'));
    this.pihpregionlist$  = this.pihpregionService.GetAllCoordinatingAgencies();
    this.userService.user$.subscribe(user => {
      this.MiLoginUser = user
      this.checkPermissions(user);      
      this.loadCoordinatingAgencies() 
    })
  }
    
  onFormSubmit() {
    this.loadCoordinatingAgencies()
  }

  loadCoordinatingAgencies() {
    console.log(this.formValue)
    this.pihpregionService.GetAllCoordinatingAgencies().pipe(
      switchMap((coordinatingAgenciesList: PihpRegion[]) => {
        if (!this.formSubmitted) {
          // Filter the list based on the partial name
          const filteredAgencies = coordinatingAgenciesList.filter(agency =>
            //agency.name.toLowerCase().includes(this.formValue.name.toLowerCase() && (this.formValue.status.toLocaleUpperCase()))
            agency.name.toLowerCase().includes(this.formValue.name.toLowerCase() )
            
          );

          if (filteredAgencies.length > 0) {
            return of(filteredAgencies); // Return an observable containing only the found agency
          } else {
            console.error(`Coordinating agency with name '${this.formValue.name}' not found.`);
            return of([]); // Return an empty observable when the agency is not found
          }
        } else {
          return of(coordinatingAgenciesList); // Return the full list when the form is not submitted
        }
      }),
      catchError((error) => {
        console.error('Error fetching coordinating agencies:', error.error);
        alert(error.error);
        return of([]); // Return an empty observable in case of an error
      })
    ).subscribe((response) => {
      this.pihpregionlist$ = of(response); // Set the pihpregionlist$ observable based on the response
    });
  }
 
  deleteItem(item: number, name: string) {
    if (confirm('Are you sure you want to deactivate this ' + name)) {
     
      this.pihpregionService.DeletePihpRegion(item.toString())
      .subscribe({
        next:(response) =>{
          this.loadCoordinatingAgencies();
        }
      });
    }
  }

  checkPermissions(user: any): void {
    const userTypeId = user.userTypeId ;   
    const permissions = user.permissions ? user.permissions.split(',') : [];

    // List of required permissions
    const requiredPermissions = [UserPermissions.Manage_Coordinating_Agency];
    const allowedUserTypes = [UserRoles.Coordinating_Agency];
    // Check if userTypeId is 2 and permissions include all required permissions
    if ((userTypeId == UserRoles.Super_Admin)||(userTypeId == UserRoles.Coordinating_Agency))  {
      this.userCanEdit = true;
    } else {
      //this.userCanEdit = allowedUserTypes.includes(userTypeId) && requiredPermissions.every(permission => permissions.includes(UserPermissions.Manage_Coordinating_Agency));     
      this.userCanEdit = permissions.includes(UserPermissions.Manage_Coordinating_Agency);
    }
  }

  sort(column: string) {
    if (this.sortConfig.column === column) {
      // If the same column is clicked again, toggle the sort direction
      this.sortConfig.direction = this.sortConfig.direction === 'asc' ? 'desc' : 'asc';
    } else {
      // If a new column is clicked, set it as the active column and default to ascending
      this.sortConfig.column = column;
      this.sortConfig.direction = 'asc';
    }

    // Now, sort the data based on the sort configuration
    this.pihpregionlist$ = this.pihpregionlist$?.pipe(
      map((data) => this.sortData(data))
    );
  }

  private sortData(data: PihpRegion[]): PihpRegion[] {
    const { column, direction } = this.sortConfig;

    if (!column) {
      return data;
    }

    return data.slice().sort((a, b) => {
      const aValue = this.getPropertyValue(a, column);
      const bValue = this.getPropertyValue(b, column);

      
    // For boolean values, explicitly cast to numbers before performing subtraction
    if (typeof aValue === 'boolean') {
      return direction === 'asc' ? (aValue as unknown as number) - (bValue as number) : (bValue as number) - (aValue as unknown as number);
    }


      if (typeof aValue === 'string') {
        return direction === 'asc' ? aValue.localeCompare(bValue) : bValue.localeCompare(aValue);
      } else if (typeof aValue === 'number') {
        return direction === 'asc' ? aValue - bValue : bValue - aValue;
      } else {
        return 0; // Add more cases as needed for other data types
      }
    });
  }

  private getPropertyValue(object: any, column: string): any {
    // Customize this part based on your data structure
    switch (column) {
      case 'name':
        return object.name;
      case 'officePhone':
        return object.officePhone;
      case 'isActive':
        return object.isActive;
      // Add more cases for other columns
      default:
        return null;
    }
  }
}
