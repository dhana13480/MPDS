import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditPihpRegionComponent } from './edit-pihp-region.component';

describe('EditPihpRegionComponent', () => {
  let component: EditPihpRegionComponent;
  let fixture: ComponentFixture<EditPihpRegionComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [EditPihpRegionComponent]
    });
    fixture = TestBed.createComponent(EditPihpRegionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
