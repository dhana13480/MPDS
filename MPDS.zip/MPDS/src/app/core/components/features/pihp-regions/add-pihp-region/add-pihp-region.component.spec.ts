import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddPihpRegionComponent } from './add-pihp-region.component';

describe('AddPihpRegionComponent', () => {
  let component: AddPihpRegionComponent;
  let fixture: ComponentFixture<AddPihpRegionComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AddPihpRegionComponent]
    });
    fixture = TestBed.createComponent(AddPihpRegionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
