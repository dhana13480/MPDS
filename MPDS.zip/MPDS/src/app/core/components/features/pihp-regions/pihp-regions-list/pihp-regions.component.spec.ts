import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PihpRegionsComponent } from './pihp-regions.component';

describe('PihpRegionsComponent', () => {
  let component: PihpRegionsComponent;
  let fixture: ComponentFixture<PihpRegionsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [PihpRegionsComponent]
    });
    fixture = TestBed.createComponent(PihpRegionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
