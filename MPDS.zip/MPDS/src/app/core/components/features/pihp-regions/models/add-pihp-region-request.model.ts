export interface AddPihpRegionRequest{  
    name:string;
    isActive:boolean;
    officePhone:string;
    fax:string;
    address1:string;
    address2:string;   
    city:string;
    state:number;
    zip:string;
    comments:string;
    addressComments:string;
    pC_FirstName:string;
    pC_MiddleName:string;
    pC_LastName:string;
    pC_Email:string;
    pC_OfficePhone:string;   
    pC_CellPhone:string;
    pC_Comments:string;
    createdBy:number;
    //creationDate:string;
    updatedBy:number;
    //updationDate:string;
    optionalData: string;
    counties: string;
    programNames: string;
    schoolDistricts: string;
}