export interface GetPihpRegionByUserTypeRequest{  
    permissions:string;
    userCoordinatingAgencyId:number;
    userEmail:string;
    userProviderAgencyId:number;
    userTypeId:number;
}