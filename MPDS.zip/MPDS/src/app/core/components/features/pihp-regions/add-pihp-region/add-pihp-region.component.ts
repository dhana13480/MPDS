import { Component,Directive, OnDestroy } from '@angular/core';
import { Observable, Subscription } from 'rxjs';
import { PihpregionService } from '../services/pihpregion.service';
import { AddPihpRegionRequest } from '../models/add-pihp-region-request.model';
import { Router } from '@angular/router';
import { County } from '../../models/county.model';
import { CountyService } from '../../services/counties.service';
import { ProgramName } from '../../models/program-name.model';
import { ProgramNameService } from '../../services/program-names.service';
import { SchoolDistrict } from '../../master-data/school-districts/models/school-district.model';
import { SchoolDistrictService } from '../../services/school-districts.service';
//import { StatesComponent } from '../../states/states.component';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators, FormArray, FormControl } from '@angular/forms'; 
@Component({
  selector: 'app-add-pihp-region',
  templateUrl: './add-pihp-region.component.html',
  styleUrls: ['./add-pihp-region.component.css']
})
export class AddPihpRegionComponent implements OnDestroy {
  model: AddPihpRegionRequest;
  userForm: FormGroup;
  countyList$?: Observable<County[]>;
  programNameList$?: Observable<ProgramName[]>;
  schoolDistrictList$?: Observable<SchoolDistrict[]>;
  private addPihpRegionSubscription? : Subscription;
  ServerErrorMessage?: string='';
  //state$?: Observable<StatesComponent[]>;


   constructor(
    private pihpregionService: PihpregionService, 
    private countyService: CountyService,
    private programNameService: ProgramNameService,
    private schoolDistrictService: SchoolDistrictService,
    private router:Router , private fb: FormBuilder) {
    this.model = {
      name:'',
      isActive:true,
      officePhone:'',
      fax:'',
      address1:'',
      address2:'', 
      city:'',
      state:0,
      zip:'',
      comments:'',
      addressComments:'',
      pC_FirstName:'',
      pC_MiddleName:'',
      pC_LastName:'',
      pC_Email:'',
      pC_OfficePhone:'',
      pC_CellPhone:'',
      pC_Comments:'',
      createdBy: Number(sessionStorage.getItem("MPDSUserId")),
      //creationDate:'',
      updatedBy: Number(sessionStorage.getItem("MPDSUserId")),
      optionalData: '',
      counties: '',
      programNames: '',
      schoolDistricts: '',
      //updationDate:''
    }

 
this.userForm = this.fb.group({
      name: ['', Validators.required],
      officePhone: [''],
      fax: [''],
      inputAddress: ['', [Validators.required]],
      inputAddress2: [''],
      inputCity: ['', [Validators.required]],
      inputState: ['', [Validators.required]],
      inputZip: ['', [Validators.required]],
      notes: [''],
      // countries: this.fb.array([]),
      // schools: this.fb.array([])
      pcFirstName:['', [Validators.required]],
      pcMiddleName:[''],
      pcLastName:['', [Validators.required]],
      pcEmail:['', [Validators.required]],
      pcPhone:['', [Validators.required]],
      pcCellPhone:[''],
      pcNotes:[''],
    });
 
   }

   ngOnInit():void{
    this.countyList$ = this.countyService.GetAllCounties();
    this.programNameList$ = this.programNameService.GetAllProgramNames();
    this.schoolDistrictList$ = this.schoolDistrictService.GetAllSchoolDistricts()
   }

   onFormSubmit(){
   // this.userForm.markAllAsTouched();
   this.userForm.markAllAsTouched();
   //this.model = this.userForm.value;
   this.model.name = this.userForm.value.name;
   this.model.officePhone = this.userForm.value.officePhone;
   this.model.fax = this.userForm.value.fax;   
   this.model.address1 = this.userForm.value.inputAddress;
   this.model.address2 =this.userForm.value.inputAddress2;
   this.model.city = this.userForm.value.inputCity;
   this.model.state = this.userForm.value.inputState;
   this.model.zip = this.userForm.value.inputZip;
   this.model.comments = this.userForm.value.notes;
   this.model.pC_FirstName = this.userForm.value.pcFirstName;
   this.model.pC_MiddleName = this.userForm.value.pcMiddleName;
   this.model.pC_LastName = this.userForm.value.pcLastName;
   this.model.pC_Email = this.userForm.value.pcEmail;
   this.model.pC_OfficePhone = this.userForm.value.pcPhone;
   this.model.pC_CellPhone = this.userForm.value.pcCellPhone;   
   this.model.pC_Comments = this.userForm.value.pcNotes;

   console.log(this.model);
   console.log(this.userForm);
   console.log(this.userForm.valid);
 //  if (this.userForm.valid) {
  if(this.model.name==='')
 {
  this.ServerErrorMessage="Please enter a PIHP Region Name.";
 } else
 if(this.model.address1==='')
 {
  this.ServerErrorMessage="Please enter Address 1 for PIHP Region.";
 } else
 if(this.model.city==='')
 {
  this.ServerErrorMessage="Please enter City Name for PIHP Region.";
 } else
 if(this.model.state === 0)
 {
  this.ServerErrorMessage="Please enter State for PIHP Region.";
 } else
 if(this.model.zip === '')
 {
  this.ServerErrorMessage="Please enter State for PIHP Region.";
 } else
 if(this.model.pC_FirstName === '')
 {
  this.ServerErrorMessage="Please enter PC First Name for PIHP Region.";
 } else
 if(this.model.pC_LastName === '')
 {
  this.ServerErrorMessage="Please enter PC Last Name for PIHP Region.";
 } else
 if(this.model.pC_Email === '')
 {
  this.ServerErrorMessage="Please enter PC Email for PIHP Region.";
 } else
 if(this.model.pC_OfficePhone === '')
 {
  this.ServerErrorMessage="Please enter PC Phone number for PIHP Region.";
 } else
     this.addPihpRegionSubscription = this.pihpregionService.CreateCoordinatingAgency(this.model)
     .subscribe({
       next:(response) =>{
           console.log('PIHP Add successful');
           alert("PIHP region created successfully");
           this.router.navigateByUrl('/coordinatingagencies');
       },      
       error: (error) => {
        // Handle error here
        this.ServerErrorMessage = error.error;
      }
     }); 
 //   }
  }
  updateOptionalData() {
    const checkboxes = document.querySelectorAll<HTMLInputElement>('.optional-data');
    const selectedOptions = Array.from(checkboxes)
        .filter(checkbox => checkbox.checked)
        .map(checkbox => checkbox.id);
    this.model.optionalData = selectedOptions.join(',');
  }

  updateCounties() {
    const checkboxes = document.querySelectorAll<HTMLInputElement>('.counties');
    const selectedOptions = Array.from(checkboxes)
        .filter(checkbox => checkbox.checked)
        .map(checkbox => checkbox.id);
    this.model.counties = selectedOptions.join(',');
  }

  updateProgramNames() {
    const checkboxes = document.querySelectorAll<HTMLInputElement>('.program-names');
    const selectedOptions = Array.from(checkboxes)
        .filter(checkbox => checkbox.checked)
        .map(checkbox => checkbox.id);
    this.model.programNames = selectedOptions.join(',');
  }

  updateSchoolDistricts() {
    const checkboxes = document.querySelectorAll<HTMLInputElement>('.school-districts');
    const selectedOptions = Array.from(checkboxes)
        .filter(checkbox => checkbox.checked)
        .map(checkbox => checkbox.id);
    this.model.schoolDistricts = selectedOptions.join(',');
  }

  ngOnDestroy(): void {
    this.addPihpRegionSubscription?.unsubscribe();
  }
}
