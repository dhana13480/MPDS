export interface Program {
    id: number,
    coordinatingAgencyId: number,
    programNameId: number,
    programName: string
}