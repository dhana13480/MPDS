import { TestBed } from '@angular/core/testing';

import { PihpregionService } from './pihpregion.service';

describe('PihpregionsService', () => {
  let service: PihpregionService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PihpregionService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
