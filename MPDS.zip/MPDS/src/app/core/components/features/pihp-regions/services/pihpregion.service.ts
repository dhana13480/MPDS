import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs'; 
import { PihpRegion } from '../models/pihp-region.model';
import { AddPihpRegionRequest } from '../models/add-pihp-region-request.model';
import { UpdatePihpRegionRequest } from '../models/update-pihp-region.model';
import { Program } from '../models/program.model';
import { UserService } from '../../users/services/user.service';
import { County } from '../../models/county.model';
 
 
@Injectable({
  providedIn: 'root'
})
export class PihpregionService {
  storedUserStringified = sessionStorage.getItem('MiLoginUser')!;

  constructor(private http: HttpClient, private userService: UserService) { }
  GetAllCoordinatingAgencies(): Observable<PihpRegion[]> {
    let params = new HttpParams()

    if (this.storedUserStringified) {
      const userRoles = JSON.parse(this.storedUserStringified);
  
      params = new HttpParams()
      .set('userTypeId', userRoles.userTypeId||0)
      .set('coordinatingAgencyId', userRoles.coordinatingAgencyId||0)
      .set('providerAgencyId', userRoles.providerAgencyId||0)
      .set('permissions', userRoles.permissions||'');
    }  
console.log(this.http.get<PihpRegion[]> (`${environment.apiBaseUrl}/api/coordinatingagencies/GetAllCoordinatingAgencies`, { params }));
    return this.http.get<PihpRegion[]> (`${environment.apiBaseUrl}/api/coordinatingagencies/GetAllCoordinatingAgencies`, { params });
  }

  GetCoordinatingAgencyById(id:string): Observable<PihpRegion>{
    return this.http.get<PihpRegion>(`${environment.apiBaseUrl}/api/CoordinatingAgencies/${id}`);
  }

  GetCountiesByCoordinatingAgencyId(id:string): Observable<County[]>{
    return this.http.get<County[]>(`${environment.apiBaseUrl}/api/CoordinatingAgencies/CountiesByCoordinatingAgencyId/${id}`);
  }
   
  CreateCoordinatingAgency(model: AddPihpRegionRequest) : Observable<void> {
    return this.http.post<void>(`${environment.apiBaseUrl}/api/coordinatingagencies`, model);
  } 
  
  GetProgramNames(): Observable<Program[]>{
   // console.log(`${environment.apiBaseUrl}/api/MasterProgramName`);
    return this.http.get<Program[]>(`${environment.apiBaseUrl}/api/MasterProgramName`);
  }

  GetProgramNamesByCoordinatingAgencyId(id:string): Observable<Program[]>{
    console.log(`${environment.apiBaseUrl}/api/ActivityGroup/CoordinatingAgencyProgramName/coordinatingAgency/${id}`);
    return this.http.get<Program[]>(`${environment.apiBaseUrl}/api/ActivityGroup/CoordinatingAgencyProgramName/coordinatingAgency/${id}`);
  }

  UpdatePihpRegion(id:string, updatePihpRegionRequest:UpdatePihpRegionRequest): Observable<PihpRegion>{
    return this.http.put<PihpRegion>(`${environment.apiBaseUrl}/api/coordinatingagencies/${id}`, updatePihpRegionRequest);
  }
  DeActivatePihpRegion(id:string):  Observable<PihpRegion> {    
    //https://localhost:7164/api/CoordinatingAgencies/deactivate/3
    console.log (`${environment.apiBaseUrl}/api/CoordinatingAgencies/deactivate/${id}` );
    return this.http.put<PihpRegion>(`${environment.apiBaseUrl}/api/CoordinatingAgencies/deactivate/${id}`, id );
  }
  DeletePihpRegion(id:string):  Observable<PihpRegion> {    
   // https://localhost:7164/api/CoordinatingAgencies/DeActivateCoordinatingAgency/3
    console.log (`${environment.apiBaseUrl}/api/CoordinatingAgencies/DeactivateCoordinatingAgency/${id}` );
    return this.http.post<PihpRegion>(`${environment.apiBaseUrl}/api/CoordinatingAgencies/DeActivateCoordinatingAgency/${id}`, id);
  }
  
}
