import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PihpregionService } from '../services/pihpregion.service';
import { Observable, Subscription } from 'rxjs';
import { PihpRegion } from '../models/pihp-region.model';
import { UpdatePihpRegionRequest } from '../models/update-pihp-region.model';
import { County } from '../../models/county.model';
import { ProgramName } from '../../models/program-name.model';
import { SchoolDistrict } from '../../models/school-district.model';
import { CountyService } from '../../services/counties.service';
import { ProgramNameService } from '../../services/program-names.service';
import { SchoolDistrictService } from '../../services/school-districts.service';
import { Validators } from '@angular/forms';

@Component({
  selector: 'app-edit-pihp-region',
  templateUrl: './edit-pihp-region.component.html',
  styleUrls: ['./edit-pihp-region.component.css']
})
export class EditPihpRegionComponent implements OnInit, OnDestroy {
  ServerErrorMessage?: string='';
  id: string | null = null;
  paramsSubscription?: Subscription;
  editPihpRegionSubscription?: Subscription;
  pihpRegion?: PihpRegion;
  countyList$?: Observable<County[]>;
  selectedCountyIds: number[] = [];
  programNameList$?: Observable<ProgramName[]>;
  selectedProgramNameIds: number[] = [];
  schoolDistrictList$?: Observable<SchoolDistrict[]>;
  selectedSchoolDistrictIds: number[] = [];
  formValue:  { 
    id: number;
    name:string;
    isActive:boolean;
    officePhone:string;
    fax:string;
    address1:string;
    address2:string;   
    city:string;
    state:number;
    zip:string;
    comments:string;
    addressComments:string;
    pc_FirstName:string;
    pc_MiddleName:string;
    pc_LastName:string;
    pc_Email:string;
    pc_OfficePhone:string;
    pc_CellPhone:string;
    pc_Comments:string;    
    createdBy:number;
    updatedBy:number;
    optionalData: string;
    counties: string;
    programNames: string;
    schoolDistricts: string;
  } = {
    id: 0,
    name: '',
    isActive: false,
    officePhone: '',
    fax: '',
    address1: '',
    address2: '',
    city: '',
    state: 0,
    zip: '',
    comments: '',
    addressComments: '',
    pc_FirstName: '',
    pc_MiddleName: '',
    pc_LastName: '',
    pc_Email: '',
    pc_OfficePhone: '',
    pc_CellPhone: '',
    pc_Comments: '',
    createdBy: 0,
    updatedBy: 0,
    optionalData: '',
    counties: '',
    programNames: '',
    schoolDistricts: ''
  };
  
  constructor (
    private route: ActivatedRoute,
    private pihpregion: PihpregionService,
    private countyService: CountyService,
    private programNameService: ProgramNameService,
    private schoolDistrictService: SchoolDistrictService,
    private router: Router) {
  }

  ngOnInit(): void {
    this.countyList$ = this.countyService.GetAllCounties();
    this.programNameList$ = this.programNameService.GetAllProgramNames();
    this.schoolDistrictList$ = this.schoolDistrictService.GetAllSchoolDistricts();

    this.paramsSubscription = this.route.paramMap.subscribe({
      next: (params) => {
        this.id = params.get('id');
        if (this.id) {

          this.pihpregion.GetCoordinatingAgencyById(this.id).subscribe({
            next: (response) => {
              this.pihpRegion = response;

              this.selectedCountyIds = this.pihpRegion.counties ? this.pihpRegion.counties.split(',').map(Number) : []
              this.selectedProgramNameIds = this.pihpRegion.programNames ? this.pihpRegion.programNames.split(',').map(Number) : []
              this.selectedSchoolDistrictIds = this.pihpRegion.schoolDistricts ? this.pihpRegion.schoolDistricts.split(',').map(Number) : []
              if (!this.pihpRegion.optionalData) {
                this.pihpRegion.optionalData = ''
              }
  
              // Initialize formValue with the data from pihpRegion
              this.formValue = {
                id: this.pihpRegion.id,
                name: this.pihpRegion.name ,
                isActive: this.pihpRegion.isActive,
                officePhone: this.pihpRegion.officePhone,
                fax: this.pihpRegion.fax,
                address1: this.pihpRegion.address1,
                address2: this.pihpRegion.address2,
                city: this.pihpRegion.city,
                state: this.pihpRegion.state,
                zip: this.pihpRegion.zip,
                comments: this.pihpRegion.comments,
                addressComments: this.pihpRegion.addressComments,
                pc_FirstName: this.pihpRegion.pc_FirstName,
                pc_MiddleName: this.pihpRegion.pc_MiddleName,
                pc_LastName: this.pihpRegion.pc_LastName,
                pc_Email: this.pihpRegion.pc_Email,
                pc_OfficePhone: this.pihpRegion.pc_OfficePhone,
                pc_CellPhone: this.pihpRegion.pc_CellPhone,
                pc_Comments: this.pihpRegion.pc_Comments,
                createdBy: this.pihpRegion.createdBy,
                updatedBy: this.pihpRegion.updatedBy,
                optionalData: this.pihpRegion.optionalData,
                counties: this.pihpRegion.counties,
                programNames: this.pihpRegion.programNames,
                schoolDistricts: this.pihpRegion.schoolDistricts
              };
            },
          });
        }
      },
    });
  }

   ngOnDestroy(): void {
    this.paramsSubscription?.unsubscribe();
    this.editPihpRegionSubscription?.unsubscribe();  
    }

    onFormSubmit():void{
      
      const updatePihpRegionRequest: UpdatePihpRegionRequest= {
        name: this.formValue?.name?? '' ,         
        isActive: this.formValue?.isActive?? true,
        officePhone: this.formValue?.officePhone?? '', 
        fax: this.formValue?.fax?? '', 
        address1: this.formValue?.address1?? '', 
        address2: this.formValue?.address2?? '', 
        city: this.formValue?.city?? '', 
        state: this.formValue?.state?? 30, 
        zip:this.formValue?.zip?? '', 
        comments: this.formValue?.comments?? '', 
        addressComments: this.formValue?.addressComments?? '', 
        pc_FirstName: this.formValue?.pc_FirstName?? '', 
        pc_MiddleName: this.formValue?.pc_MiddleName?? '', 
        pc_LastName: this.formValue?.pc_LastName?? '', 
        pc_Email: this.formValue?.pc_Email?? '', 
        pc_OfficePhone:this.formValue?.pc_OfficePhone?? '', 
        pc_CellPhone: this.formValue?.pc_CellPhone?? '', 
        pc_Comments: this.formValue?.pc_Comments?? '', 
        createdBy: this.formValue?.createdBy?? 0,
        //creationDate:this.pihpRegion?.creationDate?? '',  
        updatedBy: Number(sessionStorage.getItem("MPDSUserId"))?? 0,
        //updationDate: this.pihpRegion?.creationDate?? '',
        optionalData: this.formValue?.optionalData ?? '',
        counties: this.formValue?.counties,
        programNames: this.formValue?.programNames,
        schoolDistricts: this.formValue?.schoolDistricts  
      };
    
      if(this.id){
        console.log(updatePihpRegionRequest)
        if(updatePihpRegionRequest.name==='')
        {
         this.ServerErrorMessage="Please enter a PIHP Region Name.";
        } else
        if(updatePihpRegionRequest.address1==='')
        {
         this.ServerErrorMessage="Please enter Address 1 for PIHP Region.";
        } else
        if(updatePihpRegionRequest.city==='')
        {
         this.ServerErrorMessage="Please enter City Name for PIHP Region.";
        } else
        if(updatePihpRegionRequest.state === 0)
        {
         this.ServerErrorMessage="Please enter State for PIHP Region.";
        } else
        if(updatePihpRegionRequest.zip === '')
        {
         this.ServerErrorMessage="Please enter State for PIHP Region.";
        } else
        if(updatePihpRegionRequest.pc_FirstName === '')
        {
         this.ServerErrorMessage="Please enter PC First Name for PIHP Region.";
        } else
        if(updatePihpRegionRequest.pc_LastName === '')
        {
         this.ServerErrorMessage="Please enter PC Last Name for PIHP Region.";
        } else
        if(updatePihpRegionRequest.pc_Email === '')
        {
         this.ServerErrorMessage="Please enter PC Email for PIHP Region.";
        } else
        if(updatePihpRegionRequest.pc_OfficePhone === '')
        {
         this.ServerErrorMessage="Please enter PC Phone number for PIHP Region.";
        } else

        this.editPihpRegionSubscription =  this.pihpregion.UpdatePihpRegion(this.id, updatePihpRegionRequest)
      .subscribe({
        next:(response) =>{
          console.log(response);
          alert("PIHP updated Saved successfully");
          this.router.navigateByUrl('/coordinatingagencies')
        },
        error: (error) => {
          // Handle error here
          this.ServerErrorMessage = error.error;
        }
      })
      ;
      }
    }
    updateOptionalData() {
      const checkboxes = document.querySelectorAll<HTMLInputElement>('.optional-data');
      const selectedOptions = Array.from(checkboxes)
          .filter(checkbox => checkbox.checked)
          .map(checkbox => checkbox.id);
      this.formValue.optionalData = selectedOptions.join(',');
    }

    updateCounties() {
      const checkboxes = document.querySelectorAll<HTMLInputElement>('.counties');
      const selectedOptions = Array.from(checkboxes)
          .filter(checkbox => checkbox.checked)
          .map(checkbox => checkbox.id);
      this.formValue.counties = selectedOptions.join(',');
    }
  
    updateProgramNames() {
      const checkboxes = document.querySelectorAll<HTMLInputElement>('.program-names');
      const selectedOptions = Array.from(checkboxes)
          .filter(checkbox => checkbox.checked)
          .map(checkbox => checkbox.id);
      this.formValue.programNames = selectedOptions.join(',');
    }
  
    updateSchoolDistricts() {
      const checkboxes = document.querySelectorAll<HTMLInputElement>('.school-districts');
      const selectedOptions = Array.from(checkboxes)
          .filter(checkbox => checkbox.checked)
          .map(checkbox => checkbox.id);
      this.formValue.schoolDistricts = selectedOptions.join(',');
    }
}
