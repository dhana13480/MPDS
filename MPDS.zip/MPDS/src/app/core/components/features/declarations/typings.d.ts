declare module 'jquery-datepicker';
declare module 'jquery-datepicker/i18n/jquery.ui.datepicker-ja';

interface JQuery {
    datepicker(options?: any): JQuery;
}

interface JQueryStatic {
    datepicker: any; // Use 'any' if you don't have type information for datepicker
}