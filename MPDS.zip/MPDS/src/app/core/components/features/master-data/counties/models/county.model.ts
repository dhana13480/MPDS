export interface County{
    id: number,
    county: string,
    description: string,
    isActive: boolean,
    createdBy: number,
    creationDate: string,
    updatedBy: number,
    updationDate: string
}