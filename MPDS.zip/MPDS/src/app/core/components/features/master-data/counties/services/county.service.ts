import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs'; 
import { County } from '../models/county.model';
 
 
@Injectable({
  providedIn: 'root'
})
export class CountyService {
  storedUserStringified = sessionStorage.getItem('MiLoginUser')!;
  constructor(private http: HttpClient) { }
  
  GetAllCounties() : Observable<County[]> { 
    return this.http.get<County[]>(`${environment.apiBaseUrl}/api/county`);
  }

  CreateCounty(model: County) : Observable<void> {
    return this.http.post<void>(`${environment.apiBaseUrl}/api/County`, model);
  }

  GetCountyById(id:string): Observable<County>{
    return this.http.get<County>(`${environment.apiBaseUrl}/api/County/${id}`);
  }
   

//   GetProgramNamesByCoordinatingAgencyId(id:string): Observable<Program[]>{
//     return this.http.get<Program[]>(`${environment.apiBaseUrl}/api/CoordinatingAgencyProgramName/coordinatinatingagency/${id}`);
//   }

//   UpdatePihpRegion(id:string, updatePihpRegionRequest:UpdatePihpRegionRequest): Observable<PihpRegion>{
//     return this.http.put<PihpRegion>(`${environment.apiBaseUrl}/api/coordinatingagencies/${id}`, updatePihpRegionRequest);
//   }
  
}