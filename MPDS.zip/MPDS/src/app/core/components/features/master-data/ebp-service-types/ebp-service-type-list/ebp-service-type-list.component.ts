import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { FuncsService } from '../../../services/funcs.service';
import { Router } from '@angular/router';
import { switchMap, catchError, map } from 'rxjs/operators';
import { of } from 'rxjs';
import { EbpServiceTypeService } from '../services/ebpServiceType.service';
import { EbpServiceType } from '../models/ebpServiceType.model';
import { MiLoginUserModel } from '../../../users/models/milogin-user-model';
import { UserService } from '../../../users/services/user.service';

@Component({
  selector: 'app-ebp-service-type-list',
  templateUrl: './ebp-service-type-list.component.html',
  styleUrls: ['./ebp-service-type-list.component.css']
})
export class EbpServiceTypeListComponent {
  ebpServiceTypelist$?: Observable<EbpServiceType[]>;
  phone$?: Observable<FuncsService[]>;
  MiLoginUser?: MiLoginUserModel | null;
  currentDate: string = new Date().toISOString();
  formSubmitted = false;
  formValue: { id: number, name: string, description: string, status: string } = { id: 0, name: '', description: '', status: 'All' };
  sortConfig = {
    column: '',
    direction: 'asc', // default sorting direction
  };

  constructor(
    private ebpServiceTypeService: EbpServiceTypeService,
    private router: Router,
    private userService: UserService,
    private funcs: FuncsService 
    ){}
  ngOnInit():void{
    this.userService.user$.subscribe(user => {
      console.log(user)
      this.MiLoginUser = user;       
    });
    this.ebpServiceTypelist$ = this.ebpServiceTypeService.GetAllEbpServiceTypes();
  }
    
  onFormSubmit() {

  }


  onAdd(serviceTypeName: string, description: string) {
    if (serviceTypeName && description) {
      var newService = {
        id: 0,
        ebpServiceType: serviceTypeName,
        description: description,
        isActive: true
      }
  
  
      this.ebpServiceTypeService.CreateEbpServiceType(newService)
      .subscribe({
        next:(response) => {
          this.formValue.name = ""
          this.formValue.description = ""
          this.router.navigateByUrl(`/ebpservicetypes`);
        }
      });
    } 
  }
  isSessionActive(): boolean {
    return this.userService.isUserAuthenticated();
  }
  onEditIconClick(ebpServiceType: EbpServiceType) {
    this.formValue.name = ebpServiceType.ebpServiceType
    this.formValue.description = ebpServiceType.description
    this.formValue.id = ebpServiceType.id
  }

  updateEbpServiceType(ebpServiceTypeName: string, description: string) {
    if (ebpServiceTypeName && description) {
      var updatedEbpServiceType = {
        id: 0,
        ebpServiceType: ebpServiceTypeName,
        description: description,
        isActive: true
      }
  
  
      // this.countyService.CreateCounty(newCounty)
      // .subscribe({
      //   next:(response) => {
          // this.formValue.name = ""
          // this.formValue.description = ""
          // this.router.navigateByUrl(`/counties`);
      //   }
      // });
    } 
  }

  sort(column: string) {
    if (this.sortConfig.column === column) {
      // If the same column is clicked again, toggle the sort direction
      this.sortConfig.direction = this.sortConfig.direction === 'asc' ? 'desc' : 'asc';
    } else {
      // If a new column is clicked, set it as the active column and default to ascending
      this.sortConfig.column = column;
      this.sortConfig.direction = 'asc';
    }

    // Now, sort the data based on the sort configuration
    this.ebpServiceTypelist$ = this.ebpServiceTypelist$?.pipe(
      map((data) => this.sortData(data))
    );
  }

  private sortData(data: EbpServiceType[]): EbpServiceType[] {
    const { column, direction } = this.sortConfig;

    if (!column) {
      return data;
    }

    return data.slice().sort((a, b) => {
      const aValue = this.getPropertyValue(a, column);
      const bValue = this.getPropertyValue(b, column);

      
    // For boolean values, explicitly cast to numbers before performing subtraction
    if (typeof aValue === 'boolean') {
      return direction === 'asc' ? (aValue as unknown as number) - (bValue as number) : (bValue as number) - (aValue as unknown as number);
    }


      if (typeof aValue === 'string') {
        return direction === 'asc' ? aValue.localeCompare(bValue) : bValue.localeCompare(aValue);
      } else if (typeof aValue === 'number') {
        return direction === 'asc' ? aValue - bValue : bValue - aValue;
      } else {
        return 0; // Add more cases as needed for other data types
      }
    });
  }

  private getPropertyValue(object: any, column: string): any {
    // Customize this part based on your data structure
    switch (column) {
      case 'name':
        return object.name;
      case 'officePhone':
        return object.officePhone;
      case 'isActive':
        return object.isActive;
      // Add more cases for other columns
      default:
        return null;
    }
  }
}
