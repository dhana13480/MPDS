import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs'; 
import { EbpServiceType } from '../models/ebpServiceType.model';
 
 
@Injectable({
  providedIn: 'root'
})
export class EbpServiceTypeService {
  storedUserStringified = sessionStorage.getItem('MiLoginUser')!;
  constructor(private http: HttpClient) { }
  
  GetAllEbpServiceTypes() : Observable<EbpServiceType[]> { 
    return this.http.get<EbpServiceType[]>(`${environment.apiBaseUrl}/api/MasterEBPServiceType`);
  }
//   GetCoordinatingAgencyById(id:string): Observable<PihpRegion>{
//     return this.http.get<PihpRegion>(`${environment.apiBaseUrl}/api/CoordinatingAgencies/${id}`);
//   }
   
  CreateEbpServiceType(model: EbpServiceType) : Observable<void> {
    return this.http.post<void>(`${environment.apiBaseUrl}/api/MasterEBPServiceType`, model);
  } 

//   GetProgramNamesByCoordinatingAgencyId(id:string): Observable<Program[]>{
//     return this.http.get<Program[]>(`${environment.apiBaseUrl}/api/CoordinatingAgencyProgramName/coordinatinatingagency/${id}`);
//   }

//   UpdatePihpRegion(id:string, updatePihpRegionRequest:UpdatePihpRegionRequest): Observable<PihpRegion>{
//     return this.http.put<PihpRegion>(`${environment.apiBaseUrl}/api/coordinatingagencies/${id}`, updatePihpRegionRequest);
//   }
  
}