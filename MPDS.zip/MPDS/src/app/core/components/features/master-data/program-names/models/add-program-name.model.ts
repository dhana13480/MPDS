export interface AddProgramName {
    coordinatingAgencyId: number,
    programNameId: number,
    name: string,
    description: string,
    createdBy: number,
    updatedBy: number,
    creationDate: string,
    updationDate: string,
    deactivatedDate: string
  }