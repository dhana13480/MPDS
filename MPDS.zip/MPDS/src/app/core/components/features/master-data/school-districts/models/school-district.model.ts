export interface SchoolDistrict{
    id: number,
    schoolDistrict: string,
    description: string,
    isActive: boolean,
    countyId: number
}