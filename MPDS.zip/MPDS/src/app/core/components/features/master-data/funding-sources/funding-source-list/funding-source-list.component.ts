import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { FuncsService } from '../../../services/funcs.service';
import { Router } from '@angular/router';
import { switchMap, catchError, map } from 'rxjs/operators';
import { of } from 'rxjs';
import { FundingSource } from '../models/funding-source.model';
import { FundingSourceService } from '../services/funding-source.service';
import { UserService } from '../../../users/services/user.service';
import { MiLoginUserModel } from '../../../users/models/milogin-user-model';

@Component({
  selector: 'app-funding-source-list',
  templateUrl: './funding-source-list.component.html',
  styleUrls: ['./funding-source-list.component.css']
})
export class FundingSourceListComponent {
  fundingSourcelist$?: Observable<FundingSource[]>;
  phone$?: Observable<FuncsService[]>;
  currentDate: string = new Date().toISOString();
  formSubmitted = false; 
  MiLoginUser?: MiLoginUserModel | null;
  formValue: { id: number, fundingSource: string, description: string, status: string } = { id: 0, fundingSource: '', description: '', status: 'All' };
  sortConfig = {
    column: '',
    direction: 'asc', // default sorting direction
  };

  constructor(
    private fundingSourceService: FundingSourceService,
    private router: Router,
    private userService: UserService,
    private funcs: FuncsService 
    ){}
  ngOnInit():void{
    this.userService.user$.subscribe(user => {
      console.log(user)
      this.MiLoginUser = user;      
    });
    this.fundingSourcelist$ = this.fundingSourceService.GetAllFundingSources();
  }
    
  onFormSubmit() {

  }
  isSessionActive(): boolean {
    return this.userService.isUserAuthenticated();
  }
  updateFund(fundingSource: string, description: string) {
    if (fundingSource && description) {
      var updatedFund = {
        id: this.formValue.id,
        fundingSource: fundingSource,
        description: description,
        isActive: true,
        createdBy: 0,
        creationDate: this.currentDate,
        updatedBy: Number(  sessionStorage.getItem("MPDSUserId")),
        updationDate: this.currentDate
      }
      
      this.fundingSourceService.UpdateFundSource(updatedFund)
      .subscribe({
        next:(response) => {
          console.log(response)
          this.formValue.fundingSource = ""
          this.formValue.description = ""
          this.router.navigateByUrl(`/funding-sources`);
          
        }
      });
      alert("Fund Source update successful");
      this.router.navigateByUrl(`/funding-sources`);

    }
  }

  onAdd(fundingSource: string, description: string) {
    if (fundingSource && description) {
      var newFund = {
        id: 0,
        fundingSource: fundingSource,
        description: description,
        isActive: true,
        createdBy: Number(  sessionStorage.getItem("MPDSUserId")),
        creationDate: this.currentDate,
        updatedBy: Number(  sessionStorage.getItem("MPDSUserId")),
        updationDate: this.currentDate
      }
  
  
      this.fundingSourceService.CreateFund(newFund)
      .subscribe({
        next:(response) => {
          this.formValue.fundingSource = ""
          this.formValue.description = ""
          this.router.navigateByUrl(`/funding-sources`);
        }
      });
    } 
  }
  
  onEditIconClick(fundingSource: FundingSource) {
    this.formValue.fundingSource = fundingSource.fundingSource
    this.formValue.description = fundingSource.description
    this.formValue.id = fundingSource.id
  }

  
  sort(column: string) {
    if (this.sortConfig.column === column) {
      // If the same column is clicked again, toggle the sort direction
      this.sortConfig.direction = this.sortConfig.direction === 'asc' ? 'desc' : 'asc';
    } else {
      // If a new column is clicked, set it as the active column and default to ascending
      this.sortConfig.column = column;
      this.sortConfig.direction = 'asc';
    }

    // Now, sort the data based on the sort configuration
    this.fundingSourcelist$ = this.fundingSourcelist$?.pipe(
      map((data) => this.sortData(data))
    );
  }

  private sortData(data: FundingSource[]): FundingSource[] {
    const { column, direction } = this.sortConfig;

    if (!column) {
      return data;
    }

    return data.slice().sort((a, b) => {
      const aValue = this.getPropertyValue(a, column);
      const bValue = this.getPropertyValue(b, column);

      
    // For boolean values, explicitly cast to numbers before performing subtraction
    if (typeof aValue === 'boolean') {
      return direction === 'asc' ? (aValue as unknown as number) - (bValue as number) : (bValue as number) - (aValue as unknown as number);
    }


      if (typeof aValue === 'string') {
        return direction === 'asc' ? aValue.localeCompare(bValue) : bValue.localeCompare(aValue);
      } else if (typeof aValue === 'number') {
        return direction === 'asc' ? aValue - bValue : bValue - aValue;
      } else {
        return 0; // Add more cases as needed for other data types
      }
    });
  }

  private getPropertyValue(object: any, column: string): any {
    // Customize this part based on your data structure
    switch (column) {
      case 'fundingSource':
        return object.fundingSource;      
      case 'isActive':
        return object.isActive;
      // Add more cases for other columns
      default:
        return null;
    }
  }
}
