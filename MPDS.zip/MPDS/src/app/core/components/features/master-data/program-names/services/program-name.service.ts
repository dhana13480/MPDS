import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs'; 
import { ProgramName } from '../models/program-name.model';
import { AddProgramName } from '../models/add-program-name.model';
import { UpdateProgramName } from '../models/update-program-name.model';
 
 
@Injectable({
  providedIn: 'root'
})
export class ProgramNameService {

  constructor(private http: HttpClient) { }
  
  GetAllProgramNames() : Observable<ProgramName[]> { 
    return this.http.get<ProgramName[]>(`${environment.apiBaseUrl}/api/MasterProgramName`);
  }
//   GetCoordinatingAgencyById(id:string): Observable<PihpRegion>{
//     return this.http.get<PihpRegion>(`${environment.apiBaseUrl}/api/CoordinatingAgencies/${id}`);
//   }
   
  CreateProgramName(model: AddProgramName) : Observable<void> {
    return this.http.post<void>(`${environment.apiBaseUrl}/api/MasterProgramName`, model);
  } 

//   GetProgramNamesByCoordinatingAgencyId(id:string): Observable<Program[]>{
//     return this.http.get<Program[]>(`${environment.apiBaseUrl}/api/CoordinatingAgencyProgramName/coordinatinatingagency/${id}`);
//   }

  UpdateProgramName(id:string, updateProgramName:UpdateProgramName): Observable<ProgramName>{
    return this.http.put<ProgramName>(`${environment.apiBaseUrl}/api/MasterProgramName/${id}`, updateProgramName);
  }
  
}
