export interface ProgramName {
    id: number;
    name: string | null;
    description: string;
    isActive: boolean;
    deactivatedBy: number | null;
    createdBy: number;
    creationDate: string | null;
    updatedBy: number | null;
    updationDate: string | null;
    deactivatedDate: string | null;
  }