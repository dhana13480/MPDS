export interface EbpServiceType{
    id: number,
    ebpServiceType: string,
    description: string,
    isActive: boolean
}