import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs'; 
import { SchoolDistrict } from '../models/school-district.model';
 
 
@Injectable({
  providedIn: 'root'
})
export class SchoolDistrictService {

  constructor(private http: HttpClient) { }
  
  GetAllSchoolDistricts() : Observable<SchoolDistrict[]> { 
    return this.http.get<SchoolDistrict[]>(`${environment.apiBaseUrl}/MasterSchoolDistrict`);
  }
//   GetCoordinatingAgencyById(id:string): Observable<PihpRegion>{
//     return this.http.get<PihpRegion>(`${environment.apiBaseUrl}/api/CoordinatingAgencies/${id}`);
//   }
   
  CreateSchoolDistrict(model: SchoolDistrict) : Observable<void> {
    return this.http.post<void>(`${environment.apiBaseUrl}/api/MasterSchoolDistrict`, model);
  } 

//   GetProgramNamesByCoordinatingAgencyId(id:string): Observable<Program[]>{
//     return this.http.get<Program[]>(`${environment.apiBaseUrl}/api/CoordinatingAgencyProgramName/coordinatinatingagency/${id}`);
//   }

//   UpdatePihpRegion(id:string, updatePihpRegionRequest:UpdatePihpRegionRequest): Observable<PihpRegion>{
//     return this.http.put<PihpRegion>(`${environment.apiBaseUrl}/api/coordinatingagencies/${id}`, updatePihpRegionRequest);
//   }
  
}