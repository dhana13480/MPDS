import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs'; 
import { FundingSource } from '../models/funding-source.model';
import { UpdateFundingSource } from '../models/update-funding-source.model';
 
 
@Injectable({
  providedIn: 'root'
})
export class FundingSourceService {
  storedUserStringified = sessionStorage.getItem('MiLoginUser')!;
  constructor(private http: HttpClient) { }
  
  GetAllFundingSources() : Observable<FundingSource[]> { 
    return this.http.get<FundingSource[]>(`${environment.apiBaseUrl}/api/FundingSource/GetFundingSource`);
  }
  CreateFund(model: FundingSource) : Observable<void> {
    return this.http.post<void>(`${environment.apiBaseUrl}/api/FundingSource/Create`, model);
  }
//   GetCoordinatingAgencyById(id:string): Observable<PihpRegion>{
//     return this.http.get<PihpRegion>(`${environment.apiBaseUrl}/api/CoordinatingAgencies/${id}`);
//   }
   
//   CreateCoordinatingAgency(model: AddPihpRegionRequest) : Observable<void> {
//     return this.http.post<void>(`${environment.apiBaseUrl}/api/coordinatingagencies`, model);
//   } 

//   GetProgramNamesByCoordinatingAgencyId(id:string): Observable<Program[]>{
//     return this.http.get<Program[]>(`${environment.apiBaseUrl}/api/CoordinatingAgencyProgramName/coordinatinatingagency/${id}`);
//   }

    
   UpdateFundSource( UpdateFundSource:UpdateFundingSource): Observable<FundingSource>{
    return this.http.put<FundingSource>(`${environment.apiBaseUrl}/api/FundingSource/updateFundSource/`, UpdateFundSource);
  }
}