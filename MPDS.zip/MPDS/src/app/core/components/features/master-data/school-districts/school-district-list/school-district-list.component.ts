import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { FuncsService } from '../../../services/funcs.service';
import { Router } from '@angular/router';
import { switchMap, catchError, map } from 'rxjs/operators';
import { of } from 'rxjs';
import { SchoolDistrict } from '../models/school-district.model';
import { SchoolDistrictService } from '../services/school-district.service';
import { CountyService } from '../../counties/services/county.service';
import { County } from '../../counties/models/county.model';
@Component({
  selector: 'app-school-district-list',
  templateUrl: './school-district-list.component.html',
  styleUrls: ['./school-district-list.component.css']
})
export class SchoolDistrictListComponent {
  schoolDistrictlist$?: Observable<SchoolDistrict[]>;
  countylist$?: Observable<County[]>;
  phone$?: Observable<FuncsService[]>;
  currentDate: string = new Date().toISOString();
  formSubmitted = false;
  formValue: { id: number, name: string, description: string, countyId: number, status: string } = { id: 0, name: '', description: '', countyId: 0, status: 'All' };
  sortConfig = {
    column: '',
    direction: 'asc', // default sorting direction
  };

  constructor(
    private schoolDistrictService: SchoolDistrictService,
    private countyService: CountyService,
    private router: Router,
    private funcs: FuncsService 
    ){}
  ngOnInit():void{
    this.schoolDistrictlist$ = this.schoolDistrictService.GetAllSchoolDistricts();
    this.countylist$ = this.countyService.GetAllCounties();
  }
    
  onFormSubmit() {

  }

  onAdd(schoolDistrictName: string, description: string) {
    if (schoolDistrictName && description) {
      var newSchoolDistrict = {
        id: 0,
        schoolDistrict: schoolDistrictName,
        description: description,
        isActive: true,
        countyId: 0
      }
  
  
      this.schoolDistrictService.CreateSchoolDistrict(newSchoolDistrict)
      .subscribe({
        next:(response) => {
          this.formValue.name = ""
          this.formValue.description = ""
          this.router.navigateByUrl(`/counties`);
        }
      });
    } 
  }

  onEditIconClick(schoolDistrict: SchoolDistrict) {
    this.formValue.name = schoolDistrict.schoolDistrict
    this.formValue.description = schoolDistrict.description
    this.formValue.id = schoolDistrict.id
    this.formValue.countyId = schoolDistrict.countyId
  }

  updateCounty(schoolDistrictName: string, description: string) {
    if (schoolDistrictName && description) {
      var updatedSchoolDistrict = {
        id: this.formValue.id,
        schoolDistrict: schoolDistrictName,
        description: description,
        isActive: true,
        countyId: this.formValue.countyId
      }
  
  
      // this.countyService.CreateCounty(newCounty)
      // .subscribe({
      //   next:(response) => {
          // this.formValue.name = ""
          // this.formValue.description = ""
          // this.router.navigateByUrl(`/counties`);
      //   }
      // });
    } 
  }

  sort(column: string) {
    if (this.sortConfig.column === column) {
      // If the same column is clicked again, toggle the sort direction
      this.sortConfig.direction = this.sortConfig.direction === 'asc' ? 'desc' : 'asc';
    } else {
      // If a new column is clicked, set it as the active column and default to ascending
      this.sortConfig.column = column;
      this.sortConfig.direction = 'asc';
    }

    // Now, sort the data based on the sort configuration
    this.schoolDistrictlist$ = this.schoolDistrictlist$?.pipe(
      map((data) => this.sortData(data))
    );
  }

  private sortData(data: SchoolDistrict[]): SchoolDistrict[] {
    const { column, direction } = this.sortConfig;

    if (!column) {
      return data;
    }

    return data.slice().sort((a, b) => {
      const aValue = this.getPropertyValue(a, column);
      const bValue = this.getPropertyValue(b, column);

      
    // For boolean values, explicitly cast to numbers before performing subtraction
    if (typeof aValue === 'boolean') {
      return direction === 'asc' ? (aValue as unknown as number) - (bValue as number) : (bValue as number) - (aValue as unknown as number);
    }


      if (typeof aValue === 'string') {
        return direction === 'asc' ? aValue.localeCompare(bValue) : bValue.localeCompare(aValue);
      } else if (typeof aValue === 'number') {
        return direction === 'asc' ? aValue - bValue : bValue - aValue;
      } else {
        return 0; // Add more cases as needed for other data types
      }
    });
  }

  private getPropertyValue(object: any, column: string): any {
    // Customize this part based on your data structure
    switch (column) {
      case 'name':
        return object.name;
      case 'officePhone':
        return object.officePhone;
      case 'isActive':
        return object.isActive;
      // Add more cases for other columns
      default:
        return null;
    }
  }
}
