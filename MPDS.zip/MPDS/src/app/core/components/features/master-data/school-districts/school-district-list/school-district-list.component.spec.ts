import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SchoolDistrictListComponent } from './school-district-list.component';

describe('SchoolDistrictListComponent', () => {
  let component: SchoolDistrictListComponent;
  let fixture: ComponentFixture<SchoolDistrictListComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SchoolDistrictListComponent]
    });
    fixture = TestBed.createComponent(SchoolDistrictListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
