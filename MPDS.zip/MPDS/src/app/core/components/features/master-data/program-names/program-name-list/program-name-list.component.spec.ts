import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProgramNameListComponent } from './program-name-list.component';

describe('ProgramNameListComponent', () => {
  let component: ProgramNameListComponent;
  let fixture: ComponentFixture<ProgramNameListComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ProgramNameListComponent]
    });
    fixture = TestBed.createComponent(ProgramNameListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
