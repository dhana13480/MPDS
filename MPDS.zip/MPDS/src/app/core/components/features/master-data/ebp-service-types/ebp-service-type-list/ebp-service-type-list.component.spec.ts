import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EbpServiceTypeListComponent } from './ebp-service-type-list.component';

describe('EbpServiceTypeListComponent', () => {
  let component: EbpServiceTypeListComponent;
  let fixture: ComponentFixture<EbpServiceTypeListComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [EbpServiceTypeListComponent]
    });
    fixture = TestBed.createComponent(EbpServiceTypeListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
