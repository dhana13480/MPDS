import { Component } from '@angular/core';
import { MiLoginUserModel } from '../features/users/models/milogin-user-model';
import { UserService } from '../features/users/services/user.service';
@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent {
  MiLoginUser?: MiLoginUserModel | null;

  constructor(private userService: UserService){}
  ngOnInit(): void {
    this.userService.user$.subscribe(user => {
      console.log(user)
      this.MiLoginUser = user;      
    });
  }
}
