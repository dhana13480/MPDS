import { Injectable } from '@angular/core';
import { AppInfoService } from './app-info/app-info.service';

@Injectable({
  providedIn: 'root'
})
export class LoggerService {
  private logEnabled = false;

  constructor(private appInfoService: AppInfoService) {
      this.appInfoService.getEnvironmentInfo()
          .subscribe((response: any) => {
              let currentEnv = response.environment;
              if (currentEnv.toUpperCase() !== "PROD") {
                  this.logEnabled = true;
                  this.log("Dev logging enabled");
              } else {
                  // tslint:disable-next-line:no-console
                  console.log(`currentEnv = ${currentEnv}`);
                  this.logEnabled = false;
              }
          });
  }

  /**
   * Logs a message out to the currently configured log provider (console) if logging is turned on.
   * @param msg message to log.
   */
  public log(msg: any) {
      if (this.logEnabled) {
          // tslint:disable-next-line:no-console
          console.log(msg);
      }
  }

  /**
   * Logs a message out to the currently configured log provider (console) if logging is turned on.
   * @param msg message to log.
   */
  public warn(msg: any) {
      console.warn(msg);
  }

  /**
   * Logs a message out to the error steam of the currently configured log provider (console).
   * @param msg
   */
  public error(msg: any) {
      console.error(msg);
  }

  /**
   * Allows for overriding the environment check. Do not use unless you absolutely must.
   * @param enabled
   */
  public setLogEnabled(enabled: boolean) {
      this.logEnabled = enabled;
  }
}
