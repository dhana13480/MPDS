import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Inject, Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot } from '@angular/router';
import { Observable, ReplaySubject, Subject, throwError, catchError, of  } from 'rxjs';
import { MpdsResponse } from 'src/app/shared/objects/MpdsResponse';
import { map } from 'rxjs/operators';
 
export interface AppState {
  show: boolean;
}

export interface AppInfo {
  environment: string;
  environmentName: string;
  version: string;
}

@Injectable()
export class AppInfoService implements Resolve<AppInfo> {
  public static urlPrefix = "appinfo";
  private url = "";
  private headers = new HttpHeaders({ "Content-Type": "application/json", "Accept": "application/json" });
  private appSubject = new Subject<AppState>();
  private appState = this.appSubject.asObservable();
  private environmentInfoSubject = new ReplaySubject<AppInfo>(1);
  private environmentInfo: Observable<AppInfo> = this.environmentInfoSubject.asObservable();

  constructor( @Inject("BaseUrl") public baseUrl: string, private httpClient: HttpClient) {
      this.url = baseUrl + AppInfoService.urlPrefix;
      this.fetchEnvironmentInfo();
  }

  public getAppState() {
      return this.appState;
  }

  public show() {
      this.appSubject.next({ show: true } as AppState);
  }

  public hide() {
      this.appSubject.next({ show: false } as AppState);
  }

  /**
   * Retrieves the environment info from the backend.
   */
  public fetchEnvironmentInfo(): any {
      return this.httpClient.get<MpdsResponse>(this.url, { headers: this.headers })          
          .pipe(map((response: any) => response.data))           
          .pipe(
            catchError(err => {
              if (err) {
                console.error(err);
              }
              return of(err != null);
            })
          )
          .subscribe((res: AppInfo) => this.environmentInfoSubject.next(res));
  }

  public resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
      return this.httpClient.get<MpdsResponse>(this.url, { headers: this.headers })          
          .pipe(map((response: any) => response.data));
  }

  public getEnvironmentInfo(): Observable<any> {
      return this.environmentInfo;
  }

  public handleError(error: any) {
      if (error.status === 401) {
          //localStorage.removeItem("currentUser");
          //localStorage.setItem("SessionExpired", "true");
      }
      return throwError(()=>error || "Server error");
  }
}
