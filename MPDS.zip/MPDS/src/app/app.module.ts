import { NgModule, CUSTOM_ELEMENTS_SCHEMA  } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './core/components/navbar/navbar.component';
import { PihpRegionsComponent } from './core/components/features/pihp-regions/pihp-regions-list/pihp-regions.component';
import { FooterComponent } from './core/components/footer/footer.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { StaffListComponent } from './core/components/features/staff/staff-list/staff-list.component';
import { PhoneFormatPipe } from './core/components/features/services/phone-format.pipe';
import { BooleanFormatPipe } from './core/components/features/services/boolean-format.pipe';
import { AddPihpRegionComponent } from './core/components/features/pihp-regions/add-pihp-region/add-pihp-region.component';
import { EditPihpRegionComponent } from './core/components/features/pihp-regions/edit-pihp-region/edit-pihp-region.component';
import { StatesComponent } from './core/components/features/states/states.component';
import { LoginComponent } from './core/components/features/login/user-login/login.component';
import { DashboardComponent } from './core/components/features/dashboard/dashboard.component';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { AddStaffComponent } from './core/components/features/staff/add-staff/add-staff.component';
import { MPDSDatePipe } from './shared/pipes/mpdsdate.pipe';
import { HighlightPipe } from './shared/pipes/highlight.pipe';
import { ReadableNumPipe } from './shared/pipes/readable-num.pipe';
import { TrimPipe } from './shared/pipes/trim.pipe';

import { SpinnerComponent } from './core/spinner/spinner.component';
import { ZipCodePipe } from './shared/pipes/zipcode.pipe';
import { ProviderAgenciesListComponent } from './core/components/features/provider-agencies/provider-agencies-list/provider-agencies-list.component';
import { AddProviderAgencyComponent } from './core/components/features/provider-agencies/add-provider-agency/add-provider-agency.component';
import { GroupsListComponent } from './core/components/features/groups/groups-list/groups-list.component';
import { AddGroupComponent } from './core/components/features/groups/add-group/add-group.component';
import { EditProviderAgencyComponent } from './core/components/features/provider-agencies/edit-provider-agency/edit-provider-agency.component';
import { EditGroupComponent } from './core/components/features/groups/edit-group/edit-group.component';
import { AddActivityComponent } from './core/components/features/activities/add-activity/add-activity.component';
import { ActivityListComponent } from './core/components/features/activities/activity-list/activity-list.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { AddParticipantsComponent } from './core/components/features/participants/add-participants/add-participants.component';
import { DatePipe } from '@angular/common';
import { EditActivityComponent } from './core/components/features/activities/edit-activity/edit-activity.component';
import { EditParticipantsComponent } from './core/components/features/participants/edit-participants/edit-participants.component';
import { MainReportsComponent } from './core/components/features/reports/main-reports/main-reports.component';
import { SearchReportsComponent } from './core/components/features/reports/search-reports/search-reports.component';
import { ReportsListComponent } from './core/components/features/reports/reports-list/reports-list.component';
import { UserListComponent } from './core/components/features/users/user-list/user-list.component';
import { AddUserComponent } from './core/components/features/users/add-user/add-user.component';
import { EditUserComponent } from './core/components/features/users/edit-user/edit-user.component';
import { CountyListComponent } from './core/components/features/master-data/counties/county-list/county-list.component';
import { UserSelectionsComponent } from './core/components/features/login/user-selections/user-selections.component';
import { UserTypeFormatPipe } from './core/components/features/users/services/user-type-format.pipe';
import { EbpServiceTypeListComponent } from './core/components/features/master-data/ebp-service-types/ebp-service-type-list/ebp-service-type-list.component';
import { FundingSourceListComponent } from './core/components/features/master-data/funding-sources/funding-source-list/funding-source-list.component';
import { ProgramNameListComponent } from './core/components/features/master-data/program-names/program-name-list/program-name-list.component';
import { SchoolDistrictListComponent } from './core/components/features/master-data/school-districts/school-district-list/school-district-list.component';
import { CountyFormatPipe } from './core/components/features/services/county-format.pipe';
import { NotFoundComponent } from './core/components/features/error-response/not-found/not-found.component';
import { AccessDeniedComponent } from './core/components/features/error-response/access-denied/access-denied.component';
import { PaginationModule } from 'ngx-bootstrap/pagination';
import { ReportViewerComponent } from './core/components/features/reports/report-viewer/report-viewer.component';
import { EditStaffComponent } from './core/components/features/staff/edit-staff/edit-staff.component';
import { ReactiveFormsModule } from '@angular/forms';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { HomeComponent } from './core/components/features/home/home.component';
import { MpdsConfirmationDialogComponent } from './shared/mpds-confirmation-dialog/mpds-confirmation-dialog.component'; 
import { MatDialogModule } from '@angular/material/dialog';
@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    PihpRegionsComponent,
    FooterComponent,
    StaffListComponent,
    AddStaffComponent,
    PhoneFormatPipe,
    CountyFormatPipe,
    BooleanFormatPipe,
    AddPihpRegionComponent,
    EditPihpRegionComponent,
    StatesComponent,
        LoginComponent,
        MPDSDatePipe,
        HighlightPipe,
        ReadableNumPipe,
        TrimPipe,
        ZipCodePipe,
        SpinnerComponent,
        ProviderAgenciesListComponent,
        AddProviderAgencyComponent,
        EditProviderAgencyComponent,
    DashboardComponent,
    GroupsListComponent,
    AddGroupComponent,
    EditGroupComponent,
    AddActivityComponent,
    ActivityListComponent,
    AddParticipantsComponent,
    EditActivityComponent,
    EditParticipantsComponent,
    MainReportsComponent,
    SearchReportsComponent,
    ReportsListComponent,
    UserListComponent,
    AddUserComponent,
    EditUserComponent,
    CountyListComponent,
    UserSelectionsComponent,
    UserTypeFormatPipe,
    EbpServiceTypeListComponent,
    FundingSourceListComponent,
    ProgramNameListComponent,
    SchoolDistrictListComponent,
    NotFoundComponent,
    AccessDeniedComponent,
    ReportViewerComponent,
    EditStaffComponent,
    HomeComponent,
    MpdsConfirmationDialogComponent,    
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    MatSlideToggleModule,
    BsDatepickerModule.forRoot(),
    BrowserAnimationsModule,
    PaginationModule.forRoot(),
    MatInputModule,
    MatSelectModule,
    MatCheckboxModule,
    MatFormFieldModule,
    ReactiveFormsModule,
    MatDialogModule
  ],
  exports: [
    PaginationModule
  ],
  providers: [DatePipe],
  bootstrap: [AppComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class AppModule { }
