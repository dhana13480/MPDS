﻿CREATE VIEW [dbo].[vReadableValidationMatrix]
AS
	-- This view is not used by the system, it is purely for explaining the Validation matrix to end-users since there are often questions about the matrix

	WITH ServicePopulations 
	AS (
		SELECT VM.[Id]
			  ,CS.[item1] AS [ServicePopulationId]
		  FROM [dbo].[ValidationMatrix] VM
		  CROSS APPLY [dbo].[SplitCSVs](VM.[ServicePopulation], ',') AS CS
	),
	Strategies 
	AS (
		SELECT VM.[Id]
			  ,CS.[item1] AS [StrategyId]
		  FROM [dbo].[ValidationMatrix] VM
		  CROSS APPLY [dbo].[SplitCSVs](VM.[Strategies], ',') AS CS
	)

	SELECT GT.[Description] AS [GroupType]
		  ,PT.[Description] AS [ProgramType]
		  ,IT.[Description] AS [InterventionType]
		  ,MSP.[ServicePopulation]
		  ,MS.[Code] AS [StrategyCode]
		  ,MS.[Description] AS [Strategy]
		  ,CASE WHEN VM.[RequireTotalAttendees] = 1 THEN 'Yes' ELSE 'No' END AS [RequireTotalAttendees]
		  ,CASE WHEN VM.[RequireEstimatedReach] = 1 THEN 'Yes' ELSE 'No' END AS [RequireEstimatedReach]
		  ,CASE WHEN VM.[AllowTotalOrEstimatedReach] = 1 THEN 'Yes' ELSE 'No' END AS [AllowTotalOrEstimatedReach]
		  ,CASE WHEN VM.[AllowTotalAndOrEstimatedReach] = 1 THEN 'Yes' ELSE 'No' END AS [AllowTotalAndOrEstimatedReach]
		  ,CASE WHEN VM.[RequireDemographics] = 1 THEN 'Yes' ELSE 'No' END AS [RequireDemographics]
	  FROM [dbo].[ValidationMatrix] VM
	  INNER JOIN [dbo].[Master_GroupType] GT ON GT.[Id] = VM.[GroupType]
	  INNER JOIN [dbo].[Master_ProgramType] PT ON PT.[Id] = VM.[ProgramType]
	  INNER JOIN [dbo].[Master_InterventionType] IT ON IT.[Id] = VM.[InterventionType]
	  INNER JOIN ServicePopulations SP ON SP.[Id] = VM.[Id]
	  INNER JOIN [dbo].[Master_ServicePopulation] MSP ON MSP.[Id] = SP.[ServicePopulationId]
	  INNER JOIN Strategies S ON S.[Id] = VM.[Id]
	  INNER JOIN [dbo].[Master_Strategy] MS ON MS.[Id] = S.[StrategyId]
