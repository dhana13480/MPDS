﻿
CREATE VIEW [dbo].[vFilterActivities]
AS
	SELECT  A.Id, 
			A.GroupId, 
			A.NewMaleAttendees, 
			A.NewFemaleAttendees, 
			A.EstimatePeopleReached, 
			CONVERT(date, A.StartDate) AS StartDate, 
			CONVERT(date, A.EndDate) AS EndDate, 
			PA.Id AS ProviderAgencyId, 
			PA.[Name] AS ProviderAgency, 
			PA.CoordinatingAgencyId, 
			MPT.Id AS ProgramTypeId, 
			MPT.[Description] AS ProgramType, 
			MIT.Id AS InterventionTypeId,
			MIT.[Description] AS InterventionType, 
			MEST.Id AS EBPServiceTypeId, 
			MEST.[Description] AS EBPServiceType, 
			A.MasterStrategyEmployed AS StrategyId, 
			MSC.Id AS StrategyCategoryId, 
			MSC.[Description] AS StrategyCategory, 
			AG.IsYATRelated,
			AG.[IsGamblingRelated]

	FROM     dbo.Activity AS A 
	INNER JOIN dbo.ActivityGroup AS AG ON AG.Id = A.GroupId 
	INNER JOIN dbo.ProviderAgency AS PA ON AG.ProviderAgencyId = PA.Id 
	LEFT OUTER JOIN dbo.Master_ProgramType AS MPT ON MPT.Id = AG.ProgramType 
	LEFT OUTER JOIN dbo.Master_InterventionType AS MIT ON MIT.Id = AG.InterventionType 
	LEFT OUTER JOIN dbo.Master_EBPServiceType AS MEST ON MEST.Id = AG.EBPServiceType 
	LEFT OUTER JOIN dbo.Master_Strategy AS MS ON MS.Id = A.MasterStrategyEmployed 
	LEFT OUTER JOIN dbo.Master_StrategyCategory AS MSC ON MSC.Id = MS.CategoryId

	WHERE  A.IsDeleted = 0 AND AG.IsDeleted = 0

GO
EXECUTE sp_addextendedproperty @name = N'MS_DiagramPane1', @value = N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[40] 4[20] 2[20] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = -240
         Left = 0
      End
      Begin Tables = 
         Begin Table = "A"
            Begin Extent = 
               Top = 7
               Left = 48
               Bottom = 367
               Right = 315
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "AG"
            Begin Extent = 
               Top = 7
               Left = 377
               Bottom = 357
               Right = 627
            End
            DisplayFlags = 280
            TopColumn = 6
         End
         Begin Table = "PA"
            Begin Extent = 
               Top = 7
               Left = 675
               Bottom = 168
               Right = 943
            End
            DisplayFlags = 280
            TopColumn = 3
         End
         Begin Table = "MPT"
            Begin Extent = 
               Top = 7
               Left = 991
               Bottom = 168
               Right = 1185
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "MIT"
            Begin Extent = 
               Top = 168
               Left = 675
               Bottom = 329
               Right = 881
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "MEST"
            Begin Extent = 
               Top = 168
               Left = 929
               Bottom = 329
               Right = 1128
            End
            DisplayFlags = 280
            TopColumn = 1
         End
         Begin Table = "MS"
            Begin Extent = 
               Top = 331
               Left = 675
               Bottom = 558
               Right = 869
            End
            DisplayFlags = 280
            TopColumn = 0
 ', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'VIEW', @level1name = N'vFilterActivities';


GO
EXECUTE sp_addextendedproperty @name = N'MS_DiagramPane2', @value = N'        End
         Begin Table = "MSC"
            Begin Extent = 
               Top = 331
               Left = 917
               Bottom = 565
               Right = 1127
            End
            DisplayFlags = 280
            TopColumn = 0
         End
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 11
         Column = 1440
         Alias = 900
         Table = 1176
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1356
         SortOrder = 1416
         GroupBy = 1350
         Filter = 1356
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'VIEW', @level1name = N'vFilterActivities';


GO
EXECUTE sp_addextendedproperty @name = N'MS_DiagramPaneCount', @value = 2, @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'VIEW', @level1name = N'vFilterActivities';

