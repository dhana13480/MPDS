﻿CREATE TABLE [dbo].[Activity_ParticipantAgeGroup] (
    [Id]                    BIGINT IDENTITY (1, 1) NOT NULL,
    [ActivityId]            BIGINT NOT NULL,
    [ParticipantAgeGroupId] INT    NULL,
    [NoOfAttendees]         INT    NOT NULL,
    CONSTRAINT [PK_Activity_ParticipantAgeGroup] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_Activity_ParticipantAgeGroup_Activity] FOREIGN KEY ([ActivityId]) REFERENCES [dbo].[Activity] ([Id]),
    CONSTRAINT [FK_Activity_ParticipantAgeGroup_Master_ParticipantAgeGroup] FOREIGN KEY ([ParticipantAgeGroupId]) REFERENCES [dbo].[Master_ParticipantAgeGroup] ([Id])
);


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Primary Key', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Activity_ParticipantAgeGroup', @level2type = N'COLUMN', @level2name = N'Id';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Activity (Foreign Key to Activity)', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Activity_ParticipantAgeGroup', @level2type = N'COLUMN', @level2name = N'ActivityId';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Participant Age Group( Foreign Key to Master_ParticipantAgeGroup)', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Activity_ParticipantAgeGroup', @level2type = N'COLUMN', @level2name = N'ParticipantAgeGroupId';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Number of Attendees of Participant Age Group', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Activity_ParticipantAgeGroup', @level2type = N'COLUMN', @level2name = N'NoOfAttendees';

