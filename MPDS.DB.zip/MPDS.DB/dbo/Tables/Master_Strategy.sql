﻿CREATE TABLE [dbo].[Master_Strategy] (
    [Id]           INT           IDENTITY (1, 1) NOT NULL,
    [DisplayOrder] INT           NULL,
    [Code]         VARCHAR (10)  NULL,
    [Strategy]     VARCHAR (50)  NOT NULL,
    [Description]  VARCHAR (500) NOT NULL,
    [CategoryId]   INT           NOT NULL,
    [TempOldId]    INT           NULL,
    CONSTRAINT [PK_Strategy] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_Master_Strategy_Master_StrategyCategory] FOREIGN KEY ([CategoryId]) REFERENCES [dbo].[Master_StrategyCategory] ([Id])
);


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Primary Key', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Master_Strategy', @level2type = N'COLUMN', @level2name = N'Id';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Order in which records will be displayed', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Master_Strategy', @level2type = N'COLUMN', @level2name = N'DisplayOrder';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Code for each Strategy Type', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Master_Strategy', @level2type = N'COLUMN', @level2name = N'Code';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Name of each Strategy Type', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Master_Strategy', @level2type = N'COLUMN', @level2name = N'Strategy';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Description of each StrategyType', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Master_Strategy', @level2type = N'COLUMN', @level2name = N'Description';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Category Id to which Strategy is linked (Foreign Key to Master_StrategyCategory)', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Master_Strategy', @level2type = N'COLUMN', @level2name = N'CategoryId';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Unique Key of Strategy  from old database(used for migration)', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Master_Strategy', @level2type = N'COLUMN', @level2name = N'TempOldId';

