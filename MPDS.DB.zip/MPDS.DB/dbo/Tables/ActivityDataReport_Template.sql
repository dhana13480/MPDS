﻿CREATE TABLE [dbo].[ActivityDataReport_Template] (
    [Id]                       BIGINT        IDENTITY (1, 1) NOT NULL,
    [UserId]                   BIGINT        NOT NULL,
    [Name]                     VARCHAR (100) NOT NULL,
    [CreatedBy]                BIGINT        NOT NULL,
    [CreationDate]             DATETIME      NOT NULL,
    [UpdatedBy]                BIGINT        NULL,
    [UpdationDate]             DATETIME      NULL,
    [CSVCoordinatingAgencyIds] VARCHAR (MAX) NOT NULL,
    [CSVProviderAgencyIds]     VARCHAR (MAX) NOT NULL,
    [CSVGroupIds]              VARCHAR (MAX) NOT NULL,
    CONSTRAINT [PK_ActivityDataReport_Template] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_ActivityDataReport_Template_Users] FOREIGN KEY ([UserId]) REFERENCES [dbo].[Users] ([Id])
);

