﻿CREATE TABLE [dbo].[ProviderAgency_Staff_DoNotDelete] (
    [Id]               BIGINT       IDENTITY (1, 1) NOT NULL,
    [ProviderAgencyId] BIGINT       NOT NULL,
    [StaffId]          BIGINT       NOT NULL,
    [EffectiveFrom]    DATETIME     NOT NULL,
    [EffectiveTo]      DATETIME     NOT NULL,
    [OldPersonType]    VARCHAR (50) NULL,
    CONSTRAINT [PK_ProviderAgencyStaff] PRIMARY KEY CLUSTERED ([Id] ASC)
);


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Primary Key', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ProviderAgency_Staff_DoNotDelete', @level2type = N'COLUMN', @level2name = N'Id';

