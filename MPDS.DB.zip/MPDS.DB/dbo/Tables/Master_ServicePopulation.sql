﻿CREATE TABLE [dbo].[Master_ServicePopulation] (
    [Id]                INT           IDENTITY (1, 1) NOT NULL,
    [DisplayOrder]      INT           NULL,
    [Code]              VARCHAR (10)  NULL,
    [ServicePopulation] VARCHAR (50)  NOT NULL,
    [Description]       VARCHAR (500) NOT NULL,
    [TempOldId]         INT           NULL,
    CONSTRAINT [PK_ServicePopulation] PRIMARY KEY CLUSTERED ([Id] ASC)
);


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Primary Key', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Master_ServicePopulation', @level2type = N'COLUMN', @level2name = N'Id';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Order in which records wll be displayed', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Master_ServicePopulation', @level2type = N'COLUMN', @level2name = N'DisplayOrder';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Code for each Service Population Type', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Master_ServicePopulation', @level2type = N'COLUMN', @level2name = N'Code';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Name of service Population Type', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Master_ServicePopulation', @level2type = N'COLUMN', @level2name = N'ServicePopulation';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Description of Service Population Type', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Master_ServicePopulation', @level2type = N'COLUMN', @level2name = N'Description';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Unique Key of Service Population Type from old database(used for migration)', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Master_ServicePopulation', @level2type = N'COLUMN', @level2name = N'TempOldId';

