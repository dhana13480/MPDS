﻿CREATE TABLE [dbo].[ProviderAgency_County] (
    [Id]               INT    IDENTITY (1, 1) NOT NULL,
    [ProviderAgencyId] BIGINT NOT NULL,
    [CountyId]         INT    NOT NULL,
    CONSTRAINT [PK_ProviderAgencyCounty] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_ProviderAgency_County_Master_County] FOREIGN KEY ([CountyId]) REFERENCES [dbo].[Master_County] ([Id]),
    CONSTRAINT [FK_ProviderAgency_County_ProviderAgency] FOREIGN KEY ([ProviderAgencyId]) REFERENCES [dbo].[ProviderAgency] ([Id])
);


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Primary Key', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ProviderAgency_County', @level2type = N'COLUMN', @level2name = N'Id';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Provider Agency Id linked to County( Foreign Key to ProviderAgency)', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ProviderAgency_County', @level2type = N'COLUMN', @level2name = N'ProviderAgencyId';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'County Id  linked to Provider Agency(Foreign Key to Master_County)', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ProviderAgency_County', @level2type = N'COLUMN', @level2name = N'CountyId';

