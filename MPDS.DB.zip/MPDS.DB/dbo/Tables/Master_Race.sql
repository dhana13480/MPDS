﻿CREATE TABLE [dbo].[Master_Race] (
    [Id]          INT           IDENTITY (1, 1) NOT NULL,
    [Race]        VARCHAR (50)  NOT NULL,
    [Description] VARCHAR (500) NOT NULL,
    [TempOldId]   INT           NULL,
    CONSTRAINT [PK_Race] PRIMARY KEY CLUSTERED ([Id] ASC)
);


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Primary Key', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Master_Race', @level2type = N'COLUMN', @level2name = N'Id';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Race Name', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Master_Race', @level2type = N'COLUMN', @level2name = N'Race';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Description of Type of Race', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Master_Race', @level2type = N'COLUMN', @level2name = N'Description';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Unique Key of Race Type from old database(used for migration)', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Master_Race', @level2type = N'COLUMN', @level2name = N'TempOldId';

