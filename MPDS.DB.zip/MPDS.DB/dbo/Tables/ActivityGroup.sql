﻿CREATE TABLE [dbo].[ActivityGroup] (
    [Id]                     BIGINT           IDENTITY (1, 1) NOT NULL,
    [uKeyOld]                UNIQUEIDENTIFIER NULL,
    [uKeyOldCA]              UNIQUEIDENTIFIER NULL,
    [ukeyOldPA]              UNIQUEIDENTIFIER NULL,
    [CoordinatingAgencyId]   BIGINT           NULL,
    [ProviderAgencyIdTemp]   BIGINT           NULL,
    [ProviderAgencyId]       BIGINT           NOT NULL,
    [Name]                   VARCHAR (500)    NOT NULL,
    [IsActive]               BIT              CONSTRAINT [DF_ActivityGroup_IsActive] DEFAULT ((1)) NOT NULL,
    [IsYATRelated]           BIT              NOT NULL,
    [MinActivityCount]       INT              NOT NULL,
    [MaxActivityCount]       INT              NOT NULL,
    [GroupType]              INT              NULL,
    [ProgramType]            INT              NULL,
    [InterventionType]       INT              NULL,
    [ServiceDomain]          INT              NULL,
    [ServiceLocation]        INT              NULL,
    [FundingSource]          INT              NULL,
    [EBPServiceType]         INT              NULL,
    [ServicePopulation]      INT              NULL,
    [Comments]               VARCHAR (1000)   NOT NULL,
    [GroupOptionalDataId]    BIGINT           NULL,
    [IsDeleted]              BIT              CONSTRAINT [DF_ActivityGroup_IsDeleted] DEFAULT ((0)) NOT NULL,
    [CreatedBy]              BIGINT           NOT NULL,
    [CreationDate]           DATETIME         NOT NULL,
    [UpdatedBy]              BIGINT           NULL,
    [UpdationDate]           DATETIME         NULL,
    [DeactivationDate]       DATETIME         NULL,
    [MasterStrategyEmployed] INT              NULL,
    [ProgramNameId]          BIGINT           NULL,
    [OtherProgramName]       VARCHAR (500)    NULL,
    [IsGamblingRelated]      BIT              CONSTRAINT [DF_ActivityGroup_IsGamblingRelated] DEFAULT ((0)) NOT NULL,
    CONSTRAINT [PK_ActivityGroup] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_ActivityGroup_Group_OptionalData] FOREIGN KEY ([GroupOptionalDataId]) REFERENCES [dbo].[Group_OptionalData] ([Id]),
    CONSTRAINT [FK_ActivityGroup_Master_EBPServiceType] FOREIGN KEY ([EBPServiceType]) REFERENCES [dbo].[Master_EBPServiceType] ([Id]),
    CONSTRAINT [FK_ActivityGroup_Master_FundingSource] FOREIGN KEY ([FundingSource]) REFERENCES [dbo].[Master_FundingSource] ([Id]),
    CONSTRAINT [FK_ActivityGroup_Master_GroupType] FOREIGN KEY ([GroupType]) REFERENCES [dbo].[Master_GroupType] ([Id]),
    CONSTRAINT [FK_ActivityGroup_Master_InterventionType] FOREIGN KEY ([InterventionType]) REFERENCES [dbo].[Master_InterventionType] ([Id]),
    CONSTRAINT [FK_ActivityGroup_Master_ProgramType] FOREIGN KEY ([ProgramType]) REFERENCES [dbo].[Master_ProgramType] ([Id]),
    CONSTRAINT [FK_ActivityGroup_Master_ServiceDomain] FOREIGN KEY ([ServiceDomain]) REFERENCES [dbo].[Master_ServiceDomain] ([Id]),
    CONSTRAINT [FK_ActivityGroup_Master_ServicePopulation] FOREIGN KEY ([ServicePopulation]) REFERENCES [dbo].[Master_ServicePopulation] ([Id]),
    CONSTRAINT [FK_ActivityGroup_Master_Strategy] FOREIGN KEY ([MasterStrategyEmployed]) REFERENCES [dbo].[Master_Strategy] ([Id]),
    CONSTRAINT [FK_ActivityGroup_ProviderAgency] FOREIGN KEY ([ProviderAgencyId]) REFERENCES [dbo].[ProviderAgency] ([Id])
);


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Primary Key', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ActivityGroup', @level2type = N'COLUMN', @level2name = N'Id';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Primary Key of Old Database(used for migration)', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ActivityGroup', @level2type = N'COLUMN', @level2name = N'uKeyOld';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N' CA unique key of old database(used for migration)', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ActivityGroup', @level2type = N'COLUMN', @level2name = N'uKeyOldCA';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'  PA Unique key of old Database(used for migration)', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ActivityGroup', @level2type = N'COLUMN', @level2name = N'ukeyOldPA';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Coordinating Agency Id to which Group is linked', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ActivityGroup', @level2type = N'COLUMN', @level2name = N'CoordinatingAgencyId';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Provider Agency Id to which Group is linked (Foregin Key to Provider Agency)', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ActivityGroup', @level2type = N'COLUMN', @level2name = N'ProviderAgencyId';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Name of Group', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ActivityGroup', @level2type = N'COLUMN', @level2name = N'Name';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'If Group is active or inactive  in the system', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ActivityGroup', @level2type = N'COLUMN', @level2name = N'IsActive';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'If Group is YTA Related or not', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ActivityGroup', @level2type = N'COLUMN', @level2name = N'IsYATRelated';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Minimum Activity Count of Group', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ActivityGroup', @level2type = N'COLUMN', @level2name = N'MinActivityCount';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Maximum Activity Count of Group', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ActivityGroup', @level2type = N'COLUMN', @level2name = N'MaxActivityCount';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Type of Group (Foreign Key to Master_GroupType)', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ActivityGroup', @level2type = N'COLUMN', @level2name = N'GroupType';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Type of program to which Group is linked (Foreign Key to Master_ProgramType)', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ActivityGroup', @level2type = N'COLUMN', @level2name = N'ProgramType';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Intervention Type of Group ', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ActivityGroup', @level2type = N'COLUMN', @level2name = N'InterventionType';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Service Domain  of Group  (Foreign Key to Master_ServiceDomain )', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ActivityGroup', @level2type = N'COLUMN', @level2name = N'ServiceDomain';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Service Location of Group', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ActivityGroup', @level2type = N'COLUMN', @level2name = N'ServiceLocation';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Funding Source of Group (Foreign key with Master_FundingSource)', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ActivityGroup', @level2type = N'COLUMN', @level2name = N'FundingSource';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'EBPServiceType of Group(Foreign Key with Master_EBPServiceType)', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ActivityGroup', @level2type = N'COLUMN', @level2name = N'EBPServiceType';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Service population related to Group(Foreign Key with Master_ServicePopulation)', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ActivityGroup', @level2type = N'COLUMN', @level2name = N'ServicePopulation';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Additional Comments/Notes related to Group', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ActivityGroup', @level2type = N'COLUMN', @level2name = N'Comments';


GO
EXECUTE sp_addextendedproperty @name = N' MS_Description', @value = N'Group Optional Data (Foreign Key with Master_GroupOptionalData)', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ActivityGroup', @level2type = N'COLUMN', @level2name = N'GroupOptionalDataId';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'User who created Group', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ActivityGroup', @level2type = N'COLUMN', @level2name = N'CreatedBy';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Creation Date of Group', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ActivityGroup', @level2type = N'COLUMN', @level2name = N'CreationDate';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'User who last updated the Group', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ActivityGroup', @level2type = N'COLUMN', @level2name = N'UpdatedBy';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Date on which Group was last updated', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ActivityGroup', @level2type = N'COLUMN', @level2name = N'UpdationDate';

