﻿CREATE TABLE [dbo].[ApplicationSettings] (
    [SMTPServer]                     VARCHAR (255) NOT NULL,
    [SMTPPort]                       INT           NOT NULL,
    [SecureSMTP]                     BIT           NOT NULL,
    [MailFromAddress]                VARCHAR (255) NOT NULL,
    [MailFromUserName]               VARCHAR (255) NOT NULL,
    [MailFromPassword]               VARCHAR (255) NOT NULL,
    [PagingCount_Admin]              INT           NOT NULL,
    [PagingCount_CoordinatingAgency] INT           NOT NULL,
    [PagingCount_ProviderAgency]     INT           NOT NULL,
    [PagingCount_Auditor]            INT           NOT NULL,
    [DomainName]                     VARCHAR (50)  NOT NULL,
    [ErrorEmailAddress]              VARCHAR (500) NOT NULL
);


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SMTP(Simple Mail Transfer Protocol) Server Name used for mailing', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ApplicationSettings', @level2type = N'COLUMN', @level2name = N'SMTPServer';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SMTP Port used for  mailing', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ApplicationSettings', @level2type = N'COLUMN', @level2name = N'SMTPPort';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Secure SMTP True/False ', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ApplicationSettings', @level2type = N'COLUMN', @level2name = N'SecureSMTP';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Email Id of Mail Sender', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ApplicationSettings', @level2type = N'COLUMN', @level2name = N'MailFromAddress';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'UserName of Mail Sender', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ApplicationSettings', @level2type = N'COLUMN', @level2name = N'MailFromUserName';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Mail from address Password ', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ApplicationSettings', @level2type = N'COLUMN', @level2name = N'MailFromPassword';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Records per page to be shown to Admin', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ApplicationSettings', @level2type = N'COLUMN', @level2name = N'PagingCount_Admin';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Records per page to be shown to Coordinating Agency ', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ApplicationSettings', @level2type = N'COLUMN', @level2name = N'PagingCount_CoordinatingAgency';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Records per page to be shown to Provider Agency', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ApplicationSettings', @level2type = N'COLUMN', @level2name = N'PagingCount_ProviderAgency';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Records per page to be shown to Auditor', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ApplicationSettings', @level2type = N'COLUMN', @level2name = N'PagingCount_Auditor';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Domain name of web app ', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ApplicationSettings', @level2type = N'COLUMN', @level2name = N'DomainName';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Email Address used to Report Error', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ApplicationSettings', @level2type = N'COLUMN', @level2name = N'ErrorEmailAddress';

