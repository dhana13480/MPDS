﻿CREATE TABLE [dbo].[Master_ProgramName] (
    [Id]              INT           IDENTITY (1, 1) NOT NULL,
    [Name]            VARCHAR (MAX) NOT NULL,
    [Description]     VARCHAR (MAX) NOT NULL,
    [CreatedBy]       BIGINT        NOT NULL,
    [CreationDate]    DATETIME      NOT NULL,
    [UpdatedBy]       BIGINT        NULL,
    [UpdationDate]    DATETIME      NULL,
    [DeactivatedBy]   BIGINT        NULL,
    [DeactivatedDate] DATETIME      NULL,
    CONSTRAINT [PK_ProgramName] PRIMARY KEY CLUSTERED ([Id] ASC)
);

