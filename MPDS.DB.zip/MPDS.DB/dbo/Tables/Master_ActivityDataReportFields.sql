﻿CREATE TABLE [dbo].[Master_ActivityDataReportFields] (
    [Id]        SMALLINT      IDENTITY (1, 1) NOT NULL,
    [FieldName] VARCHAR (100) NOT NULL,
    [GroupId]   SMALLINT      NOT NULL,
    CONSTRAINT [PK_Master_ActivityDataReportFields] PRIMARY KEY CLUSTERED ([Id] ASC)
);

