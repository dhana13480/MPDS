﻿CREATE TABLE [dbo].[Activity_OptionalData] (
    [Id]                              BIGINT           IDENTITY (1, 1) NOT NULL,
    [uKeyOld]                         UNIQUEIDENTIFIER NULL,
    [numberOfOriginalItemsCreated]    INT              NULL,
    [numberOfBrochuresDistributed]    INT              NULL,
    [IsSchoolBasedActivity]           BIT              NULL,
    [IndirectSpeakingEngagementReach] INT              NULL,
    [IndirectSpeakingEngagementCount] INT              NULL,
    [SchoolDistrictId]                INT              NULL,
    [CountyId]                        INT              NULL,
    [LocationZipCode]                 VARCHAR (10)     NULL,
    [ServiceSettingId]                INT              NULL,
    CONSTRAINT [PK_ActivityOptionalData_1] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_Activity_OptionalData_Master_County] FOREIGN KEY ([CountyId]) REFERENCES [dbo].[Master_County] ([Id]),
    CONSTRAINT [FK_Activity_OptionalData_Master_SchoolDistrict] FOREIGN KEY ([SchoolDistrictId]) REFERENCES [dbo].[Master_SchoolDistrict] ([Id]),
    CONSTRAINT [FK_Activity_OptionalData_Master_ServiceSetting] FOREIGN KEY ([ServiceSettingId]) REFERENCES [dbo].[Master_ServiceSetting] ([Id])
);


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Primary Key', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Activity_OptionalData', @level2type = N'COLUMN', @level2name = N'Id';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Key in Old Database(used for migration)', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Activity_OptionalData', @level2type = N'COLUMN', @level2name = N'uKeyOld';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Number of Original Items created', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Activity_OptionalData', @level2type = N'COLUMN', @level2name = N'numberOfOriginalItemsCreated';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Number of Brochures Distributed in Activity', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Activity_OptionalData', @level2type = N'COLUMN', @level2name = N'numberOfBrochuresDistributed';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'If related Activity is school based Activity', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Activity_OptionalData', @level2type = N'COLUMN', @level2name = N'IsSchoolBasedActivity';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Indirect Speaking Engagement Reached for Activity', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Activity_OptionalData', @level2type = N'COLUMN', @level2name = N'IndirectSpeakingEngagementReach';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Count of  Indirect Speaking Engagement Reached for Activity', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Activity_OptionalData', @level2type = N'COLUMN', @level2name = N'IndirectSpeakingEngagementCount';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'School District Related to the Activity(Foreign Key to Master_SchoolDistrict)', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Activity_OptionalData', @level2type = N'COLUMN', @level2name = N'SchoolDistrictId';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'County related to Activity(Foreign Key to Master_County)', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Activity_OptionalData', @level2type = N'COLUMN', @level2name = N'CountyId';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Zip Code of  location related to Activity', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Activity_OptionalData', @level2type = N'COLUMN', @level2name = N'LocationZipCode';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Service Settings related to Activity (Foreign Key to Master_ServiceSetting)', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Activity_OptionalData', @level2type = N'COLUMN', @level2name = N'ServiceSettingId';

