﻿CREATE TABLE [dbo].[Users] (
    [Id]                      BIGINT         IDENTITY (1, 1) NOT NULL,
    [FirstName]               VARCHAR (50)   NOT NULL,
    [MiddleName]              VARCHAR (15)   NOT NULL,
    [LastName]                VARCHAR (50)   NOT NULL,
    [UserName]                VARCHAR (100)  NOT NULL,
    [Password]                VARCHAR (255)  NOT NULL,
    [Email]                   VARCHAR (255)  NOT NULL,
    [Phone]                   VARCHAR (15)   NOT NULL,
    [UserTypeId]              SMALLINT       NOT NULL,
    [CoordinatingAgencyId]    BIGINT         NULL,
    [ProviderAgencyId]        BIGINT         NULL,
    [Permissions]             VARCHAR (100)  NOT NULL,
    [Address1]                VARCHAR (255)  NOT NULL,
    [Address2]                VARCHAR (255)  NOT NULL,
    [City]                    VARCHAR (50)   NOT NULL,
    [StateId]                 SMALLINT       NOT NULL,
    [Zip]                     VARCHAR (15)   NOT NULL,
    [Comments]                VARCHAR (1000) NOT NULL,
    [IsPasswordResetRequired] BIT            NOT NULL,
    [IsActive]                BIT            NOT NULL,
    [IsDeleted]               BIT            NOT NULL,
    [CreatedBy]               BIGINT         NOT NULL,
    [CreationDate]            DATETIME       NOT NULL,
    [UpdatedBy]               BIGINT         NULL,
    [UpdationDate]            DATETIME       NULL,
    [HashingAlgorithm]        VARCHAR (50)   CONSTRAINT [DF_Users_HashingAlgorithm] DEFAULT ('SHA512') NOT NULL,
    CONSTRAINT [PK_Users] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_Users_CoordinatingAgency] FOREIGN KEY ([CoordinatingAgencyId]) REFERENCES [dbo].[CoordinatingAgency] ([Id]),
    CONSTRAINT [FK_Users_Master_State] FOREIGN KEY ([StateId]) REFERENCES [dbo].[Master_State] ([Id]),
    CONSTRAINT [FK_Users_Master_UserType] FOREIGN KEY ([UserTypeId]) REFERENCES [dbo].[Master_UserType] ([Id]),
    CONSTRAINT [FK_Users_ProviderAgency] FOREIGN KEY ([ProviderAgencyId]) REFERENCES [dbo].[ProviderAgency] ([Id])
);


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Primary Key', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Users', @level2type = N'COLUMN', @level2name = N'Id';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'First Name of User', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Users', @level2type = N'COLUMN', @level2name = N'FirstName';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Middle Name Of User', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Users', @level2type = N'COLUMN', @level2name = N'MiddleName';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Last Name of User', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Users', @level2type = N'COLUMN', @level2name = N'LastName';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Unique Name of User In Application (Required for Login)', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Users', @level2type = N'COLUMN', @level2name = N'UserName';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Password of User Required for Login', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Users', @level2type = N'COLUMN', @level2name = N'Password';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Email Id of User', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Users', @level2type = N'COLUMN', @level2name = N'Email';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Phone Number of User', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Users', @level2type = N'COLUMN', @level2name = N'Phone';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Type  of User(Foreign Key to Master_UserType)', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Users', @level2type = N'COLUMN', @level2name = N'UserTypeId';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Coordinating Agency Id to which User is linked(Foreign Key to Coordinating Agency)', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Users', @level2type = N'COLUMN', @level2name = N'CoordinatingAgencyId';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Provider Agency Id to which User is linked(Foreign Key to Provider Agency)', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Users', @level2type = N'COLUMN', @level2name = N'ProviderAgencyId';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Permissions Granted to User', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Users', @level2type = N'COLUMN', @level2name = N'Permissions';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Address1 of User', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Users', @level2type = N'COLUMN', @level2name = N'Address1';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Address2 of User', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Users', @level2type = N'COLUMN', @level2name = N'Address2';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'City of User', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Users', @level2type = N'COLUMN', @level2name = N'City';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'State of User(Foreign Key to Master_State)', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Users', @level2type = N'COLUMN', @level2name = N'StateId';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Zip of User', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Users', @level2type = N'COLUMN', @level2name = N'Zip';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Additional Comments/Notes related to User', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Users', @level2type = N'COLUMN', @level2name = N'Comments';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'whether password is set by User himself or not', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Users', @level2type = N'COLUMN', @level2name = N'IsPasswordResetRequired';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'If User is active or inactive in the system', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Users', @level2type = N'COLUMN', @level2name = N'IsActive';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'If User is deleted or not', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Users', @level2type = N'COLUMN', @level2name = N'IsDeleted';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'User who created this User', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Users', @level2type = N'COLUMN', @level2name = N'CreatedBy';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Date when User was created', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Users', @level2type = N'COLUMN', @level2name = N'CreationDate';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'User who last updated this User', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Users', @level2type = N'COLUMN', @level2name = N'UpdatedBy';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Date on which User was last updated', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Users', @level2type = N'COLUMN', @level2name = N'UpdationDate';

