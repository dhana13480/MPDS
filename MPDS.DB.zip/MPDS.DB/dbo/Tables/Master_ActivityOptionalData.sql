﻿CREATE TABLE [dbo].[Master_ActivityOptionalData] (
    [Id]          INT           IDENTITY (1, 1) NOT NULL,
    [FieldName]   VARCHAR (50)  NOT NULL,
    [Description] VARCHAR (500) NOT NULL,
    [TempOldId]   INT           NULL,
    CONSTRAINT [PK_ActivityOptionalData] PRIMARY KEY CLUSTERED ([Id] ASC)
);


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Primary Key', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Master_ActivityOptionalData', @level2type = N'COLUMN', @level2name = N'Id';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Optional Data Field Name', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Master_ActivityOptionalData', @level2type = N'COLUMN', @level2name = N'FieldName';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Description of Optional  Data field', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Master_ActivityOptionalData', @level2type = N'COLUMN', @level2name = N'Description';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Optional data Unique Key from old Database(used for migratioin)', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Master_ActivityOptionalData', @level2type = N'COLUMN', @level2name = N'TempOldId';

