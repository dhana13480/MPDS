﻿CREATE TABLE [dbo].[Notification] (
    [Id]                       BIGINT         IDENTITY (1, 1) NOT NULL,
    [TypeId]                   SMALLINT       NOT NULL,
    [Title]                    VARCHAR (100)  NOT NULL,
    [Text]                     VARCHAR (2000) NOT NULL,
    [StartDate]                DATETIME       NOT NULL,
    [EndDate]                  DATETIME       NOT NULL,
    [CreatedBy]                BIGINT         NOT NULL,
    [CreationDate]             DATETIME       NOT NULL,
    [UpdatedBy]                BIGINT         NULL,
    [UpdationDate]             DATETIME       NULL,
    [CSVProviderAgencyIds]     VARCHAR (2000) NOT NULL,
    [CSVCoordinatingAgencyIds] VARCHAR (2000) NOT NULL,
    [IsEmailSent]              BIT            CONSTRAINT [DF__Notificat__IsEma__6E8B6712] DEFAULT ((0)) NOT NULL,
    CONSTRAINT [PK_Notifications] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_Notifications_Master_NotificationType] FOREIGN KEY ([TypeId]) REFERENCES [dbo].[Master_NotificationType] ([Id])
);

