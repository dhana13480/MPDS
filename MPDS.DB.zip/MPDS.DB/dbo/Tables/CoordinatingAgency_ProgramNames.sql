﻿CREATE TABLE [dbo].[CoordinatingAgency_ProgramNames] (
    [Id]                   INT    IDENTITY (1, 1) NOT NULL,
    [CoordinatingAgencyId] BIGINT NOT NULL,
    [ProgramNameId]        INT    NOT NULL,
    CONSTRAINT [PK_CoordinatingAgencyProgramName] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_CoordinatingAgency_ProgramNames_CoordinatingAgency] FOREIGN KEY ([CoordinatingAgencyId]) REFERENCES [dbo].[CoordinatingAgency] ([Id]),
    CONSTRAINT [FK_CoordinatingAgency_ProgramNames_Master_ProgramName] FOREIGN KEY ([ProgramNameId]) REFERENCES [dbo].[Master_ProgramName] ([Id])
);

