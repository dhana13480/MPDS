﻿CREATE TABLE [dbo].[Master_IntendedPopulation] (
    [Id]                 INT           IDENTITY (1, 1) NOT NULL,
    [DisplayOrder]       INT           NULL,
    [Code]               VARCHAR (10)  NULL,
    [IntendedPopulation] VARCHAR (50)  NOT NULL,
    [Description]        VARCHAR (500) NOT NULL,
    [TempOldId]          INT           NULL,
    CONSTRAINT [PK_Master_IntendedPopulation] PRIMARY KEY CLUSTERED ([Id] ASC)
);


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Primary Key', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Master_IntendedPopulation', @level2type = N'COLUMN', @level2name = N'Id';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Order in which fields will be displayed', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Master_IntendedPopulation', @level2type = N'COLUMN', @level2name = N'DisplayOrder';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Code for each Intended Population Type', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Master_IntendedPopulation', @level2type = N'COLUMN', @level2name = N'Code';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Type Of Intended Population', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Master_IntendedPopulation', @level2type = N'COLUMN', @level2name = N'IntendedPopulation';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Description of Type of Intended Population', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Master_IntendedPopulation', @level2type = N'COLUMN', @level2name = N'Description';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Unique Key of Intended Population from old database(used for migration)', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Master_IntendedPopulation', @level2type = N'COLUMN', @level2name = N'TempOldId';

