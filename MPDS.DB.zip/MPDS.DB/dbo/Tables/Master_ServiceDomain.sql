﻿CREATE TABLE [dbo].[Master_ServiceDomain] (
    [Id]            INT           IDENTITY (1, 1) NOT NULL,
    [DisplayOrder]  INT           NULL,
    [Code]          VARCHAR (10)  NULL,
    [ServiceDomain] VARCHAR (50)  NOT NULL,
    [Description]   VARCHAR (500) NOT NULL,
    [TempOldId]     INT           NULL,
    CONSTRAINT [PK_ServiceDomain] PRIMARY KEY CLUSTERED ([Id] ASC)
);


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Primary Key', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Master_ServiceDomain', @level2type = N'COLUMN', @level2name = N'Id';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Order in which records will be displayed', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Master_ServiceDomain', @level2type = N'COLUMN', @level2name = N'DisplayOrder';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Code for each Service Domain Type', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Master_ServiceDomain', @level2type = N'COLUMN', @level2name = N'Code';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Service Domain Type', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Master_ServiceDomain', @level2type = N'COLUMN', @level2name = N'ServiceDomain';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Description of each Service Domain Type', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Master_ServiceDomain', @level2type = N'COLUMN', @level2name = N'Description';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Unique Key of Service Domain Type from old database(used for migration)', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Master_ServiceDomain', @level2type = N'COLUMN', @level2name = N'TempOldId';

