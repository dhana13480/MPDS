﻿CREATE TABLE [dbo].[ProviderAgency] (
    [Id]                      BIGINT           IDENTITY (1, 1) NOT NULL,
    [uKeyOld]                 UNIQUEIDENTIFIER NULL,
    [uKeyOldORG]              UNIQUEIDENTIFIER NULL,
    [Name]                    VARCHAR (200)    NOT NULL,
    [CoordinatingAgencyId]    BIGINT           NULL,
    [License]                 VARCHAR (50)     NOT NULL,
    [DaysAllowedForDataEntry] INT              NOT NULL,
    [IsActive]                BIT              CONSTRAINT [DF_ProviderAgency_IsActive] DEFAULT ((1)) NOT NULL,
    [OfficePhone]             VARCHAR (15)     NOT NULL,
    [Fax]                     VARCHAR (12)     NOT NULL,
    [Address1]                VARCHAR (500)    NOT NULL,
    [Address2]                VARCHAR (500)    NOT NULL,
    [City]                    VARCHAR (50)     NOT NULL,
    [State]                   SMALLINT         NOT NULL,
    [Zip]                     VARCHAR (9)      NOT NULL,
    [Comments]                VARCHAR (1000)   NOT NULL,
    [AddressComments]         VARCHAR (1000)   NULL,
    [CreatedBy]               BIGINT           NOT NULL,
    [CreationDate]            DATETIME         NOT NULL,
    [UpdatedBy]               BIGINT           NULL,
    [UpdationDate]            DATETIME         NULL,
    [GuidId]                  UNIQUEIDENTIFIER NULL,
    CONSTRAINT [PK_ProviderAgency] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_ProviderAgency_CoordinatingAgency] FOREIGN KEY ([CoordinatingAgencyId]) REFERENCES [dbo].[CoordinatingAgency] ([Id]),
    CONSTRAINT [FK_ProviderAgency_Master_State] FOREIGN KEY ([State]) REFERENCES [dbo].[Master_State] ([Id])
);


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Primary Key', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ProviderAgency', @level2type = N'COLUMN', @level2name = N'Id';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Provider Agency Unique Key  from old database(used for migration)', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ProviderAgency', @level2type = N'COLUMN', @level2name = N'uKeyOld';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Organisation Unique Key  from old database(used for migration)', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ProviderAgency', @level2type = N'COLUMN', @level2name = N'uKeyOldORG';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Name of Provider Agency', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ProviderAgency', @level2type = N'COLUMN', @level2name = N'Name';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Coordinating Agency linked to Provider Agency (Foreign Key to Coordinating Agency)', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ProviderAgency', @level2type = N'COLUMN', @level2name = N'CoordinatingAgencyId';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'License Number Of Provider Agency', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ProviderAgency', @level2type = N'COLUMN', @level2name = N'License';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Days allowed for data entry', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ProviderAgency', @level2type = N'COLUMN', @level2name = N'DaysAllowedForDataEntry';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'If Provider Agency is active or inactive in the system', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ProviderAgency', @level2type = N'COLUMN', @level2name = N'IsActive';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Office Phone of Provider Agency', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ProviderAgency', @level2type = N'COLUMN', @level2name = N'OfficePhone';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Fax Number of Provider Agency', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ProviderAgency', @level2type = N'COLUMN', @level2name = N'Fax';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Address1 of Provider Agency', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ProviderAgency', @level2type = N'COLUMN', @level2name = N'Address1';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Address2 of Provider Agency', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ProviderAgency', @level2type = N'COLUMN', @level2name = N'Address2';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'City of Provider Agency', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ProviderAgency', @level2type = N'COLUMN', @level2name = N'City';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'State of Provider Agency (Foreign Key to Master_State)', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ProviderAgency', @level2type = N'COLUMN', @level2name = N'State';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Zip of Provider Agency', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ProviderAgency', @level2type = N'COLUMN', @level2name = N'Zip';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Additional Comments /Notes related to provider Agency', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ProviderAgency', @level2type = N'COLUMN', @level2name = N'Comments';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'User who created Provider Agency', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ProviderAgency', @level2type = N'COLUMN', @level2name = N'CreatedBy';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Date when Provider Agency was created', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ProviderAgency', @level2type = N'COLUMN', @level2name = N'CreationDate';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'User who last updated the Provider Agency', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ProviderAgency', @level2type = N'COLUMN', @level2name = N'UpdatedBy';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Date when Provider Agency was last updated', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ProviderAgency', @level2type = N'COLUMN', @level2name = N'UpdationDate';

