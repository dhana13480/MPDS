﻿CREATE TABLE [dbo].[ProviderAgency_SchoolDistrict] (
    [Id]               INT    IDENTITY (1, 1) NOT NULL,
    [ProviderAgencyId] BIGINT NOT NULL,
    [SchoolDistrictId] INT    NOT NULL,
    CONSTRAINT [PK_ProviderAgencySchool] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_ProviderAgency_SchoolDistrict_Master_SchoolDistrict] FOREIGN KEY ([SchoolDistrictId]) REFERENCES [dbo].[Master_SchoolDistrict] ([Id]),
    CONSTRAINT [FK_ProviderAgency_SchoolDistrict_ProviderAgency] FOREIGN KEY ([ProviderAgencyId]) REFERENCES [dbo].[ProviderAgency] ([Id])
);


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Primary Key', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ProviderAgency_SchoolDistrict', @level2type = N'COLUMN', @level2name = N'Id';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Provider Agency Id linked to School District (Foreign Key to ProviderAgency)', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ProviderAgency_SchoolDistrict', @level2type = N'COLUMN', @level2name = N'ProviderAgencyId';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'School District Id linked to Provider Agency (Foreign Key to Master_SchoolDistrict)', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ProviderAgency_SchoolDistrict', @level2type = N'COLUMN', @level2name = N'SchoolDistrictId';

