﻿CREATE TABLE [dbo].[CoordinatingAgency] (
    [Id]              BIGINT           IDENTITY (1, 1) NOT NULL,
    [uKeyOldCA]       UNIQUEIDENTIFIER NULL,
    [uKeyOldORG]      UNIQUEIDENTIFIER NULL,
    [Name]            VARCHAR (200)    NOT NULL,
    [IsActive]        BIT              CONSTRAINT [DF_CoordinatingAgency_IsActive] DEFAULT ((1)) NOT NULL,
    [OfficePhone]     VARCHAR (15)     NOT NULL,
    [Fax]             VARCHAR (12)     NOT NULL,
    [Address1]        VARCHAR (500)    NOT NULL,
    [Address2]        VARCHAR (500)    NOT NULL,
    [City]            VARCHAR (50)     NOT NULL,
    [State]           SMALLINT         NOT NULL,
    [Zip]             VARCHAR (9)      NOT NULL,
    [Comments]        VARCHAR (1000)   NOT NULL,
    [AddressComments] VARCHAR (1000)   NULL,
    [PC_FirstName]    VARCHAR (50)     NULL,
    [PC_MiddleName]   VARCHAR (15)     NULL,
    [PC_LastName]     VARCHAR (50)     NULL,
    [PC_Email]        VARCHAR (500)    NULL,
    [PC_OfficePhone]  VARCHAR (15)     NULL,
    [PC_CellPhone]    VARCHAR (15)     NULL,
    [PC_Comments]     VARCHAR (1000)   NULL,
    [CreatedBy]       BIGINT           NOT NULL,
    [CreationDate]    DATETIME         NOT NULL,
    [UpdatedBy]       BIGINT           NULL,
    [UpdationDate]    DATETIME         NULL,
    CONSTRAINT [PK_CoordinateAgency] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_CoordinatingAgency_Master_State] FOREIGN KEY ([State]) REFERENCES [dbo].[Master_State] ([Id])
);


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Primary Key', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'CoordinatingAgency', @level2type = N'COLUMN', @level2name = N'Id';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CA Unique key of old database(used for migration)', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'CoordinatingAgency', @level2type = N'COLUMN', @level2name = N'uKeyOldCA';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Organization Unique Key of old Database(used for migration)', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'CoordinatingAgency', @level2type = N'COLUMN', @level2name = N'uKeyOldORG';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Name of CoordinatingAgencyId', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'CoordinatingAgency', @level2type = N'COLUMN', @level2name = N'Name';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'If CoordinatingAgency is active or inactive in system', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'CoordinatingAgency', @level2type = N'COLUMN', @level2name = N'IsActive';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Office Phone of Coordinating Agency', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'CoordinatingAgency', @level2type = N'COLUMN', @level2name = N'OfficePhone';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Fax Number of Coordinating Agency', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'CoordinatingAgency', @level2type = N'COLUMN', @level2name = N'Fax';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Address1 of Coordinating Agency', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'CoordinatingAgency', @level2type = N'COLUMN', @level2name = N'Address1';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Address2 of Coordinating Agency', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'CoordinatingAgency', @level2type = N'COLUMN', @level2name = N'Address2';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'City of Coordinating Agency', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'CoordinatingAgency', @level2type = N'COLUMN', @level2name = N'City';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'State of Coordinating Agency(Foreign Key to Master_State)', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'CoordinatingAgency', @level2type = N'COLUMN', @level2name = N'State';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Zip of Coordinating Agency', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'CoordinatingAgency', @level2type = N'COLUMN', @level2name = N'Zip';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Additional Comments/Notes related to Coordinating Agency', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'CoordinatingAgency', @level2type = N'COLUMN', @level2name = N'Comments';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Not being used in new database', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'CoordinatingAgency', @level2type = N'COLUMN', @level2name = N'AddressComments';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N' First Name of Prevention Coordinator of Coordinating Agency', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'CoordinatingAgency', @level2type = N'COLUMN', @level2name = N'PC_FirstName';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Middle Name of Prevention Coordinator of Coordinating Agency', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'CoordinatingAgency', @level2type = N'COLUMN', @level2name = N'PC_MiddleName';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Last Name of Prevention Coordinator of Coordinating Agency', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'CoordinatingAgency', @level2type = N'COLUMN', @level2name = N'PC_LastName';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'EmailId of Prevention Coordinator of Coordinating Agency', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'CoordinatingAgency', @level2type = N'COLUMN', @level2name = N'PC_Email';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Office Phone of Prevention Coordinator of Coordinating Agency', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'CoordinatingAgency', @level2type = N'COLUMN', @level2name = N'PC_OfficePhone';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Cell Phone Number of Prevention Coordinator of Coordinating Agency', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'CoordinatingAgency', @level2type = N'COLUMN', @level2name = N'PC_CellPhone';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Additoinal Comments/Notes related to Prevention Coordinator of Coordinating Agency', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'CoordinatingAgency', @level2type = N'COLUMN', @level2name = N'PC_Comments';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'User who created the Coordinating Agency', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'CoordinatingAgency', @level2type = N'COLUMN', @level2name = N'CreatedBy';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Date of creation of Coordinating Agency', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'CoordinatingAgency', @level2type = N'COLUMN', @level2name = N'CreationDate';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'User who last updated the Coordinating Agency', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'CoordinatingAgency', @level2type = N'COLUMN', @level2name = N'UpdatedBy';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Date when Coordinating Agency was last updated', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'CoordinatingAgency', @level2type = N'COLUMN', @level2name = N'UpdationDate';

