﻿CREATE TABLE [dbo].[ValidationMatrix] (
    [Id]                            SMALLINT       NOT NULL,
    [GroupType]                     INT            NOT NULL,
    [ProgramType]                   INT            NOT NULL,
    [InterventionType]              INT            NOT NULL,
    [ServicePopulation]             VARCHAR (1000) NOT NULL,
    [Strategies]                    VARCHAR (1000) NOT NULL,
    [RequireTotalAttendees]         BIT            NOT NULL,
    [RequireEstimatedReach]         BIT            NOT NULL,
    [AllowTotalOrEstimatedReach]    BIT            NOT NULL,
    [AllowTotalAndOrEstimatedReach] BIT            NOT NULL,
    [RequireDemographics]           BIT            NOT NULL,
    CONSTRAINT [PK_ValidationMatrix] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_ValidationMatrix_Master_GroupType] FOREIGN KEY ([GroupType]) REFERENCES [dbo].[Master_GroupType] ([Id]),
    CONSTRAINT [FK_ValidationMatrix_Master_InterventionType] FOREIGN KEY ([InterventionType]) REFERENCES [dbo].[Master_InterventionType] ([Id]),
    CONSTRAINT [FK_ValidationMatrix_Master_ProgramType] FOREIGN KEY ([ProgramType]) REFERENCES [dbo].[Master_ProgramType] ([Id])
);


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Primary Key', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ValidationMatrix', @level2type = N'COLUMN', @level2name = N'Id';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Group Type to which Validation Matrix Values are linked(Foreign Key to Master_GroupType)', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ValidationMatrix', @level2type = N'COLUMN', @level2name = N'GroupType';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Program Type to which Group is linked(Foreign Key to Master_ProgramType)', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ValidationMatrix', @level2type = N'COLUMN', @level2name = N'ProgramType';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Intervention Type to which Group is linked(Foreign Key to Master_InterventionType)', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ValidationMatrix', @level2type = N'COLUMN', @level2name = N'InterventionType';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Service Population to which Group is linked', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ValidationMatrix', @level2type = N'COLUMN', @level2name = N'ServicePopulation';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Strategies linked with Activity', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ValidationMatrix', @level2type = N'COLUMN', @level2name = N'Strategies';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Total Attendees required for Activity', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ValidationMatrix', @level2type = N'COLUMN', @level2name = N'RequireTotalAttendees';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Estmated Reach required for Activity', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ValidationMatrix', @level2type = N'COLUMN', @level2name = N'RequireEstimatedReach';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Allowed Total or Estimated Reach for Activity', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ValidationMatrix', @level2type = N'COLUMN', @level2name = N'AllowTotalOrEstimatedReach';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Allowed Total and Estimated Reach for Activity', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ValidationMatrix', @level2type = N'COLUMN', @level2name = N'AllowTotalAndOrEstimatedReach';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Required Demographics for Activity', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ValidationMatrix', @level2type = N'COLUMN', @level2name = N'RequireDemographics';

