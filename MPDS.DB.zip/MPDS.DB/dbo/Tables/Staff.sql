﻿CREATE TABLE [dbo].[Staff] (
    [Id]                   BIGINT           IDENTITY (1, 1) NOT NULL,
    [uKeyOld]              UNIQUEIDENTIFIER NULL,
    [FirstName]            VARCHAR (50)     NOT NULL,
    [MiddleName]           VARCHAR (15)     NOT NULL,
    [LastName]             VARCHAR (50)     NOT NULL,
    [CoordinatingAgencyId] BIGINT           NULL,
    [ProviderAgencyId]     BIGINT           NULL,
    [EffectiveFrom]        DATETIME         NULL,
    [EffectiveTo]          DATETIME         NULL,
    [IsActive]             BIT              NOT NULL,
    [Email]                VARCHAR (255)    NOT NULL,
    [CellPhone]            VARCHAR (15)     NOT NULL,
    [OfficePhone]          VARCHAR (15)     NOT NULL,
    [HomePhone]            VARCHAR (12)     NOT NULL,
    [Fax]                  VARCHAR (12)     NOT NULL,
    [Address1]             VARCHAR (500)    NOT NULL,
    [Address2]             VARCHAR (500)    NOT NULL,
    [City]                 VARCHAR (50)     NOT NULL,
    [State]                SMALLINT         NOT NULL,
    [Zip]                  VARCHAR (9)      NOT NULL,
    [Comments]             VARCHAR (1000)   NOT NULL,
    [CreatedBy]            BIGINT           NOT NULL,
    [CreationDate]         DATETIME         NOT NULL,
    [UpdatedBy]            BIGINT           NULL,
    [UpdationDate]         DATETIME         NULL,
    [StaffType]            SMALLINT         NOT NULL,
    [IsDeleted]            BIT              CONSTRAINT [DF__Staff__IsDeleted__4865BE2A] DEFAULT ((0)) NOT NULL,
    CONSTRAINT [PK_Person] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_Staff_CoordinatingAgency] FOREIGN KEY ([CoordinatingAgencyId]) REFERENCES [dbo].[CoordinatingAgency] ([Id]),
    CONSTRAINT [FK_Staff_Master_StaffType] FOREIGN KEY ([StaffType]) REFERENCES [dbo].[Master_StaffType] ([Id]),
    CONSTRAINT [FK_Staff_ProviderAgency] FOREIGN KEY ([ProviderAgencyId]) REFERENCES [dbo].[ProviderAgency] ([Id])
);


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Primary Key', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Staff', @level2type = N'COLUMN', @level2name = N'Id';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Key in Old Database(used for migration)', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Staff', @level2type = N'COLUMN', @level2name = N'uKeyOld';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'First Name of Staff Member', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Staff', @level2type = N'COLUMN', @level2name = N'FirstName';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Middle Name of Staff Member', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Staff', @level2type = N'COLUMN', @level2name = N'MiddleName';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Last Name Of Staff Member', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Staff', @level2type = N'COLUMN', @level2name = N'LastName';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Coordinating Agency Id  to which Staff Member is linked(Foreign Key to CoordinatingAgency)', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Staff', @level2type = N'COLUMN', @level2name = N'CoordinatingAgencyId';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Provider Agency Id to which Staff Member is linked(Foreign Key to Provider Agency)', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Staff', @level2type = N'COLUMN', @level2name = N'ProviderAgencyId';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Tenure Start Date', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Staff', @level2type = N'COLUMN', @level2name = N'EffectiveFrom';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Tenure End Date ', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Staff', @level2type = N'COLUMN', @level2name = N'EffectiveTo';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'If Staff Member is active or inactive in the system', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Staff', @level2type = N'COLUMN', @level2name = N'IsActive';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Email Id of Staff Member', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Staff', @level2type = N'COLUMN', @level2name = N'Email';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Cell Phone of Staff Member', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Staff', @level2type = N'COLUMN', @level2name = N'CellPhone';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Office Phone of Staff Member', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Staff', @level2type = N'COLUMN', @level2name = N'OfficePhone';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Home Phone of Staff Member', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Staff', @level2type = N'COLUMN', @level2name = N'HomePhone';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Fax Number of Staff Member', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Staff', @level2type = N'COLUMN', @level2name = N'Fax';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Address1  of Staff Member', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Staff', @level2type = N'COLUMN', @level2name = N'Address1';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Address2 of Staff Member', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Staff', @level2type = N'COLUMN', @level2name = N'Address2';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'City Of Staff Member', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Staff', @level2type = N'COLUMN', @level2name = N'City';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'State of Staff Member', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Staff', @level2type = N'COLUMN', @level2name = N'State';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Zip of Staff Member', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Staff', @level2type = N'COLUMN', @level2name = N'Zip';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Additional Comments/Notes related to staff Member', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Staff', @level2type = N'COLUMN', @level2name = N'Comments';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Id of User who created the Staff Member', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Staff', @level2type = N'COLUMN', @level2name = N'CreatedBy';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Date when Staff Member was created', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Staff', @level2type = N'COLUMN', @level2name = N'CreationDate';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'User who last updated Staff Member', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Staff', @level2type = N'COLUMN', @level2name = N'UpdatedBy';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Date when Staff Member was last updated', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Staff', @level2type = N'COLUMN', @level2name = N'UpdationDate';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Staff Type of Staff Member(Foreign Key to Master_StaffType)', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Staff', @level2type = N'COLUMN', @level2name = N'StaffType';

