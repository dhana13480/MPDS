﻿CREATE TABLE [dbo].[Master_ParticipantAgeGroup] (
    [Id]                  INT           IDENTITY (1, 1) NOT NULL,
    [ParticipantAgeGroup] VARCHAR (50)  NOT NULL,
    [Description]         VARCHAR (500) NOT NULL,
    [TempOldId]           INT           NULL,
    CONSTRAINT [PK_ParticipantAgeGroup] PRIMARY KEY CLUSTERED ([Id] ASC)
);


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Primary Key', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Master_ParticipantAgeGroup', @level2type = N'COLUMN', @level2name = N'Id';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Participant Age Group Type', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Master_ParticipantAgeGroup', @level2type = N'COLUMN', @level2name = N'ParticipantAgeGroup';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Description of Participant Age Group Type', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Master_ParticipantAgeGroup', @level2type = N'COLUMN', @level2name = N'Description';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Unique Key of Participant Age Group Type from old database(used for migration)', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Master_ParticipantAgeGroup', @level2type = N'COLUMN', @level2name = N'TempOldId';

