﻿CREATE TABLE [dbo].[ProviderAgency_OptionalData] (
    [Id]               INT    IDENTITY (1, 1) NOT NULL,
    [ProviderAgencyId] BIGINT NOT NULL,
    [OptionalDataId]   INT    NOT NULL,
    CONSTRAINT [PK_ProviderAgencyOptionalData] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_ProviderAgency_OptionalData_Master_ActivityOptionalData] FOREIGN KEY ([OptionalDataId]) REFERENCES [dbo].[Master_ActivityOptionalData] ([Id]),
    CONSTRAINT [FK_ProviderAgency_OptionalData_ProviderAgency] FOREIGN KEY ([ProviderAgencyId]) REFERENCES [dbo].[ProviderAgency] ([Id])
);


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Primary Key', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ProviderAgency_OptionalData', @level2type = N'COLUMN', @level2name = N'Id';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Provider Agency Id linked to Optional Data(Foreign Key to ProviderAgency) ', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ProviderAgency_OptionalData', @level2type = N'COLUMN', @level2name = N'ProviderAgencyId';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Optional Data Id linked to Provider Agency (Foreign Key to Master_ActivityOptionalData)', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ProviderAgency_OptionalData', @level2type = N'COLUMN', @level2name = N'OptionalDataId';

