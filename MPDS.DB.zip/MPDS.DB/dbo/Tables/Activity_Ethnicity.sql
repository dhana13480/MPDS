﻿CREATE TABLE [dbo].[Activity_Ethnicity] (
    [Id]            BIGINT IDENTITY (1, 1) NOT NULL,
    [ActivityId]    BIGINT NOT NULL,
    [EthnicityId]   INT    NULL,
    [NoOfAttendees] INT    NOT NULL,
    CONSTRAINT [PK_Activity_Ethnicity] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_Activity_Ethnicity_Activity] FOREIGN KEY ([ActivityId]) REFERENCES [dbo].[Activity] ([Id]),
    CONSTRAINT [FK_Activity_Ethnicity_Activity_Ethnicity] FOREIGN KEY ([EthnicityId]) REFERENCES [dbo].[Master_Ethnicity] ([Id])
);


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Primary Key', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Activity_Ethnicity', @level2type = N'COLUMN', @level2name = N'Id';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Activity Id related to Ethnicity (Foreign Key to Activity)', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Activity_Ethnicity', @level2type = N'COLUMN', @level2name = N'ActivityId';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Ethnicity Id  related to Activity(Foreign Key related to Master_Ethnicity)', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Activity_Ethnicity', @level2type = N'COLUMN', @level2name = N'EthnicityId';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Number of Attendees for this Ethnicity', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Activity_Ethnicity', @level2type = N'COLUMN', @level2name = N'NoOfAttendees';

