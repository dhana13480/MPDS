﻿CREATE TABLE [dbo].[Notifications_Attachment] (
    [Id]             BIGINT        IDENTITY (1, 1) NOT NULL,
    [NotificationId] BIGINT        NOT NULL,
    [Name]           VARCHAR (50)  NOT NULL,
    [FileName]       VARCHAR (100) NOT NULL,
    [CreatedBy]      BIGINT        NOT NULL,
    [CreationDate]   DATETIME      NOT NULL,
    CONSTRAINT [PK_Notifications_Attachments] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_Notifications_Attachments_Notifications] FOREIGN KEY ([NotificationId]) REFERENCES [dbo].[Notification] ([Id])
);

