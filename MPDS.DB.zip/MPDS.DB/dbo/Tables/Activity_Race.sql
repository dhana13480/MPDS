﻿CREATE TABLE [dbo].[Activity_Race] (
    [Id]            BIGINT IDENTITY (1, 1) NOT NULL,
    [ActivityId]    BIGINT NOT NULL,
    [RaceId]        INT    NULL,
    [NoOfAttendees] INT    NOT NULL,
    CONSTRAINT [PK_Activity_Race] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_Activity_Race_Activity] FOREIGN KEY ([ActivityId]) REFERENCES [dbo].[Activity] ([Id]),
    CONSTRAINT [FK_Activity_Race_Master_Race] FOREIGN KEY ([RaceId]) REFERENCES [dbo].[Master_Race] ([Id])
);


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Primary Key', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Activity_Race', @level2type = N'COLUMN', @level2name = N'Id';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Activity (Foreign Key to Activity))', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Activity_Race', @level2type = N'COLUMN', @level2name = N'ActivityId';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N' Race related to Activity(Foreign Key to Master_Race)', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Activity_Race', @level2type = N'COLUMN', @level2name = N'RaceId';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Number of Activity Attendees of this Race', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Activity_Race', @level2type = N'COLUMN', @level2name = N'NoOfAttendees';

