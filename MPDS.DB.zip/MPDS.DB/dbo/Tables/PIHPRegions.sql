﻿CREATE TABLE [dbo].[PIHPRegions] (
    [Id]     UNIQUEIDENTIFIER NOT NULL,
    [Name]   NVARCHAR (MAX)   NULL,
    [Phone]  NVARCHAR (MAX)   NULL,
    [Status] NVARCHAR (MAX)   NULL,
    CONSTRAINT [PK_PIHPRegions] PRIMARY KEY CLUSTERED ([Id] ASC)
);

