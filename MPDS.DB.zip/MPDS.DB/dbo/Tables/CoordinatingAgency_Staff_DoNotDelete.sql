﻿CREATE TABLE [dbo].[CoordinatingAgency_Staff_DoNotDelete] (
    [Id]                   BIGINT       IDENTITY (1, 1) NOT NULL,
    [CoordinatingAgencyId] BIGINT       NOT NULL,
    [StaffId]              BIGINT       NOT NULL,
    [EffectiveFrom]        DATETIME     NULL,
    [EffectiveTo]          DATETIME     NULL,
    [OldPersonType]        VARCHAR (50) NULL,
    CONSTRAINT [PK_CoordinatingAgencyStaff] PRIMARY KEY CLUSTERED ([Id] ASC)
);

