﻿CREATE TABLE [dbo].[CoordinatingAgency_County] (
    [Id]                   INT    IDENTITY (1, 1) NOT NULL,
    [CoordinatingAgencyId] BIGINT NOT NULL,
    [CountyId]             INT    NOT NULL,
    CONSTRAINT [PK_CoordinatingAgencyCounty] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_CoordinatingAgency_County_CoordinatingAgency] FOREIGN KEY ([CoordinatingAgencyId]) REFERENCES [dbo].[CoordinatingAgency] ([Id]),
    CONSTRAINT [FK_CoordinatingAgency_County_Master_County] FOREIGN KEY ([CountyId]) REFERENCES [dbo].[Master_County] ([Id])
);


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Primary Key', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'CoordinatingAgency_County', @level2type = N'COLUMN', @level2name = N'Id';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Coordinating Agency to which county is linked(Foreign Key to CoordinatingAgency) ', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'CoordinatingAgency_County', @level2type = N'COLUMN', @level2name = N'CoordinatingAgencyId';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'County Related with Coordinating Agency (Foreign Key with Master_County)', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'CoordinatingAgency_County', @level2type = N'COLUMN', @level2name = N'CountyId';

