﻿CREATE TABLE [dbo].[ActivityDataReport_TemplateDetails] (
    [Id]         BIGINT   IDENTITY (1, 1) NOT NULL,
    [TemplateId] BIGINT   NOT NULL,
    [FieldId]    SMALLINT NOT NULL,
    CONSTRAINT [PK_ActivityDataReport_TemplateDetails] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_ActivityDataReport_TemplateDetails_ActivityDataReport_Template] FOREIGN KEY ([TemplateId]) REFERENCES [dbo].[ActivityDataReport_Template] ([Id]),
    CONSTRAINT [FK_ActivityDataReport_TemplateDetails_Master_ActivityDataReportFields] FOREIGN KEY ([FieldId]) REFERENCES [dbo].[Master_ActivityDataReportFields] ([Id])
);

