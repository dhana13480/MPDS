﻿CREATE TABLE [dbo].[__RawProgramNames] (
    [Id]       UNIQUEIDENTIFIER CONSTRAINT [DF___RawProgramNames_Id] DEFAULT (newid()) NOT NULL,
    [EBP]      NVARCHAR (255)   NULL,
    [Region1]  NVARCHAR (255)   NULL,
    [Region2]  NVARCHAR (255)   NULL,
    [Region3]  NVARCHAR (255)   NULL,
    [Region4]  NVARCHAR (255)   NULL,
    [Region5]  NVARCHAR (255)   NULL,
    [Region6]  NVARCHAR (255)   NULL,
    [Region7]  NVARCHAR (255)   NULL,
    [Region8]  NVARCHAR (255)   NULL,
    [Region9]  NVARCHAR (255)   NULL,
    [Region10] NVARCHAR (255)   NULL,
    CONSTRAINT [PK___RawProgramNames] PRIMARY KEY CLUSTERED ([Id] ASC)
);

