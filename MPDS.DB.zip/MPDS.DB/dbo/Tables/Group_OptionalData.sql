﻿CREATE TABLE [dbo].[Group_OptionalData] (
    [Id]                  BIGINT           IDENTITY (1, 1) NOT NULL,
    [uKeyOld]             UNIQUEIDENTIFIER NULL,
    [ebpCycle]            INT              NULL,
    [ServicePopulationId] INT              NULL,
    [ServiceSettingId]    INT              NULL,
    [ebpOtherServiceType] VARCHAR (500)    NULL,
    CONSTRAINT [PK_GroupOptionalData_1] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_Group_OptionalData_Master_ServicePopulation] FOREIGN KEY ([ServicePopulationId]) REFERENCES [dbo].[Master_IntendedPopulation] ([Id]),
    CONSTRAINT [FK_Group_OptionalData_Master_ServiceSetting] FOREIGN KEY ([ServiceSettingId]) REFERENCES [dbo].[Master_ServiceSetting] ([Id])
);


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Primary Key', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Group_OptionalData', @level2type = N'COLUMN', @level2name = N'Id';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Unique Optional data key from old database', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Group_OptionalData', @level2type = N'COLUMN', @level2name = N'uKeyOld';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Evidence Based Program Cycle', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Group_OptionalData', @level2type = N'COLUMN', @level2name = N'ebpCycle';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Service Population linked with Group Optional Data (Foreign Key to Master_ServicePopulation)', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Group_OptionalData', @level2type = N'COLUMN', @level2name = N'ServicePopulationId';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Service Settings linked with Group Optional Data (Foreign Key to Master_ServiceSetting)', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Group_OptionalData', @level2type = N'COLUMN', @level2name = N'ServiceSettingId';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Ebp related other service Type linked with Group optional data', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Group_OptionalData', @level2type = N'COLUMN', @level2name = N'ebpOtherServiceType';

