﻿CREATE TABLE [dbo].[Activity_Staff] (
    [Id]               BIGINT       IDENTITY (1, 1) NOT NULL,
    [ActivityId]       BIGINT       NOT NULL,
    [StaffId]          BIGINT       NOT NULL,
    [StrategyId]       INT          NULL,
    [Units]            INT          NOT NULL,
    [OptionalLocalMBO] VARCHAR (10) NULL,
    [StartDate]        DATETIME     NULL,
    [EndDate]          DATETIME     NULL,
    CONSTRAINT [PK_Activity_Staff] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_Activity_Staff_Activity] FOREIGN KEY ([ActivityId]) REFERENCES [dbo].[Activity] ([Id]),
    CONSTRAINT [FK_Activity_Staff_Master_Strategy] FOREIGN KEY ([StrategyId]) REFERENCES [dbo].[Master_Strategy] ([Id]),
    CONSTRAINT [FK_Activity_Staff_Staff] FOREIGN KEY ([StaffId]) REFERENCES [dbo].[Staff] ([Id])
);


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Primary Key', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Activity_Staff', @level2type = N'COLUMN', @level2name = N'Id';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Activity linked to Staff (Foreign Key to Activity)', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Activity_Staff', @level2type = N'COLUMN', @level2name = N'ActivityId';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Staff  related to Activity(Foreign Key to Staff)', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Activity_Staff', @level2type = N'COLUMN', @level2name = N'StaffId';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Strategy related to Activity(Foreign Key to Master_Strategy )', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Activity_Staff', @level2type = N'COLUMN', @level2name = N'StrategyId';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Units spent for Activity', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Activity_Staff', @level2type = N'COLUMN', @level2name = N'Units';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Optional Data Local MBO ', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Activity_Staff', @level2type = N'COLUMN', @level2name = N'OptionalLocalMBO';

