﻿CREATE TABLE [dbo].[Master_StaffType] (
    [Id]        SMALLINT     IDENTITY (1, 1) NOT NULL,
    [StaffType] VARCHAR (50) NOT NULL,
    CONSTRAINT [PK_Master_StaffType] PRIMARY KEY CLUSTERED ([Id] ASC)
);


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Primary Key', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Master_StaffType', @level2type = N'COLUMN', @level2name = N'Id';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Name of Staff Type', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Master_StaffType', @level2type = N'COLUMN', @level2name = N'StaffType';

