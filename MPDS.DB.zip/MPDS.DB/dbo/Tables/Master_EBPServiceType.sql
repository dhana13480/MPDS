﻿CREATE TABLE [dbo].[Master_EBPServiceType] (
    [Id]             INT           IDENTITY (1, 1) NOT NULL,
    [EBPServiceType] VARCHAR (50)  NOT NULL,
    [Description]    VARCHAR (500) NOT NULL,
    [IsActive]       BIT           CONSTRAINT [DF_Master_EBPServiceType_IsActive] DEFAULT ((1)) NOT NULL,
    [CreatedBy]      BIGINT        NOT NULL,
    [CreationDate]   DATETIME      NOT NULL,
    [UpdatedBy]      BIGINT        NULL,
    [UpdationDate]   DATETIME      NULL,
    [TempOldId]      INT           NULL,
    CONSTRAINT [PK_EBPServiceType] PRIMARY KEY CLUSTERED ([Id] ASC)
);


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Primary Key', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Master_EBPServiceType', @level2type = N'COLUMN', @level2name = N'Id';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Name of EBPServiceType', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Master_EBPServiceType', @level2type = N'COLUMN', @level2name = N'EBPServiceType';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Description of EBPServiceType', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Master_EBPServiceType', @level2type = N'COLUMN', @level2name = N'Description';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'If EBPServiceType is active or inactive in the system', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Master_EBPServiceType', @level2type = N'COLUMN', @level2name = N'IsActive';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'User who created EBPServiceType', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Master_EBPServiceType', @level2type = N'COLUMN', @level2name = N'CreatedBy';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Date when EBPServiceType was created', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Master_EBPServiceType', @level2type = N'COLUMN', @level2name = N'CreationDate';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'User who last updated the  EBPServiceType', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Master_EBPServiceType', @level2type = N'COLUMN', @level2name = N'UpdatedBy';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Date when EBPServiceType was last updated', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Master_EBPServiceType', @level2type = N'COLUMN', @level2name = N'UpdationDate';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Unique Key of EBPServiceType from old database(used for migration)', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Master_EBPServiceType', @level2type = N'COLUMN', @level2name = N'TempOldId';

