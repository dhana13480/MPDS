﻿CREATE procedure [dbo].[UpdateNotificationEmailStatus] 
@NotificationId bigint 
   AS
  BEGIN
  SET NOCOUNT ON;
      -- Update Password as well along with other fields
      Update dbo.Notification set dbo.Notification.IsEmailSent=1
      Where dbo.Notification.Id=@NotificationId;
 END


