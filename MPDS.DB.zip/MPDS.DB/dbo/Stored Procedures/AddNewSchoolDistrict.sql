﻿CREATE procedure [dbo].[AddNewSchoolDistrict]  
  @SchoolDistrict varchar(50),
  @CountyId int, 
  @Description varchar(500),
  @CreationDate datetime,
  @CreatedBy bigint  
 as  
 begin    
 insert into Master_SchoolDistrict  
 (CountyId, 
 SchoolDistrict,
 Description,
 IsActive,
 CreationDate,
 CreatedBy)
  
 values(  
  @CountyId,
  @SchoolDistrict,
  @Description,
  1,
  @CreationDate,
  @CreatedBy)  
    
END
