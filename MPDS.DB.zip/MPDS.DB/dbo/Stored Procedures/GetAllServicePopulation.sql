﻿-- exec GetAllServicePopulation

 CREATE procedure [dbo].[GetAllServicePopulation]
 
 as
 begin 
 
 Select dbo.Master_ServicePopulation.Id,
        dbo.Master_ServicePopulation.Code
        +' - '+dbo.Master_ServicePopulation.ServicePopulation as ServicePopulation 
    
		 from dbo.Master_ServicePopulation
		 order by dbo.Master_ServicePopulation.DisplayOrder asc
  
 end
