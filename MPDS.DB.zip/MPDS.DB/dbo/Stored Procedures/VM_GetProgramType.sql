﻿-- exec VM_GetProgramType 3

 CREATE procedure [dbo].[VM_GetProgramType]
 
 @GroupTypeId int
 
 as
 begin 
 
 Select distinct dbo.Master_ProgramType.Id,
  dbo.Master_ProgramType.ProgramType,  
  dbo.Master_ProgramType.Description  
  from dbo.ValidationMatrix
  inner Join dbo.Master_ProgramType on dbo.ValidationMatrix.ProgramType=dbo.Master_ProgramType.Id
  Where dbo.ValidationMatrix.GroupType=@GroupTypeId
  order by dbo.Master_ProgramType.ProgramType 
  asc
  
 end
