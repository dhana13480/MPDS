﻿-- exec GetProviderAgencyDetails 17

 CREATE procedure [dbo].[GetProviderAgencyCounties]  
  @ProviderAgencyId bigint 
  as  
 begin 
		 Select 
		 dbo.ProviderAgency_County.CountyId,
		 dbo.Master_County.County 
		 From dbo.ProviderAgency_County
		 inner join dbo.Master_County on dbo.ProviderAgency_County.CountyId=Master_County.Id
		  
		 Where dbo.ProviderAgency_County.ProviderAgencyId=@ProviderAgencyId
		 order by  dbo.Master_County.County  asc
    
  end
