﻿CREATE procedure [dbo].[UpdateSchoolDistrict]
  @SchoolDistrict varchar(50)
 ,@Description  varchar(500)
 ,@UpdatedBy   bigint
 ,@UpdationDate datetime
 ,@Id int
  
 as
 begin 
 
 update Master_SchoolDistrict set SchoolDistrict=@SchoolDistrict
 ,[Description]=@Description
 ,UpdatedBy=@UpdatedBy
 ,UpdationDate=@UpdationDate 
 where Id=@Id
 
  
 end
