﻿-- exec GetCoordinatingAgencySchoolDistrictsByCounty 15,''

 CREATE procedure [dbo].[GetCoordinatingAgencySchoolDistrictsByCounty]  
  @CoordinatingAgencyId bigint,
  @CSVCounties varchar(max) 
  as  
 begin 
		
	 SET NOCOUNT ON;  
  
DECLARE @statement nvarchar(max); 
DECLARE @statementParamDec nvarchar(200);   
 
	
set @statement='		 
		Select dbo.CoordinatingAgency_SchoolDistrict.SchoolDistrictId,
		 dbo.Master_SchoolDistrict.SchoolDistrict,
		 dbo.Master_SchoolDistrict.CountyId
		  
		 From dbo.CoordinatingAgency_SchoolDistrict
		 inner join dbo.Master_SchoolDistrict on dbo.CoordinatingAgency_SchoolDistrict.SchoolDistrictId=Master_SchoolDistrict.Id
		  
		 Where dbo.CoordinatingAgency_SchoolDistrict.CoordinatingAgencyId=@CoordinatingAgencyId
		 '
		 
		 if(@CSVCounties<>'') 		
			 begin  
			  set @statement=@statement+' and Master_SchoolDistrict.CountyId IN ('+@CSVCounties+')'  
			 end
			 
			  set @statement=@statement+' order by dbo.Master_SchoolDistrict.SchoolDistrict asc'  
			 
	--Print @statement
	 
	  SET @statementParamDec = N'@CoordinatingAgencyId bigint';  
 
	  EXEC sp_executesql @statement, @statementParamDec,@CoordinatingAgencyId
	   
  END
