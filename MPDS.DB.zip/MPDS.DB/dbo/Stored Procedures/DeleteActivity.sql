﻿--- 

CREATE PROCEDURE [dbo].[DeleteActivity] 
@Id bigint,
@UpdatedBy bigint,
@UpdationDate datetime 

AS
BEGIN

BEGIN TRY
	BEGIN TRANSACTION

Declare @GroupId bigint;

Set @GroupId = (Select GroupId from Activity Where Id=@Id);

UPDATE dbo.Activity SET 
dbo.Activity.IsDeleted=1,
dbo.Activity.UpdatedBy=@UpdatedBy,
dbo.Activity.UpdationDate=@UpdationDate
WHERE dbo.Activity.Id=@Id

-- Update Activity Order
-- Used IN AddActivity, UpdateActivity and DeleteActivity
Update A
Set A.OrderNumber = GA.Num
From Activity A
Inner Join (
Select ROW_NUMBER() over (Order BY StartDate) Num,  Id, StartDate, ActivityName from Activity 
Where IsDeleted = 0
AND GroupId = @GroupId) GA ON (GA.ID = A.Id)


	COMMIT TRANSACTION
END TRY
	BEGIN CATCH
		ROLLBACK TRANSACTION
		DECLARE @ErrorMessage NVARCHAR(4000);
    DECLARE @ErrorSeverity INT;
    DECLARE @ErrorState INT;

    SELECT 
        @ErrorMessage = + ERROR_MESSAGE(),
        @ErrorSeverity = ERROR_SEVERITY(),
        @ErrorState = ERROR_STATE();

    RAISERROR (@ErrorMessage, -- Message text.
               @ErrorSeverity, -- Severity.
               @ErrorState -- State.
               );
   
		--Select -1;
	END CATCH

end
