﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>

-- exec GetAllNotificationsCount -1,100,0,1
-- =============================================
CREATE PROCEDURE [dbo].[GetAllNotificationsCount] 
	-- Add the parameters for the stored procedure here

@UserId bigint,
@UserTypeId smallint,
@Date datetime

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

DECLARE @statement nvarchar(max);
DECLARE @statementParamDec nvarchar(2000);	

Declare @CoordinatingAgencyId bigint;
Declare @ProviderAgencyId bigint;
Set @CoordinatingAgencyId=0;
Set @ProviderAgencyId=0;

If(@UserTypeId=3) -- CA
BEGIN
Set @CoordinatingAgencyId=(Select dbo.Users.CoordinatingAgencyId from dbo.Users
							Where dbo.Users.Id=@UserId)
END
ELSE if (@UserTypeId=4) -- PA
BEGIN
Select @CoordinatingAgencyId=P_CA.Id,
		@ProviderAgencyId=ProviderAgencyId from dbo.Users
							inner join dbo.ProviderAgency on dbo.Users.ProviderAgencyId=dbo.ProviderAgency.Id
							inner join dbo.CoordinatingAgency P_CA on dbo.ProviderAgency.CoordinatingAgencyId=P_CA.Id
							Where dbo.Users.Id=@UserId
END
	

set @statement='
		SELECT count(1)
		from dbo.Notification 
		Where Convert(Date,@Date) >= Convert(Date,CONVERT(VARCHAR, dbo.Notification.StartDate, 101))
		AND Convert(Date,@Date) <= Convert(Date,CONVERT(VARCHAR, dbo.Notification.EndDate, 101))'

		If(@UserTypeId=3) -- CA 
			BEGIN
			set @statement=@statement+'	
			and (
			((dbo.Notification.TypeId=2 or dbo.Notification.TypeId=4)
			And Convert(varchar(255),@CoordinatingAgencyId) IN (Select item1 from dbo.SplitCSVs(dbo.Notification.CSVCoordinatingAgencyIds,'','')))
			OR dbo.Notification.TypeId=1
			)'
			--(
			--Case When (dbo.Notification.TypeId=2 or dbo.Notification.TypeId=4)
			--THEN (Convert(varchar(max),dbo.Notification.CSVCoordinatingAgencyIds))
			--WHEN dbo.Notification.TypeId=1
			--THEN (@CoordinatingAgencyId)
			--end
			--)
		END
		ELSE IF (@UserTypeId=4) -- PA
		BEGIN		 
			set @statement=@statement+ '
			and (
			((dbo.Notification.TypeId=3 or dbo.Notification.TypeId=4)
			And Convert(varchar(255),@ProviderAgencyId) IN (Select item1 from dbo.SplitCSVs(dbo.Notification.CSVProviderAgencyIds, '','')))
			OR dbo.Notification.TypeId=1
			)'
			--(
			--Case When (dbo.Notification.TypeId=3 or dbo.Notification.TypeId=4)
			--THEN (Convert(varchar(max),dbo.Notification.CSVProviderAgencyIds))
			--WHEN dbo.Notification.TypeId=1
			--THEN (@ProviderAgencyId)
			--end
			--)
		END

		

SET @statementParamDec = N'@UserId bigint,@UserTypeId smallint,@Date datetime,@CoordinatingAgencyId bigint,@ProviderAgencyId bigint';

--select @statement
EXEC sp_executesql @statement,@statementParamDec, @UserId,@UserTypeId,@Date,@CoordinatingAgencyId,@ProviderAgencyId;



END


