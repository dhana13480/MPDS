﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- exec CreateUser dsf
-- =============================================
CREATE PROCEDURE [dbo].[SaveActivityDataReportTemplate] 
	-- Add the parameters for the stored procedure here
@TemplateId bigint,
@TemplateName varchar(100),
@CSVFieldIds varchar(Max),
@CSVCoordinatingAgencyIds varchar (MAX),
@CSVProviderAgencyIds varchar (MAX),
@CSVGroupIds varchar (MAX),
@UserId bigint,
@CreationDate datetime


AS
BEGIN
	 --SET NOCOUNT ON added to prevent extra result sets from
	 --interfering with SELECT statements.
	SET NOCOUNT ON;

BEGIN TRY
	BEGIN TRANSACTION
Declare @CreatedTemplateId bigint=NULL;	
	

If(@TemplateId>0)
	BEGIN
	-- delete and create
	Update dbo.ActivityDataReport_Template Set 
	Name=@TemplateName,
	CSVCoordinatingAgencyIds=@CSVCoordinatingAgencyIds,
	CSVProviderAgencyIds=@CSVProviderAgencyIds,
	CSVGroupIds=@CSVGroupIds,
	UpdatedBy=@UserId,
	UpdationDate=@CreationDate 

	Where dbo.ActivityDataReport_Template.Id=@TemplateId;

	Delete From  dbo.ActivityDataReport_TemplateDetails where 
	dbo.ActivityDataReport_TemplateDetails.TemplateId=@TemplateId;

	Insert into dbo.ActivityDataReport_TemplateDetails (TemplateId, FieldId)
	Select @TemplateId, item1 from dbo.SplitCSVs(@CSVFieldIds,',')

	END
ELSE
	BEGIN
	-- create
	insert into dbo.ActivityDataReport_Template (UserId, Name,CSVCoordinatingAgencyIds
	,CSVProviderAgencyIds,CSVGroupIds, CreatedBy, CreationDate)
	values (@UserId,@TemplateName,@CSVCoordinatingAgencyIds,
	@CSVProviderAgencyIds,@CSVGroupIds,@UserId,@CreationDate)

	Set	@CreatedTemplateId= @@IDENTITY;

	Insert into dbo.ActivityDataReport_TemplateDetails (TemplateId, FieldId)
	Select @CreatedTemplateId, item1 from dbo.SplitCSVs(@CSVFieldIds,',')
	END
	
	COMMIT TRANSACTION
END TRY
	BEGIN CATCH
		ROLLBACK TRANSACTION
		DECLARE @ErrorMessage NVARCHAR(4000);
    DECLARE @ErrorSeverity INT;
    DECLARE @ErrorState INT;

    SELECT 
        @ErrorMessage = ERROR_MESSAGE(),
        @ErrorSeverity = ERROR_SEVERITY(),
        @ErrorState = ERROR_STATE();

    RAISERROR (@ErrorMessage, -- Message text.
               @ErrorSeverity, -- Severity.
               @ErrorState -- State.
               );  
		
	END CATCH
END



