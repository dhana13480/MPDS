﻿
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- exec CreateUser dsf
-- =============================================
CREATE PROCEDURE [dbo].[UpdateCoordinatingAgency] 
	@Id bigint,
	@Name varchar(200),
	@OfficePhone varchar(15),
	@Fax varchar(12),
	@Address1 varchar(500),
	@Address2 varchar(500),
	@City varchar(50),
	@State smallint,
	@Zip varchar(9),
	@Comments varchar(1000),
	@PC_FirstName varchar(50),
	@PC_MiddleName varchar(15),
	@PC_LastName varchar(50),
	@PC_Email varchar(500),
	@PC_OfficePhone varchar(15),
	@PC_CellPhone varchar(15),
	@PC_Comments varchar(1000),
	@UpdatedBy bigint,
	@UpdationDate datetime,
	@CSVCounties varchar(max),
	@CSVSchoolDistricts varchar(max),
	@CSVOptionalData varchar(max),
	@CSVProgramNames varchar(max)
AS
BEGIN

	SET NOCOUNT ON;

	BEGIN TRY
		BEGIN TRANSACTION

			
		Update dbo.CoordinatingAgency
		Set [Name] = @Name, 
			OfficePhone = @OfficePhone, 
			Fax = @Fax, 
			Address1 = @Address1, 
			Address2 = @Address2, 
			City = @City, 
			[State] = @State, 
			Zip = @Zip, 
			Comments = @Comments, 
			PC_FirstName = @PC_FirstName, 
			PC_LastName = @PC_LastName,
			PC_MiddleName = @PC_MiddleName, 
			PC_Email = @PC_Email, 
			PC_OfficePhone = @PC_OfficePhone, 
			PC_CellPhone = @PC_CellPhone,
			PC_Comments = @PC_Comments, 
			UpdatedBy = @UpdatedBy, 
			UpdationDate = @UpdationDate

		Where dbo.CoordinatingAgency.Id=@Id
	
		Delete from dbo.CoordinatingAgency_County where
		dbo.CoordinatingAgency_County.CoordinatingAgencyId=@Id;

		Insert into dbo.CoordinatingAgency_County
		Select @Id,item1 from dbo.SplitCSVs(@CSVCounties,',')
	
		Delete from dbo.CoordinatingAgency_SchoolDistrict where
		dbo.CoordinatingAgency_SchoolDistrict.CoordinatingAgencyId=@Id;

		Insert into dbo.CoordinatingAgency_SchoolDistrict
		Select @Id,item1 from dbo.SplitCSVs(@CSVSchoolDistricts,',')

		Delete from dbo.CoordinatingAgency_OptionalData where
		dbo.CoordinatingAgency_OptionalData.CoordinatingAgencyId=@Id;

		Insert into dbo.CoordinatingAgency_OptionalData
		Select @Id,item1 from dbo.SplitCSVs(@CSVOptionalData,',')

		DELETE FROM [dbo].[CoordinatingAgency_ProgramNames] 
		WHERE [CoordinatingAgencyId] = @Id;

		INSERT INTO [dbo].[CoordinatingAgency_ProgramNames]
		SELECT @Id,
			   item1
			   FROM [dbo].[SplitCSVs](@CSVProgramNames, ',')
			
		select @Id;	
	
		COMMIT TRANSACTION
	END TRY
	BEGIN CATCH
		ROLLBACK TRANSACTION
		DECLARE @ErrorMessage NVARCHAR(4000);
    DECLARE @ErrorSeverity INT;
    DECLARE @ErrorState INT;

    SELECT 
        @ErrorMessage = ERROR_MESSAGE(),
        @ErrorSeverity = ERROR_SEVERITY(),
        @ErrorState = ERROR_STATE();

    RAISERROR (@ErrorMessage, -- Message text.
               @ErrorSeverity, -- Severity.
               @ErrorState -- State.
               );
   
		--Select -1;
	END CATCH
END
