﻿-- exec GetCoordinatingAgencyDetails 17

 CREATE procedure [dbo].[GetCoordinatingAgencyDetails]  
  @Id bigint 
  as  
 begin 
		 Select 
		 dbo.CoordinatingAgency.Id,
		 dbo.CoordinatingAgency.Name, 
		-- dbo.CoordinatingAgency.IsActive, 
		 dbo.CoordinatingAgency.OfficePhone, 
		 dbo.CoordinatingAgency.Fax, 
		 dbo.CoordinatingAgency.Address1, 
		 dbo.CoordinatingAgency.Address2, 
		 dbo.CoordinatingAgency.City, 
		 dbo.CoordinatingAgency.State, 
		 dbo.CoordinatingAgency.Zip, 
		 dbo.CoordinatingAgency.Comments, 
		 dbo.CoordinatingAgency.PC_FirstName, 
		 dbo.CoordinatingAgency.PC_MiddleName, 
		 dbo.CoordinatingAgency.PC_LastName, 
		 dbo.CoordinatingAgency.PC_Email, 
		 dbo.CoordinatingAgency.PC_OfficePhone, 
		 dbo.CoordinatingAgency.PC_CellPhone, 
		 dbo.CoordinatingAgency.PC_Comments
		  
		  From dbo.CoordinatingAgency
		  
		 Where dbo.CoordinatingAgency.Id=@Id;
		 
	
	EXEC dbo.GetCoordinatingAgencyCounties @Id;
	EXEC dbo.GetCoordinatingAgencySchoolDistricts @Id;
	EXEC dbo.GetCoordinatingAgencyOptionalData @Id;
    
  end
