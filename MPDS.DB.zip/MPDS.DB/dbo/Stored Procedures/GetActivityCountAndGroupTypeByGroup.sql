﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>

-- exec GetActivityCountAndGroupTypeByGroup 72334444

-- =============================================
CREATE PROCEDURE [dbo].[GetActivityCountAndGroupTypeByGroup] 
	-- Add the parameters for the stored procedure here

 @GroupId bigint
 
 AS 
 BEGIN
 
 --[GetPendingActivities] 75,33,15
 
	Select 
	coalesce((SELECT Count(1)
	FROM  [Activity] as A 
	Where A.GroupId=@GroupId and A.IsDeleted = 0),0) as PresentActivityCount,
	
	coalesce((SELECT MaxActivityCount
	FROM  dbo.ActivityGroup as AG 
	Where AG.Id=@GroupId),0) as MaxActivityCount,
	
	coalesce((Select GroupType from dbo.ActivityGroup where Id = @GroupId),0) as GroupType
		
END
