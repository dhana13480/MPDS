﻿CREATE procedure [dbo].[GetAllMasterActivityOptionalData]
 
 as
 begin 
 
 Select dbo.Master_ActivityOptionalData.Id,
  dbo.Master_ActivityOptionalData.Description,
  dbo.Master_ActivityOptionalData.FieldName
  from dbo.Master_ActivityOptionalData
 
 
  
 end
