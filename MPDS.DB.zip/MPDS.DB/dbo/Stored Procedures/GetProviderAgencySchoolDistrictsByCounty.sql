﻿-- exec GetProviderAgencySchoolDistrictsByCounty 21,''

 CREATE procedure [dbo].[GetProviderAgencySchoolDistrictsByCounty]  
  @ProviderAgencyId bigint,
  @CountyId int 
  as  
 begin 
		
	 SET NOCOUNT ON;  
  

		 if(@CountyId > 0)
		 Begin
			 Select dbo.ProviderAgency_SchoolDistrict.SchoolDistrictId,
			 dbo.Master_SchoolDistrict.SchoolDistrict,
			 dbo.Master_SchoolDistrict.CountyId
			 From dbo.ProviderAgency_SchoolDistrict
			 inner join dbo.Master_SchoolDistrict on dbo.ProviderAgency_SchoolDistrict.SchoolDistrictId=Master_SchoolDistrict.Id
			 Where dbo.ProviderAgency_SchoolDistrict.ProviderAgencyId=@ProviderAgencyId
			 and dbo.Master_SchoolDistrict.CountyId=@CountyId
			 order by dbo.Master_SchoolDistrict.SchoolDistrict asc
		 End
		 Else
		 Begin
			Select dbo.ProviderAgency_SchoolDistrict.SchoolDistrictId,
			 dbo.Master_SchoolDistrict.SchoolDistrict,
			 dbo.Master_SchoolDistrict.CountyId
			 From dbo.ProviderAgency_SchoolDistrict
			 inner join dbo.Master_SchoolDistrict on dbo.ProviderAgency_SchoolDistrict.SchoolDistrictId=Master_SchoolDistrict.Id
			 Where dbo.ProviderAgency_SchoolDistrict.ProviderAgencyId=@ProviderAgencyId
			 order by dbo.Master_SchoolDistrict.SchoolDistrict asc
			 
		 End
			   
  END
