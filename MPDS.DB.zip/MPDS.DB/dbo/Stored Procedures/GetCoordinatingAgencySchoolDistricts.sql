﻿-- exec GetCoordinatingAgencyDetails 17

 CREATE procedure [dbo].[GetCoordinatingAgencySchoolDistricts]  
  @CoordinatingAgencyId bigint 
  as  
 begin 
		 Select 
		 dbo.CoordinatingAgency_SchoolDistrict.SchoolDistrictId,
		 dbo.Master_SchoolDistrict.SchoolDistrict,
		 dbo.Master_SchoolDistrict.CountyId
		  
		  From dbo.CoordinatingAgency_SchoolDistrict
		 inner join dbo.Master_SchoolDistrict on dbo.CoordinatingAgency_SchoolDistrict.SchoolDistrictId=Master_SchoolDistrict.Id
		  
		 Where dbo.CoordinatingAgency_SchoolDistrict.CoordinatingAgencyId=@CoordinatingAgencyId
		 order by dbo.Master_SchoolDistrict.SchoolDistrict asc
		 
    
  end
