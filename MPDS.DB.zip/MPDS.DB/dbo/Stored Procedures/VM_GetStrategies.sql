﻿
CREATE PROCEDURE [dbo].[VM_GetStrategies]
	@GroupTypeId int,
	@ProgramTypeId int,
	@InterventionTypeId int,
	@ServicePopulation int
 AS
 BEGIN 
 
	Declare @StrategyTable as table
	(
		Id int
	)

	INSERT INTO @StrategyTable
	Select item1 from dbo.SplitCSVs((Select dbo.GetStrategiesViaVM (@GroupTypeId, @ProgramTypeId, @InterventionTypeId, @ServicePopulation)),',')

	Select MS.Id, MS.Code +' - '+ MS.Strategy as Strategy from dbo.Master_Strategy MS
	Inner Join @StrategyTable ST on (ST.Id = MS.Id)
	order by MS.DisplayOrder asc
 
 end
