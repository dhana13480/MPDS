﻿-- exec GetCoordinatingAgencyAddressDetails 17

 CREATE procedure [dbo].[GetProviderAgencyAddressDetails]  
  @ProviderAgencyId bigint 
  as  
 begin 
		 Select 
		 dbo.ProviderAgency.Id,
		 dbo.ProviderAgency.Address1, 
		 dbo.ProviderAgency.Address2, 
		 dbo.ProviderAgency.City, 
		 dbo.ProviderAgency.State, 
		 dbo.ProviderAgency.Zip 
		  
		  From dbo.ProviderAgency
		  
		 Where dbo.ProviderAgency.Id=@ProviderAgencyId;
		 
	  end
