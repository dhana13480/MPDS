﻿CREATE procedure [dbo].[IsSchoolDistrictInUseByCoordinatingAgency]   
  @Id int
  as  
begin 
 	If((  Select  count(1) 
		  From dbo.CoordinatingAgency_SchoolDistrict Where SchoolDistrictId=@Id)>0)
		  Begin
        Select  1
      End
  Else
      Begin      
        Select 0
      End 
		 
  end
