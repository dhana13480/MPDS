﻿-- exec [GetAllServiceSetting]
 CREATE procedure [dbo].[GetAllServiceSetting]
 
 as
 begin 
 
 Select dbo.Master_ServiceSetting.Id,
  dbo.Master_ServiceSetting.ServiceSetting  
  from dbo.Master_ServiceSetting
  order by dbo.Master_ServiceSetting.DisplayOrder
  asc
  
 end
