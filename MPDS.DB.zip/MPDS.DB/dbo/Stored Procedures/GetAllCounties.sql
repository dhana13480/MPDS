﻿-- exec GetAllCounties NULL,-1,1,1,1

CREATE procedure [dbo].[GetAllCounties]

@IsActive bit,
@count INT = 10,
@pageNumber	INT=1,
@SortOrder TINYINT=1,
@SortId TINYINT = 1
 as
 begin 
 
 	SET NOCOUNT ON;

DECLARE @statement nvarchar(max);
DECLARE @statementParamDec nvarchar(200);	
DECLARE @SortBy VARCHAR(100);
DECLARE @SortOrd VARCHAR(100);
		

    SELECT  @SortBy=CASE
	WHEN  @SortId=1 THEN
	'County'
	WHEN  @SortId=2 THEN
	'Description' 
	WHEN  @SortId=3 THEN
	'IsActive'
	END
	
	SELECT @SortOrd=CASE
	WHEN @SortOrder=1 THEN
	'ASC'
	WHEN @SortOrder=0 THEN
	'DESC'
	END;
	
	if(@count<0)
	begin
		set @statement='SELECT * FROM ('
	end
else
	begin 
		set @statement='SELECT TOP '+ CONVERT(VARCHAR, @Count) + ' * FROM ('
	end
	
set @statement=@statement+'
          Select Id,
          County,
          Description,
          IsActive,
          ROW_NUMBER() OVER (ORDER BY '+@SortBy+' '+@SortOrd+') AS Row_Numb 
          from Master_County
		  Where dbo.Master_County.Id>0 '	
		
		 If(@IsActive is not NULL)
			begin
			set @statement=@statement+' and dbo.Master_County.IsActive=@IsActive'
	     end	
	
		
		set @statement=@statement+')
		
		AS O WHERE Row_Numb >= (@count * (@pageNumber - 1) + 1);'
	
	
		SET @statementParamDec = N'@count INT,@pageNumber INT,@IsActive Bit';
      --  select @statement
		 EXEC sp_executesql @statement, @statementParamDec,@count,@pageNumber,@IsActive;
		 
		 EXEC dbo.GetAllCountiesCount @IsActive
 end
