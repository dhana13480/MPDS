﻿CREATE procedure [dbo].[GetAllStates]
 
 as
 begin 
 
 Select dbo.Master_State.Id,
  dbo.Master_State.State  
  from dbo.Master_State
  
 end
