﻿-- exec [GetAllIntendedPopulation]
 CREATE procedure [dbo].[GetAllIntendedPopulation]
 
 as
 begin 
 
 Select dbo.Master_IntendedPopulation.Id,
  dbo.Master_IntendedPopulation.Code +' - '+  
  dbo.Master_IntendedPopulation.IntendedPopulation as IntendedPopulation
  from dbo.Master_IntendedPopulation
  order by dbo.Master_IntendedPopulation.DisplayOrder asc
  
 end
