﻿CREATE procedure [dbo].[AddNewCounty]    
  @County varchar(50),
  @Description varchar(500),
  @CreationDate datetime,
  @CreatedBy bigint    
 
 as    
 begin      
 insert into Master_County     
 (County, Description, IsActive, CreationDate, CreatedBy)    
 values(@County, @Description,1, @CreationDate,@CreatedBy)    
      
 end
