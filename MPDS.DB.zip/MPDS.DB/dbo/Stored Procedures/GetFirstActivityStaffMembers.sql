﻿-- EXEC [GetFirstActivityStaffMembers] 1

CREATE procedure [dbo].[GetFirstActivityStaffMembers] -- 939,2
@GroupId bigint

as
begin

Declare @FirstActivityId bigint;

Select @FirstActivityId = A.Id
FROM  dbo.Activity as A
Left outer join dbo.ActivityGroup AG on (AG.Id= A.GroupId) 
Where A.IsFirstActivityInGroup = 1 And AG.Id = @GroupId and A.IsDeleted = 0

if(@FirstActivityId > 0)
Begin

	Select S.FirstName, S.LastName, A_S.StaffId,
	(MS.Code + ' - ' + MS.Strategy) as Strategy, A_S.StrategyId, 
	A_S.OptionalLocalMBO
	from dbo.Activity_Staff A_S
	Left outer join dbo.Staff S on(S.Id = A_S.StaffId)
	Left outer join dbo.Master_Strategy MS on(MS.Id = A_S.StrategyId)
	where A_S.ActivityId = @FirstActivityId;
End
        
END
