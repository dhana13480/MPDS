﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>

-- exec GetAllFundingSourceCount -1,100,0,1
-- =============================================
CREATE PROCEDURE [dbo].[GetAllCountiesCount] 
	-- Add the parameters for the stored procedure here

@IsActive bit

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
    DECLARE @statement nvarchar(max);
DECLARE @statementParamDec nvarchar(200);	
	

set @statement='
		select count(1)
		from dbo.Master_County
		where dbo.Master_County.Id>0 '

			
		If(@IsActive is not NULL)
		begin
		set @statement=@statement+' and dbo.Master_County.IsActive=@IsActive'
		end	

SET @statementParamDec = N'@IsActive bit';

--select @statement
		EXEC sp_executesql @statement,@statementParamDec,@IsActive;


END
