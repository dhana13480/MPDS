﻿
CREATE procedure [dbo].[AddProgramName]
	@Name varchar(50),
	@Description  varchar(MAx),  
	@CreationDate datetime,
	@CreatedBy bigint
 AS  
 BEGIN    

	INSERT INTO [dbo].[Master_ProgramName]
           ([Name]
           ,[Description]
           ,[CreatedBy]
           ,[CreationDate])
     VALUES
           (@Name
           ,@Description
           ,@CreatedBy
           ,@CreationDate)
    
END
