﻿-- EXEC GetUserDetails 116,4

CREATE procedure [dbo].[GetUserDetails]   
 @Id bigint,
 @UserType smallint
as 
begin

DECLARE @statement nvarchar(max);  
DECLARE @statementParamDec nvarchar(200);   

set @statement= ' select
U.Id
,U.[FirstName] 
,U.MiddleName
,U.[LastName] 
,U.[IsActive]	 
,U.[UserTypeId] 
,ISNULL(U.[CoordinatingAgencyId],0)  as CoordinatingAgencyId
,ISNULL(U.[ProviderAgencyId],0)   as ProviderAgencyId
,U.[Permissions] 
,U.[UserName] 
,U.[Email] 
,U.[Phone] 
,U.[Address1]	 
,U.[Address2] 
,U.[City]	 
,U.[StateId] 
,U.[Zip] 
,U.[Comments] '

		If (@UserType=3) -- CA Staff
		Begin
			set @statement=@statement  +' 
			,CA.Name as AgencyName '
		End
		ELSE if(@UserType=4) --check for pa(addtional fields)
		begin   
			set @statement=@statement  +'
			,PA.Name as AgencyName '
		end  
		set @statement=@statement  +' from dbo.Users U '

		if(@UserType=3) -- CA Staff
		begin   
			Set @statement=@statement  +' Inner Join dbo.CoordinatingAgency CA on (CA.Id = U.CoordinatingAgencyId) '
		END
		else if(@UserType=4) -- PA Staff
		begin   
			Set @statement=@statement  +' Inner Join dbo.ProviderAgency PA on (PA.Id = U.ProviderAgencyId) '
		END
        
        SET @statement=@statement  +' WHERE U.Id = @Id '
 		SET @statementParamDec = N'@Id bigint';  
		
		EXEC sp_executesql @statement, @statementParamDec,@Id;

END
