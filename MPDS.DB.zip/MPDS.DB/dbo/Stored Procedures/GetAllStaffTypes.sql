﻿create procedure [dbo].[GetAllStaffTypes]
as
begin

select Id,StaffType from Master_StaffType

end
