﻿CREATE procedure [dbo].[GetAllGroupType]
 
 as
 begin 
 
 Select dbo.Master_GroupType.Id,
  dbo.Master_GroupType.GroupType  
  from dbo.Master_GroupType
  order by dbo.Master_GroupType.GroupType asc
  
 end
