﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>

-- exec GetAllNotifications 64,4,'2013-12-01',-1,1,1,5

-- =============================================
CREATE PROCEDURE [dbo].[GetAllNotifications] 
	-- Add the parameters for the stored procedure here

@UserId bigint,
@UserTypeId smallint,
@Date datetime,
@count INT = 10,
@pageNumber	INT=1,
@SortOrder TINYINT=1,
@SortId TINYINT = 1

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

DECLARE @statement nvarchar(max);
DECLARE @statementParamDec nvarchar(2000);	
DECLARE @SortBy VARCHAR(100);
DECLARE @SortOrd VARCHAR(100);

Declare @CoordinatingAgencyId bigint;
Declare @ProviderAgencyId bigint;
Set @CoordinatingAgencyId=0;
Set @ProviderAgencyId=0;

If(@UserTypeId=3) -- CA
BEGIN
Set @CoordinatingAgencyId=(Select dbo.Users.CoordinatingAgencyId from dbo.Users
							Where dbo.Users.Id=@UserId)
END
ELSE if (@UserTypeId=4) -- PA
BEGIN
Select @CoordinatingAgencyId=P_CA.Id,
		@ProviderAgencyId=ProviderAgencyId from dbo.Users
							inner join dbo.ProviderAgency on dbo.Users.ProviderAgencyId=dbo.ProviderAgency.Id
							inner join dbo.CoordinatingAgency P_CA on dbo.ProviderAgency.CoordinatingAgencyId=P_CA.Id
							Where dbo.Users.Id=@UserId
END

	--print @ProviderAgencyId	

SELECT  @SortBy=CASE
	WHEN  @SortId=1 THEN
	'O.Title'
	WHEN  @SortId=2 THEN
	'O.Text'
	WHEN  @SortId=3 THEN
	'O.StartDate'
	WHEN  @SortId=4 THEN
	'O.EndDate'
	WHEN  @SortId=5 THEN
	'O.AttachmentCount'
	END
	
	SELECT @SortOrd=CASE
	WHEN @SortOrder=1 THEN
	'ASC'
	WHEN @SortOrder=0 THEN
	'DESC'
	END;

if(@count<0)
	begin
		set @statement='SELECT * FROM ('
	end
else
	begin 
		set @statement='SELECT TOP '+ CONVERT(VARCHAR, @Count) + ' * FROM ('
	end
	
set @statement=@statement+'
		Select *, ROW_NUMBER() OVER (ORDER BY '+@SortBy+' '+@SortOrd+') AS Row_Numb From
		(
		Select dbo.Notification.Id,
		dbo.Notification.Title,
		dbo.Notification.Text,
		dbo.Notification.StartDate,
		dbo.Notification.EndDate,
		(Select Count(1) from dbo.Notifications_Attachment where dbo.Notifications_Attachment.NotificationId = dbo.Notification.Id) as AttachmentCount
		from dbo.Notification
		Where Convert(Date,@Date) >= Convert(Date,CONVERT(VARCHAR, dbo.Notification.StartDate, 101))
		AND Convert(Date,@Date) <= Convert(Date,CONVERT(VARCHAR, dbo.Notification.EndDate, 101))'
		If(@UserTypeId=3) -- CA 
			BEGIN
			set @statement=@statement+'	
			and (
			((dbo.Notification.TypeId=2 or dbo.Notification.TypeId=4)
			And Convert(varchar(255),@CoordinatingAgencyId) IN (Select item1 from dbo.SplitCSVs(dbo.Notification.CSVCoordinatingAgencyIds,'','')))
			OR dbo.Notification.TypeId=1
			)'
			--(
			--Case When (dbo.Notification.TypeId=2 or dbo.Notification.TypeId=4)
			--THEN (Convert(varchar(max),dbo.Notification.CSVCoordinatingAgencyIds))
			--WHEN dbo.Notification.TypeId=1
			--THEN (@CoordinatingAgencyId)
			--end
			--)
		END
		ELSE IF (@UserTypeId=4) -- PA
		BEGIN		 
			set @statement=@statement+ '
			and (
			((dbo.Notification.TypeId=3 or dbo.Notification.TypeId=4)
			And Convert(varchar(255),@ProviderAgencyId) IN (Select item1 from dbo.SplitCSVs(dbo.Notification.CSVProviderAgencyIds, '','')))
			OR dbo.Notification.TypeId=1
			)'
			--(
			--Case When (dbo.Notification.TypeId=3 or dbo.Notification.TypeId=4)
			--THEN (Convert(varchar(max),dbo.Notification.CSVProviderAgencyIds))
			--WHEN dbo.Notification.TypeId=1
			--THEN (@ProviderAgencyId)
			--end
			--)
		END
				
		set @statement=@statement+')
		
		AS O )
		
		AS OO WHERE OO.Row_Numb >= (@count * (@pageNumber - 1) + 1)'

	SET @statementParamDec = N'@count INT,@pageNumber INT,@UserId bigint,@UserTypeId smallint,@Date datetime,@CoordinatingAgencyId bigint,@ProviderAgencyId bigint';
	EXEC sp_executesql @statement, @statementParamDec,@count,@pageNumber,@UserId,@UserTypeId,@Date,@CoordinatingAgencyId,@ProviderAgencyId;
	--Print @statement
	EXEC GetAllNotificationsCount @UserId,@UserTypeId,@Date;

END


/****** Object:  StoredProcedure [dbo].[GetAllNotificationsCount]    Script Date: 12/11/2013 22:08:42 ******/
SET ANSI_NULLS ON
