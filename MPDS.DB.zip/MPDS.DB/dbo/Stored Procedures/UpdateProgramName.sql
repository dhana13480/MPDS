﻿
CREATE procedure [dbo].[UpdateProgramName]
	@Id bigint,
	@Name varchar(50),
	@Description  varchar(MAx),  
	@UpdatedBy bigint,
	@UpdationDate datetime
 AS  
 BEGIN    

	UPDATE  [dbo].[Master_ProgramName]
           SET [Name] = @Name
           ,[Description] = @Description
           ,[UpdatedBy] = @UpdatedBy
           ,[UpdationDate] = @UpdationDate

		WHERE [Id] = @Id
    
END
