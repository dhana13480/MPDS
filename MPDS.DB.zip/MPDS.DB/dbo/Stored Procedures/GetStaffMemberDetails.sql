﻿-- EXEC GetStaffMemberDetails 9,2

CREATE procedure [dbo].[GetStaffMemberDetails] -- 939,2
@Id bigint,
@StaffTypeId smallint

as
begin


DECLARE @statement nvarchar(max);  
DECLARE @statementParamDec nvarchar(200);   

	set @statement= 'select S.[Id], S.[FirstName]
      ,S.[MiddleName]
      ,S.[LastName]
      ,S.[IsActive]
      ,S.[Email]
      ,S.[CellPhone]
      ,S.[OfficePhone]
      ,S.[HomePhone]
      ,S.[Fax]
      ,S.[Address1]
      ,S.[Address2]
      ,S.[City]
      ,S.[State]
      ,S.[Zip]
      ,S.[Comments]
      ,S.ProviderAgencyId
      ,S.CoordinatingAgencyId '
      
		If (@StaffTypeId=1) -- CA Staff
		Begin
			set @statement=@statement  +' 
			,CA.Name as AgencyName '
		End
		ELSE if(@StaffTypeId=2) --check for pa(addtional fields)
		begin   
			set @statement=@statement  +' 
			,S.EffectiveFrom as StartDate
			,S.EffectiveTo as EndDate
			,PA.Name as AgencyName '
		end  
					
        set @statement=@statement  +' from dbo.Staff S '
        
		if(@StaffTypeId=1) -- CA Staff
		begin   
			Set @statement=@statement  +' Inner Join dbo.CoordinatingAgency CA on (CA.Id = S.CoordinatingAgencyId) '
		END
		else if(@StaffTypeId=2) -- PA Staff
		begin   
			Set @statement=@statement  +' Inner Join dbo.ProviderAgency PA on (PA.Id = S.ProviderAgencyId) '
		END
        
        set @statement=@statement  +' WHERE S.Id=@Id '

		SET @statementParamDec = N'@Id bigint';  
		print @statement ;	 
                               
		EXEC sp_executesql @statement, @statementParamDec,@Id;
        
        END
