﻿CREATE procedure [dbo].[IsEBPServiceTypeNameInUse]  
  @Name varchar (50) 
  as  
begin 
  If((Select COUNT(1) from dbo.Master_EBPServiceType
      where dbo.Master_EBPServiceType.EBPServiceType=@Name)>0)
      Begin
        Select 1
      End
  Else
      Begin      
        Select 0
      End    
end
