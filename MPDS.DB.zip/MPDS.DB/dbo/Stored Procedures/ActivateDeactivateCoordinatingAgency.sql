﻿CREATE procedure [dbo].[ActivateDeactivateCoordinatingAgency]  
  @Id bigint,
  @Status bit,
  @UpdatedBy bigint,
  @UpdationDate datetime 
  as  
begin 
 
 
 Update dbo.CoordinatingAgency 
 set dbo.CoordinatingAgency.IsActive=@Status,
 dbo.CoordinatingAgency.UpdatedBy=@UpdatedBy,
 dbo.CoordinatingAgency.UpdationDate=@UpdationDate 
 where dbo.CoordinatingAgency.Id=@Id
 
end
