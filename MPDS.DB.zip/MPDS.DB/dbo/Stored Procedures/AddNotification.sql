﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- exec CreateUser dsf
-- =============================================
CREATE PROCEDURE [dbo].[AddNotification] 
	-- Add the parameters for the stored procedure here
@NotificationTypeId smallint,
@CSVCoordinatingAgencyIds varchar(2000),
@CSVProviderAgencyIds varchar(2000),
@Title varchar(100),
@Text varchar(2000),
@StartDate datetime,
@EndDate datetime,
@CSVAttachmentName varchar(500),
@CSVAttachmentFileName varchar(1000),
@CreatedBy bigint,
@CreationDate datetime


AS
BEGIN
	 --SET NOCOUNT ON added to prevent extra result sets from
	 --interfering with SELECT statements.
	SET NOCOUNT ON;

BEGIN TRY
	BEGIN TRANSACTION
Declare @NotificationId bigint=NULL;	
	


	BEGIN
	-- delete and create
	Insert into  dbo.Notification 
	(TypeId, 
	CSVCoordinatingAgencyIds,
	CSVProviderAgencyIds,
	Title, 
	Text, 
	StartDate, 
	EndDate, 
	CreatedBy, 
	CreationDate) values
	(@NotificationTypeId,@CSVCoordinatingAgencyIds,@CSVProviderAgencyIds,@Title,@Text,@StartDate,@EndDate
	,@CreatedBy,@CreationDate)
	
	Set @NotificationId = @@IDENTITY;
	
	if(@CSVAttachmentName<>'' AND @CSVAttachmentFileName<>'')
		BEGIN
			Insert into dbo.Notifications_Attachment
			(NotificationId, CreatedBy, CreationDate,Name, FileName) 
			 Select @NotificationId,@CreatedBy,@CreationDate, 
			 part1, part2 from dbo.SplitTwoString(@CSVAttachmentName,@CSVAttachmentFileName,'|@~@|')
		END
	END

	
	COMMIT TRANSACTION
END TRY
	BEGIN CATCH
		ROLLBACK TRANSACTION
		DECLARE @ErrorMessage NVARCHAR(4000);
    DECLARE @ErrorSeverity INT;
    DECLARE @ErrorState INT;

    SELECT 
        @ErrorMessage = ERROR_MESSAGE(),
        @ErrorSeverity = ERROR_SEVERITY(),
        @ErrorState = ERROR_STATE();

    RAISERROR (@ErrorMessage, -- Message text.
               @ErrorSeverity, -- Severity.
               @ErrorState -- State.
               );  
		
	END CATCH
END


