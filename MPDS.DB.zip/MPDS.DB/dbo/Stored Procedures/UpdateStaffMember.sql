﻿CREATE procedure [dbo].[UpdateStaffMember] 
      @Id bigint, 
      @StaffTypeId smallint,
      @FirstName   varchar(50),
      @MiddleName varchar(15),
      @LastName varchar(50),
      @Email varchar(255),
      @CellPhone varchar(15),
      @OfficePhone varchar(15),
      @HomePhone varchar(12),
      @Fax varchar(12),
      @Address1 varchar(500),
      @Address2 varchar(500),
      @City varchar(50),
      @State  smallint,
      @Zip varchar(9),
      @Comments varchar(1000),
      @UpdatedBy bigint,
      @UpdationDate datetime,
      @EffectiveFrom datetime,
      @EffectiveTo datetime
      
  AS
  BEGIN
   if(@StaffTypeId=2)--PA
    begin 
      UPDATE Staff set				       
					 
			FirstName=@FirstName,
			MiddleName	  =@MiddleName,
			LastName	  =@LastName,
			Email		  =@Email,
			CellPhone	  =@CellPhone,
			OfficePhone  =@OfficePhone,
			HomePhone	  =@HomePhone,
			Fax		  =@Fax,
			Address1	  =@Address1,
			Address2	  =@Address2,
			City		  =@City,
			State		  =@State,
			Zip		  =@Zip,
			Comments	  =@Comments,
			UpdatedBy	  =@UpdatedBy,
			UpdationDate =@UpdationDate, 
			 EffectiveFrom=@EffectiveFrom,
			 EffectiveTo=@EffectiveTo  
		      where Id=@Id
     end
     else if(@StaffTypeId=1)--CA
    begin 
      UPDATE Staff set				       
					 
			FirstName=@FirstName,
			MiddleName	  =@MiddleName,
			LastName	  =@LastName,
			Email		  =@Email,
			CellPhone	  =@CellPhone,
			OfficePhone  =@OfficePhone,
			HomePhone	  =@HomePhone,
			Fax		  =@Fax,
			Address1	  =@Address1,
			Address2	  =@Address2,
			City		  =@City,
			State		  =@State,
			Zip		  =@Zip,
			Comments	  =@Comments,
			UpdatedBy	  =@UpdatedBy,
			UpdationDate =@UpdationDate   
		      where Id=@Id
     end
    
    
END
