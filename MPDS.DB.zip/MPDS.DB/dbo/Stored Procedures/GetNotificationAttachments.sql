﻿-- exec [dbo].[GetNotificationAttachments] 1  
CREATE procedure [dbo].[GetNotificationAttachments]    
  @NotificationId bigint
  as  
begin 
 Select 
 Id, 
 NotificationId, 
 Name, 
 FileName
 from
 dbo.Notifications_Attachment
 Where dbo.Notifications_Attachment.NotificationId=@NotificationId
 
 
end
