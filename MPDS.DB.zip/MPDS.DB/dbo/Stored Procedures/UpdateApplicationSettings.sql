﻿/****** Script for SelectTopNRows command from SSMS  ******/

CREATE procedure [dbo].[UpdateApplicationSettings]
	 @SMTPServer varchar(255)
	,@SMTPPort int
	,@SecureSMTP bit
	,@MailFromAddress varchar(255)
	,@MailFromUserName varchar(255)
	,@MailFromPassword varchar(255) 
	,@PagingCount_Admin int
	,@PagingCount_CoordinatingAgency int
	,@PagingCount_ProviderAgency int
	,@PagingCount_Auditor int
	,@DomainName varchar(50)
	,@ErrorEmailAddress varchar(500)
AS
BEGIN

	IF(EXISTS(SELECT TOP 1 * FROM [ApplicationSettings]))
	BEGIN
		update ApplicationSettings
			set SMTPServer= @SMTPServer
				,SMTPPort = @SMTPPort
				,SecureSMTP = @SecureSMTP
				,MailFromAddress = @MailFromAddress
				,MailFromUserName = @MailFromUserName
				,MailFromPassword = @MailFromPassword 
				,PagingCount_Admin = @PagingCount_Admin
				,PagingCount_CoordinatingAgency= @PagingCount_CoordinatingAgency
				,PagingCount_ProviderAgency	= @PagingCount_ProviderAgency
				,PagingCount_Auditor = @PagingCount_Auditor
				,[DomainName] = @DomainName 
				,ErrorEmailAddress = @ErrorEmailAddress
	END
	ELSE
	BEGIN
		INSERT INTO [dbo].[ApplicationSettings]
           ([SMTPServer]
           ,[SMTPPort]
           ,[SecureSMTP]
           ,[MailFromAddress]
           ,[MailFromUserName]
           ,[MailFromPassword]
           ,[PagingCount_Admin]
           ,[PagingCount_CoordinatingAgency]
           ,[PagingCount_ProviderAgency]
           ,[PagingCount_Auditor]
           ,[DomainName]
           ,[ErrorEmailAddress])
     VALUES
           (@SMTPServer
           ,@SMTPPort
           ,@SecureSMTP
           ,@MailFromAddress
           ,@MailFromUserName
           ,@MailFromPassword
           ,@PagingCount_Admin
           ,@PagingCount_CoordinatingAgency
           ,@PagingCount_ProviderAgency
           ,@PagingCount_Auditor
           ,@DomainName
           ,@ErrorEmailAddress)
	END

	
  
END
