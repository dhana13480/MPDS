﻿CREATE procedure  [dbo].[IsUserNameInUse]
@UserName varchar(50)
as
begin
if((select COUNT(1)  from Users where UserName=@UserName AND IsDeleted=0)>0)
begin
select 1
end
else
begin
select 0
end

end
