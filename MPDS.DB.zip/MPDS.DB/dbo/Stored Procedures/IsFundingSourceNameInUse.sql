﻿CREATE procedure [dbo].[IsFundingSourceNameInUse]  
  @Name varchar (50) 
  as  
begin 
  If((Select COUNT(1) from dbo.Master_FundingSource
      where dbo.Master_FundingSource.FundingSource=@Name)>0)
      Begin
        Select 1
      End
  Else
      Begin      
        Select 0
      End    
end
