﻿-- EXEC IsStaffAlreadyEngagedWithOtherActivityForDateRange 913,0,'2012-07-11 14:00:00.000','2012-07-11 16:00:00.000'

CREATE PROCEDURE [dbo].[IsStaffAlreadyEngagedWithOtherActivityForDateRange]
  @StaffId bigint,
  @ActivityId bigint,
  @StartDate datetime,
  @EndDate datetime
  as  
begin 
  If((Select COUNT(1) from dbo.Activity_Staff A_S
	  Inner Join dbo.Activity A on (A.Id = A_S.ActivityId)
	  where A_S.ActivityId<>@ActivityId
      AND A_S.StaffId=@StaffId
      AND A.IsDeleted <> 1
      AND (
      (A_S.StartDate > @StartDate AND A_S.StartDate < @EndDate)
      OR
      (A_S.EndDate > @StartDate AND A_S.EndDate < @EndDate)
      OR
      (A_S.StartDate <= @StartDate AND A_S.EndDate >= @EndDate)
      )
      )>0)
      Begin
        Select  1
      End
  Else
      Begin      
        Select 0
      End    
end
