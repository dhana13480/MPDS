﻿-- exec GetCoordinatingAgencyDetails 17

 CREATE procedure [dbo].[GetCoordinatingAgencyCounties]  
  @CoordinatingAgencyId bigint 
  as  
 begin 
		 Select 
		 dbo.CoordinatingAgency_County.CountyId,
		 dbo.Master_County.County 
		 From dbo.CoordinatingAgency_County
		 inner join dbo.Master_County on dbo.CoordinatingAgency_County.CountyId=Master_County.Id
		  
		 Where dbo.CoordinatingAgency_County.CoordinatingAgencyId=@CoordinatingAgencyId
		 order by dbo.Master_County.County asc
		 
    
  end
