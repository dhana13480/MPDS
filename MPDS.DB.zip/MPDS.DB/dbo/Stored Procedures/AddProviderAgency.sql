﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- exec CreateUser dsf
-- =============================================
CREATE PROCEDURE [dbo].[AddProviderAgency] 
	-- Add the parameters for the stored procedure here
@Name varchar(200),
@CoordinatingAgencyId bigint,
@LicenseNumber varchar(50),
@DaysAllowedForDataEntry int,
@OfficePhone varchar(15),
@Fax varchar(12),
@Address1 varchar(500),
@Address2 varchar(500),
@City varchar(50),
@State smallint,
@Zip varchar(9),
@Comments varchar(1000),
@CreatedBy bigint,
@CreationDate datetime,
@CSVCounties varchar(max),
@CSVSchoolDistricts varchar(max),
@CSVOptionalData varchar(max)


AS
BEGIN
	 --SET NOCOUNT ON added to prevent extra result sets from
	 --interfering with SELECT statements.
	SET NOCOUNT ON;

BEGIN TRY
	BEGIN TRANSACTION
			DECLARE @LastInsertedId bigint;
			
INSERT INTO dbo.ProviderAgency(
			
Name, 
CoordinatingAgencyId,
DaysAllowedForDataEntry,
License,
OfficePhone, 
Fax, 
Address1, 
Address2, 
City, 
State, 
Zip, 
Comments,
CreatedBy, 
CreationDate
)
Values
(
@Name, 
@CoordinatingAgencyId,
@DaysAllowedForDataEntry,
@LicenseNumber,
@OfficePhone, 
@Fax, 
@Address1, 
@Address2, 
@City, 
@State, 
@Zip, 
@Comments,  
@CreatedBy, 
@CreationDate
)			
			
set @LastInsertedId=@@Identity

		Insert into dbo.ProviderAgency_County
		Select @LastInsertedId,item1 from dbo.SplitCSVs(@CSVCounties,',')
	
		Insert into dbo.ProviderAgency_SchoolDistrict
		Select @LastInsertedId,item1 from dbo.SplitCSVs(@CSVSchoolDistricts,',')
		
		Insert into dbo.ProviderAgency_OptionalData
		Select @LastInsertedId,item1 from dbo.SplitCSVs(@CSVOptionalData,',')
			
	select @LastInsertedId;	
	
	COMMIT TRANSACTION
END TRY
	BEGIN CATCH
		ROLLBACK TRANSACTION
		DECLARE @ErrorMessage NVARCHAR(4000);
    DECLARE @ErrorSeverity INT;
    DECLARE @ErrorState INT;

    SELECT 
        @ErrorMessage = ERROR_MESSAGE(),
        @ErrorSeverity = ERROR_SEVERITY(),
        @ErrorState = ERROR_STATE();

    RAISERROR (@ErrorMessage, -- Message text.
               @ErrorSeverity, -- Severity.
               @ErrorState -- State.
               );
   
		--Select -1;
	END CATCH
END
