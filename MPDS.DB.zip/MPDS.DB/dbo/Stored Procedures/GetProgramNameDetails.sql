﻿
CREATE PROCEDURE [dbo].[GetProgramNameDetails] 
	@Id bigint
AS
BEGIN
	SET NOCOUNT ON;

	SELECT [Id]
		  ,[Name]
		  ,[Description]
		  ,[CreatedBy]
		  ,[CreationDate]
		  ,[UpdatedBy]
		  ,[UpdationDate]
		  ,[DeactivatedBy]
		  ,[DeactivatedDate]
	  FROM [dbo].[Master_ProgramName]
	  WHERE [Id] = @Id

END
