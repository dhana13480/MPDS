﻿CREATE PROCEDURE [dbo].[ActivateDeactivateUser] 
      @Id bigint,
      @IsActive bit,
      @UpdatedBy bigint,
      @UpdationDate Datetime
       
      as
      begin
      update Users 
      set IsActive=@IsActive,
      UpdatedBy=@UpdatedBy,
      UpdationDate=@UpdationDate
      where id=@id
END
