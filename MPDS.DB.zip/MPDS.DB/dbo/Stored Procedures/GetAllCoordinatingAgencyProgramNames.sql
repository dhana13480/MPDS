﻿

CREATE PROCEDURE [dbo].[GetAllCoordinatingAgencyProgramNames]
	@CoordinatingAgencyId int,
	@ProgramNameId bigint
AS 
BEGIN  
  
	SELECT prog.[Id]
		  ,prog.[Name]
		  ,CAST(CASE WHEN CPN.[CoordinatingAgencyId] IS NOT NULL THEN 1 ELSE 0 END AS BIT) AS [IsSelected]
	  FROM [dbo].[Master_ProgramName] prog
	  LEFT OUTER JOIN [dbo].[CoordinatingAgency_ProgramNames] CPN ON CPN.[ProgramNameId] = prog.[Id] AND (CPN.[CoordinatingAgencyId] IS NULL OR CPN.[CoordinatingAgencyId] = @CoordinatingAgencyId)

	  WHERE prog.[DeactivatedDate] IS NULL OR (@ProgramNameId IS NOT NULL AND prog.[Id] = @ProgramNameId)

	  ORDER BY prog.[Name]
END
