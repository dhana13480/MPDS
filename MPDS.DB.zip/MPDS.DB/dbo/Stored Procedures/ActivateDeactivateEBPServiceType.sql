﻿CREATE procedure [dbo].[ActivateDeactivateEBPServiceType]  
  @Id int,
  @Status bit,
  @UpdatedBy bigint,
  @UpdationDate datetime  
  as  
begin 

if(@Status=0) -- deactivate
	 Begin
		 If((Select COUNT(1) from dbo.ActivityGroup
		   where dbo.ActivityGroup.EBPServiceType =@Id)>0)  --- EBP service type is in use by group
			  BEGIN
			   Select 0;
			  END
		ELSE
		      BEGIN  -- deactivate not in use
			    Update dbo.Master_EBPServiceType
				 set dbo.Master_EBPServiceType.IsActive=@Status,
				 dbo.Master_EBPServiceType.UpdatedBy=@UpdatedBy,
				 dbo.Master_EBPServiceType.UpdationDate=@UpdationDate 
				 where dbo.Master_EBPServiceType.Id=@Id
				 Select 1;
			  END
	END
ELSE
    BEGIN 	
				 Update dbo.Master_EBPServiceType
				 set dbo.Master_EBPServiceType.IsActive=@Status,
				 dbo.Master_EBPServiceType.UpdatedBy=@UpdatedBy,
				 dbo.Master_EBPServiceType.UpdationDate=@UpdationDate 
				 where dbo.Master_EBPServiceType.Id=@Id
				 Select 1;
	END			 
   
end
