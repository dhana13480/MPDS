﻿CREATE procedure [dbo].[IsStaffMemberInUse] --'4','asd','asd','asd',-1,47
 
 @FirstName varchar(50),
 @LastName varchar(50),
 @MiddleName varchar(15),
 @CoordinatingAgencyId bigint,
 @ProviderAgencyId bigint

as
begin

declare @StaffTypeId smallint 

 if(@ProviderAgencyId>0 )
 begin
 set @StaffTypeId=2
 end
 else if(@CoordinatingAgencyId>0 )
 begin
 set @StaffTypeId=1
 end 

DECLARE @statement nvarchar(max);  
DECLARE @statementParamDec nvarchar(200);

set @statement='if((select count(1) from staff' 

      set  @statement= @statement  + '  where IsActive=1  '

            if(@StaffTypeId=1)
			begin   
				set @statement=@statement  +' and  CoordinatingAgencyId = @CoordinatingAgencyId '
			end 
			else if(@StaffTypeId=2)
			begin   
				set @statement=@statement  +' and ProviderAgencyId =@ProviderAgencyId '
			end 
			
			set @statement= @statement  + ' 
			and FirstName=@FirstName 
			and MiddleName=@MiddleName 
			and LastName=@LastName)>0)'
	         
	 set @statement=@statement  +' 
	 Begin 
	  Select  1   
	 End  
	 Else   
	 Begin
	    Select 0 
	 End'
			 
	 SET @statementParamDec = N'@FirstName varchar(50),@MiddleName varchar(15),@LastName varchar(50), @CoordinatingAgencyId  bigint,@ProviderAgencyId  bigint';  
	 EXEC sp_executesql @statement, @statementParamDec,@FirstName,@MiddleName,@LastName,@CoordinatingAgencyId,@ProviderAgencyId ;  
	
end
