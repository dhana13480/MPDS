﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>

-- exec GetAllCoordinatingAgencies '',0,-1,1,0,5
-- =============================================
CREATE PROCEDURE [dbo].[GetAllCoordinatingAgencies] 
	-- Add the parameters for the stored procedure here
@Name varchar (200),
@IsActive bit,
@count INT = 10,
@pageNumber	INT=1,
@SortOrder TINYINT=1,
@SortId TINYINT = 1
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

DECLARE @statement nvarchar(max);
DECLARE @statementParamDec nvarchar(200);	
DECLARE @SortBy VARCHAR(100);
DECLARE @SortOrd VARCHAR(100);
		

SELECT  @SortBy=CASE
	WHEN  @SortId=1 THEN
	'dbo.CoordinatingAgency.Name'
	WHEN  @SortId=2 THEN
	'dbo.CoordinatingAgency.OfficePhone'
	WHEN  @SortId=3 THEN
	'dbo.CoordinatingAgency.IsActive'
	
	END
	
	SELECT @SortOrd=CASE
	WHEN @SortOrder=1 THEN
	'ASC'
	WHEN @SortOrder=0 THEN
	'DESC'
	END;

if(@count<0)
	begin
		set @statement='SELECT * FROM ('
	end
else
	begin 
		set @statement='SELECT TOP '+ CONVERT(VARCHAR, @Count) + ' * FROM ('
	end
	
set @statement=@statement+'
		select dbo.CoordinatingAgency.Id,
		dbo.CoordinatingAgency.Name,
		dbo.CoordinatingAgency.OfficePhone,
		dbo.CoordinatingAgency.IsActive,
		ROW_NUMBER() OVER (ORDER BY '+@SortBy+' '+@SortOrd+') AS Row_Numb 
		from dbo.CoordinatingAgency
		Where dbo.CoordinatingAgency.Id>0 '
		
		If(@Name<>'')
		begin
		SET @Name = @Name+'%';		
		set @statement=@statement+' and dbo.CoordinatingAgency.Name like @Name'
		end
		
		If(@IsActive is not NULL)
		begin
		set @statement=@statement+' and dbo.CoordinatingAgency.IsActive=@IsActive'
		end	
				
		set @statement=@statement+')
		
		AS O WHERE Row_Numb >= (@count * (@pageNumber - 1) + 1);'

	SET @statementParamDec = N'@count INT,@pageNumber INT,@Name varchar(200),@IsActive bit';

print @statement
		EXEC sp_executesql @statement, @statementParamDec,@count,@pageNumber,@Name,@IsActive;

		EXEC dbo.GetAllCoordinatingAgenciesCount @Name,@IsActive;

END
