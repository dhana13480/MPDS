﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>

-- exec IsActivityVerified 7597
-- =============================================
CREATE PROCEDURE [dbo].[IsActivityVerified] 
	-- Add the parameters for the stored procedure here

@Id bigint

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

		SELECT 
		A.IsVerified
		from dbo.Activity as A
		Where A.Id = @Id 
END
