﻿CREATE procedure [dbo].[GetAllUserTypes]
  as
  begin
   Select [Id],
      [Type]
  FROM Master_UserType
  end
