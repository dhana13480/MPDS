﻿
-- =============================================
-- Author:      <Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>

-- exec Report_P14 '','', '', '193'

-- =============================================
CREATE PROCEDURE [dbo].[Report_P14]
	@StartDate varchar(20),
	@EndDate varchar(20),
	@CoordinatingAgencyIds varchar(max), -- Come in as '#' or '#,#,...'
	@ProviderAgencyIds varchar(max), -- Come in as '#' or '#,#,...'
	@IsGamblingRelated bit
AS
BEGIN
	SET NOCOUNT ON;
	
	SET @CoordinatingAgencyIds = ISNULL(@CoordinatingAgencyIds, '')
	SET @ProviderAgencyIds = ISNULL(@ProviderAgencyIds, '')
	
	Select 
		O_EBP.Id as EBPTypeId, 
		O_EBP.Description as EBPType, 
		coalesce(OuterTable.UniversalIndirect,0) as UniversalIndirect,
		coalesce(OuterTable.UniversalDirect,0) as UniversalDirect,
		coalesce(OuterTable.TotalUniversal,0) as TotalUniversal,
		coalesce(OuterTable.Indicated,0) as Indicated,
		coalesce(OuterTable.Selective,0) as Selective,
		coalesce(OuterTable.Total,0) as Total
	from (select pivotTable.EBPTypeId,
				pivotTable.EBPType, 
				[1] as 'UniversalIndirect', 
				[2] as 'UniversalDirect',
				(coalesce([1],0) + coalesce([2],0)) as 'TotalUniversal',
				[3] as 'Indicated',
				[5] as 'Selective',
				(coalesce([1],0) + coalesce([2],0) + coalesce([3],0)+ coalesce([5],0)) As 'Total'
			from (Select	FA.EBPServiceTypeId as 'EBPTypeId', 
							FA.EBPServiceType As 'EBPType', 
							FA.InterventionTypeId AS 'InterventionType', 
							Count(DISTINCT FA.GroupId) AS 'GroupCount'	
						from vFilterActivities FA
						LEFT OUTER JOIN dbo.[CoordinatingAgency] CA ON CA.Id = FA.CoordinatingAgencyId

						Where CA.IsActive = 1
							AND FA.StartDate >= Convert(Date,@StartDate)
							AND FA.StartDate <= Convert(Date,@EndDate)
							AND (@CoordinatingAgencyIds = ''
									OR FA.CoordinatingAgencyId IN (SELECT * FROM [dbo].[SplitCSVs] (@CoordinatingAgencyIds, ',')))
							AND (@ProviderAgencyIds = ''
								OR FA.ProviderAgencyId IN (SELECT * FROM [dbo].[SplitCSVs] (@ProviderAgencyIds, ',')))
							AND FA.[IsGamblingRelated] = @IsGamblingRelated

						Group By FA.EBPServiceTypeId, FA.EBPServiceType, FA.InterventionTypeId) filterTable
					pivot (Sum(filterTable.GroupCount) for filterTable.InterventionType in ([1],[2],[3],[5])) as pivotTable  
			) OuterTable
		-- For Showing all EBP
		Right Outer Join dbo.Master_EBPServiceType O_EBP on(O_EBP.Id = OuterTable.EBPTypeId)
	
END
