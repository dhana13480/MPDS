﻿CREATE procedure [dbo].[IsSchoolDistrictNameInUse]  
  @Name varchar (50),
  @CountyId int
  as  
begin 
  If((Select COUNT(1) from dbo.Master_SchoolDistrict
      where dbo.Master_SchoolDistrict.SchoolDistrict=@Name and CountyId =@CountyId)>0 
      
        )
      Begin
        Select 1
      End
  Else
      Begin      
        Select 0
      End    
end
