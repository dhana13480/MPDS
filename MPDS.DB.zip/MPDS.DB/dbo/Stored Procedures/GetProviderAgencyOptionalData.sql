﻿-- exec GetProviderAgencyDetails 17

 CREATE procedure [dbo].[GetProviderAgencyOptionalData]  
  @ProviderAgencyId bigint 
  as  
 begin 
		 Select 
		 dbo.ProviderAgency_OptionalData.OptionalDataId,
		 dbo.Master_ActivityOptionalData.FieldName
		 
		 From dbo.ProviderAgency_OptionalData
		 inner join dbo.Master_ActivityOptionalData on dbo.ProviderAgency_OptionalData.OptionalDataId=Master_ActivityOptionalData.Id
		  
		 Where dbo.ProviderAgency_OptionalData.ProviderAgencyId=@ProviderAgencyId
		 order by dbo.Master_ActivityOptionalData.FieldName asc
    
  end
