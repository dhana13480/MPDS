﻿CREATE procedure [dbo].[VM_GetGroupType]
 
 as
 begin 
 
 Select dbo.Master_GroupType.Id,
  dbo.Master_GroupType.GroupType,  
  dbo.Master_GroupType.Description  
  from dbo.Master_GroupType
  order by dbo.Master_GroupType.GroupType
  asc
  
 end
