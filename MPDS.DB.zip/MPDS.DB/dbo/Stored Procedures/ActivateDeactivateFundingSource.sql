﻿CREATE procedure [dbo].[ActivateDeactivateFundingSource]  
  @Id int,
  @Status bit,
  @UpdatedBy bigint,
  @UpdationDate datetime   
  as  
begin 
 
 if(@Status=0) -- deactivate
	 Begin
		 If((Select COUNT(1) from dbo.ActivityGroup where [FundingSource] = @Id AND [IsActive] = 1 AND [IsDeleted] = 0)>0)  --- funding source is in use by group
			  BEGIN
			   Select 0;
			  END
		ELSE
		      BEGIN  -- deactivate not in use
		 Update dbo.Master_FundingSource 
		 set dbo.Master_FundingSource.IsActive=@Status,
		 dbo.Master_FundingSource.UpdatedBy=@UpdatedBy,
		 dbo.Master_FundingSource.UpdationDate=@UpdationDate 
		 where dbo.Master_FundingSource.Id=@Id
		 Select 1;
			   END		  	 
	 END
ELSE  -- activate
	BEGIN	 
		 Update dbo.Master_FundingSource 
		 set dbo.Master_FundingSource.IsActive=@Status,
		 dbo.Master_FundingSource.UpdatedBy=@UpdatedBy,
		 dbo.Master_FundingSource.UpdationDate=@UpdationDate 
		 where dbo.Master_FundingSource.Id=@Id
		 Select 1;
	END   
end
