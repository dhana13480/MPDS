﻿-- exec GetAllSchoolDistricts  '1,2',0,-1,1,1,1

CREATE procedure [dbo].[GetAllSchoolDistricts]  

@CountyIds varchar (max),
@IsActive bit,
@count INT = 10,  
@pageNumber INT=1,  
@SortOrder TINYINT=1,  
@SortId TINYINT = 1 

  
 as  
 begin   
   
  SET NOCOUNT ON;  
  
DECLARE @statement nvarchar(max);  
DECLARE @statementParamDec nvarchar(200);   
DECLARE @SortBy VARCHAR(100);  
DECLARE @SortOrd VARCHAR(100);  
    
  
    SELECT  @SortBy=CASE  
 WHEN  @SortId=1 THEN  
 'Master_SchoolDistrict.SchoolDistrict'  
 WHEN  @SortId=2 THEN  
 'Master_SchoolDistrict.Description'   
 	WHEN  @SortId=3 THEN
	'Master_SchoolDistrict.IsActive'
	WHEN  @SortId=4 THEN
	'MC.County'
 END  
   
 SELECT @SortOrd=CASE  
 WHEN @SortOrder=1 THEN  
 'ASC'  
 WHEN @SortOrder=0 THEN  
 'DESC'  
 END;  
   
 if(@count<0)  
 begin  
  set @statement='SELECT * FROM ('  
 end  
else  
 begin   
  set @statement='SELECT TOP '+ CONVERT(VARCHAR, @Count) + ' * FROM ('  
 end  
   
set @statement=@statement+'
			Select Master_SchoolDistrict.Id,
			MC.County,
			Master_SchoolDistrict.SchoolDistrict,
			Master_SchoolDistrict.Description,
			Master_SchoolDistrict.IsActive, 
			ROW_NUMBER() OVER (ORDER BY '+@SortBy+' '+@SortOrd+') AS Row_Numb
			from Master_SchoolDistrict inner join   Master_County MC on
			MC.Id=Master_SchoolDistrict.CountyId
			Where dbo.Master_SchoolDistrict.Id >0'  
        
		  if(@CountyIds<>'')  
			 begin  
			  set @statement=@statement+' and CountyId IN ('+@CountyIds+')'  
		     end  

           If(@IsActive is not NULL)
			begin
			  set @statement=@statement+' and dbo.Master_SchoolDistrict.IsActive=@IsActive'
	        end	
    
  set @statement=@statement+')  
    
  AS O WHERE Row_Numb >= (@count * (@pageNumber - 1) + 1);'  
   
   
  SET @statementParamDec = N'@count INT,@pageNumber INT,@CountyIds varchar(max),@IsActive Bit';  
      -- print @statement  
  EXEC sp_executesql @statement, @statementParamDec,@count,@pageNumber,@CountyIds,@IsActive;  
  
  EXEC GetAllSchoolDistrictCount  @CountyIds,@IsActive 
 end
