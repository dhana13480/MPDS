﻿-- exec GetAllServiceDomains
 CREATE procedure [dbo].[GetAllServiceDomains]
 
 as
 begin 
 
 Select dbo.Master_ServiceDomain.Id,
  dbo.Master_ServiceDomain.ServiceDomain 
  
  from dbo.Master_ServiceDomain
  order by dbo.Master_ServiceDomain.DisplayOrder
  asc
  
 end
