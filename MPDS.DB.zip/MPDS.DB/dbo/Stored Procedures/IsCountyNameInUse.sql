﻿CREATE procedure [dbo].[IsCountyNameInUse]  
  @Name varchar (50) 
  as  
begin 
  If((Select COUNT(1) from dbo.Master_County
      where dbo.Master_County.County=@Name)>0)
      Begin
        Select  1
      End
  Else
      Begin      
        Select 0
      End    
end
