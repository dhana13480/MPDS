﻿
CREATE procedure [dbo].[ActivateDeactivateGroup]  
  @Id bigint,
  @Status bit,
  @UpdatedBy bigint,
  @UpdationDate datetime    
  as  
begin 
 
 if(@Status=0) -- deactivate
	 Begin 
		 Update dbo.ActivityGroup 
		 set dbo.ActivityGroup.IsActive=@Status,
		 dbo.ActivityGroup.UpdatedBy=@UpdatedBy,
		 dbo.ActivityGroup.UpdationDate=@UpdationDate,
		 dbo.ActivityGroup.DeactivationDate=@UpdationDate
		 where dbo.ActivityGroup.Id=@Id
		 Select 1; 
     END 
ELSE  -- activate
     BEGIN
        
        Declare @ProviderAgencyId bigint;
        Declare @GroupName varchar(500);
							Select @ProviderAgencyId=dbo.ActivityGroup.ProviderAgencyId,
							@GroupName=dbo.ActivityGroup.Name
							 from dbo.ActivityGroup where dbo.ActivityGroup.Id=@Id
							 and dbo.ActivityGroup.IsDeleted=0
        
        If((Select COUNT(1) from dbo.ActivityGroup where dbo.ActivityGroup.Name=(Select top(1) dbo.ActivityGroup.Name
			   From dbo.ActivityGroup where dbo.ActivityGroup.ProviderAgencyId=@ProviderAgencyId
			   and dbo.ActivityGroup.IsActive=1 and dbo.ActivityGroup.IsDeleted=0 and dbo.ActivityGroup.Name=@GroupName))>0)
			   Begin           
			         Select 0;  -- cannot activate as there is already a group with the same name and active
			   END
       ELSE     
               BEGIN
				 Update dbo.ActivityGroup 
				 set dbo.ActivityGroup.IsActive=@Status,
				 dbo.ActivityGroup.UpdatedBy=@UpdatedBy,
				 dbo.ActivityGroup.UpdationDate=@UpdationDate,
				 dbo.ActivityGroup.DeactivationDate=NULL
				 where dbo.ActivityGroup.Id=@Id  
				 Select 1;
		        END 
       END
END

