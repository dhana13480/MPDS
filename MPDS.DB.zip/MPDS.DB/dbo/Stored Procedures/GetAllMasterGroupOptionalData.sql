﻿CREATE procedure [dbo].[GetAllMasterGroupOptionalData]
 
 as
 begin 
 
 Select dbo.Master_GroupOptionalData.Id,
  dbo.Master_GroupOptionalData.Description,
  dbo.Master_GroupOptionalData.FieldName
  from dbo.Master_GroupOptionalData
 
 
  
 end
