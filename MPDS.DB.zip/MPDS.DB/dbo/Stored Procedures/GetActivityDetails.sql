﻿
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>

-- exec GetActivityDetails 7981
-- =============================================
CREATE PROCEDURE [dbo].[GetActivityDetails] 
	-- Add the parameters for the stored procedure here

@Id bigint

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

		SELECT 
		A.Id, 
		A.ActivityName, 
		PA.Id as ProviderAgencyId,
		PA.Name as ProviderAgency,
		CA.Id as CoordinatingAgencyId,
		CA.Name as CoordinatingAgency,
		A.GroupId, 
		AG.Name as GroupName,
		CASE WHEN AG.[ProgramNameId] = -2 THEN AG.[OtherProgramName] ELSE MPN.[Name] END AS [ProgramName],
		A.StartDate, 
		A.EndDate, 
		A.IsVerified,
		A.TotalAttendees, 
		A.NewMaleAttendees, 
		A.NewFemaleAttendees, 
		A.MasterStrategyEmployed, 
		A.EstimatePeopleReached, 
		A.AttendeesCompletingGroup, 
		A.ActivityOptionalDataId,
		A.IsVerified,
		U.UserName as VerifiedByName,
		A.VerifiedOn,
		A.VerifyComments,
		AOD.numberOfOriginalItemsCreated,
		AOD.numberOfBrochuresDistributed,
		AOD.IndirectSpeakingEngagementReach,
		AOD.IndirectSpeakingEngagementCount,
		AOD.IsSchoolBasedActivity,
		AOD.SchoolDistrictId,
		AOD.CountyId,
		AOD.LocationZipCode,
		AOD.ServiceSettingId,
		A.IsActive, 
		A.IsFirstActivityInGroup, 
		A.RecordNumber, 
		A.Comments,
		A.CreationDate
		from dbo.Activity as A
		Inner Join dbo.ActivityGroup as AG on (AG.Id = A.GroupId)
		Left Outer Join dbo.Activity_OptionalData as AOD on (AOD.Id = A.ActivityOptionalDataId)
		LEFT OUTER JOIN [dbo].[Master_ProgramName] MPN ON MPN.[Id] = AG.[ProgramNameId]
		Inner Join dbo.ProviderAgency as PA on (PA.Id = AG.ProviderAgencyId)
		Inner Join dbo.CoordinatingAgency as CA on (CA.Id = PA.CoordinatingAgencyId)
		left outer join dbo.Users as U on (U.Id = A.VerifiedBy) 
		Where A.Id = @Id 
		
		Select 
		S.FirstName, S.LastName, A_S.StaffId,
		(MS.Code + ' - ' + MS.Strategy) as Strategy, A_S.StrategyId, 
		A_S.Units, A_S.OptionalLocalMBO ,
		A_S.StartDate, A_S.EndDate
		from dbo.Activity_Staff A_S
		Left outer join dbo.Staff S on(S.Id = A_S.StaffId)
		Left outer join dbo.Master_Strategy MS on(MS.Id = A_S.StrategyId)
		where A_S.ActivityId = @Id;
		
		Select RaceId, NoOfAttendees from dbo.Activity_Race where ActivityId=@Id;
		Select EthnicityId, NoOfAttendees from dbo.Activity_Ethnicity where ActivityId=@Id;
		Select ParticipantAgeGroupId, NoOfAttendees from dbo.Activity_ParticipantAgeGroup where ActivityId=@Id;

END
