﻿-- exec [dbo].[GetAllActivityDataReportFields]
CREATE procedure [dbo].[GetAllActivityDataReportFields]
as
begin
Select [Id],
[FieldName],
[GroupId]
FROM dbo.Master_ActivityDataReportFields
Order by Id asc
end
