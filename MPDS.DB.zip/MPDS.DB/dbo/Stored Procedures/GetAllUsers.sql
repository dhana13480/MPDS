﻿-- [GetAllUsers] -1,1,0,6,4,'','','',15,-1

CREATE procedure [dbo].[GetAllUsers]   
     @count INT = 10   
    ,@pageNumber INT=1   
    ,@SortOrder TINYINT=1   
    ,@SortId TINYINT = 1  
	,@SearchByType  Smallint =-1
	,@SearchByLastName  Varchar(50)='' 
	,@SearchByUserName Varchar(100)='' 
	,@SearchByEmail Varchar(50)=''
	,@CoordinatingAgencyId bigint =-1
	,@ProviderAgencyId bigint=-1

     
      as
      begin
      
        SET NOCOUNT ON;  

		DECLARE @statement nvarchar(max);  
		DECLARE @statementParamDec nvarchar(200);   
		DECLARE @SortBy VARCHAR(100);  
		DECLARE @SortOrd VARCHAR(100);  

		SELECT  @SortBy=CASE  
		WHEN  @SortId=1 THEN  
		'U.FirstName'   
		WHEN  @SortId=2 THEN
		'U.LastName'
		WHEN  @SortId=3 THEN  
		'U.Email'   
		WHEN  @SortId=4 THEN
		'U.Phone' 
		WHEN  @SortId=5 THEN  
		'U.UserName'
		WHEN  @SortId=6 THEN  
		'MU.Type'
		WHEN  @SortId=7 THEN  
		'U.IsActive'
		
		END  

		SELECT @SortOrd=CASE  
		WHEN @SortOrder=1 THEN  
		'ASC'  
		WHEN @SortOrder=0 THEN  
		'DESC'  
		END;   
		
		if(@count<0)  
		begin  
		set @statement='SELECT * FROM ('  
		end  
		else  
		begin   
		set @statement='SELECT TOP '+ CONVERT(VARCHAR, @Count) + ' * FROM ('  
		end  


		set @statement=@statement+' SELECT  U.[Id]
		,U.[FirstName] 
		,U.[LastName]
		,U.MiddleName
		,U.[UserName] 
		,U.[Email]
		,U.[UserTypeId]
		,MU.[Type] as[UserType] 
		,U.[IsActive] 
		,U.[Phone], 
		ROW_NUMBER() OVER (ORDER BY '+@SortBy+' '+@SortOrd+') AS Row_Numb  
		from [Users] as U 
		INNER join  Master_UserType MU on (MU.Id=U.[UserTypeId])
		LEFT OUTER JOIN dbo.CoordinatingAgency CA ON CA.Id = U.CoordinatingAgencyId
		
		Where U.IsDeleted =0 AND (CA.Id IS NULL OR CA.IsActive = 1) '

		if(@SearchByLastName <> '')
		Begin
		SET @SearchByLastName = @SearchByLastName+'%';		
		set @statement=@statement+' AND U.LastName like @SearchByLastName'
		End

		if(@SearchByUserName <>'')
		Begin
		
		SET @SearchByUserName = @SearchByUserName+'%';
		set @statement=@statement+' AND U.UserName  like @SearchByUserName'
		End


		if(@SearchByEmail<>'')
		Begin
		SET @SearchByEmail = @SearchByEmail+'%';
			set @statement=@statement+' AND U.Email like @SearchByEmail'
		END
		
		if(@SearchByType > 0)
		Begin
			set @statement=@statement+' and U.[UserTypeId]=@SearchByType'
			
			if(@ProviderAgencyId > 0)
			Begin
				set @statement=@statement+' AND U.ProviderAgencyId=@ProviderAgencyId'
			END
			ELSE if(@ProviderAgencyId <= 0 AND @CoordinatingAgencyId > 0)
			Begin
				if(@SearchByType = 4) -- PA
				Begin
					set @statement=@statement+' AND U.ProviderAgencyId IN (Select dbo.ProviderAgency.Id from dbo.ProviderAgency where dbo.ProviderAgency.CoordinatingAgencyId = @CoordinatingAgencyId)'
				End
				Else
				Begin
					set @statement = @statement + ' AND U.CoordinatingAgencyId= @CoordinatingAgencyId'
				End
				
			END
			
		end
		Else -- @SearchByType is not provided
		Begin
			if(@ProviderAgencyId > 0)
			Begin
				set @statement=@statement+' AND U.ProviderAgencyId=@ProviderAgencyId'
			End
			Else if (@ProviderAgencyId <= 0 AND @CoordinatingAgencyId > 0)
			Begin
				set @statement=@statement+' AND
				(U.CoordinatingAgencyId= @CoordinatingAgencyId 
				 OR 
				 U.ProviderAgencyId IN (Select dbo.ProviderAgency.Id from dbo.ProviderAgency where dbo.ProviderAgency.CoordinatingAgencyId = @CoordinatingAgencyId)
				 ) '
			End
			--ELSE
			--Begin
			--	-- No Parameter, show All user	
			--End
		End    
         

		set @statement=@statement+' )   


		AS O WHERE Row_Numb >= (@count * (@pageNumber - 1) + 1);' 

		SET @statementParamDec = N'@count INT,@pageNumber INT,@CoordinatingAgencyId bigint,@ProviderAgencyId bigint,@SearchByType smallint,@SearchByLastName varchar(50),@SearchByUserName varchar(100),@SearchByEmail varchar(50)';  
	 	-- print @statement ;

	   EXEC sp_executesql @statement, @statementParamDec,@count,@pageNumber,@CoordinatingAgencyId,@ProviderAgencyId,@SearchByType,@SearchByLastName,@SearchByUserName,@SearchByEmail;  

	   EXEC GetAllUserCount	 @SearchByType,@SearchByLastName,@SearchByUserName,@SearchByEmail,@CoordinatingAgencyId,@ProviderAgencyId   


end   

 --
