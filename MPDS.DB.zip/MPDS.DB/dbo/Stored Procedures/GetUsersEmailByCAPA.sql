﻿-- EXEC [GetUsersEmailByCAPA] 3,'14,15,16,17','179,80,154,169'
CREATE PROCEDURE [dbo].[GetUsersEmailByCAPA]
@NotificationTypeId smallint,
@CSVCoordinatingAgencyIds varchar(MAX),
@CSVProviderAgencyIds varchar(MAX)

AS
BEGIN
SET NOCOUNT ON;
DECLARE @statement nvarchar(max);
DECLARE @statementParamDec nvarchar(2000);
DECLARE @EmailAddresses VARCHAR(MAX);
SET @EmailAddresses='';
SET @statement='SELECT 
@EmailAddresses =
COALESCE ( COALESCE(@EmailAddresses +'','','''') + Users.Email , @EmailAddresses)
FROM Users Where Users.UserTypeId<>1 and Users.UserTypeId<>2 and Users.Email<>'''''
If(@NotificationTypeId=2) -- CA
BEGIN
	set @statement=@statement+ ' and dbo.Users.CoordinatingAgencyId in 
								(Select item1 from dbo.SplitCSVS(@CSVCoordinatingAgencyIds,'',''))' -- CA
END
ELSE If(@NotificationTypeId=3) -- PA
BEGIN
	set @statement=@statement+ ' and dbo.Users.ProviderAgencyId in
								(Select item1 from dbo.SplitCSVS(@CSVProviderAgencyIds,'',''))'
END  
ELSE If(@NotificationTypeId=4) -- BOTH
BEGIN
	set @statement=@statement+ ' and dbo.Users.CoordinatingAgencyId in 
								(Select item1 from dbo.SplitCSVS(@CSVCoordinatingAgencyIds,'','')) OR
								dbo.Users.ProviderAgencyId in
								(Select item1 from dbo.SplitCSVS(@CSVProviderAgencyIds,'',''))'
	--							(@CSVCoordinatingAgencyIds) OR dbo.Users.ProviderAgencyId in 
	--							(@CSVProviderAgencyIds)'
END 
set @statement=@statement+ ' Select @EmailAddresses [EmailAddresses]'

SET @statementParamDec = N'@CSVCoordinatingAgencyIds Varchar(MAX),@CSVProviderAgencyIds Varchar(MAX),@EmailAddresses VARCHAR(MAX)';   
--Print @statement
EXEC sp_executesql @statement,@statementParamDec,@CSVCoordinatingAgencyIds,@CSVProviderAgencyIds,@EmailAddresses 
END



