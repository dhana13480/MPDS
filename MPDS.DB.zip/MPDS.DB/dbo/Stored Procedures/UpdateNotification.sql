﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- exec CreateUser dsf
-- =============================================
CREATE PROCEDURE [dbo].[UpdateNotification] 
	-- Add the parameters for the stored procedure here
@NotificationId bigint,
@CSVCoordinatingAgencyIds varchar(2000),
@CSVProviderAgencyIds varchar(2000),
@Title varchar(100),
@Text varchar(2000),
@StartDate datetime,
@EndDate datetime,
@CSVAttachmentName varchar(500),
@CSVAttachmentFileName varchar(1000),
@UpdatedBy bigint,
@UpdationDate datetime


AS
BEGIN
	 --SET NOCOUNT ON added to prevent extra result sets from
	 --interfering with SELECT statements.
	SET NOCOUNT ON;

BEGIN TRY
	BEGIN TRANSACTION

	BEGIN
	-- delete and create
	Update dbo.Notification Set 
	CSVCoordinatingAgencyIds=@CSVCoordinatingAgencyIds,
	CSVProviderAgencyIds=@CSVProviderAgencyIds,
	Title=@Title,
	Text=@Text,
	StartDate=@StartDate,
	EndDate=@EndDate,
	IsEmailSent=0, --set to default
	UpdatedBy=@UpdatedBy,
	UpdationDate=@UpdationDate
	
	Where dbo.Notification.Id=@NotificationId;
	
	Delete from dbo.Notifications_Attachment where 
	dbo.Notifications_Attachment.NotificationId=@NotificationId;
	
	if(@CSVAttachmentName<>'' AND @CSVAttachmentFileName<>'')
	BEGIN
		Insert into dbo.Notifications_Attachment
		(NotificationId, CreatedBy, CreationDate,Name, FileName) 
		 Select @NotificationId,@UpdatedBy,@UpdationDate, 
		 part1, part2 from dbo.SplitTwoString(@CSVAttachmentName,@CSVAttachmentFileName,'|@~@|')
	END
	END

	
	COMMIT TRANSACTION
END TRY
	BEGIN CATCH
		ROLLBACK TRANSACTION
		DECLARE @ErrorMessage NVARCHAR(4000);
    DECLARE @ErrorSeverity INT;
    DECLARE @ErrorState INT;

    SELECT 
        @ErrorMessage = ERROR_MESSAGE(),
        @ErrorSeverity = ERROR_SEVERITY(),
        @ErrorState = ERROR_STATE();

    RAISERROR (@ErrorMessage, -- Message text.
               @ErrorSeverity, -- Severity.
               @ErrorState -- State.
               );  
		
	END CATCH
END



