﻿
CREATE procedure [dbo].[GetAllProgramNames] 
AS
  BEGIN

	  SELECT MPN.[Id]
		    ,MPN.[Name]
		    ,MPN.[Description]
		    ,MPN.[CreatedBy]
		    ,MPN.[CreationDate]
		    ,MPN.[UpdatedBy]
		    ,MPN.[UpdationDate]
		    ,MPN.[DeactivatedBy]
		    ,MPN.[DeactivatedDate]
	  FROM [dbo].[Master_ProgramName] MPN

	  ORDER BY MPN.[Name]

  END
