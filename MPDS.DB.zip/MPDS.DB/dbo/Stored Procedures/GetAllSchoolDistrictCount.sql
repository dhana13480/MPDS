﻿CREATE PROCEDURE [dbo].[GetAllSchoolDistrictCount] 
	-- Add the parameters for the stored procedure here

@CountyIds varchar(max),
@IsActive bit = null


AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	
DECLARE @statement nvarchar(max);
DECLARE @statementParamDec nvarchar(200);	
	

set @statement='
		select count(1)
		from dbo.Master_SchoolDistrict
		Where dbo.Master_SchoolDistrict.Id>0'
		
		if(@CountyIds<>'')
			begin
				set @statement=@statement+' and CountyId IN ('+@CountyIds+')'  
			end
			
		 If(@IsActive is not NULL)
			begin
			  set @statement=@statement+' and dbo.Master_SchoolDistrict.IsActive=@IsActive'
	        end		

SET @statementParamDec = N'@CountyIds varchar(max),@IsActive bit';
--select @statement
		EXEC sp_executesql @statement,@statementParamDec, @CountyIds,@IsActive;

	

END
