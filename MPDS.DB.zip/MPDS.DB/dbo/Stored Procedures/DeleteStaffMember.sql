﻿CREATE procedure [dbo].[DeleteStaffMember]
@Id bigint,
@UpdatedBy bigint,
@UpdationDate datetime
as
begin

If EXISTS(Select dbo.Activity_Staff.Id from dbo.Activity_Staff
Where dbo.Activity_Staff.StaffId=@Id)
BEGIN
-- Staff associated with activity, cannot be deleted
Select 0
END
ELSE -- staff not in activity, can be deleted
BEGIN
Update dbo.Staff set dbo.Staff.IsDeleted=1,
UpdatedBy=@UpdatedBy,
UpdationDate=@UpdationDate
where dbo.Staff.Id=@Id
Select 1
END

end
