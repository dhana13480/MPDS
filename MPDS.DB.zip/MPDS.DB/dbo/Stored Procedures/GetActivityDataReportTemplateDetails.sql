﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>

-- exec GetActivityDataReportTemplateDetails 10
-- =============================================
CREATE PROCEDURE [dbo].[GetActivityDataReportTemplateDetails] 
	-- Add the parameters for the stored procedure here

@TemplateId bigint

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

		SELECT TemplateId,
		FieldId,
		GroupId,
		CSVCoordinatingAgencyIds,
		CSVProviderAgencyIds,
		CSVGroupIds
		
		from dbo.ActivityDataReport_TemplateDetails
        inner join dbo.Master_ActivityDataReportFields on
        (dbo.ActivityDataReport_TemplateDetails.FieldId=dbo.Master_ActivityDataReportFields.Id)
         inner join dbo.ActivityDataReport_Template on
        (dbo.ActivityDataReport_Template.Id=dbo.ActivityDataReport_TemplateDetails.TemplateId)
       
         Where dbo.ActivityDataReport_TemplateDetails.TemplateId=@TemplateId;
END


INSERT INTO [Master_NotificationType] ([Type])VALUES('PA')
INSERT INTO [Master_NotificationType] ([Type])VALUES('Both')
