﻿/****** Script for SelectTopNRows command from SSMS  ******/

CREATE procedure [dbo].[GetApplicationSettings]
as
begin

select SMTPServer
      ,SMTPPort
      ,SecureSMTP
      ,MailFromAddress
      ,MailFromUserName
      ,MailFromPassword 
      ,PagingCount_Admin
      ,PagingCount_CoordinatingAgency
      ,PagingCount_ProviderAgency
      ,PagingCount_Auditor
      ,[DomainName]
      ,ErrorEmailAddress
  from ApplicationSettings
  
  end
