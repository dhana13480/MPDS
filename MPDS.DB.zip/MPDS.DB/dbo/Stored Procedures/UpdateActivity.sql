﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- exec CreateUser dsf
-- =============================================
CREATE PROCEDURE [dbo].[UpdateActivity]
	-- Add the parameters for the stored procedure here
@Id bigint,
@Name varchar(500),
@StartDate datetime,
@EndDate datetime,
@MasterStrategyEmployed int,
@TotalAttendees int,
@NewMaleAttendees int,
@NewFemaleAttendees int,
@EstimatePeopleReached int,
@AttendeesCompletingGroup int,
@IsFirstActivityInGroup bit,
@Comments varchar(1000),

@CSVEthnicity varchar(1000),
@CSVEthnicityAttendees varchar(1000),

@CSVRace varchar(1000),
@CSVRaceAttendees varchar(1000),

@CSVParticipantByAge varchar(1000),
@CSVParticipantByAgeAttendees varchar(1000),

@CSVStaffIds varchar(1000),
@CSVStaffStrategyIds varchar(1000),
@CSVStaffUnits varchar(1000),
@CSVStaffLocalMBOs varchar(1000),
@CSVStaffStartTime varchar(1000),
@CSVStaffEndTime varchar(1000),

@NumberOfOriginalItemsCreated int,
@NumberOfBrochuresDistributed int,
@IndirectSpeakingEngagementReach int,
@IndirectSpeakingEngagementCount int,
@IsSchoolBasedActivity bit,
@SchoolDistrictId int,
@CountyId int,
@LocationZipCode varchar(10),
@ServiceSettingId int,

@UpdatedBy bigint,
@UpdationDate datetime


AS
BEGIN
	 --SET NOCOUNT ON added to prevent extra result sets from
	 --interfering with SELECT statements.
	SET NOCOUNT ON;

BEGIN TRY
	BEGIN TRANSACTION

Declare @OptionalDataId bigint=null;
Declare @LatestOptionaDataId bigint;

	Set @OptionalDataId =(Select dbo.ActivityGroup.GroupOptionalDataId
	from dbo.ActivityGroup where dbo.ActivityGroup.Id=@Id)

Set @LatestOptionaDataId = @OptionalDataId;

if(@OptionalDataId is NULL) -- no optional data present
   BEGIN
		 if(@NumberOfOriginalItemsCreated is NOT NULL
			OR @NumberOfBrochuresDistributed is NOT NULL
			OR @IndirectSpeakingEngagementReach is NOT NULL
			OR @IndirectSpeakingEngagementCount is NOT NULL
			OR @IsSchoolBasedActivity is NOT NULL
			OR @SchoolDistrictId is NOT NULL
			OR @CountyId is NOT NULL
			--OR @ServiceSettingId is NOT NULL
			OR @LocationZipCode<>'')
		     BEGIN -- optional data present
		    
		     Insert into dbo.Activity_OptionalData
		     (
				numberOfOriginalItemsCreated, 
				numberOfBrochuresDistributed,
				IndirectSpeakingEngagementReach,
				IndirectSpeakingEngagementCount,
				IsSchoolBasedActivity, 
				SchoolDistrictId, 
				CountyId, 
				LocationZipCode, 
				ServiceSettingId
		     )
		     values (
				@NumberOfOriginalItemsCreated, 
				@NumberOfBrochuresDistributed, 
				@IndirectSpeakingEngagementReach,
				@IndirectSpeakingEngagementCount,
				@IsSchoolBasedActivity, 
				@SchoolDistrictId, 
				@CountyId, 
				@LocationZipCode, 
				@ServiceSettingId
		     )
		     Set @LatestOptionaDataId = @@IDENTITY;
		     
		     END
   
    END
ELSE   -- optional data present
    BEGIN    
        if(@NumberOfOriginalItemsCreated is NOT NULL
			OR @NumberOfBrochuresDistributed is NOT NULL
			OR @IndirectSpeakingEngagementReach is NOT NULL
			OR @IndirectSpeakingEngagementCount is NOT NULL
			OR @IsSchoolBasedActivity is NOT NULL
			OR @SchoolDistrictId is NOT NULL
			OR @CountyId is NOT NULL
			--OR @ServiceSettingId is NOT NULL
			OR @LocationZipCode<>'')
		     BEGIN -- optional data present
				 Update dbo.Activity_OptionalData set						
					numberOfOriginalItemsCreated=@NumberOfOriginalItemsCreated,
					numberOfBrochuresDistributed=@NumberOfBrochuresDistributed, 
					IndirectSpeakingEngagementReach=@IndirectSpeakingEngagementReach, 
					IndirectSpeakingEngagementCount=@IndirectSpeakingEngagementCount, 
					IsSchoolBasedActivity=@IsSchoolBasedActivity, 
					SchoolDistrictId=@SchoolDistrictId, 
					CountyId=@CountyId, 
					LocationZipCode=@LocationZipCode
					--ServiceSettingId=@ServiceSettingId -- Not Updating Service Setting
					Where dbo.Activity_OptionalData.Id=@OptionalDataId;		     
			 END
		  --ELSE -- no optional data present (Do nothing)
		  --   BEGIN
				-- Delete from dbo.Activity_OptionalData where dbo.Activity_OptionalData.Id=@OptionalDataId;
				-- Set @LatestOptionaDataId = null;
		  --   END   
    
    END
			
Update dbo.Activity
Set
ActivityName=@Name, 
StartDate=@StartDate, 
EndDate=@EndDate, 
TotalAttendees=@TotalAttendees, 
NewMaleAttendees=@NewMaleAttendees, 
NewFemaleAttendees=@NewFemaleAttendees, 
MasterStrategyEmployed=@MasterStrategyEmployed, 
EstimatePeopleReached=@EstimatePeopleReached, 
AttendeesCompletingGroup=@AttendeesCompletingGroup, 
IsFirstActivityInGroup = @IsFirstActivityInGroup,
ActivityOptionalDataId=@LatestOptionaDataId, 
Comments=@Comments, 
UpdatedBy=@UpdatedBy, 
UpdationDate=@UpdationDate
Where dbo.Activity.Id=@Id


	Delete from dbo.Activity_Ethnicity Where dbo.Activity_Ethnicity.ActivityId= @Id;
	if(@CSVEthnicity<>'')
	Begin
		Insert into  dbo.Activity_Ethnicity(
		ActivityId, EthnicityId, NoOfAttendees
		) Select @Id, item1, item2 from dbo.SplitTwoCSVs(@CSVEthnicity,@CSVEthnicityAttendees,',')
	End

	Delete from dbo.Activity_Race Where dbo.Activity_Race.ActivityId= @Id;	
	if(@CSVRace<>'')
	Begin
		Insert into dbo.Activity_Race(
		ActivityId, RaceId, NoOfAttendees
		) Select @Id, item1, item2 from dbo.SplitTwoCSVs(@CSVRace,@CSVRaceAttendees,',')
	End
	
	Delete from dbo.Activity_ParticipantAgeGroup Where dbo.Activity_ParticipantAgeGroup.ActivityId= @Id;
	if(@CSVParticipantByAge<>'')
	Begin
		Insert into dbo.Activity_ParticipantAgeGroup(
		ActivityId, ParticipantAgeGroupId, NoOfAttendees
		) Select @Id, item1, item2 from dbo.SplitTwoCSVs(@CSVParticipantByAge,@CSVParticipantByAgeAttendees,',')
	END
	
	Delete from dbo.Activity_Staff Where dbo.Activity_Staff.ActivityId= @Id;
	if(@CSVStaffIds<>'')
	Begin
		Insert into dbo.Activity_Staff(
		ActivityId, StaffId, StrategyId, Units, OptionalLocalMBO, StartDate, EndDate
		) Select @Id, part1, part2, part3, part4, part5, part6 from dbo.SplitSixString(@CSVStaffIds,@CSVStaffStrategyIds, @CSVStaffUnits, @CSVStaffLocalMBOs,@CSVStaffStartTime, @CSVStaffEndTime,'|#|%|@|')
	End	


Declare @GroupId bigint;
Set @GroupId = (Select GroupId from Activity Where Id=@Id);

-- Update Activity Order
-- Used IN AddActivity, UpdateActivity and DeleteActivity
Update A
Set A.OrderNumber = GA.Num
From Activity A
Inner Join (
Select ROW_NUMBER() over (Order BY StartDate) Num,  Id, StartDate, ActivityName from Activity 
Where IsDeleted = 0
AND GroupId = @GroupId) GA ON (GA.ID = A.Id)

Select @Id;	
	
	COMMIT TRANSACTION
END TRY
	BEGIN CATCH
		ROLLBACK TRANSACTION
		DECLARE @ErrorMessage NVARCHAR(4000);
    DECLARE @ErrorSeverity INT;
    DECLARE @ErrorState INT;

    SELECT 
        @ErrorMessage = ERROR_MESSAGE(),
        @ErrorSeverity = ERROR_SEVERITY(),
        @ErrorState = ERROR_STATE();

    RAISERROR (@ErrorMessage, -- Message text.
               @ErrorSeverity, -- Severity.
               @ErrorState -- State.
               );
   
		--Select -1;
	END CATCH
END
