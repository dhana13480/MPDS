﻿--exec [dbo].[IsActivityDataReportTemplateNameInUse] 3,6,'third template'
CREATE procedure [dbo].[IsActivityDataReportTemplateNameInUse]
@UserId bigint,
@TemplateId bigint,
@TemplateName varchar(100)
as
begin
if EXISTS(select dbo.ActivityDataReport_Template.Id
from dbo.ActivityDataReport_Template where
dbo.ActivityDataReport_Template.Name=@TemplateName
AND dbo.ActivityDataReport_Template.UserId=@UserId
AND dbo.ActivityDataReport_Template.Id<>@TemplateId)
begin
select 1
end
else
begin
select 0
end
end
