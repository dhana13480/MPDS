﻿-- exec GetCoordinatingAgencyAddressDetails 17

 CREATE procedure [dbo].[GetCoordinatingAgencyAddressDetails]  
  @CoordinatingAgencyId bigint 
  as  
 begin 
		 Select 
		 dbo.CoordinatingAgency.Id,
		 dbo.CoordinatingAgency.Address1, 
		 dbo.CoordinatingAgency.Address2, 
		 dbo.CoordinatingAgency.City, 
		 dbo.CoordinatingAgency.State, 
		 dbo.CoordinatingAgency.Zip 
		  
		  From dbo.CoordinatingAgency
		  
		 Where dbo.CoordinatingAgency.Id=@CoordinatingAgencyId;
		 
	  end
