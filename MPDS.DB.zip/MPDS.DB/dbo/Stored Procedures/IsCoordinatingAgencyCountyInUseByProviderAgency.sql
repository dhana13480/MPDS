﻿CREATE procedure [dbo].[IsCoordinatingAgencyCountyInUseByProviderAgency]  
  
  @CoordinatingAgencyId bigint,
  @CountyId int 
  as  
begin 
  If((Select COUNT(1)from dbo.ProviderAgency_County where 
   dbo.ProviderAgency_County.ProviderAgencyId in (Select dbo.ProviderAgency.Id from 
	dbo.ProviderAgency where CoordinatingAgencyId=@CoordinatingAgencyId)
      and dbo.ProviderAgency_County.CountyId=@CountyId)>0)      
      Begin
      Select 1;
      End
Else
     Begin
      Select 0;
      End
end
