﻿CREATE procedure [dbo].[UpdateUser] 
@Id bigint
,@FirstName  varchar (50)
,@MiddleName varchar (15)
,@LastName  varchar (50)   
,@Password varchar(255)
,@Permissions varchar (100) 
,@Email varchar (255)
,@Phone varchar (15)
,@Address1	 varchar (255)
,@Address2 varchar (255)
,@City	 varchar (50)
,@StateId smallint
,@Zip varchar (15)
,@Comments varchar (1000)
,@UpdatedBy bigint
 ,@UpdationDate   datetime
 
   as
      begin
      -- Update Password as well along with other fields
      if(@Password<>'')
      begin
      update users set 
					 FirstName	  =@FirstName
					,MiddleName	  =@MiddleName
					,LastName	  =@LastName 
					,Password=@Password  
					,IsPasswordResetRequired=1
					,[HashingAlgorithm] = 'SHA512' -- New default
					 ,Permissions=@Permissions 
					,Email		  =@Email
					,Phone	  =@Phone	  
					,Address1	  =@Address1
					,Address2	  =@Address2
					,City		  =@City
					,StateId		  =@StateId
					,Zip		  =@Zip
					,Comments	  =@Comments
					,UpdatedBy	  =@UpdatedBy
					,UpdationDate =@UpdationDate
					      
      where Id=@Id
      
      end
      
      else
      
       begin
      update users set 
					 FirstName	  =@FirstName
					,MiddleName	  =@MiddleName
					,LastName	  =@LastName  
					 ,Permissions=@Permissions 
					,Email		  =@Email
					,Phone	  =@Phone	  
					,Address1	  =@Address1
					,Address2	  =@Address2
					,City		  =@City
					,StateId		  =@StateId
					,Zip		  =@Zip
					,Comments	  =@Comments
					,UpdatedBy	  =@UpdatedBy
					,UpdationDate =@UpdationDate
					      
      where Id=@Id
      
      end
      
       
          end
