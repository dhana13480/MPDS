﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>

-- exec GetAllNotificationsCount -1,100,0,1
-- =============================================
CREATE PROCEDURE [dbo].[GetAllNotificationsByUserCount] 
	-- Add the parameters for the stored procedure here

@UserId bigint

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

DECLARE @statement nvarchar(max);
DECLARE @statementParamDec nvarchar(200);	

set @statement='
		SELECT count(1)
		from dbo.Notification 
		Where 
		dbo.Notification.CreatedBy=@UserId' -- created by self

SET @statementParamDec = N'@UserId bigint';

--select @statement
EXEC sp_executesql @statement,@statementParamDec, @UserId;

END
