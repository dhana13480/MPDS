﻿CREATE procedure [dbo].[AddNewStaffMember] --3,'','',0,'','','','','','','','','','','','','',''  
       @CoordinatingAgencyId  bigint
      ,@StaffTypeId  smallint 
      ,@ProviderAgencyId  bigint 
      ,@FirstName   varchar(50)    
      ,@MiddleName varchar(15)   
      ,@IsActive bit  
      ,@LastName varchar(50)   
      ,@Email varchar(255)  
      ,@CellPhone varchar(15)  
      ,@OfficePhone varchar(15)
      ,@HomePhone varchar(15)   
      ,@Fax varchar(12)  
      ,@Address1 varchar(500)  
      ,@Address2 varchar(500)  
      ,@City varchar(50)  
      ,@State smallint  
      ,@Zip varchar(9)  
      ,@Comments varchar(1000)  
      ,@CreatedBy bigint  
      ,@CreationDate  datetime  
      ,@effectiveFrom datetime  
      ,@effectiveTo datetime  
      as  
      begin  
      
  if(@StaffTypeId=2)--PA
    begin
       insert into Staff  
      (   
       CoordinatingAgencyId  
      ,ProviderAgencyId   
      ,FirstName  
      ,MiddleName  
      ,LastName  
      ,IsActive  
      ,Email  
      ,CellPhone  
      ,OfficePhone 
      ,HomePhone  
      ,Fax  
      ,Address1  
      ,Address2  
      ,City  
      ,State  
      ,Zip  
      ,Comments  
      ,CreatedBy  
      ,CreationDate 
      ,effectiveFrom  
      ,effectiveTo   
      ,StaffType 
      )  
  
      values  
      (        
       NULL
      ,@ProviderAgencyId    
      ,@FirstName  
      ,@MiddleName  
      ,@LastName  
      ,'1' --by default active  
      ,@Email  
      ,@CellPhone  
      ,@OfficePhone  
      ,@HomePhone
      ,@Fax  
      ,@Address1  
      ,@Address2  
      ,@City  
      ,@State  
      ,@Zip  
      ,@Comments  
      ,@CreatedBy  
      ,@CreationDate  
      ,@effectiveFrom  
      ,@effectiveTo  
      ,@StaffTypeId
      )  
         end
 else if(@StaffTypeId=1)--CA
 begin  
       insert into Staff  
      (   
       CoordinatingAgencyId  
      ,ProviderAgencyId   
      ,FirstName  
      ,MiddleName  
      ,LastName  
      ,IsActive  
      ,Email  
      ,CellPhone  
      ,OfficePhone 
      ,HomePhone  
      ,Fax  
      ,Address1  
      ,Address2  
      ,City  
      ,State 
      ,Zip
      ,Comments 
      ,CreatedBy
      ,CreationDate
      ,StaffType 
      )  
  
      values  
      (        
       @CoordinatingAgencyId   
      ,NULL    
      ,@FirstName  
      ,@MiddleName  
      ,@LastName  
      ,'1' --by default active  
      ,@Email  
      ,@CellPhone  
      ,@OfficePhone  
      ,@HomePhone
      ,@Fax  
      ,@Address1  
      ,@Address2  
      ,@City  
      ,@State  
      ,@Zip  
      ,@Comments  
      ,@CreatedBy  
      ,@CreationDate   
      ,@StaffTypeId
      )  
         end 
    
    
     
  end
