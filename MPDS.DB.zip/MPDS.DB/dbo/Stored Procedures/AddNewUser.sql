﻿CREATE procedure [dbo].[AddNewUser] 
 
@FirstName  varchar (50)
,@MiddleName varchar (15)
,@LastName  varchar (50) 
,@Password  varchar(255)
,@IsActive	 bit 
,@UserTypeId  smallint
,@CoordinatingAgencyId bigint 
,@ProviderAgencyId	 bigint
,@Permissions varchar (100)
,@UserName varchar (100)
,@Email varchar (255)
,@Phone varchar (12)
,@Address1	 varchar (255)
,@Address2 varchar (255)
,@City	 varchar (50)
,@StateId smallint
,@Zip varchar (15)
,@Comments varchar (1000)
,@CreatedBy bigint
,@CreationDate   datetime 
 
   AS
      BEGIN
      INSERT INTO Users   
		( FirstName	  
		,MiddleName	  
		,LastName	 
		,Password 
		,IsActive   
		,UserTypeId  
		,CoordinatingAgencyId   
		,ProviderAgencyId   
		,Permissions        
		,UserName           
		,Email		        
		,Phone	            
		,Address1	        
		,Address2	        
		,City		        
		,StateId		    
		,Zip		        
		,Comments	        
		,CreatedBy	        
		,CreationDate
		,IsPasswordResetRequired 
		,IsDeleted)   

		values
		(
		@FirstName
		,@MiddleName
		,@LastName 
		,@Password
		,@IsActive
		,@UserTypeId
		,@CoordinatingAgencyId 
		,@ProviderAgencyId	 
		,@Permissions
		,@UserName
		,@Email
		,@Phone	  
		,@Address1
		,@Address2
		,@City
		,@StateId
		,@Zip
		,@Comments
		,@CreatedBy
		,@CreationDate
		,1 -- Password Reset Require
		,0 -- Not Deleted
		)    

          end
