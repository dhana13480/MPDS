﻿CREATE procedure [dbo].[DeleteUser]
@Id bigint,
@UpdatedBy bigint,
@UpdationDate datetime
as
begin

UPDATE Users
SET IsDeleted=1,
UpdatedBy=@UpdatedBy,
UpdationDate=@UpdationDate
WHERE Id=@Id

end
