﻿CREATE procedure [dbo].[GetSchoolDistrictDetails]    
  @Id int
  as  
begin 

 Select 
 Id,
 SchoolDistrict,
 Description,
 CountyId 
 from Master_SchoolDistrict where Id=@Id
end
