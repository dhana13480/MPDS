﻿-- exec [dbo].[GetAllActivityDataReportTemplates]
CREATE procedure [dbo].[GetAllActivityDataReportTemplates]
@UserId bigint
as
begin
Select [Id],
[Name]
FROM dbo.ActivityDataReport_Template
Where dbo.ActivityDataReport_Template.UserId=@UserId
Order by Id asc
end
