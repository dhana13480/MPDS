﻿CREATE procedure [dbo].[ActivateDeactivateProviderAgency]  
  @Id bigint,
  @Status bit,
  @UpdatedBy bigint,
  @UpdationDate datetime    
  as  
begin 
 
 Update dbo.ProviderAgency 
 set dbo.ProviderAgency.IsActive=@Status,
 dbo.ProviderAgency.UpdatedBy=@UpdatedBy,
 dbo.ProviderAgency.UpdationDate=@UpdationDate 
 where dbo.ProviderAgency.Id=@Id
   
end
