﻿CREATE procedure [dbo].[GetPermissionsByUserType]--  3  
		@UserTypeId smallint
		as
	   	begin
	     Select    
		 mup.PermissionId
		,mp.Permission
		FROM [Master_UserType_Permission_Mapping] mup inner join
		Master_UserType mu on mu.Id=mup.UserTypeId 
		inner join Master_Permission mp on mp.id=mup.PermissionId  
		where mup.[UserTypeId]=@UserTypeId
		
		
		end
