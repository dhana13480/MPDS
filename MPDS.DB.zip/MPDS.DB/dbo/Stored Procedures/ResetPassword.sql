﻿CREATE  procedure [dbo].[ResetPassword]       
@NewPassword varchar(255), 
@UserName varchar(100),
@UpdationDate datetime 

as 
  begin
  
  
 if((select count(1) from dbo.Users where 
			dbo.Users.UserName=@Username and IsDeleted=0)> 0)
		BEGIN	-- username correct
			If((Select COUNT(1) from dbo.Users Where dbo.Users.UserName=@UserName and dbo.Users.IsActive=1)>0)
			  BEGIN		-- username correct and active    
				update dbo.Users set
					dbo.Users.Password=@NewPassword,
					dbo.Users.IsPasswordResetRequired=1,
					UpdatedBy =-1,--machine generated password(Forgot password)
					UpdationDate=@UpdationDate,
					[HashingAlgorithm] = 'SHA512' -- New default
					where dbo.Users.UserName=@UserName;
				Select 1 as ResponseCode,
				dbo.Users.Id,
				dbo.Users.UserTypeId
				from dbo.Users where dbo.Users.UserName=@UserName
			  END
			ELSE -- username correct but inactive
			  BEGIN
				Select 0 as ResponseCode,							 --INCATIVE USER
				dbo.Users.UserTypeId
				from dbo.Users where dbo.Users.UserName=@UserName  
			  END		  	
	   END
ELSE				
	 BEGIN
		   select -1 as ResponseCode  ---USERNAME NOT VALID OR NOT FOUND
	 END     
        
END   
		--[ResetPassword] 'we12','','email@test.comupnew'
