﻿-- exec GetProviderAgencyDetails 17

 CREATE procedure [dbo].[GetProviderAgencySchoolDistricts]  
  @ProviderAgencyId bigint 
  as  
 begin 
		 Select 
		 dbo.ProviderAgency_SchoolDistrict.SchoolDistrictId,
		 dbo.Master_SchoolDistrict.SchoolDistrict
		  
		  From dbo.ProviderAgency_SchoolDistrict
		 inner join dbo.Master_SchoolDistrict on dbo.ProviderAgency_SchoolDistrict.SchoolDistrictId=Master_SchoolDistrict.Id
		  
		 Where dbo.ProviderAgency_SchoolDistrict.ProviderAgencyId=@ProviderAgencyId
		 order by dbo.Master_SchoolDistrict.SchoolDistrict asc
		 
    
  end
