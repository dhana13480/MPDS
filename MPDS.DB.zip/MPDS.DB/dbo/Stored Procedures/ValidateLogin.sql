﻿-- ValidateLogin 'CA', '11-44-5F-D5-90-25-09-A8-B8-C0-D4-18-71-FF-4B-E8'

 CREATE procedure [dbo].[ValidateLogin]  
 @UserName varchar(100),
 @Password varchar(255)
 
 as
   begin
    
	select 
	
	dbo.Users.Id, 
	dbo.Users.UserTypeId,
	dbo.Users.FirstName, 
	dbo.Users.LastName, 
	dbo.Users.UserName, 	
	dbo.Users.Email, 	
	dbo.Users.IsActive,
	dbo.Users.Permissions,
	P_CA.Name as P_CoordinatingAgency,
	P_CA.IsActive as P_CoordinatingAgencyStatus,
	IsNull(P_CA.Id,0) as P_CoordinatingAgencyId ,
	CA.Name as CoordinatingAgency,
	CA.IsActive as CAStatus,
	IsNull(CA.Id,0) as CoordinatingAgencyId ,
	dbo.ProviderAgency.Name as ProviderAgency,
	dbo.ProviderAgency.IsActive as PAStatus,
    IsNull(dbo.Users.ProviderAgencyId,0) as ProviderAgencyId,
	dbo.Users.IsPasswordResetRequired 
	from Users 
	left outer join dbo.ProviderAgency on dbo.Users.ProviderAgencyId=dbo.ProviderAgency.Id
	left outer join dbo.CoordinatingAgency P_CA on dbo.ProviderAgency.CoordinatingAgencyId=P_CA.Id
	
	left outer join dbo.CoordinatingAgency CA on dbo.Users.CoordinatingAgencyId=CA.Id

	where dbo.Users.Password=@Password and dbo.Users.UserName=@UserName     
    and dbo.Users.IsDeleted=0
   end
   
   -- ValidateLogin  'we1235','SatyaJit'
