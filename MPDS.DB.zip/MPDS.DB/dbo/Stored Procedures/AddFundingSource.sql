﻿CREATE procedure [dbo].[AddFundingSource]  
  
  @Source varchar(50),
  @Description  varchar(500),  
  @CreationDate datetime,
  @CreatedBy bigint 
  
 AS  
 BEGIN    
 insert into Master_FundingSource
 ( 
  FundingSource,
  Description,
  CreationDate,
  CreatedBy  
 )  
 values(  
  @Source,
  @Description,
  @CreationDate,
  @CreatedBy  
 )  
    
 end
