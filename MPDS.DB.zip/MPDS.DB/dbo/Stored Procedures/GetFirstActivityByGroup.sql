﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>

-- exec GetFirstActivityByGroup 72334444

-- =============================================
CREATE PROCEDURE [dbo].[GetFirstActivityByGroup] 
	-- Add the parameters for the stored procedure here

 @GroupId bigint
 
 AS 
 BEGIN
 
 --[GetPendingActivities] 75,33,15
 
	-- First Activity By flag
	Select 
	A.Id, A.ActivityName, A.RecordNumber
	FROM  dbo.Activity as A
	Left outer join dbo.ActivityGroup AG on (AG.Id= A.GroupId) 
	Where A.IsFirstActivityInGroup = 1 And AG.Id = @GroupId and A.IsDeleted = 0

	-- First Activity By entry	
	Select top 1
	A.Id, A.ActivityName, A.RecordNumber, A.MasterStrategyEmployed
	FROM  dbo.Activity as A
	Left outer join dbo.ActivityGroup AG on (AG.Id= A.GroupId) 
	Where AG.Id = @GroupId and A.IsDeleted = 0
	Order by A.Id ASC
		
END
