﻿CREATE procedure  [dbo].[GetAllStaffMemberCount]  -- 1,3
 	@CoordinatingAgencyId bigint = -1,
	@ProviderAgencyId bigint = -1,
	@SearchByLastName  Varchar(50) = '',
	@SearchByFirstName Varchar(50) = ''
AS 
BEGIN

	DECLARE @statement nvarchar(max); 
	DECLARE @statementParamDec nvarchar(200);

	SET @statement = 'select 
							count(1)  
						from Staff  
						LEFT OUTER JOIN dbo.CoordinatingAgency CA ON CA.Id = Staff.CoordinatingAgencyId
						LEFT OUTER JOIN dbo.ProviderAgency PA ON PA.Id = Staff.ProviderAgencyId

						where Staff.IsDeleted = 0 AND (CA.IsActive = 1 OR PA.IsActive = 1) '  

	IF(@ProviderAgencyId <= 0 AND @CoordinatingAgencyId > 0)
	BEGIN
		SET @statement = @statement + ' AND (Staff.CoordinatingAgencyId = @CoordinatingAgencyId 
											OR Staff.ProviderAgencyId IN (Select dbo.ProviderAgency.Id from dbo.ProviderAgency 
																		where dbo.ProviderAgency.CoordinatingAgencyId = @CoordinatingAgencyId)
											) 
											'
	END
	ELSE IF(@ProviderAgencyId > 0)--PA
	BEGIN 
		SET @statement = @statement  +' and Staff.ProviderAgencyId = @ProviderAgencyId '
	END
	ELSE IF(@CoordinatingAgencyId > 0)--CA
	BEGIN
		SET @statement = @statement  +' and Staff.CoordinatingAgencyId = @CoordinatingAgencyId '
	END 

 
	IF(@SearchByLastName <> '')
	BEGIN
		SET @SearchByLastName = @SearchByLastName + '%';		
		SET @statement = @statement +' AND Staff.LastName like @SearchByLastName'
	END

	IF(@SearchByFirstName <> '')
	BEGIN
		SET @SearchByFirstName = @SearchByFirstName + '%';
		SET @statement = @statement + ' AND Staff.FirstName  like @SearchByFirstName'
	END
 
	SET @statementParamDec = N'@CoordinatingAgencyId bigint, @ProviderAgencyId bigint, @SearchByLastName varchar(50), @SearchByFirstName varchar(50)';  

	EXEC sp_executesql @statement, @statementParamDec, @CoordinatingAgencyId, @ProviderAgencyId, @SearchByLastName, @SearchByFirstName ;

END


