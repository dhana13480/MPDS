﻿CREATE procedure [dbo].[IsCountyInUseByCoordinatingAgency]   
  @Id int
  as  
begin 
 	If(( Select 
		count(1) From dbo.CoordinatingAgency_County where CountyId=@Id)>0)
		  Begin
        Select  1
      End
  Else
      Begin      
        Select 0
      End 
		 
  end
