﻿CREATE procedure [dbo].[GetAllUserCount]    
	 @SearchByType  Smallint =-1,
	 @SearchByLastName  Varchar(50)='',
	 @SearchByUserName Varchar(100)='',
	 @SearchByEmail Varchar(50)='',
	 @CoordinatingAgencyId bigint =-1,
	 @ProviderAgencyId bigint=-1
							
as begin
 	DECLARE @statement nvarchar(max);  
		DECLARE @statementParamDec nvarchar(200);  
 
 set @statement= ' SELECT count(1) from [Users] as U 
		INNER join  Master_UserType MU on (MU.Id=U.[UserTypeId])
		LEFT OUTER JOIN dbo.CoordinatingAgency CA ON CA.Id = U.CoordinatingAgencyId
		
		Where U.IsDeleted =0 AND (CA.Id IS NULL OR CA.IsActive = 1) '

if(@SearchByLastName <> '')
		Begin
		SET @SearchByLastName = @SearchByLastName+'%';		
		set @statement=@statement+' AND U.LastName like @SearchByLastName'
		End

		if(@SearchByUserName <>'')
		Begin
		
		SET @SearchByUserName = @SearchByUserName+'%';
		set @statement=@statement+' AND U.UserName  like @SearchByUserName'
		End


		if(@SearchByEmail<>'')
		Begin
		SET @SearchByEmail = @SearchByEmail+'%';
			set @statement=@statement+' AND U.Email like @SearchByEmail'
		END
		
		if(@SearchByType > 0)
		Begin
			set @statement=@statement+' and U.[UserTypeId]=@SearchByType'
			
			if(@ProviderAgencyId > 0)
			Begin
				set @statement=@statement+' AND U.ProviderAgencyId=@ProviderAgencyId'
			END
			ELSE if(@ProviderAgencyId <= 0 AND @CoordinatingAgencyId > 0)
			Begin
				if(@SearchByType = 4) -- PA
				Begin
					set @statement=@statement+' AND U.ProviderAgencyId IN (Select dbo.ProviderAgency.Id from dbo.ProviderAgency where dbo.ProviderAgency.CoordinatingAgencyId = @CoordinatingAgencyId)'
				End
				Else
				Begin
					set @statement = @statement + ' AND U.CoordinatingAgencyId= @CoordinatingAgencyId'
				End
				
			END
			
		end
		Else -- @SearchByType is not provided
		Begin
			if(@ProviderAgencyId > 0)
			Begin
				set @statement=@statement+' AND U.ProviderAgencyId=@ProviderAgencyId'
			End
			Else if (@ProviderAgencyId <= 0 AND @CoordinatingAgencyId > 0)
			Begin
				set @statement=@statement+' AND
				(U.CoordinatingAgencyId= @CoordinatingAgencyId 
				 OR 
				 U.ProviderAgencyId IN (Select dbo.ProviderAgency.Id from dbo.ProviderAgency where dbo.ProviderAgency.CoordinatingAgencyId = @CoordinatingAgencyId)
				 ) '
			End
			--ELSE
			--Begin
			--	-- No Parameter, show All user	
			--End
		End    
         

       SET @statementParamDec = N'@CoordinatingAgencyId bigint,@ProviderAgencyId bigint,@SearchByType smallint,@SearchByLastName varchar(50),@SearchByUserName varchar(100),@SearchByEmail varchar(50)';  
	   -- print @statement ;

	   EXEC sp_executesql @statement, @statementParamDec, @CoordinatingAgencyId,@ProviderAgencyId,@SearchByType,@SearchByLastName,@SearchByUserName,@SearchByEmail; 
	 
  end
