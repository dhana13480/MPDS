﻿CREATE procedure [dbo].[UpdateSchoolDistrictStatus]
  
  @UpdatedBy   bigint
 ,@Status    bit
 ,@UpdationDate datetime
 ,@Id int
  
 as
 begin 
 
 update Master_SchoolDistrict set  
  UpdatedBy=@UpdatedBy
 ,UpdationDate=@UpdationDate
 ,IsActive=@Status
 where id=@Id
 
  
 end
