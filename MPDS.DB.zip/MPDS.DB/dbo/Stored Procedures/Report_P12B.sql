﻿


-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>

-- exec Report_P12B '02/02/2009','11/19/2013', '', '',''

-- =============================================
CREATE PROCEDURE [dbo].[Report_P12B]
	@StartDate varchar(20),
	@EndDate varchar(20),
	@CoordinatingAgencyIds varchar(max), -- Come in as '#' or '#,#,...'
	@ProviderAgencyIds varchar(max), -- Come in as '#' or '#,#,...'
	@GroupIds varchar(max), -- Come in as '#' or '#,#,...'
	@IsGamblingRelated bit
AS
BEGIN
	SET NOCOUNT ON;

	SET @CoordinatingAgencyIds = ISNULL(@CoordinatingAgencyIds, '')
	SET @ProviderAgencyIds = ISNULL(@ProviderAgencyIds, '')
	SET @GroupIds = ISNULL(@GroupIds, '')

	--Get relevant activities
	CREATE TABLE #FilterActivities
	(
	   Id bigint,
	   GroupId bigint,
	   NewMaleAttendees int,
	   NewFemaleAttendees int,
	   StartDate datetime,
	   EndDate datetime,
	   EstimatePeopleReached int
	)

	Insert Into #FilterActivities
		Select A.Id, 
				A.GroupId,
				A.NewMaleAttendees, 
				A.NewFemaleAttendees, 
				A.StartDate, 
				A.EndDate,
				A.EstimatePeopleReached
			from dbo.[vFilterActivities] A
			LEFT OUTER JOIN dbo.[CoordinatingAgency] CA ON CA.Id = A.CoordinatingAgencyId
			Where A.[ProgramType] = 'Population'
				AND CA.IsActive = 1
				AND (ISNULL(@StartDate,'') = '' OR A.StartDate >= Convert(date, @StartDate))
				AND (ISNULL(@EndDate,'') = '' OR A.StartDate <= Convert(date, @EndDate))
				AND (@CoordinatingAgencyIds = ''
						OR A.CoordinatingAgencyId IN (SELECT * FROM [dbo].[SplitCSVs] (@CoordinatingAgencyIds, ',')))
				AND (@ProviderAgencyIds = ''
					OR A.ProviderAgencyId IN (SELECT * FROM [dbo].[SplitCSVs] (@ProviderAgencyIds, ',')))
				AND (@GroupIds = ''
					OR A.GroupId IN (SELECT * FROM [dbo].[SplitCSVs] (@GroupIds, ',')))
				AND A.[IsGamblingRelated] = @IsGamblingRelated


	DECLARE @reach int = (Select coalesce(SUM(EstimatePeopleReached),0) AS EstimatedReach from #FilterActivities FA)

	--Breakdown by Age
	SELECT  MPAG.[Id],
			MPAG.[Description] AS 'Age Group',
			ISNULL(SUM(APAG.[NoOfAttendees]),0) AS 'Total Attendees'
		INTO #TempResultsAge
		FROM #FilterActivities FA
		LEFT OUTER JOIN dbo.Activity_ParticipantAgeGroup APAG ON APAG.ActivityId = FA.Id
		RIGHT OUTER JOIN dbo.Master_ParticipantAgeGroup MPAG ON MPAG.[Id] = APAG.[ParticipantAgeGroupId]

		GROUP BY MPAG.[Id], MPAG.[Description]
		ORDER BY MPAG.[Id];
		
	(SELECT	 [Age Group], [Total Attendees] FROM #TempResultsAge)
		UNION ALL
	(Select 'Age Not Known', @reach); -- Estimated people reached have unknown ages

	DROP TABLE #TempResultsAge;
	
	--Breakdown by Race
	SELECT  M_Race.Id,
			M_Race.[Description] AS 'Race',
			ISNULL(SUM(A_Race.[NoOfAttendees]),0) AS 'Total Attendees'
		INTO #TempResultsRace 
		FROM #FilterActivities FA
		LEFT OUTER JOIN dbo.Activity_Race A_Race ON A_Race.ActivityId = FA.Id
		RIGHT OUTER JOIN dbo.Master_Race M_Race ON M_Race.[Id] = A_Race.RaceId

		GROUP BY M_Race.[Id], M_Race.[Description]
		ORDER BY M_Race.[Id];

	(Select [Race], [Total Attendees] FROM #TempResultsRace)
		UNION ALL
	(Select 'Race Not Known', @reach) -- Estimated people reached have unknown races

	DROP TABLE #TempResultsRace
	
	--Breakdown by Ethnicity
	SELECT  M_Ethnicity.Id,
			M_Ethnicity.[Description] AS 'Ethnicity',
			ISNULL(SUM(A_Ethnicity.[NoOfAttendees]),0) AS 'Total Attendees'
		INTO #TempResultsEthnicity
		FROM #FilterActivities FA
		LEFT OUTER JOIN dbo.Activity_Ethnicity A_Ethnicity ON A_Ethnicity.ActivityId = FA.Id
		RIGHT OUTER JOIN dbo.Master_Ethnicity M_Ethnicity ON M_Ethnicity.[Id] = A_Ethnicity.EthnicityId

		GROUP BY M_Ethnicity.[Id], M_Ethnicity.[Description]
		ORDER BY M_Ethnicity.[Id];

	(SELECT [Ethnicity], [Total Attendees] FROM #TempResultsEthnicity)
		UNION ALL
	(Select 'Ethnicity Not Known', @reach)-- Estimated people reached have unknown ethnicities

	DROP TABLE #TempResultsEthnicity

	--Breakdown by Gender
	Select coalesce(SUM(NewMaleAttendees),0) AS 'Male',
			coalesce(Sum(NewFemaleAttendees),0) as 'Female',
			@reach as 'GenderNotKnown' -- Estimated people reached have unknown genders
	from #FilterActivities FA
		 
	DROP TABLE #FilterActivities
	
END
