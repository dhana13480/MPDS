﻿-- exec GetCoordinatingAgencyDetails 17

 CREATE procedure [dbo].[GetCoordinatingAgencyOptionalData]  
  @CoordinatingAgencyId bigint 
  as  
 begin 
		 Select 
		 dbo.CoordinatingAgency_OptionalData.OptionalDataId,
		 dbo.Master_GroupOptionalData.FieldName
		 
		 From dbo.CoordinatingAgency_OptionalData
		 inner join dbo.Master_GroupOptionalData on dbo.CoordinatingAgency_OptionalData.OptionalDataId=Master_GroupOptionalData.Id
		  
		 Where dbo.CoordinatingAgency_OptionalData.CoordinatingAgencyId=@CoordinatingAgencyId
		 order by dbo.Master_GroupOptionalData.FieldName asc
		 
    
  end
