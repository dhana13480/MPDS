﻿




-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>

-- exec Report_PESR '2012/10/01','2013/09/30', '16', ''

-- =============================================
CREATE PROCEDURE [dbo].[Report_PESR]
	@StartDate varchar(20),
	@EndDate varchar(20),
	@CoordinatingAgencyIds varchar(max), -- Come in as '#' or '#,#,...'
	@ProviderAgencyIds varchar(max), -- Come in as '#' or '#,#,...'
	@FundingSourceIds varchar(max),
	@IsGamblingRelated bit
AS
BEGIN
	SET NOCOUNT ON;
	/********************************
		Setup Tables and Variables
	*********************************/
	
	SET @CoordinatingAgencyIds = ISNULL(@CoordinatingAgencyIds, '')
	SET @ProviderAgencyIds = ISNULL(@ProviderAgencyIds, '')
	SET @FundingSourceIds = ISNULL(@FundingSourceIds, '-1')

	CREATE TABLE #FilterActivities
	(
		Id bigint,
		PAId bigint,
		PAName varchar(200),
		GroupId bigint,
		NewMaleAttendees int,
		NewFemaleAttendees int,
		StartDate datetime,
		EndDate datetime,
		MasterStrategyEmployed int,
		EBPServiceType int,
		InterventionTypeId int,
		InterventionType varchar(500),
		IsYATRelated bit,
		ProgramTypeId int,
		StrategyCategoryId int,
		StrategyCategory varchar(500),
		[FundingSource] int null
	)

	INSERT INTO #FilterActivities
		SELECT  FA.Id, 
				FA.ProviderAgencyId AS [PAId], 
				FA.ProviderAgency AS [PAName], 
				FA.GroupId,
				FA.NewMaleAttendees, 
				FA.NewFemaleAttendees, 
				FA.StartDate, 
				FA.EndDate, 
				FA.StrategyId, 
				FA.EBPServiceTypeId,
				FA.InterventionTypeId,
				FA.InterventionType,
				FA.IsYATRelated,
				FA.ProgramTypeId,
				FA.StrategyCategoryId,
				FA.StrategyCategory,
				AG.[FundingSource]
		from vFilterActivities FA
		LEFT OUTER JOIN dbo.[CoordinatingAgency] CA ON CA.Id = FA.CoordinatingAgencyId
		LEFT OUTER JOIN [dbo].[ActivityGroup] AG ON AG.[Id] = FA.[GroupId]
		Where CA.IsActive = 1
			AND (ISNULL(@StartDate,'') = '' OR FA.StartDate >= Convert(date, @StartDate))
			AND (ISNULL(@EndDate,'') = '' OR FA.StartDate <= Convert(date, @EndDate))
			AND (@CoordinatingAgencyIds = '' OR FA.CoordinatingAgencyId IN (SELECT * FROM [dbo].[SplitCSVs] (@CoordinatingAgencyIds, ',')))
			AND (@ProviderAgencyIds = '' OR FA.ProviderAgencyId IN (SELECT * FROM [dbo].[SplitCSVs] (@ProviderAgencyIds, ',')))
			AND (@FundingSourceIds = '-1' OR AG.[FundingSource] IN (SELECT Item1 FROM [dbo].[SplitCSVs](@FundingSourceIds, ',')))
			AND AG.[IsGamblingRelated] = @IsGamblingRelated;

	/********************************
			Report Query
	*********************************/

	WITH TableWithoutStaff AS(

		-- Get GroupCount and NewAttendees
		Select  FA.PAId AS [ProviderAgencyId], 
				FA.PAName AS [ProviderAgency], 

				CASE 
					WHEN FA.IsYATRelated = 0 THEN FA.StrategyCategoryId
					ELSE 0 END AS [StrategyId],

				CASE 
					WHEN FA.IsYATRelated = 0 THEN FA.StrategyCategory
					ELSE 'Section 1926 - Tobacco (If ''''Tobacco Related'''' checked)' END AS [Strategy],

				FA.InterventionTypeId,
				FA.InterventionType, 
				FA.ProgramTypeId AS [ProgramType],
				Count(DISTINCT FA.GroupId) AS [GroupCount],
				ISNULL(SUM (FA.NewMaleAttendees + FA.NewFemaleAttendees), 0) As [NewAttendees]

		from #FilterActivities FA
		WHERE FA.EBPServiceType != 6
		Group By    FA.PAId, 
					FA.PAName, 
					FA.StrategyCategoryId, 
					FA.StrategyCategory, 
					FA.InterventionTypeId, 
					FA.InterventionType, 
					FA.ProgramTypeId,
			        FA.IsYATRelated
	
	), TableWithStaff AS ( 
	
		-- Get Units where EBP is not "none"
		SELECT  FA.PAId AS [ProviderAgencyId], 
				FA.PAName AS [ProviderAgency], 

				CASE 
					WHEN FA.IsYATRelated = 0 THEN FA.StrategyCategoryId
					ELSE 0 END AS [StrategyId],

				CASE 
					WHEN FA.IsYATRelated = 0 THEN FA.StrategyCategory
					ELSE 'Section 1926 - Tobacco (If ''''Tobacco Related'''' checked)' END AS [Strategy],

				FA.InterventionTypeId,
				FA.InterventionType, 
				FA.ProgramTypeId AS [ProgramType],
				Sum(A_S.Units) As [Units] 

			FROM #FilterActivities FA
			LEFT OUTER JOIN Activity_Staff A_S on(A_S.ActivityId = FA.Id)
			WHERE FA.EBPServiceType != 6

			GROUP BY FA.PAId, 
			FA.PAName, 
			FA.StrategyCategoryId, 
			FA.StrategyCategory,
			FA.InterventionTypeId, 
			FA.InterventionType, 
			FA.ProgramTypeId,
			FA.IsYATRelated

	), TableWithStaffAllEBP AS(
		
		-- Get Units regardless of EBP
		SELECT  FA.PAId AS [ProviderAgencyId], 
				FA.PAName AS [ProviderAgency], 

				CASE 
					WHEN FA.IsYATRelated = 0 THEN FA.StrategyCategoryId
					ELSE 0 END AS [StrategyId],

				CASE 
					WHEN FA.IsYATRelated = 0 THEN FA.StrategyCategory
					ELSE 'Section 1926 - Tobacco (If ''''Tobacco Related'''' checked)' END AS [Strategy],

				FA.InterventionTypeId,
				FA.InterventionType, 
				FA.ProgramTypeId AS [ProgramType],
				Sum(A_S.Units) As [Units] 

			FROM #FilterActivities FA
			LEFT OUTER JOIN Activity_Staff A_S on(A_S.ActivityId = FA.Id)

			GROUP BY FA.PAId, 
			FA.PAName, 
			FA.StrategyCategoryId, 
			FA.StrategyCategory, 
			FA.InterventionTypeId,
			FA.InterventionType, 
			FA.ProgramTypeId,
			FA.IsYATRelated
	)
			
	SELECT  pivotTable.ProviderAgencyId,
			pivotTable.ProviderAgency,
			pivotTable.StrategyId,
			pivotTable.Strategy,
			pivotTable.InterventionTypeId, 
			pivotTable.InterventionType, 
			pivotTable.GroupCount, 
			coalesce(pivotTable.Units, 0) as Units,
			coalesce(pivotTable.UnitsAllEBP, 0) as UnitsAllEBP,
			coalesce([1], 0) as 'New Attendees (Population)', 
			coalesce([2],0) as 'New Attendees (Individual)' 
		FROM (Select TableWithoutStaff.*, 
					 TableWithStaff.Units, 
					 TableWithStaffAllEBP.Units as UnitsAllEBP
				-- Get GroupCount and NewAttendees
				from TableWithoutStaff
				-- Get Units where EBP is not "none"
				INNER JOIN TableWithStaff ON (TableWithStaff.ProviderAgencyId = TableWithoutStaff.ProviderAgencyId
												AND TableWithStaff.StrategyId = TableWithoutStaff.StrategyId
												AND TableWithStaff.InterventionTypeId = TableWithoutStaff.InterventionTypeId
												AND TableWithStaff.ProgramType = TableWithoutStaff.ProgramType)
				-- Get Units regardless of EBP
				INNER JOIN TableWithStaffAllEBP ON (TableWithStaffAllEBP.ProviderAgencyId = TableWithoutStaff.ProviderAgencyId
													AND TableWithStaffAllEBP.StrategyId = TableWithoutStaff.StrategyId
													AND TableWithStaffAllEBP.InterventionTypeId = TableWithoutStaff.InterventionTypeId
													AND TableWithStaffAllEBP.ProgramType = TableWithoutStaff.ProgramType)
	) filterTable
	pivot (Sum(filterTable.NewAttendees) for filterTable.ProgramType in ([1],[2])) as pivotTable 
	
	ORDER BY pivotTable.ProviderAgency, pivotTable.InterventionTypeId

	DROP Table #FilterActivities
	
END
