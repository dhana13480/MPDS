﻿-- exec GetServicePopulation 1,1,1

 CREATE procedure [dbo].[GetServicePopulation]
 
as
 begin 
 
 Select dbo.Master_ServicePopulation.Id,
  dbo.Master_ServicePopulation.ServicePopulation,
  dbo.Master_ServicePopulation.ServicePopulation
   
  from dbo.Master_ServicePopulation
 
  
 end
