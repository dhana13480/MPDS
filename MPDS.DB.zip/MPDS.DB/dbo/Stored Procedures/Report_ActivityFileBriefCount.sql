﻿-- =============================================
-- Author:      <Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>

-- exec Report_ActivityFileBrief '','',15, '',''

-- =============================================
CREATE procedure [dbo].[Report_ActivityFileBriefCount]
	@StartDate varchar(20),
	@EndDate varchar(20),
	@CoordinatingAgencyIds varchar(max),
	@ProviderAgencyIds varchar(max),
	@GroupIds varchar(max),
	@IsGamblingRelated bit = NULL
AS
BEGIN
	SET NOCOUNT ON;

	Select 
			Count (1)
		from dbo.Activity A

		Inner Join dbo.ActivityGroup AG on (A.GroupId = AG.Id)
		Inner Join dbo.ProviderAgency As PA on(AG.ProviderAgencyId = PA.Id)
		Inner Join dbo.CoordinatingAgency As CA on(CA.Id = PA.CoordinatingAgencyId)

		Left Outer Join dbo.Master_GroupType M_GT on (M_GT.Id = AG.GroupType)
		Left Outer Join dbo.Master_FundingSource M_FS on (M_FS.Id = AG.FundingSource)
		Left Outer Join dbo.Master_ServiceDomain M_SD on (M_SD.Id = AG.ServiceDomain)
		Left Outer Join dbo.Master_ProgramType M_PT on (M_PT.Id = AG.ProgramType)
		Left Outer Join dbo.Master_EBPServiceType M_EBP on (M_EBP.Id = AG.EBPServiceType)
		Left Outer Join dbo.Master_InterventionType M_IT on (M_IT.Id = AG.InterventionType)
		Left Outer Join dbo.Master_ServicePopulation M_SP on (M_SP.Id = AG.ServicePopulation)
		Left Outer Join dbo.Master_Strategy M_Strategy on (M_Strategy.Id = A.MasterStrategyEmployed)

		Where A.IsDeleted = 0 AND AG.IsDeleted = 0 AND CA.IsActive = 1
			AND Convert(Date,CONVERT(VARCHAR, A.StartDate, 101))>= Convert(Date,@StartDate)
			AND Convert(Date,CONVERT(VARCHAR, A.StartDate, 101))<= Convert(Date,@EndDate)
			AND (@CoordinatingAgencyIds = ''
					OR CA.Id IN (SELECT * FROM [dbo].[SplitCSVs] (@CoordinatingAgencyIds, ',')))
			AND (@ProviderAgencyIds = ''
				OR PA.Id IN (SELECT * FROM [dbo].[SplitCSVs] (@ProviderAgencyIds, ',')))
			AND (@GroupIds = ''
				OR A.GroupId IN (SELECT * FROM [dbo].[SplitCSVs] (@GroupIds, ',')))
			AND (@IsGamblingRelated IS NULL OR AG.[IsGamblingRelated] = @IsGamblingRelated)
	
END
