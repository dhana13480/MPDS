﻿-- exec VM_GetServicePopulation 1,1

 CREATE procedure [dbo].[VM_GetServicePopulation]
 
 @GroupTypeId int,
 @ProgramTypeId int,
 @InterventionTypeId int
 
 as
 begin 
 
 Select distinct dbo.ValidationMatrix.ServicePopulation  
  from dbo.ValidationMatrix
  Where dbo.ValidationMatrix.GroupType=@GroupTypeId
  and dbo.ValidationMatrix.ProgramType=@ProgramTypeId
  and dbo.ValidationMatrix.InterventionType=@InterventionTypeId
  
 end
