﻿
-- =============================================
-- Author:      <Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>

-- exec Report_ActivityFileBrief '2011-10-01','2012-12-19',4,136,'', -1,1,1,16

-- =============================================
CREATE PROCEDURE [dbo].[Report_ActivityFileBrief]
	@StartDate varchar(20),
	@EndDate varchar(20),
	@CoordinatingAgencyIds varchar(max),
	@ProviderAgencyIds varchar(max),
	@GroupIds varchar(max),
	@IsGamblingRelated bit = NULL,
	@count INT = 10,
	@pageNumber	INT=1,
	@SortOrder TINYINT=1,
	@SortId TINYINT = 1
AS
BEGIN
	SET NOCOUNT ON;

	CREATE TABLE #FilterActivities
	(
	   Id bigint,
	   PIHP varchar(200),
	   Provider varchar(200),
	   [Group] varchar(500),
	   [Group Min Activities] int,
	   [Group Max Activities] int,
	   [GroupNote Text] varchar(1000),
	   [Group-Type] varchar(50),
	   [Funding Source] varchar(50),
	   [Service Domain] varchar(50),
	   [Program Type] varchar(50),
	   [EBP Service Type] varchar(50),
	   [Intervention Type] varchar(50),
	   [Service Population] varchar(70),
	   [YTA Related] bit,
	   [Is Gambling Related] bit,
	   [Activity Name] varchar(MAX),
	   [Primary Strategy] varchar(70),
	   [Activity Start Date] varchar(50),
	   [Activity Start Time] varchar(50),
	   [Activity End Date] varchar(50),
	   [Activity End Time] varchar(50),
	   [Activity Duration] int,
	   [Activity Units] int,
	   [Activity Creation Date] varchar(50),
	   [Row_Number] int
	)

	Insert Into #FilterActivities
		SELECT * FROM (Select *, ROW_NUMBER() OVER (ORDER BY  
											--Ascending Columns
											CASE	WHEN @SortOrder=1 AND @SortId=1 THEN CAST(O.[PIHP] AS varchar(MAX)) END ASC,
											CASE	WHEN @SortOrder=1 AND @SortId=2 THEN CAST(O.Provider AS varchar(MAX)) END ASC,
											CASE	WHEN @SortOrder=1 AND @SortId=3 THEN CAST(O.[Group] AS varchar(MAX)) END ASC,
											CASE	WHEN @SortOrder=1 AND @SortId=4 THEN CAST(O.[Group Min Activities] AS varchar(MAX)) END ASC,
											CASE	WHEN @SortOrder=1 AND @SortId=5 THEN CAST(O.[Group Max Activities] AS varchar(MAX)) END ASC,
											CASE	WHEN @SortOrder=1 AND @SortId=6 THEN CAST(O.[GroupNote Text] AS varchar(MAX)) END ASC,
											CASE	WHEN @SortOrder=1 AND @SortId=7 THEN CAST(O.[Group-Type] AS varchar(MAX)) END ASC,
											CASE	WHEN @SortOrder=1 AND @SortId=8 THEN CAST(O.[Funding Source] AS varchar(MAX)) END ASC,
											CASE	WHEN @SortOrder=1 AND @SortId=9 THEN CAST(O.[Service Domain] AS varchar(MAX)) END ASC,
											CASE	WHEN @SortOrder=1 AND @SortId=10 THEN CAST(O.[Program Type] AS varchar(MAX)) END ASC,
											CASE	WHEN @SortOrder=1 AND @SortId=11 THEN CAST(O.[EBP Service Type] AS varchar(MAX)) END ASC,
											CASE	WHEN @SortOrder=1 AND @SortId=12 THEN CAST(O.[Intervention Type] AS varchar(MAX)) END ASC,
											CASE	WHEN @SortOrder=1 AND @SortId=13 THEN CAST(O.[Service Population] AS varchar(MAX)) END ASC,
											CASE	WHEN @SortOrder=1 AND @SortId=14 THEN CAST(O.[YTA Related] AS varchar(MAX)) END ASC,
											CASE	WHEN @SortOrder=1 AND @SortId=15 THEN CAST(O.[Activity Name] AS varchar(MAX)) END ASC,
											CASE	WHEN @SortOrder=1 AND @SortId=16 THEN CAST(O.[Primary Strategy] AS varchar(MAX)) END ASC,
											CASE	WHEN @SortOrder=1 AND @SortId=17 THEN CAST(O.[Activity Start Date] AS varchar(MAX)) END ASC,
											CASE	WHEN @SortOrder=1 AND @SortId=18 THEN CAST(O.[Activity Start Time] AS varchar(MAX)) END ASC,
											CASE	WHEN @SortOrder=1 AND @SortId=19 THEN CAST(O.[Activity End Date] AS varchar(MAX)) END ASC,
											CASE	WHEN @SortOrder=1 AND @SortId=20 THEN CAST(O.[Activity End Time] AS varchar(MAX)) END ASC,
											CASE	WHEN @SortOrder=1 AND @SortId=21 THEN CAST(O.[Activity Duration] AS varchar(MAX)) END ASC,
											CASE	WHEN @SortOrder=1 AND @SortId=22 THEN CAST(O.[Activity Units] AS varchar(MAX)) END ASC,
											CASE	WHEN @SortOrder=1 AND @SortId=23 THEN CAST(O.[Activity Creation Date] AS varchar(MAX)) END ASC,

											--Descending Columns
											CASE	WHEN @SortOrder=0 AND @SortId=1 THEN CAST(O.[PIHP] AS varchar(MAX)) END DESC,
											CASE	WHEN @SortOrder=0 AND @SortId=2 THEN CAST(O.Provider AS varchar(MAX)) END DESC,
											CASE	WHEN @SortOrder=0 AND @SortId=3 THEN CAST(O.[Group] AS varchar(MAX)) END DESC,
											CASE	WHEN @SortOrder=0 AND @SortId=4 THEN CAST(O.[Group Min Activities] AS varchar(MAX)) END DESC,
											CASE	WHEN @SortOrder=0 AND @SortId=5 THEN CAST(O.[Group Max Activities] AS varchar(MAX)) END DESC,
											CASE	WHEN @SortOrder=0 AND @SortId=6 THEN CAST(O.[GroupNote Text] AS varchar(MAX)) END DESC,
											CASE	WHEN @SortOrder=0 AND @SortId=7 THEN CAST(O.[Group-Type] AS varchar(MAX)) END DESC,
											CASE	WHEN @SortOrder=0 AND @SortId=8 THEN CAST(O.[Funding Source] AS varchar(MAX)) END DESC,
											CASE	WHEN @SortOrder=0 AND @SortId=9 THEN CAST(O.[Service Domain] AS varchar(MAX)) END DESC,
											CASE	WHEN @SortOrder=0 AND @SortId=10 THEN CAST(O.[Program Type] AS varchar(MAX)) END DESC,
											CASE	WHEN @SortOrder=0 AND @SortId=11 THEN CAST(O.[EBP Service Type] AS varchar(MAX)) END DESC,
											CASE	WHEN @SortOrder=0 AND @SortId=12 THEN CAST(O.[Intervention Type] AS varchar(MAX)) END DESC,
											CASE	WHEN @SortOrder=0 AND @SortId=13 THEN CAST(O.[Service Population] AS varchar(MAX)) END DESC,
											CASE	WHEN @SortOrder=0 AND @SortId=14 THEN CAST(O.[YTA Related] AS varchar(MAX)) END DESC,
											CASE	WHEN @SortOrder=0 AND @SortId=15 THEN CAST(O.[Activity Name] AS varchar(MAX)) END DESC,
											CASE	WHEN @SortOrder=0 AND @SortId=16 THEN CAST(O.[Primary Strategy] AS varchar(MAX)) END DESC,
											CASE	WHEN @SortOrder=0 AND @SortId=17 THEN CAST(O.[Activity Start Date] AS varchar(MAX)) END DESC,
											CASE	WHEN @SortOrder=0 AND @SortId=18 THEN CAST(O.[Activity Start Time] AS varchar(MAX)) END DESC,
											CASE	WHEN @SortOrder=0 AND @SortId=19 THEN CAST(O.[Activity End Date] AS varchar(MAX)) END DESC,
											CASE	WHEN @SortOrder=0 AND @SortId=20 THEN CAST(O.[Activity End Time] AS varchar(MAX)) END DESC,
											CASE	WHEN @SortOrder=0 AND @SortId=21 THEN CAST(O.[Activity Duration] AS varchar(MAX)) END DESC,
											CASE	WHEN @SortOrder=0 AND @SortId=22 THEN CAST(O.[Activity Units] AS varchar(MAX)) END DESC,
											CASE	WHEN @SortOrder=0 AND @SortId=23 THEN CAST(O.[Activity Creation Date] AS varchar(MAX)) END DESC
									) AS Row_Numb 
					From (Select A.Id,
								CA.Name as 'PIHP',
								PA.Name as 'Provider',
								AG.Name as 'Group',
								AG.MinActivityCount as 'Group Min Activities',
								AG.MaxActivityCount as 'Group Max Activities',
								AG.Comments as 'GroupNote Text',
								M_GT.GroupType as 'Group-Type',
								M_FS.FundingSource as 'Funding Source',
								M_SD.ServiceDomain as 'Service Domain',
								M_PT.ProgramType as 'Program Type',
								M_EBP.EBPServiceType as 'EBP Service Type',
								M_IT.InterventionType as 'Intervention Type',
								M_SP.Code + ' - ' + M_SP.ServicePopulation as 'Service Population',
								AG.IsYATRelated as 'YTA Related',
								AG.[IsGamblingRelated] AS [Is Gambling Related],

								A.ActivityName + ' #' + Convert(varchar, A.OrderNumber) as 'Activity Name',
								M_Strategy.Code + ' - ' + M_Strategy.Strategy as 'Primary Strategy',

								Convert(Varchar(50),A.StartDate, 110) as 'Activity Start Date',
								RIGHT(CONVERT(VARCHAR, A.StartDate, 100),7) as 'Activity Start Time',

								Convert(Varchar(50),A.EndDate, 110) as 'Activity End Date',
								RIGHT(CONVERT(VARCHAR, A.EndDate, 100),7) as 'Activity End Time',

								DATEDIFF(minute, StartDate, EndDate) as 'Activity Duration',
								(Select dbo.CalculateActivityUnits(DATEDIFF(minute, StartDate, EndDate))) as  'Activity Units',
								Convert(Varchar(50), A.CreationDate, 100) as 'Activity Creation Date'

					from dbo.Activity A
					Inner Join dbo.ActivityGroup AG on (A.GroupId = AG.Id)
					Inner Join dbo.ProviderAgency As PA on(AG.ProviderAgencyId = PA.Id)
					Inner Join dbo.CoordinatingAgency As CA on(CA.Id = PA.CoordinatingAgencyId)

					Left Outer Join dbo.Master_GroupType M_GT on (M_GT.Id = AG.GroupType)
					Left Outer Join dbo.Master_FundingSource M_FS on (M_FS.Id = AG.FundingSource)
					Left Outer Join dbo.Master_ServiceDomain M_SD on (M_SD.Id = AG.ServiceDomain)
					Left Outer Join dbo.Master_ProgramType M_PT on (M_PT.Id = AG.ProgramType)
					Left Outer Join dbo.Master_EBPServiceType M_EBP on (M_EBP.Id = AG.EBPServiceType)
					Left Outer Join dbo.Master_InterventionType M_IT on (M_IT.Id = AG.InterventionType)
					Left Outer Join dbo.Master_ServicePopulation M_SP on (M_SP.Id = AG.ServicePopulation)
					Left Outer Join dbo.Master_Strategy M_Strategy on (M_Strategy.Id = A.MasterStrategyEmployed)

					Where A.IsDeleted = 0 AND AG.IsDeleted = 0 AND CA.IsActive = 1
							AND Convert(Date,CONVERT(VARCHAR, A.StartDate, 101))>= Convert(Date,@StartDate)
							AND Convert(Date,CONVERT(VARCHAR, A.StartDate, 101))<= Convert(Date,@EndDate)
							AND (@CoordinatingAgencyIds = ''
									OR CA.Id IN (SELECT * FROM [dbo].[SplitCSVs] (@CoordinatingAgencyIds, ',')))
							AND (@ProviderAgencyIds = ''
								OR PA.Id IN (SELECT * FROM [dbo].[SplitCSVs] (@ProviderAgencyIds, ',')))
							AND (@GroupIds = ''
								OR A.GroupId IN (SELECT * FROM [dbo].[SplitCSVs] (@GroupIds, ',')))
							AND (@IsGamblingRelated IS NULL OR AG.[IsGamblingRelated] = @IsGamblingRelated)
					) AS O 
			) AS OO WHERE OO.Row_Numb >= (@count * (@pageNumber - 1) + 1)

	if(@count <= 0)
		begin
			SELECT * FROM #FilterActivities
		end
	else
		begin 
			SELECT TOP (@count) * FROM #FilterActivities
		end

	DROP TABLE #FilterActivities

	EXEC Report_ActivityFileBriefCount @StartDate, @EndDate, @CoordinatingAgencyIds, @ProviderAgencyIds, @GroupIds, @IsGamblingRelated
	
END
