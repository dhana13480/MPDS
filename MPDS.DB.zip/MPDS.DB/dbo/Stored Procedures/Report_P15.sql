﻿
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>

-- exec Report_P15 '','', '5', '80'

-- =============================================
CREATE PROCEDURE [dbo].[Report_P15]
	@StartDate varchar(20),
	@EndDate varchar(20),
	@CoordinatingAgencyIds varchar(max), -- Come in as '#' or '#,#,...'
	@ProviderAgencyIds varchar(max), -- Come in as '#' or '#,#,...'
	@IsGamblingRelated bit
AS
BEGIN
	SET NOCOUNT ON;
	
	SET @CoordinatingAgencyIds = ISNULL(@CoordinatingAgencyIds, '')
	SET @ProviderAgencyIds = ISNULL(@ProviderAgencyIds, '')

	Select O_IT.InterventionType, 
			coalesce(OuterTable.GroupCount,0) as GroupCount,
			Coalesce(OuterTable.TotalSpent,0) as TotalSpent 
		from ( Select	FA.InterventionTypeId AS 'Id', 
						FA.InterventionType,
						Count(Distinct FA.GroupId) GroupCount, 
						0 as TotalSpent
					from vFilterActivities FA
					LEFT OUTER JOIN dbo.[CoordinatingAgency] CA ON CA.Id = FA.CoordinatingAgencyId

					Where CA.IsActive = 1
						AND FA.EBPServiceType != '7-None Of The Above'
						AND FA.StartDate >= Convert(Date,@StartDate)
						AND FA.StartDate <= Convert(Date,@EndDate)
						AND (@CoordinatingAgencyIds = ''
								OR FA.CoordinatingAgencyId IN (SELECT * FROM [dbo].[SplitCSVs] (@CoordinatingAgencyIds, ',')))
						AND (@ProviderAgencyIds = ''
							OR FA.ProviderAgencyId IN (SELECT * FROM [dbo].[SplitCSVs] (@ProviderAgencyIds, ',')))
						AND FA.[IsGamblingRelated] = @IsGamblingRelated

					Group By FA.InterventionTypeId, FA.InterventionType
			) OuterTable
			-- For Showing all IT
			RIGHT Outer Join dbo.Master_InterventionType O_IT on(O_IT.Id = OuterTable.Id) 
	
END
