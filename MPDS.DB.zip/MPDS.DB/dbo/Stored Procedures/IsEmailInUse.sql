﻿CREATE procedure [dbo].[IsEmailInUse]
@Email varchar(255)
as
begin
If((Select COUNT(1) from dbo.Users
      where (Email)=@Email AND IsDeleted=0)>0   )
      Begin
        Select  1
      End
  Else
      Begin      
        Select 0
      End   

end
