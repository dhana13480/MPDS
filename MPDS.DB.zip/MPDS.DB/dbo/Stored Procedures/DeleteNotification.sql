﻿CREATE procedure  [dbo].[DeleteNotification]
@NotificationId bigint
as
begin
BEGIN TRY
	BEGIN TRANSACTION
	
	Delete from dbo.Notifications_Attachment 
	Where dbo.Notifications_Attachment.NotificationId=@NotificationId;
	
	Delete from dbo.Notification
	Where dbo.Notification.Id=@NotificationId; 
	
COMMIT TRANSACTION
END TRY
	BEGIN CATCH
		ROLLBACK TRANSACTION
		DECLARE @ErrorMessage NVARCHAR(4000);
    DECLARE @ErrorSeverity INT;
    DECLARE @ErrorState INT;

    SELECT 
        @ErrorMessage = ERROR_MESSAGE(),
        @ErrorSeverity = ERROR_SEVERITY(),
        @ErrorState = ERROR_STATE();

    RAISERROR (@ErrorMessage, -- Message text.
               @ErrorSeverity, -- Severity.
               @ErrorState -- State.
               );  
		
END CATCH	
end
