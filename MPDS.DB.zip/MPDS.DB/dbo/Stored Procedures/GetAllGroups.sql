﻿




-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>

-- exec GetAllGroups -1,'','''',1,15,2,1,5

-- =============================================
CREATE PROCEDURE [dbo].[GetAllGroups] 
	@CoordinatingAgencyId bigint,
	@ProviderAgencyIds varchar(max),
	@Name varchar(500),
	@IsActive bit,
	@count INT = 10,
	@pageNumber	INT=1,
	@SortOrder TINYINT=1,
	@SortId TINYINT = 1,
	@StartDate DATETIME = NULL,
	@EndDate DATETIME = NULL,
	@ProgramNameId bigint = NULL,
	@IsGamblingRelated bit = NULL
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @statement nvarchar(max);
	DECLARE @statementParamDec nvarchar(MAX);	
	DECLARE @SortBy VARCHAR(MAX);
	DECLARE @SortOrd VARCHAR(MAX);
		

	SELECT  @SortBy=CASE
		WHEN  @SortId=1 THEN
		'O.Name'
		WHEN  @SortId=2 THEN
		'O.IsActive'
		WHEN  @SortId=3 THEN
		'O.GroupType'
		WHEN  @SortId=4 THEN
		'O.ProgramType'
		WHEN  @SortId=5 THEN
		'O.ActivityCount'
		END
	
		SELECT @SortOrd=CASE
		WHEN @SortOrder=1 THEN
		'ASC'
		WHEN @SortOrder=0 THEN
		'DESC'
		END;

	if(@count<0)
		begin
			set @statement='SELECT * FROM ('
		end
	else
		begin 
			set @statement='SELECT TOP '+ CONVERT(VARCHAR, @Count) + ' * FROM ('
		end
	
	set @statement=@statement+'
			Select *, ROW_NUMBER() OVER (ORDER BY '+@SortBy+' '+@SortOrd+') AS Row_Numb From
			(
			Select AG.Id,
					AG.Name,
					AG.IsActive,
					M_GT.GroupType,
					M_PT.ProgramType,
					PA.IsActive as ProviderAgencyStatus,
					CA.IsActive as CoordinatingAgencyStatus,
					(Select Count(1) from dbo.Activity where dbo.Activity.GroupId = AG.Id and dbo.Activity.IsDeleted = 0) as ActivityCount,
					CASE 
						WHEN AG.[ProgramNameId] = -2 THEN AG.[OtherProgramName] 
						ELSE MPN.[Name] END AS [ProgramName],
					AG.CoordinatingAgencyId as [CoordinatingAgencyId],
					AG.ProviderAgencyId as [ProviderAgencyId],
					AG.ProgramNameId
				from dbo.ActivityGroup AS AG
				left outer Join dbo.Master_GroupType AS M_GT ON (AG.GroupType=M_GT.Id)
				left outer Join dbo.Master_ProgramType AS M_PT ON (AG.ProgramType=M_PT.Id)
				left outer Join dbo.ProviderAgency as PA on (AG.ProviderAgencyId=PA.Id)
				left outer Join dbo.CoordinatingAgency as CA on (PA.CoordinatingAgencyId=CA.Id)
				LEFT OUTER JOIN [dbo].[Master_ProgramName] MPN ON MPN.[Id] = AG.[ProgramNameId]
			
				Where AG.IsDeleted = 0 '
		
			If(@Name<>'')
			begin
			SET @Name = @Name+'%';		
			set @statement=@statement+' and AG.Name like @Name'
			end
		
			If(@IsActive IS NOT NULL)
			begin
			set @statement=@statement+' and AG.IsActive = @IsActive'
			end	
		
			If(@ProviderAgencyIds<>'')
			begin
			set @statement=@statement+' and AG.ProviderAgencyId IN ('+@ProviderAgencyIds+')'
			end	
		
			If(@CoordinatingAgencyId>0)
			begin
		
			set @statement=@statement+' and PA.CoordinatingAgencyId = @CoordinatingAgencyId'
			end		

			IF(@ProgramNameId IS NOT NULL)
			BEGIN
				SET @statement = @statement + ' and AG.[ProgramNameId] = @ProgramNameId';
			END

			IF(@IsGamblingRelated IS NOT NULL)
			BEGIN
				SET @statement = @statement + ' and (@IsGamblingRelated IS NULL OR AG.[IsGamblingRelated] = @IsGamblingRelated)';
			END
		
			--Filter deactivated groups by Start/End Date when possible
			If(@StartDate IS NOT NULL AND @EndDate IS NOT NULL)
			begin
				set @statement=@statement+' and (AG.IsActive = 1 OR (AG.DeactivationDate >= @StartDate AND AG.DeactivationDate <= @EndDate))'
			end		
			ELSE If(@StartDate IS NOT NULL)
			begin
				set @statement=@statement+' and (AG.IsActive = 1 OR AG.DeactivationDate >= @StartDate)'
			end		
			ELSE If(@EndDate IS NOT NULL)
			begin
				set @statement=@statement+' and (AG.IsActive = 1 OR AG.DeactivationDate <= @EndDate)'
			end	
		
			set @statement=@statement+')
		
			AS O )
		
			AS OO WHERE OO.Row_Numb >= (@count * (@pageNumber - 1) + 1)'

		SET @statementParamDec = N'@count INT,
		@pageNumber INT,
		@CoordinatingAgencyId bigint,
		@Name varchar(500),
		@ProviderAgencyIds varchar(max),
		@IsActive Bit,
		@StartDate DATETIME,
		@EndDate DATETIME,
		@ProgramNameId bigint,
		@IsGamblingRelated bit';
		
		EXEC sp_executesql @statement, @statementParamDec,
		@count,
		@pageNumber,
		@CoordinatingAgencyId,
		@Name,
		@ProviderAgencyIds,
		@IsActive,
		@StartDate,
		@EndDate, 
		@ProgramNameId,
		@IsGamblingRelated;

		--Print @statement
		EXEC GetAllGroupsCount @CoordinatingAgencyId, @Name, @ProviderAgencyIds, @IsActive

END



