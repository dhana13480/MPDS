﻿

-- =============================================
-- Author:      <Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>

-- exec Report_ActivityFile '1011/03/03','2012/12/12','2', '','', 0, 16

-- =============================================
CREATE PROCEDURE [dbo].[Report_ActivityFile]
	@StartDate varchar(20),
	@EndDate varchar(20),
	@CoordinatingAgencyIds varchar(max),
	@ProviderAgencyIds varchar(max),
	@GroupIds varchar(max),
	@IsGamblingRelated bit = NULL,
	@SortOrder TINYINT=1,
	@SortId TINYINT = 1
AS
BEGIN

	SET NOCOUNT ON;

-------------------------------------------------------------------------
	--First Result Set
	Select 
			*, 
			ROW_NUMBER() OVER (ORDER BY	  
				--Ascending Columns
				CASE	WHEN @SortOrder=1 AND @SortId=1 THEN CAST(O.PIHP AS varchar(MAX)) END ASC,
				CASE	WHEN @SortOrder=1 AND @SortId=2 THEN CAST(O.Provider AS varchar(MAX)) END ASC,
				CASE	WHEN @SortOrder=1 AND @SortId=3 THEN CAST(O.[Group] AS varchar(MAX)) END ASC,
				CASE	WHEN @SortOrder=1 AND @SortId=4 THEN CAST(O.[Group Min Activities] AS varchar(MAX)) END ASC,
				CASE	WHEN @SortOrder=1 AND @SortId=5 THEN CAST(O.[Group Max Activities] AS varchar(MAX)) END ASC,
				CASE	WHEN @SortOrder=1 AND @SortId=6 THEN CAST(O.[GroupNote Text] AS varchar(MAX))  END ASC,
				CASE	WHEN @SortOrder=1 AND @SortId=7 THEN CAST(O.[Group-Type] AS varchar(MAX)) END ASC,
				CASE	WHEN @SortOrder=1 AND @SortId=8 THEN CAST(O.[Funding Source] AS varchar(MAX)) END ASC,
				CASE	WHEN @SortOrder=1 AND @SortId=9 THEN CAST(O.[Service Domain] AS varchar(MAX)) END ASC,
				CASE	WHEN @SortOrder=1 AND @SortId=10 THEN CAST(O.[Program Type] AS varchar(MAX)) END ASC,
				CASE	WHEN @SortOrder=1 AND @SortId=11 THEN CAST(O.[EBP Service Type] AS varchar(MAX)) END ASC,
				CASE	WHEN @SortOrder=1 AND @SortId=12 THEN CAST(O.[Intervention Type] AS varchar(MAX)) END ASC,
				CASE	WHEN @SortOrder=1 AND @SortId=13 THEN CAST(O.[Service Population] AS varchar(MAX))  END ASC,
				CASE	WHEN @SortOrder=1 AND @SortId=14 THEN CAST(O.[YTA Related] AS varchar(MAX)) END ASC,
				CASE	WHEN @SortOrder=1 AND @SortId=15 THEN CAST(O.[Activity Name] AS varchar(MAX)) END ASC,
				CASE	WHEN @SortOrder=1 AND @SortId=16 THEN CAST(O.[Primary Strategy] AS varchar(MAX)) END ASC,
				CASE	WHEN @SortOrder=1 AND @SortId=17 THEN CAST([Activity Start Date] AS varchar(MAX)) END ASC,
				CASE	WHEN @SortOrder=1 AND @SortId=18 THEN CAST([Activity Start Time] AS varchar(MAX)) END ASC,
				CASE	WHEN @SortOrder=1 AND @SortId=19 THEN CAST([Activity End Date] AS varchar(MAX)) END ASC,
				CASE	WHEN @SortOrder=1 AND @SortId=20 THEN CAST([Activity End Time] AS varchar(MAX)) END ASC,
				CASE	WHEN @SortOrder=1 AND @SortId=21 THEN CAST(O.[Activity Duration] AS varchar(MAX)) END ASC,
				CASE	WHEN @SortOrder=1 AND @SortId=22 THEN CAST(O.[Activity Units] AS varchar(MAX)) END ASC,
				CASE	WHEN @SortOrder=1 AND @SortId=23 THEN CAST(O.[Activity Creation Date] AS varchar(MAX)) END ASC,

				--Descending Columns
				CASE	WHEN @SortOrder=0 AND @SortId=1 THEN CAST(O.PIHP AS varchar(MAX)) END DESC,
				CASE	WHEN @SortOrder=0 AND @SortId=2 THEN CAST(O.Provider AS varchar(MAX)) END DESC,
				CASE	WHEN @SortOrder=0 AND @SortId=3 THEN CAST(O.[Group] AS varchar(MAX)) END DESC,
				CASE	WHEN @SortOrder=0 AND @SortId=4 THEN CAST(O.[Group Min Activities] AS varchar(MAX)) END DESC,
				CASE	WHEN @SortOrder=0 AND @SortId=5 THEN CAST(O.[Group Max Activities] AS varchar(MAX))  END DESC,
				CASE	WHEN @SortOrder=0 AND @SortId=6 THEN CAST(O.[GroupNote Text] AS varchar(MAX))  END DESC,
				CASE	WHEN @SortOrder=0 AND @SortId=7 THEN CAST(O.[Group-Type] AS varchar(MAX)) END DESC,
				CASE	WHEN @SortOrder=0 AND @SortId=8 THEN CAST(O.[Funding Source] AS varchar(MAX)) END DESC,
				CASE	WHEN @SortOrder=0 AND @SortId=9 THEN CAST(O.[Service Domain] AS varchar(MAX)) END DESC,
				CASE	WHEN @SortOrder=0 AND @SortId=10 THEN CAST(O.[Program Type] AS varchar(MAX)) END DESC,
				CASE	WHEN @SortOrder=0 AND @SortId=11 THEN CAST(O.[EBP Service Type] AS varchar(MAX)) END DESC,
				CASE	WHEN @SortOrder=0 AND @SortId=12 THEN CAST(O.[Intervention Type] AS varchar(MAX)) END DESC,
				CASE	WHEN @SortOrder=0 AND @SortId=13 THEN CAST(O.[Service Population] AS varchar(MAX))  END DESC,
				CASE	WHEN @SortOrder=0 AND @SortId=14 THEN CAST(O.[YTA Related] AS varchar(MAX)) END DESC,
				CASE	WHEN @SortOrder=0 AND @SortId=15 THEN CAST(O.[Activity Name] AS varchar(MAX)) END DESC,
				CASE	WHEN @SortOrder=0 AND @SortId=16 THEN CAST(O.[Primary Strategy] AS varchar(MAX)) END DESC,
				CASE	WHEN @SortOrder=0 AND @SortId=17 THEN CAST(O.[Activity Start Date] AS varchar(MAX)) END DESC,
				CASE	WHEN @SortOrder=0 AND @SortId=18 THEN CAST(O.[Activity Start Time] AS varchar(MAX)) END DESC,
				CASE	WHEN @SortOrder=0 AND @SortId=19 THEN CAST(O.[Activity End Date] AS varchar(MAX)) END DESC,
				CASE	WHEN @SortOrder=0 AND @SortId=20 THEN CAST(O.[Activity End Time] AS varchar(MAX)) END DESC,
				CASE	WHEN @SortOrder=0 AND @SortId=21 THEN CAST(O.[Activity Duration] AS varchar(MAX)) END DESC,
				CASE	WHEN @SortOrder=0 AND @SortId=22 THEN CAST(O.[Activity Units] AS varchar(MAX)) END DESC,
				CASE	WHEN @SortOrder=0 AND @SortId=23 THEN CAST(O.[Activity Creation Date] AS varchar(MAX)) END DESC							
			) AS Row_Numb 
		From (Select A.Id,
					--Basic:
					CA.Name as 'PIHP',
					PA.Name as 'Provider',

					--Group:
					AG.Name as 'Group',
					CASE WHEN AG.[ProgramNameId] = -2 THEN AG.[OtherProgramName] ELSE MPN.[Name] END AS [Program Name],
					AG.MinActivityCount as 'Group Min Activities',
					AG.MaxActivityCount as 'Group Max Activities',
					AG.Comments as 'GroupNote Text',
					M_GT.GroupType as 'Group-Type',
					M_FS.FundingSource as 'Funding Source',
					M_SD.ServiceDomain as 'Service Domain',
					M_PT.ProgramType as 'Program Type',
					M_EBP.EBPServiceType as 'EBP Service Type',
					M_IT.InterventionType as 'Intervention Type',
					M_SP.Code + ' - ' + M_SP.ServicePopulation as 'Service Population',
					AG.IsYATRelated as 'YTA Related',
					AG.[IsGamblingRelated] AS [Is Gambling Related],
					remaining.[Remaining Incomplete Attendees],

					--Activity:
					A.ActivityName + ' #' + Convert(varchar, A.OrderNumber) as 'Activity Name',
					M_Strategy.Code + ' - ' + M_Strategy.Strategy as 'Primary Strategy',

					Convert(Date, Convert(Varchar(50),A.StartDate, 110)) as 'Activity Start Date',
					RIGHT(CONVERT(VARCHAR, A.StartDate, 100),7) as 'Activity Start Time',

					Convert(Date, Convert(Varchar(50),A.EndDate, 110)) as 'Activity End Date',
					RIGHT(CONVERT(VARCHAR, A.EndDate, 100),7) as 'Activity End Time',

					DATEDIFF(minute, StartDate, EndDate) as 'Activity Duration',
					(Select dbo.CalculateActivityUnits(DATEDIFF(minute, StartDate, EndDate))) as  'Activity Units',

					Convert(Varchar(50), A.CreationDate, 100) as 'Activity Creation Date',
					A.TotalAttendees as 'Total Attendees',
					A.NewMaleAttendees as 'New Male Attendees',
					A.NewFemaleAttendees as 'New Female Attendees',
					(A.NewMaleAttendees + A.NewFemaleAttendees) as 'New Attendees',
					A.AttendeesCompletingGroup as 'Number Completing Event',
					A.EstimatePeopleReached as 'Estimated Number Reached',
					A.RecordNumber as 'Activity Record Number',
					A.IsVerified as 'Activity Verified',
					A.VerifiedOn as 'Activity Verified On',
					U.UserName  as 'Activity Verified By',
					AOD.numberOfOriginalItemsCreated as 'Number Original Items',
					AOD.numberOfBrochuresDistributed as 'Number Brochures',
					AOD.IndirectSpeakingEngagementCount as 'Indirect Speaking Engagement Count',
					AOD.IndirectSpeakingEngagementReach as 'Indirect Speaking Engagement Reach',
					AOD.IsSchoolBasedActivity as 'School Based',
					AOD.LocationZipCode as 'Location Zip Code',
					AOD_SD.SchoolDistrict as 'School District',
					AOD_County.County as 'County',
					AOD_SS.ServiceSetting as 'Service Setting',
					A.Comments as 'Activity Notes',

					RaceJoin.[White] as 'White Attendees', 
					RaceJoin.[Multi-Racial] as 'Multi Racial Attendees', 
					RaceJoin.[Unknown/Other] as 'Unknown Race Attendees',
					RaceJoin.[American Indian/Alaskan Native] as 'Indian Alaskan Attendees', 
					RaceJoin.[African American] as 'African American Attendees',
					RaceJoin.[Asian] as 'Asian Attendees',
					RaceJoin.[Hawaiian/Pacific Islander] as 'Hawaiian Attendees',

					AgeJoin.[0 to 4] as 'Age 0-4 Attendees',
					AgeJoin.[5 to 11] as 'Age 5-11 Attendees',
					AgeJoin.[12 to 14] as 'Age 12-14 Attendees',
					AgeJoin.[15 to 17]as 'Age 15-17 Attendees',
					AgeJoin.[18 to 20] as 'Age 18-20 Attendees',
					AgeJoin.[21 to 24] as 'Age 21-24 Attendees',
					AgeJoin.[25 to 44] as 'Age 25-44 Attendees',
					AgeJoin.[45 to 64] as 'Age 45-64 Attendees',
					AgeJoin.[65+] as 'Age 65+ Attendees',

					EthnicityJoin.[Hispanic/Latino] as 'Ethnicity Hispanic Attendees',
					EthnicityJoin.[Arab-American/Caldean] as 'Ethnicity Arab Attendees',
					EthnicityJoin.[Not Listed] as 'Ethnicity Not Listed Attendees'

			from dbo.Activity A
			Inner Join dbo.ActivityGroup AG on (A.GroupId = AG.Id)
			Inner Join dbo.ProviderAgency As PA on(AG.ProviderAgencyId = PA.Id)
			Inner Join dbo.CoordinatingAgency As CA on(CA.Id = PA.CoordinatingAgencyId)

			LEFT OUTER JOIN dbo.[vRemainingIncompleteAttendees] remaining ON remaining.GroupId = AG.Id

			Left Outer Join dbo.Master_GroupType M_GT on (M_GT.Id = AG.GroupType)
			Left Outer Join dbo.Master_FundingSource M_FS on (M_FS.Id = AG.FundingSource)
			Left Outer Join dbo.Master_ServiceDomain M_SD on (M_SD.Id = AG.ServiceDomain)
			Left Outer Join dbo.Master_ProgramType M_PT on (M_PT.Id = AG.ProgramType)
			LEFT OUTER JOIN [dbo].[Master_ProgramName] MPN ON MPN.[Id] = AG.[ProgramNameId]
			Left Outer Join dbo.Master_EBPServiceType M_EBP on (M_EBP.Id = AG.EBPServiceType)
			Left Outer Join dbo.Master_InterventionType M_IT on (M_IT.Id = AG.InterventionType)
			Left Outer Join dbo.Master_ServicePopulation M_SP on (M_SP.Id = AG.ServicePopulation)
			Left Outer Join dbo.Master_Strategy M_Strategy on (M_Strategy.Id = A.MasterStrategyEmployed)

			left outer Join dbo.Users U on (A.VerifiedBy = U.Id)

			left outer Join dbo.Activity_OptionalData AOD on (A.ActivityOptionalDataId = AOD.Id)

			left outer Join dbo.Master_SchoolDistrict AOD_SD on (AOD_SD.Id = AOD.SchoolDistrictId)
			left outer Join dbo.Master_ServiceSetting AOD_SS on (AOD_SS.Id = AOD.ServiceSettingId)
			left outer Join dbo.Master_County AOD_County on (AOD_County.Id = AOD.CountyId)

			Left Outer Join [dbo].[vActivityRaceAttendees] RaceJoin on (RaceJoin.ActivityId = A.Id)

			Left Outer join [dbo].[vActivityAgeAttendees] AgeJoin on (AgeJoin.ActivityId = A.Id)

			Left outer join [dbo].[vActivityEthnicityAttendees] EthnicityJoin on (EthnicityJoin.ActivityId = A.Id)

			Where A.IsDeleted = 0 AND AG.IsDeleted = 0 AND CA.IsActive = 1
					AND Convert(Date,CONVERT(VARCHAR, A.StartDate, 101))>= Convert(Date,@StartDate)
					AND Convert(Date,CONVERT(VARCHAR, A.StartDate, 101))<= Convert(Date,@EndDate)
					AND (@CoordinatingAgencyIds = ''
							OR CA.Id IN (SELECT * FROM [dbo].[SplitCSVs] (@CoordinatingAgencyIds, ',')))
					AND (@ProviderAgencyIds = ''
						OR PA.Id IN (SELECT * FROM [dbo].[SplitCSVs] (@ProviderAgencyIds, ',')))
					AND (@GroupIds = ''
						OR A.GroupId IN (SELECT * FROM [dbo].[SplitCSVs] (@GroupIds, ',')))
					AND (@IsGamblingRelated IS NULL OR AG.[IsGamblingRelated] = @IsGamblingRelated)
		) AS O

-------------------------------------------------------------------------
	--Second Result Set
	Select 
			A_S.ActivityId, 
			ROW_NUMBER() over (partition By ActivityId order by ActivityId)as StaffNumber,
			S.FirstName + ' ' + S.LastName as StaffName,
			M_S.Code + ' - ' + M_S.Strategy as 'Strategy', 
			A_S.Units, 
			A_S.OptionalLocalMBO as LocalMBO 
		from dbo.Activity_Staff AS A_S
		Join dbo.Staff S on (A_S.StaffId = S.Id)
		Left Outer Join dbo.Master_Strategy M_S on (A_S.StrategyId = M_S.Id)
		Inner Join dbo.Activity A on (A.Id = A_S.ActivityId)
		Inner Join dbo.ActivityGroup AG on (A.GroupId = AG.Id)
		Inner Join dbo.ProviderAgency As PA on(AG.ProviderAgencyId = PA.Id)
		Inner Join dbo.CoordinatingAgency As CA on(CA.Id = PA.CoordinatingAgencyId)

		Where A.IsDeleted = 0 AND AG.IsDeleted = 0 AND CA.IsActive = 1
			AND Convert(Date,CONVERT(VARCHAR, A.StartDate, 101))>= Convert(Date,@StartDate)
			AND Convert(Date,CONVERT(VARCHAR, A.StartDate, 101))<= Convert(Date,@EndDate)
			AND (@CoordinatingAgencyIds = ''
					OR CA.Id IN (SELECT * FROM [dbo].[SplitCSVs] (@CoordinatingAgencyIds, ',')))
			AND (@ProviderAgencyIds = ''
				OR PA.Id IN (SELECT * FROM [dbo].[SplitCSVs] (@ProviderAgencyIds, ',')))
			AND (@GroupIds = ''
				OR A.GroupId IN (SELECT * FROM [dbo].[SplitCSVs] (@GroupIds, ',')))
	
END
