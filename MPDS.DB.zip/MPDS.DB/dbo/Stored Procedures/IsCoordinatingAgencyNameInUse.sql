﻿CREATE procedure [dbo].[IsCoordinatingAgencyNameInUse]  
  @Name varchar (200) 
  as  
begin 
  If((Select COUNT(1) from dbo.CoordinatingAgency
      where dbo.CoordinatingAgency.Name=@Name)>0)
      Begin
        Select 1
      End
  Else
      Begin      
        Select 0
      End    
end
