﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>

-- exec GetAllNotificationsByUser 2,-1,1,1,5

-- =============================================
CREATE PROCEDURE [dbo].[GetAllNotificationsByUser] 
	-- Add the parameters for the stored procedure here

@UserId bigint,
@count INT = 10,
@pageNumber	INT=1,
@SortOrder TINYINT=1,
@SortId TINYINT = 1

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

DECLARE @statement nvarchar(max);
DECLARE @statementParamDec nvarchar(200);	
DECLARE @SortBy VARCHAR(100);
DECLARE @SortOrd VARCHAR(100);

SELECT  @SortBy=CASE
	WHEN  @SortId=1 THEN
	'O.Title'
	WHEN  @SortId=2 THEN
	'O.Text'
	WHEN  @SortId=3 THEN
	'O.StartDate'
	WHEN  @SortId=4 THEN
	'O.EndDate'
	WHEN  @SortId=5 THEN
	'O.AttachmentCount'
	END
	
	SELECT @SortOrd=CASE
	WHEN @SortOrder=1 THEN
	'ASC'
	WHEN @SortOrder=0 THEN
	'DESC'
	END;

if(@count<0)
	begin
		set @statement='SELECT * FROM ('
	end
else
	begin 
		set @statement='SELECT TOP '+ CONVERT(VARCHAR, @Count) + ' * FROM ('
	end
	
set @statement=@statement+'
		Select *, ROW_NUMBER() OVER (ORDER BY '+@SortBy+' '+@SortOrd+') AS Row_Numb From
		(
		Select dbo.Notification.Id,
		dbo.Notification.Title,
		dbo.Notification.Text,
		dbo.Notification.StartDate,
		dbo.Notification.EndDate,
		(Select Count(1) from dbo.Notifications_Attachment where dbo.Notifications_Attachment.NotificationId = dbo.Notification.Id) as AttachmentCount
		from dbo.Notification
		Where dbo.Notification.CreatedBy=@UserId ' -- created by self
						
		set @statement=@statement+')
		
		AS O )
		
		AS OO WHERE OO.Row_Numb >= (@count * (@pageNumber - 1) + 1)'

	SET @statementParamDec = N'@count INT,@pageNumber INT,@UserId bigint';
	EXEC sp_executesql @statement, @statementParamDec,@count,@pageNumber,@UserId;
	--Print @statement
	EXEC GetAllNotificationsByUserCount @UserId;

END
