﻿CREATE procedure [dbo].[IsGroupNameInUse]  
  @Name varchar (500),
  @ProviderAgencyId bigint 
  as  
begin 
  If((Select COUNT(1) from dbo.ActivityGroup
      where dbo.ActivityGroup.Name=@Name
      and dbo.ActivityGroup.ProviderAgencyId=@ProviderAgencyId
      and dbo.ActivityGroup.IsActive=1
      and dbo.ActivityGroup.IsDeleted=0)>0)
      Begin
        Select  1
      End
  Else
      Begin      
        Select 0
      End    
end
