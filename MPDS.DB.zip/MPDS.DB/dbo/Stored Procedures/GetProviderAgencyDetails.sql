﻿-- exec GetProviderAgencyDetails 17

 CREATE procedure [dbo].[GetProviderAgencyDetails]  
  @Id bigint 
  as  
 begin 
		 Select 
		 dbo.ProviderAgency.Id,
		 dbo.ProviderAgency.Name, 
		 dbo.ProviderAgency.CoordinatingAgencyId, 
		 dbo.CoordinatingAgency.Name as CoordinatingAgency, 
		 dbo.ProviderAgency.License, 
		 dbo.ProviderAgency.DaysAllowedForDataEntry, 
		-- dbo.ProviderAgency.IsActive, 
		 dbo.ProviderAgency.OfficePhone, 
		 dbo.ProviderAgency.Fax, 
		 dbo.ProviderAgency.Address1, 
		 dbo.ProviderAgency.Address2, 
		 dbo.ProviderAgency.City, 
		 dbo.ProviderAgency.State, 
		 dbo.ProviderAgency.Zip, 
		 dbo.ProviderAgency.Comments
		 
		 From dbo.ProviderAgency
		 Inner Join dbo.CoordinatingAgency on (dbo.ProviderAgency.CoordinatingAgencyId=dbo.CoordinatingAgency.Id) 
		 Where dbo.ProviderAgency.Id=@Id;
		 
	
	EXEC dbo.GetProviderAgencyCounties @Id;
	EXEC dbo.GetProviderAgencySchoolDistricts @Id;
	EXEC dbo.GetProviderAgencyOptionalData @Id;
    
  end
