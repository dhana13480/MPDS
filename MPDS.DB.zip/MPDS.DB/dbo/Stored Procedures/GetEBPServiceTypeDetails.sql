﻿CREATE procedure [dbo].[GetEBPServiceTypeDetails]  
  @Id int 
  as  
 begin 
		 Select 
		 dbo.Master_EBPServiceType.Id,
		 dbo.Master_EBPServiceType.EBPServiceType as Type,
		 dbo.Master_EBPServiceType.Description 
		 From dbo.Master_EBPServiceType    
		 Where dbo.Master_EBPServiceType.Id=@Id;
    
  end
