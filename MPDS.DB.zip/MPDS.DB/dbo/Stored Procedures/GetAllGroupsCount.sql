﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>

-- exec GetAllEBPServiceType -1,100,0,1
-- =============================================
CREATE PROCEDURE [dbo].[GetAllGroupsCount] 
	-- Add the parameters for the stored procedure here

@CoordinatingAgencyId bigint=-1,
@Name varchar(500),
@ProviderAgencyIds varchar(max),
@IsActive bit

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

DECLARE @statement nvarchar(max);
DECLARE @statementParamDec nvarchar(200);	
	

set @statement='
		SELECT count(1)
		from dbo.ActivityGroup AG
		left outer Join dbo.ProviderAgency as PA on (AG.ProviderAgencyId=PA.Id)
		Where AG.IsDeleted = 0 '

		If(@Name<>'')
		begin
		SET @Name = @Name+'%';		
		set @statement=@statement+' and AG.Name like @Name'
		end
		
		If(@IsActive is not NULL)
		begin
		set @statement=@statement+' and AG.IsActive=@IsActive'
		end	
		
		If(@ProviderAgencyIds<>'')
		begin
		set @statement=@statement+' and AG.ProviderAgencyId IN ('+@ProviderAgencyIds+')'
		end	
		
		If(@CoordinatingAgencyId>0)
		begin		
		set @statement=@statement+' and PA.CoordinatingAgencyId =@CoordinatingAgencyId'
		end				

SET @statementParamDec = N'@CoordinatingAgencyId bigint,@Name varchar(500), @ProviderAgencyIds varchar(max),@IsActive Bit';

--select @statement
		EXEC sp_executesql @statement,@statementParamDec, @CoordinatingAgencyId,@Name,@ProviderAgencyIds,@IsActive;



END
