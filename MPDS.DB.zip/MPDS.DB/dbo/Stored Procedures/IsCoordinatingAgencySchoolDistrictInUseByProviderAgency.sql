﻿CREATE procedure [dbo].[IsCoordinatingAgencySchoolDistrictInUseByProviderAgency]  
  
  @CoordinatingAgencyId bigint,
  @SchoolDistrictId int 
  as  
begin 
  If((Select COUNT(1)from dbo.ProviderAgency_SchoolDistrict where 
   dbo.ProviderAgency_SchoolDistrict.ProviderAgencyId in (Select dbo.ProviderAgency.Id from 
	dbo.ProviderAgency where CoordinatingAgencyId=@CoordinatingAgencyId)
      and dbo.ProviderAgency_SchoolDistrict.SchoolDistrictId=@SchoolDistrictId)>0)      
      Begin
      Select 1;
      End
Else
     Begin
      Select 0;
      End
end
