﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>

-- exec GetAllActivitiesCount 1,-1,-1,'','','',-1
-- =============================================
CREATE PROCEDURE [dbo].[GetAllActivitiesCount] 
	-- Add the parameters for the stored procedure here

 @GroupId bigint,
 @ProviderAgencyId bigint,
 @CoordinatingAgencyId bigint,
 @CreationDate varchar(30),
 @StartDate varchar(30),
 @EndDate varchar(30),
 @RecordNumber varchar(20),
 @Status varchar(5)
 
 AS 
 BEGIN
 
 --[GetPendingActivities] 75,33,15
 
DECLARE @statement nvarchar(MAX);
DECLARE @statementParamDec nvarchar(MAX);
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

set @statement='SELECT Count(1)
		FROM  [Activity] as A 
		Inner join ActivityGroup AG on (AG.Id=A.GroupId) '
		
		If(@CoordinatingAgencyId > 0 OR @ProviderAgencyId > 0)
		Begin
			Set @statement = @statement + ' Inner join ProviderAgency PA ON (PA.Id=AG.ProviderAgencyId) '
		End
		
		Set @statement = @statement + ' Where A.IsDeleted = 0'
				
		if(@CoordinatingAgencyId > 0)
		Begin
			set @statement = @statement + ' AND PA.CoordinatingAgencyId=@CoordinatingAgencyId '
		End
		
		if(@ProviderAgencyId > 0)
		Begin
			set @statement = @statement + ' and PA.Id=@ProviderAgencyId '
		End
		
		if(@GroupId > 0)
		Begin
			set @statement = @statement + ' and A.GroupId=@GroupId '
		End
		
		if(@RecordNumber <> '')
		Begin
			set @statement = @statement + ' and A.RecordNumber=@RecordNumber '
		End
		
		if(@Status <> '')
		Begin
			if(@Status = '0')
			Begin
				set @statement = @statement + ' and A.IsVerified IS NULL'
			End
			Else If(@Status = '1')
			Begin
				set @statement = @statement + ' and A.IsVerified = 1'
			End
		End
		
		-- Activity StartDate Must lies b/w date range
		if(@StartDate<>'')    
		 Begin    
		  set @statement = @statement + ' AND Convert(Date,CONVERT(VARCHAR, A.StartDate, 101))>= Convert(Date,@StartDate)'      
		 End     
		    
		 if(@EndDate<>'')    
		 Begin    
		  set @statement = @statement + ' AND Convert(Date,CONVERT(VARCHAR, A.StartDate, 101))<= Convert(Date,@EndDate)'      
		 End
		
		if(@CreationDate<>'')    
		 Begin    
		  set @statement = @statement + ' AND Convert(Date,CONVERT(VARCHAR, A.CreationDate, 101))= Convert(Date,@CreationDate)'      
		 End
		
					
		SET @statementParamDec = N'@GroupId bigint, @ProviderAgencyId bigint, @CoordinatingAgencyId bigint, @CreationDate varchar(30), @StartDate varchar(30), @EndDate varchar(30), @RecordNumber varchar(20), @Status varchar(5)';	
    
		-- print  @statement
	   
	   EXEC sp_executesql @statement, @statementParamDec, @GroupId, @ProviderAgencyId, @CoordinatingAgencyId, @CreationDate, @StartDate, @EndDate, @RecordNumber, @Status;
  

END
