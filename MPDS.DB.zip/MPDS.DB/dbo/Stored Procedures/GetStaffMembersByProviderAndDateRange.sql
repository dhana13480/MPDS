﻿-- Exec GetStaffMembersByProviderAndDateRange 160,'11/22/2010','11/23/2012'

CREATE PROCEDURE [dbo].[GetStaffMembersByProviderAndDateRange]
	@AgencyId bigint,
	@StartDate varchar(20),
	@EndDate varchar(20)
AS
BEGIN  

	SET NOCOUNT ON;  

	SELECT 
			S.Id,
			S.FirstName,
			S.MiddleName,
			S.LastName
		from  [Staff] S 
		Where S.ProviderAgencyId = @AgencyId
			AND S.IsActive = 1
			AND S.IsDeleted = 0
			-- Tenure start date is no longer checked, staff members can be added so long as they haven't been end-dated
			--AND Convert(Date,CONVERT(VARCHAR, S.EffectiveFrom, 101)) <= Convert(Date,@StartDate)
			AND Convert(Date,CONVERT(VARCHAR, S.EffectiveTo, 101)) >= Convert(Date,@EndDate)

		Order By S.FirstName, S.MiddleName, S.LastName
 
end
