﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>

-- exec GetAllFundingSource -1,100,0,4
-- =============================================
CREATE PROCEDURE [dbo].[GetAllFundingSource] 
	-- Add the parameters for the stored procedure here
@IsActive bit,
@count INT = 10,
@pageNumber	INT=1,
@SortOrder TINYINT=1,
@SortId TINYINT = 1
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

DECLARE @statement nvarchar(max);
DECLARE @statementParamDec nvarchar(200);	
DECLARE @SortBy VARCHAR(100);
DECLARE @SortOrd VARCHAR(100);
		

SELECT  @SortBy=CASE
	WHEN  @SortId=1 THEN
	'dbo.Master_FundingSource.FundingSource'
	WHEN  @SortId=2 THEN
	'dbo.Master_FundingSource.Description'
	WHEN  @SortId=3 THEN
	'dbo.Master_FundingSource.IsActive'
	
	END
	
	SELECT @SortOrd=CASE
	WHEN @SortOrder=1 THEN
	'ASC'
	WHEN @SortOrder=0 THEN
	'DESC'
	END;

if(@count<0)
	begin
		set @statement='SELECT * FROM ('
	end
else
	begin 
		set @statement='SELECT TOP '+ CONVERT(VARCHAR, @Count) + ' * FROM ('
	end
	
set @statement=@statement+'
		select dbo.Master_FundingSource.Id,
		dbo.Master_FundingSource.FundingSource as Source,
		dbo.Master_FundingSource.Description,
		dbo.Master_FundingSource.IsActive,
		ROW_NUMBER() OVER (ORDER BY '+@SortBy+' '+@SortOrd+') AS Row_Numb 
		from dbo.Master_FundingSource
		where dbo.Master_FundingSource.Id>0 '
		
		If(@IsActive is not NULL)
		begin
		set @statement=@statement+' and dbo.Master_FundingSource.IsActive=@IsActive'
		end	

				
		set @statement=@statement+')
		
		AS O WHERE Row_Numb >= (@count * (@pageNumber - 1) + 1);'

	SET @statementParamDec = N'@count INT,@pageNumber INT,@IsActive bit';
--select @statementParamDec
		EXEC sp_executesql @statement, @statementParamDec,@count,@pageNumber,@IsActive;

   EXEC GetAllFundingSourceCount @IsActive

END
