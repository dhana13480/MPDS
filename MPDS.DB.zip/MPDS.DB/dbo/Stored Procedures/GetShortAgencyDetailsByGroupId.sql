﻿-- exec GetProviderAgencyDetails 17

 CREATE procedure [dbo].[GetShortAgencyDetailsByGroupId]  
  @Id bigint 
  AS  
 BEGIN 
		 Select 
		 CA.Id CoordinatingAgencyId,
		 CA.Name CoordinatingAgency,
	 	 PA.Id ProviderAgencyId,
		 PA.Name ProviderAgency,
		 AG.Name GroupName
		 From dbo.ActivityGroup AG
		 Left outer join dbo.ProviderAgency PA on (PA.Id = AG.ProviderAgencyId)
		 Left outer join dbo.CoordinatingAgency CA on (CA.Id = PA.CoordinatingAgencyId)
		 Where Ag.Id=@Id;
		     
  end
