﻿CREATE procedure [dbo].[UpdateCountyStatus]
  
  @UpdatedBy   bigint
 ,@Status    bit
 ,@UpdationDate datetime
 ,@Id int
  
 as
 begin 
 
 update Master_County set  
  UpdatedBy=@UpdatedBy
 ,UpdationDate=@UpdationDate
 ,IsActive=@Status
 where Id=@Id
 
  
 end
