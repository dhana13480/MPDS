﻿-- =============================================
-- Author:          Max Kruglov
-- Create date: 06/02/2016
-- Description:     Get total new attendees in group overall
-- =============================================
CREATE PROCEDURE [dbo].[GetGroupTotalNewAttendees]
       @Id INT,
       @ActivityIdToExclude INT
AS
BEGIN
       SET NOCOUNT ON;

       DECLARE @TotalNewAttendees INT = 0

       SELECT 
                    @TotalNewAttendees = ISNULL(SUM([NewMaleAttendees] + [NewFemaleAttendees]), 0) - ISNULL(SUM([AttendeesCompletingGroup]), 0)
             FROM [ActivityGroup] AG
             LEFT OUTER JOIN [Activity] A ON A.GroupId = AG.Id

             WHERE AG.Id = @Id
                    AND A.IsDeleted = 0
                    AND A.Id != @ActivityIdToExclude

       SELECT @TotalNewAttendees

       RETURN @TotalNewAttendees
END
