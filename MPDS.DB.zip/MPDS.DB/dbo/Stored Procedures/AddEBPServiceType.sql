﻿CREATE procedure [dbo].[AddEBPServiceType]  
  
  @Type varchar(50),
  @Description  varchar(500),
  @CreationDate datetime,
  @CreatedBy bigint 
  
 AS  
 BEGIN    
 insert into Master_EBPServiceType
 (  
 EBPServiceType,
 Description,
 CreationDate,
 CreatedBy  
 )  
 values(  
  @Type,
  @Description,
  @CreationDate,
  @CreatedBy  
 )  
    
 end
