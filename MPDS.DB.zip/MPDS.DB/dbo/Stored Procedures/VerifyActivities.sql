﻿/****** Script for SelectTopNRows command from SSMS  ******/

CREATE procedure [dbo].[VerifyActivities] 
 @CSVIds varchar(max),
 @VerifiedBy bigint,
 @VerifiedOn datetime,
 @Comments varchar(1000),
 @Status bit
 as 
 
 begin 
 
DECLARE @statementParamDec Nvarchar(250)
DECLARE @statement Nvarchar(max)
	
	SET @statement = 'UPDATE dbo.Activity SET '
	
	if(@Status is null)
	Begin
		SET @statement = @statement + 'IsVerified = NULL, '
	END
	ELSE
	Begin
		SET @statement = @statement + 'IsVerified = 1, '
	END
	
	SET @statement = @statement + 'VerifiedBy=@VerifiedBy,
	VerifiedOn=@VerifiedOn,
	UpdatedBy= @VerifiedBy,
	UpdationDate =@VerifiedOn,
	VerifyComments= VerifyComments + @Comments 
	where  convert(varchar,Id)  in ('+@CSVIds+')'
  		 
     SET @statementParamDec = N'@IdList varchar(max),@VerifiedBy bigint,@VerifiedOn datetime,@Comments varchar(1000)';
  	 EXEC sp_executesql @statement,@statementParamDec,@CSVIds,@VerifiedBy,@VerifiedOn,@Comments;
   
	 
 -- [VerifyActivities]  '''1'',''2''',1,null,null,null,''
 
  end
