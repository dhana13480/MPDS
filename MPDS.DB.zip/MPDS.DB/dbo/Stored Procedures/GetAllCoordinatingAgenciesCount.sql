﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>

-- exec GetAllCoordinatingAgenciesCount 't'
-- =============================================
CREATE PROCEDURE [dbo].[GetAllCoordinatingAgenciesCount] 
	-- Add the parameters for the stored procedure here
@Name varchar(200),
@IsActive bit
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

DECLARE @statement nvarchar(max);
DECLARE @statementParamDec nvarchar(200);	
	

set @statement='
		select count(1)
		from dbo.CoordinatingAgency
		Where dbo.CoordinatingAgency.Id>0 '

		If(@Name<>'')
		begin
		SET @Name = @Name+'%';		
		set @statement=@statement+' and dbo.CoordinatingAgency.Name like @Name'
		end
		
		If(@IsActive is not NULL)
		begin
		set @statement=@statement+' and dbo.CoordinatingAgency.IsActive=@IsActive'
		end	



SET @statementParamDec = N'@Name Varchar(200),@IsActive bit';

--select @statement
		EXEC sp_executesql @statement,@statementParamDec, @Name,@IsActive;



END
