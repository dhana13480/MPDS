﻿-- exec GetNotificationsEligibleForEmailNotification
CREATE procedure [dbo].[GetNotificationsEligibleForEmailNotification]
  as
  SET NOCOUNT ON;
  BEGIN
	   Select dbo.Notification.Id,
	   dbo.Notification.Title,
	   dbo.Notification.TypeId,
	   dbo.Notification.CSVCoordinatingAgencyIds,
	   dbo.Notification.CSVProviderAgencyIds   
	   From dbo.Notification 
	   Where dbo.Notification.IsEmailSent=0
   
  END


