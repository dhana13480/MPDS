﻿-- exec VM_GetInterventionType 1

 CREATE procedure [dbo].[VM_GetInterventionType]
 
 @GroupTypeId int,
 @ProgramTypeId int
 
 as
 begin 
 
 Select distinct dbo.Master_InterventionType.Id,
  dbo.Master_InterventionType.InterventionType,  
  dbo.Master_InterventionType.Description  
  from dbo.ValidationMatrix
  inner Join dbo.Master_InterventionType on dbo.ValidationMatrix.InterventionType=dbo.Master_InterventionType.Id
  Where dbo.ValidationMatrix.GroupType=@GroupTypeId
  and dbo.ValidationMatrix.ProgramType=@ProgramTypeId
  order by dbo.Master_InterventionType.InterventionType
  asc
  
 end
