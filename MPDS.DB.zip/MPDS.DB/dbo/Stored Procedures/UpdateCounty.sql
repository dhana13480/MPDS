﻿CREATE procedure [dbo].[UpdateCounty]
 
  @County      varchar(50)
 ,@Description  varchar(500)
 ,@UpdatedBy   bigint 
 ,@UpdationDate datetime
 ,@Id int
  
 as
 begin 
 
 update Master_County set County=@County
 ,[Description]=@Description
 ,UpdatedBy=@UpdatedBy
 ,UpdationDate=@UpdationDate 
 where Id=@Id
 
  
 end
