﻿


CREATE PROCEDURE [dbo].[UpdateGroup] 

	@Id bigint,
	@Name varchar(500),
	@IsYATRelated bit,
	@IsGamblingRelated bit,
	@MinimumActivityCount int,
	@MaximumActivityCount int,
	@GroupTypeId int,
	@ProgramTypeId int,
	@InterventionTypeId int,
	@ServiceDomainId int,
	@ServicePopulationId int,
	@FundingSourceId int,
	@EBPServiceTypeId int,
	@Comments varchar(1000),
	@EBPCycle int,
	@IntendedPopulationId int,
	@ServiceSettingId int,
	@EBPOtherServiceType varchar(500),
	@UpdatedBy bigint,
	@UpdationDate datetime,
	@MasterStrategyEmployed int,
	@ProgramNameId bigint,
	@OtherProgramName varchar(500)

AS
BEGIN

	SET NOCOUNT ON;

	BEGIN TRY
		BEGIN TRANSACTION

			Declare @OptionalDataId bigint=null;
			Declare @LatestOptionaDataId bigint=null;

			Set @OptionalDataId =(Select dbo.ActivityGroup.GroupOptionalDataId
						from dbo.ActivityGroup where dbo.ActivityGroup.Id=@Id)

			Set @LatestOptionaDataId = @OptionalDataId;

			if(@OptionalDataId is NULL) -- no optional data present
			   BEGIN
					  if(@EBPCycle is NOT NULL
							OR @IntendedPopulationId is NOT NULL
							OR @ServiceSettingId is NOT NULL
							OR @EBPOtherServiceType<>'')
						 BEGIN -- optional data present
		    
							 Insert into dbo.Group_OptionalData
							 (ServicePopulationId,ServiceSettingId,ebpCycle,ebpOtherServiceType)
							 values (@IntendedPopulationId,@ServiceSettingId,@EBPCycle,@EBPOtherServiceType)
			     
							 Set @LatestOptionaDataId = @@IDENTITY;
		    
						 END
   
				END
			ELSE   -- optional data present
				BEGIN    
					 if(@EBPCycle is NOT NULL
							OR @IntendedPopulationId is NOT NULL
							OR @ServiceSettingId is NOT NULL
							OR @EBPOtherServiceType<>'')
						 BEGIN -- optional data present
							Update dbo.Group_OptionalData set						
							ebpCycle=@EBPCycle, 
							ServicePopulationId=@IntendedPopulationId,
							ServiceSettingId=@ServiceSettingId,
							ebpOtherServiceType=@EBPOtherServiceType
							Where dbo.Group_OptionalData.Id=@OptionalDataId;		     
						 END			 
						 -- DO Nothing    
				END
			
			Update dbo.ActivityGroup
				Set Name=@Name,
					IsYATRelated=@IsYATRelated, 
					IsGamblingRelated = @IsGamblingRelated,
					MinActivityCount=@MinimumActivityCount, 
					MaxActivityCount=@MaximumActivityCount, 
					GroupType=@GroupTypeId, 
					ProgramType=@ProgramTypeId, 
					InterventionType=@InterventionTypeId, 
					ServiceDomain=@ServiceDomainId, 
					FundingSource=@FundingSourceId, 
					EBPServiceType=@EBPServiceTypeId, 
					ServicePopulation=@ServicePopulationId, 
					GroupOptionalDataId = @LatestOptionaDataId,
					Comments=@Comments, 
					UpdatedBy=@UpdatedBy, 
					UpdationDate=@UpdationDate,
					MasterStrategyEmployed=@MasterStrategyEmployed,
					ProgramNameId = @ProgramNameId,
					OtherProgramName = @OtherProgramName

				Where dbo.ActivityGroup.Id=@Id
			
			select @Id;

			--Update underlying activities to match Strategy
			UPDATE [dbo].[Activity]
				SET UpdatedBy=@UpdatedBy, 
					UpdationDate=@UpdationDate,
					MasterStrategyEmployed=@MasterStrategyEmployed

				WHERE [dbo].[Activity].[GroupId] = @Id

			--Update Staff Activities to match Strategy
			UPDATE ActS
				SET [StrategyId] = @MasterStrategyEmployed

				FROM [dbo].[Activity_Staff] ActS
				LEFT OUTER JOIN [dbo].[Activity] Act ON Act.[Id] = ActS.[ActivityId]

				WHERE Act.[GroupId] = @Id
	
		COMMIT TRANSACTION
	END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION
			DECLARE @ErrorMessage NVARCHAR(4000);
		DECLARE @ErrorSeverity INT;
		DECLARE @ErrorState INT;

		SELECT 
			@ErrorMessage = ERROR_MESSAGE(),
			@ErrorSeverity = ERROR_SEVERITY(),
			@ErrorState = ERROR_STATE();

		RAISERROR (@ErrorMessage, -- Message text.
				   @ErrorSeverity, -- Severity.
				   @ErrorState -- State.
				   );
	END CATCH
END
