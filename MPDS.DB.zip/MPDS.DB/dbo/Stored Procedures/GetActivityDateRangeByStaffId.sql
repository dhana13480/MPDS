﻿CREATE procedure [dbo].[GetActivityDateRangeByStaffId]  
 @Id bigint,
 @ProviderAgencyId bigint
  as 
 begin
 
  SELECT  
  
  min(A.StartDate) as  StartDate,
  max(A.EndDate) as EndDate from Activity A 
  
  INNER JOIN Activity_Staff A_S on (A_S.ActivityId=A.Id)
  
  INNER JOIN  Staff  S on ( S.Id=A_S.StaffId)
  
  WHERE A_S.StaffId=@Id  and  S.ProviderAgencyId=@ProviderAgencyId   and A.IsDeleted = 0
  
  
 end


