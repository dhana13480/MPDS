﻿CREATE procedure [dbo].[UpdateFundingSource]  
  
  @Id int,
  @Source varchar(50),
  @Description  varchar(500),
  @UpdationDate datetime,
  @UpdatedBy bigint 
  
 AS  
 BEGIN    
 
 Update dbo.Master_FundingSource
  set 
     FundingSource=@Source,
	 Description=@Description,
     UpdationDate=@UpdationDate,
     UpdatedBy=@UpdatedBy
     
     Where dbo.Master_FundingSource.Id=@Id;
    
 end
