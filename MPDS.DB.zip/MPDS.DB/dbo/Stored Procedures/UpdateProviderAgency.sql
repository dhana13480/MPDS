﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- exec CreateUser dsf
-- =============================================
CREATE PROCEDURE [dbo].[UpdateProviderAgency] 
	-- Add the parameters for the stored procedure here
@Id bigint,
@Name varchar(200),
@DaysAllowedForDataEntry int,
@LicenseNumber varchar(50),
@OfficePhone varchar(15),
@Fax varchar(12),
@Address1 varchar(500),
@Address2 varchar(500),
@City varchar(50),
@State smallint,
@Zip varchar(9),
@Comments varchar(1000),
@UpdatedBy bigint,
@UpdationDate datetime,
@CSVCounties varchar(max),
@CSVSchoolDistricts varchar(max),
@CSVOptionalData varchar(max)


AS
BEGIN
	 --SET NOCOUNT ON added to prevent extra result sets from
	 --interfering with SELECT statements.
	SET NOCOUNT ON;

BEGIN TRY
	BEGIN TRANSACTION

			
Update dbo.ProviderAgency

Set
			
Name=@Name,
License=@LicenseNumber,
DaysAllowedForDataEntry=@DaysAllowedForDataEntry, 
OfficePhone=@OfficePhone, 
Fax=@Fax, 
Address1=@Address1, 
Address2=@Address2, 
City=@City, 
State=@State, 
Zip=@Zip, 
Comments=@Comments, 
UpdatedBy=@UpdatedBy, 
UpdationDate=@UpdationDate

Where dbo.ProviderAgency.Id=@Id
	
			
	
		Delete from dbo.ProviderAgency_County where
		dbo.ProviderAgency_County.ProviderAgencyId=@Id;

		Insert into dbo.ProviderAgency_County
		Select @Id,item1 from dbo.SplitCSVs(@CSVCounties,',')
	
	    Delete from dbo.ProviderAgency_SchoolDistrict where
		dbo.ProviderAgency_SchoolDistrict.ProviderAgencyId=@Id;

		Insert into dbo.ProviderAgency_SchoolDistrict
		Select @Id,item1 from dbo.SplitCSVs(@CSVSchoolDistricts,',')
		
		
		Delete from dbo.ProviderAgency_OptionalData where
		dbo.ProviderAgency_OptionalData.ProviderAgencyId=@Id;

		
		Insert into dbo.ProviderAgency_OptionalData
		Select @Id,item1 from dbo.SplitCSVs(@CSVOptionalData,',')
			
	select @Id;	
	
	COMMIT TRANSACTION
END TRY
	BEGIN CATCH
		ROLLBACK TRANSACTION
		DECLARE @ErrorMessage NVARCHAR(4000);
    DECLARE @ErrorSeverity INT;
    DECLARE @ErrorState INT;

    SELECT 
        @ErrorMessage = ERROR_MESSAGE(),
        @ErrorSeverity = ERROR_SEVERITY(),
        @ErrorState = ERROR_STATE();

    RAISERROR (@ErrorMessage, -- Message text.
               @ErrorSeverity, -- Severity.
               @ErrorState -- State.
               );
   
		--Select -1;
	END CATCH
END
