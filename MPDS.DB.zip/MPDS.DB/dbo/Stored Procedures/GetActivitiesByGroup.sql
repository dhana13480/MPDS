﻿
CREATE PROCEDURE [dbo].[GetActivitiesByGroup] 
	@GroupId bigint
AS
BEGIN

	SET NOCOUNT ON;

	SELECT A.[Id]
		  ,A.[uKeyOld]
		  ,A.[ActivityName]
		  ,A.[GroupId]
		  ,A.[StartDate]
		  ,A.[EndDate]
		  ,A.[TotalAttendees]
		  ,A.[NewMaleAttendees]
		  ,A.[NewFemaleAttendees]
		  ,A.[MasterStrategyEmployed]
		  ,A.[EstimatePeopleReached]
		  ,A.[AttendeesCompletingGroup]
		  ,A.[ActivityOptionalDataId]
		  ,A.[IsActive]
		  ,A.[IsDeleted]
		  ,A.[IsTobaccoRelated]
		  ,A.[IsFirstActivityInGroup]
		  ,A.[RecordNumber]
		  ,A.[IsVerified]
		  ,A.[VerifiedOn]
		  ,A.[VerifiedByName]
		  ,A.[VerifiedBy]
		  ,A.[Comments]
		  ,A.[VerifyComments]
		  ,A.[CreatedBy]
		  ,A.[CreationDate]
		  ,A.[UpdatedBy]
		  ,A.[UpdationDate]
		  ,A.[OrderNumber]
	  FROM [dbo].[Activity] A

	  WHERE A.[GroupId] = @GroupId
			AND A.[IsActive] = 1
			AND A.[IsDeleted] = 0
END
