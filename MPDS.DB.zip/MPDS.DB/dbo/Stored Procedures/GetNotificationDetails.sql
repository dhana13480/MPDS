﻿-- exec [dbo].[GetNotificationDetails] 14  
CREATE procedure [dbo].[GetNotificationDetails]    
  @NotificationId bigint
  as  
begin 
 Select 
 Id, 
 TypeId, 
 CSVCoordinatingAgencyIds, 
 CSVProviderAgencyIds,
 Title, 
 Text, 
 StartDate, 
 EndDate
 from
 dbo.Notification
 Where dbo.Notification.Id=@NotificationId
 
 
 EXEC dbo.GetNotificationAttachments @NotificationId
 
end


