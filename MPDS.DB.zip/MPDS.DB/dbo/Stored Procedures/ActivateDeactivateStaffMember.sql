﻿CREATE PROCEDURE [dbo].[ActivateDeactivateStaffMember] 
      @Id bigint,
      @IsActive bit,
      @UpdatedBy bigint,
      @UpdationDate Datetime
       
      as
      begin
      update Staff 
      set IsActive=@IsActive,
      UpdatedBy=@UpdatedBy,
      UpdationDate=@UpdationDate
      where id=@id
END
