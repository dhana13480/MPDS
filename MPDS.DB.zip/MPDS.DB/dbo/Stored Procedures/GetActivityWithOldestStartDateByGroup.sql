﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>

-- exec GetFirstActivityByGroup 7
-- exec GetActivityWithOldestStartDateByGroup 7

-- =============================================
CREATE PROCEDURE [dbo].[GetActivityWithOldestStartDateByGroup] 
	-- Add the parameters for the stored procedure here

 @GroupId bigint
 
 AS 
 BEGIN
 
 --[GetPendingActivities] 75,33,15
 
	Select top (1) min(A.StartDate) as StartDate,
	A.Id, A.ActivityName, A.RecordNumber, A.IsFirstActivityInGroup
	FROM  dbo.Activity as A
	Left outer join dbo.ActivityGroup AG on (AG.Id= A.GroupId) 
	Where AG.Id = @GroupId and A.IsDeleted = 0
	Group By A.Id, A.ActivityName, A.RecordNumber, A.IsFirstActivityInGroup
	Order By StartDate
		
END
