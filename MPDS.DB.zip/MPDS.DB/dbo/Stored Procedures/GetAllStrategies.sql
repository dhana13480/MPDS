﻿--EXEC GetAllStrategies

 CREATE PROCEDURE [dbo].[GetAllStrategies]
 
 as
 begin 
 
 Select dbo.Master_Strategy.Id,
  dbo.Master_Strategy.Code + ' - '+ 
  dbo.Master_Strategy.Strategy as Strategy  
  from dbo.Master_Strategy
  order by dbo.Master_Strategy.DisplayOrder asc
  
 end
