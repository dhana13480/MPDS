﻿
CREATE procedure [dbo].[ToggleProgramNameStatus]  
	@Id int,
	@UpdatedBy bigint,
	@UpdationDate datetime   
AS  
BEGIN
 
	UPDATE [dbo].[Master_ProgramName]
	   SET [UpdatedBy] = @UpdatedBy
		  ,[UpdationDate] = @UpdationDate
		  ,[DeactivatedBy] = @UpdatedBy
		  ,[DeactivatedDate] = CASE WHEN [DeactivatedDate] IS NULL THEN GETDATE() ELSE NULL END
	 WHERE [Id] = @Id

	 SELECT CAST(CASE WHEN [DeactivatedDate] IS NULL THEN 1 ELSE 0 END AS BIT) FROM [dbo].[Master_ProgramName] WHERE [Id] = @Id
END
