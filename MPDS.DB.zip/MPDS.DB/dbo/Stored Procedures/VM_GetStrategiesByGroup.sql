﻿-- exec [VM_GetStrategiesByGroup] 1

CREATE PROCEDURE [dbo].[VM_GetStrategiesByGroup]
 
 @GroupId bigint
 
 AS
 BEGIN 
 
 Declare @StrategyTable as table
  (
   Id int
   )

INSERT INTO @StrategyTable
Select item1 from dbo.SplitCSVs((Select dbo.GetStrategiesByGroupId (@GroupId)),',')

Select MS.Id, MS.Code +' - '+ MS.Strategy as Strategy from dbo.Master_Strategy MS
Inner Join @StrategyTable ST on (ST.Id = MS.Id)
order by MS.DisplayOrder asc
 
 end
