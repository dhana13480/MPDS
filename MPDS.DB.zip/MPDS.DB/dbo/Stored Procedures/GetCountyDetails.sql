﻿CREATE procedure [dbo].[GetCountyDetails]    
  @Id bigint
  as  
begin 
 Select Id,
 County,
 Description 
 from 
 Master_County 
 where Id=@Id
end
