﻿--- 

CREATE procedure [dbo].[DeleteGroup] 
@Id bigint,
@UpdatedBy bigint,
@UpdationDate datetime 

AS
BEGIN

BEGIN TRY
	BEGIN TRANSACTION

UPDATE dbo.ActivityGroup SET 
dbo.ActivityGroup.IsDeleted=1,
dbo.ActivityGroup.UpdatedBy=@UpdatedBy,
dbo.ActivityGroup.UpdationDate=@UpdationDate

WHERE dbo.ActivityGroup.Id=@Id


-- delete all activities under the group

UPDATE dbo.Activity SET 
dbo.Activity.IsDeleted=1,
dbo.Activity.UpdatedBy=@UpdatedBy,
dbo.Activity.UpdationDate=@UpdationDate

Where dbo.Activity.GroupId=@Id;

COMMIT TRANSACTION
END TRY
	BEGIN CATCH
		ROLLBACK TRANSACTION
		DECLARE @ErrorMessage NVARCHAR(4000);
    DECLARE @ErrorSeverity INT;
    DECLARE @ErrorState INT;

    SELECT 
        @ErrorMessage = ERROR_MESSAGE(),
        @ErrorSeverity = ERROR_SEVERITY(),
        @ErrorState = ERROR_STATE();

    RAISERROR (@ErrorMessage, -- Message text.
               @ErrorSeverity, -- Severity.
               @ErrorState -- State.
               );
   
		--Select -1;
	END CATCH

end
