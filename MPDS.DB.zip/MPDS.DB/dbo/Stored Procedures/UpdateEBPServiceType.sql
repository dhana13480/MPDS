﻿CREATE procedure [dbo].[UpdateEBPServiceType]  
  
  @Id int,
  @Type varchar(50),
  @Description  varchar(500),
  @UpdationDate datetime,
  @UpdatedBy bigint 
  
 AS  
 BEGIN    
 
 Update dbo.Master_EBPServiceType
  set 
     EBPServiceType=@Type,
	 Description=@Description,
     UpdationDate=@UpdationDate,
     UpdatedBy=@UpdatedBy
     
     Where dbo.Master_EBPServiceType.Id=@Id;
    
 end
