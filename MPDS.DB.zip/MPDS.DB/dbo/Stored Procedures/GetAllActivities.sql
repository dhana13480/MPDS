﻿
/****** Script for SelectTopNRows command from SSMS  ******/
 
CREATE PROCEDURE [dbo].[GetAllActivities]  
	 @GroupId bigint,
	 @ProviderAgencyId bigint,
	 @CoordinatingAgencyId bigint,
	 @CreationDate varchar(30),
	 @StartDate varchar(30),
	 @EndDate varchar(30),
	 @RecordNumber varchar(20),
	 @Status varchar(5),
	 @count INT = 10,
	 @pageNumber INT=1,
	 @SortOrder TINYINT=1,
	 @SortId TINYINT = 1   
 AS 
 BEGIN
 
	DECLARE @statement nvarchar(MAX);
	DECLARE @statementParamDec nvarchar(MAX);	
	DECLARE @SortBy VARCHAR(100);
	DECLARE @SortOrd VARCHAR(100);
		
    SELECT @SortBy = CASE
					WHEN  @SortId=1 THEN 'A.StartDate'
					WHEN  @SortId=2 THEN 'AG.Name' 
					WHEN  @SortId=3 THEN 'A.ActivityName'
					WHEN  @SortId=4 THEN 'A.EndDate' 
					WHEN  @SortId=5 THEN 'A.RecordNumber' 
					WHEN  @SortId=6 THEN 'A.IsVerified' 
					END
	 
    SELECT @SortOrd = CASE
						WHEN @SortOrder=1 THEN 'ASC'
						WHEN @SortOrder=0 THEN 'DESC'
						END
	
	IF(@count < 0)
		BEGIN
			SET @statement='SELECT * FROM ('
		END
	ELSE
		BEGIN 
			SET @statement='SELECT TOP '+ CONVERT(VARCHAR, @Count) + ' * FROM ('
		END
 
	SET @statement = @statement+'SELECT A.[Id],
		A.[ActivityName],
		A.GroupId,
		AG.Name as [GroupName],
		A.[StartDate],
		A.[EndDate],
		A.[RecordNumber],
		A.[OrderNumber],
		A.[IsVerified],
		A.IsFirstActivityInGroup,
		ROW_NUMBER() OVER (ORDER BY ' + @SortBy + ' ' + @SortOrd + ') AS Row_Numb 
		FROM  [Activity] as A 
		Inner join ActivityGroup AG on (AG.Id=A.GroupId) '
		
	IF(@CoordinatingAgencyId > 0 OR @ProviderAgencyId > 0)
		BEGIN
			SET @statement = @statement + ' Inner join ProviderAgency PA ON (PA.Id=AG.ProviderAgencyId) '
		END
		
	SET @statement = @statement + ' Where A.IsDeleted = 0 '
		
	IF(@CoordinatingAgencyId > 0)
		BEGIN
			set @statement = @statement + ' AND PA.CoordinatingAgencyId=@CoordinatingAgencyId '
		END
		
	IF(@ProviderAgencyId > 0)
		BEGIN
			set @statement = @statement + ' and PA.Id=@ProviderAgencyId '
		END
		
	IF(@GroupId > 0)
		BEGIN
			set @statement = @statement + ' and A.GroupId=@GroupId '
		END
		
	IF(@RecordNumber <> '')
		BEGIN
			set @statement = @statement + ' and A.RecordNumber=@RecordNumber '
		END
		
	IF(@Status <> '')
		BEGIN
			IF(@Status = '0')
				BEGIN
					set @statement = @statement + ' and A.IsVerified IS NULL'
				END
			ELSE IF(@Status = '1')
				BEGIN
					set @statement = @statement + ' and A.IsVerified = 1'
				END
		END
		
	-- Activity StartDate Must lies b/w date range
	IF(@StartDate<>'')    
		BEGIN    
		set @statement = @statement + ' AND Convert(Date,CONVERT(VARCHAR, A.StartDate, 101))>= Convert(Date,@StartDate)'      
		END     
		    
	IF(@EndDate<>'')    
		BEGIN    
		set @statement = @statement + ' AND Convert(Date,CONVERT(VARCHAR, A.StartDate, 101))<= Convert(Date,@EndDate)'      
		END
		
	IF(@CreationDate<>'')    
		BEGIN    
		set @statement = @statement + ' AND Convert(Date,CONVERT(VARCHAR, A.CreationDate, 101)) = Convert(Date,@CreationDate)'      
		END
		
	SET @statement = @statement + ')
		AS O WHERE Row_Numb >= (@count * (@pageNumber - 1) + 1)
		ORDER BY ' + REPLACE(REPLACE(@SortBy, 'A.', ''), 'AG.Name', 'GroupName') + ' ' + @SortOrd + ', Id;'
			
	SET @statementParamDec = N'@count INT, @pageNumber INT, @GroupId bigint, @ProviderAgencyId bigint, @CoordinatingAgencyId bigint, @CreationDate varchar(30), @StartDate varchar(30), @EndDate varchar(30), @RecordNumber varchar(20), @Status varchar(5)'
    
		--print  @statement
	   
	EXEC sp_executesql @statement, @statementParamDec, @count, @pageNumber, @GroupId, @ProviderAgencyId, @CoordinatingAgencyId, @CreationDate, @StartDate, @EndDate, @RecordNumber, @Status;
  
	EXEC GetAllActivitiesCount @GroupId, @ProviderAgencyId, @CoordinatingAgencyId, @CreationDate, @StartDate, @EndDate, @RecordNumber, @Status 

END
