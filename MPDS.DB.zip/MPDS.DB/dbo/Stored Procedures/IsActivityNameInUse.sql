﻿CREATE procedure [dbo].[IsActivityNameInUse]  
  @Name varchar (500),
  @GroupId bigint 
  as  
begin 
  If((Select COUNT(1) from dbo.Activity
	  where ActivityName=@Name
      and GroupId=@GroupId
      and IsDeleted=0)>0)
      Begin
        Select  1
      End
  Else
      Begin      
        Select 0
      End    
end
