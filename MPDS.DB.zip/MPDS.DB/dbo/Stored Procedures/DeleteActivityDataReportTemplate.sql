﻿CREATE procedure [dbo].[DeleteActivityDataReportTemplate]
@TemplateId bigint
as
begin
BEGIN TRY
BEGIN TRANSACTION

Delete from dbo.ActivityDataReport_TemplateDetails
Where dbo.ActivityDataReport_TemplateDetails.TemplateId=@TemplateId;

Delete from dbo.ActivityDataReport_Template
Where dbo.ActivityDataReport_Template.Id=@TemplateId;

COMMIT TRANSACTION
END TRY
BEGIN CATCH
ROLLBACK TRANSACTION
DECLARE @ErrorMessage NVARCHAR(4000);
DECLARE @ErrorSeverity INT;
DECLARE @ErrorState INT;

SELECT
@ErrorMessage = ERROR_MESSAGE(),
@ErrorSeverity = ERROR_SEVERITY(),
@ErrorState = ERROR_STATE();

RAISERROR (@ErrorMessage, -- Message text.
@ErrorSeverity, -- Severity.
@ErrorState -- State.
);

END CATCH
end
