﻿CREATE procedure [dbo].[GetAllNotificationTypes]
  as
  begin
   Select [Id],
      [Type]
  FROM Master_NotificationType
  end
