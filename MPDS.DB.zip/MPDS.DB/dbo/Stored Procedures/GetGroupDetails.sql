﻿



-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>

-- exec GetGroupDetails 3108
-- =============================================
CREATE PROCEDURE [dbo].[GetGroupDetails] 
	-- Add the parameters for the stored procedure here

@Id bigint

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

		SELECT 
		
          dbo.ActivityGroup.Id, 
          dbo.ActivityGroup.ProviderAgencyId, 
          dbo.ProviderAgency.Name as ProviderAgency,
          dbo.CoordinatingAgency.Name as CoordinatorAgency,
          dbo.CoordinatingAgency.Id as CoordinatingAgencyId,
          dbo.ActivityGroup.Name, 
          dbo.ActivityGroup.IsActive, 
          dbo.ActivityGroup.IsYATRelated, 
          dbo.ActivityGroup.IsGamblingRelated, 
          dbo.ActivityGroup.MinActivityCount, 
          dbo.ActivityGroup.MaxActivityCount, 
          dbo.ActivityGroup.GroupType, 
          dbo.ActivityGroup.ProgramType, 
          dbo.ActivityGroup.InterventionType, 
          dbo.ActivityGroup.ServiceDomain, 
          dbo.ActivityGroup.ServiceLocation, 
          dbo.ActivityGroup.FundingSource, 
          dbo.ActivityGroup.EBPServiceType, 
          dbo.ActivityGroup.ServicePopulation, 
          dbo.ActivityGroup.Comments, 
        (Select Count(1) from dbo.Activity where dbo.Activity.GroupId = ActivityGroup.Id AND dbo.Activity.IsDeleted = 0) as ActivityCount,
		
          dbo.ActivityGroup.GroupOptionalDataId,
          dbo.Group_OptionalData.ebpCycle,
          dbo.Group_OptionalData.ServicePopulationId as IntendedPopulationId,
          dbo.Group_OptionalData.ServiceSettingId,
          dbo.Group_OptionalData.ebpOtherServiceType,  
          dbo.ActivityGroup.MasterStrategyEmployed,  
          dbo.ActivityGroup.[ProgramNameId],
		  MPN.[Name] AS [ProgramName],
		  dbo.ActivityGroup.[OtherProgramName]
                   
         From dbo.ActivityGroup
         left outer join dbo.Group_OptionalData on (dbo.ActivityGroup.GroupOptionalDataId=dbo.Group_OptionalData.Id)
         left outer join dbo.ProviderAgency on (dbo.ActivityGroup.ProviderAgencyId=dbo.ProviderAgency.Id)
         left outer join dbo.CoordinatingAgency on (dbo.ProviderAgency.CoordinatingAgencyId=dbo.CoordinatingAgency.Id)
		 LEFT OUTER JOIN [dbo].[Master_ProgramName] MPN ON MPN.[Id] = dbo.ActivityGroup.[ProgramNameId]
         Where dbo.ActivityGroup.Id=@Id;
END
