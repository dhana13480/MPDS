﻿-- exec [VM_GetActivityMatrixByGroupIdAndStrategy] 587, 1

CREATE PROCEDURE [dbo].[VM_GetActivityMatrixByGroupIdAndStrategy]
 
 @GroupId bigint,
 @StrategyId int
 
 AS
 BEGIN 
 
	Declare @GroupType int;
	Declare @ProgramType int;
	Declare @InterventionType int;
	Declare @ServicePopulation int;
 
	Select @GroupType = AG.GroupType,
	@ProgramType = AG.ProgramType,
	@InterventionType =AG.InterventionType,
	@ServicePopulation = AG.ServicePopulation
	from dbo.ActivityGroup AG 
	Where AG.Id = @GroupId;
	

	Select dbo.ValidationMatrix.Id,
	RequireTotalAttendees,
	RequireEstimatedReach,
	AllowTotalOrEstimatedReach,
	AllowTotalAndOrEstimatedReach,
	RequireDemographics
	from dbo.ValidationMatrix	
	where dbo.ValidationMatrix.GroupType=@GroupType
	and dbo.ValidationMatrix.ProgramType=@ProgramType
	and dbo.ValidationMatrix.InterventionType=@InterventionType
	and (',' + dbo.ValidationMatrix.ServicePopulation + ',') like ('%,' + CONVERT(varchar,@ServicePopulation) + ',%')
	and (',' + dbo.ValidationMatrix.Strategies + ',') like ('%,' + CONVERT(varchar,@StrategyId) + ',%')

 
 end
