﻿CREATE procedure [dbo].[GetFundingSourceDetails]  
  @Id int 
  as  
 begin 
		 Select 
		 dbo.Master_FundingSource.Id,
		 dbo.Master_FundingSource.FundingSource as Source,
		 dbo.Master_FundingSource.Description 
		 From dbo.Master_FundingSource    
		 Where dbo.Master_FundingSource.Id=@Id;
    
  end
