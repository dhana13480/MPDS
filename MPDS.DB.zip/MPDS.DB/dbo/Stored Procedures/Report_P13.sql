﻿

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>

-- exec Report_P13 '','', '1', '',''

-- =============================================
CREATE PROCEDURE [dbo].[Report_P13]
	@StartDate varchar(20),
	@EndDate varchar(20),
	@CoordinatingAgencyIds varchar(max), -- Come in as '#' or '#,#,...'
	@ProviderAgencyIds varchar(max), -- Come in as '#' or '#,#,...'
	@GroupIds varchar(max), -- Come in as '#' or '#,#,...'
	@IsGamblingRelated bit
AS
BEGIN
	SET NOCOUNT ON;
	
	SET @CoordinatingAgencyIds = ISNULL(@CoordinatingAgencyIds, '')
	SET @ProviderAgencyIds = ISNULL(@ProviderAgencyIds, '')
	SET @GroupIds = ISNULL(@GroupIds, '')

	Select O_IT.InterventionType, 
			coalesce(OuterTable.Population,0) as 'Population',
			coalesce(OuterTable.Individual,0) as 'Individual' 
		from (select pivotTable.Id, 
					pivotTable.InterventionType, 
					coalesce([1], 0) as 'Population', 
					coalesce([2], 0) as 'Individual' 
				from (Select  IT.InterventionTypeId AS 'Id', 
								IT.InterventionType, 
								IT.ProgramTypeId AS 'ProgramType', 
								SUM (IT.NewMaleAttendees + IT.NewFemaleAttendees) NewAttendee
							from vFilterActivities IT
							LEFT OUTER JOIN dbo.[CoordinatingAgency] CA ON CA.Id = IT.CoordinatingAgencyId

							Where  CA.IsActive = 1
									AND (ISNULL(@StartDate,'') = '' OR IT.StartDate >= Convert(date, @StartDate))
									AND (ISNULL(@EndDate,'') = '' OR IT.StartDate <= Convert(date, @EndDate))
									AND (@CoordinatingAgencyIds = ''
											OR IT.CoordinatingAgencyId IN (SELECT * FROM [dbo].[SplitCSVs] (@CoordinatingAgencyIds, ',')))
									AND (@ProviderAgencyIds = ''
										OR IT.ProviderAgencyId IN (SELECT * FROM [dbo].[SplitCSVs] (@ProviderAgencyIds, ',')))
									AND (@GroupIds = ''
										OR IT.GroupId IN (SELECT * FROM [dbo].[SplitCSVs] (@GroupIds, ',')))
									AND IT.[IsGamblingRelated] = @IsGamblingRelated
			
							Group By IT.InterventionTypeId, IT.InterventionType, IT.ProgramTypeId ) AS filterTable
							pivot (Sum(filterTable.NewAttendee) for filterTable.ProgramType in ([1], [2])) as pivotTable 
		) OuterTable
		-- For Showing all IT
		Right Outer Join dbo.Master_InterventionType O_IT on(O_IT.Id = OuterTable.Id)
	
END
