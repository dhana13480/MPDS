﻿
CREATE procedure [dbo].[IsProgramNameInUse]  
	@Name varchar (50),
	@ExcludeId INT
 AS  
BEGIN 
	SELECT CAST(CASE WHEN EXISTS(SELECT 
										[Id] 
									FROM [dbo].[Master_ProgramName] 
									WHERE [Name] = @Name AND (@ExcludeId IS NULL OR [Id] != @ExcludeId)
								) THEN 1 ELSE 0 END AS BIT)
END
