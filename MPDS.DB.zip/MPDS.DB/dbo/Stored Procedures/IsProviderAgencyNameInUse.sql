﻿CREATE procedure [dbo].[IsProviderAgencyNameInUse]  
  @Name varchar (200), 
  @CoordinatingAgencyId bigint 
  as  
begin 
  If((Select COUNT(1) from dbo.ProviderAgency
      where dbo.ProviderAgency.Name=@Name
      and dbo.ProviderAgency.CoordinatingAgencyId=@CoordinatingAgencyId)>0)
      Begin
        Select 1
      End
  Else
      Begin      
        Select 0
      End    
end
