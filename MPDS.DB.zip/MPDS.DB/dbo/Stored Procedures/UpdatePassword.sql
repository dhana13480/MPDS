﻿CREATE procedure [dbo].[UpdatePassword]     
@newPassword varchar(255),
@oldPassword varchar(255),
@Id varchar(100), 
@UpdationDate datetime 

as 
begin

if((select count(1) from dbo.Users where dbo.Users.Id=@Id and dbo.Users.Password=@oldPassword)> 0)
	begin
		update  dbo.Users set 
		 dbo.Users.Password=@newPassword,
		 dbo.Users.IsPasswordResetRequired=0,
		 UpdatedBy =@Id,--password changed by user himself
		 UpdationDate=@UpdationDate, 
		 [HashingAlgorithm] = 'SHA512' -- New default
		where  dbo.Users.Id=@Id
		select 1
	end
else
	begin
	    select 0
	end
end
