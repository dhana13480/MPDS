﻿

CREATE PROCEDURE [dbo].[AddGroup] 
	@Name varchar(500),
	@ProviderAgencyId bigint,
	@IsYatRelated bit,
	@IsGamblingRelated bit,
	@MinimumActivityCount int,
	@MaximumActivityCount int,
	@GroupTypeId int,
	@ProgramTypeId int,
	@InterventionTypeId int,
	@ServiceDomainId int,
	@ServicePopulationId int,
	@FundingSourceId int,
	@EBPServiceTypeId int,
	@Comments varchar(1000),
	@EBPCycle int,
	@IntendedPopulationId int,
	@ServiceSettingId int,
	@EBPOtherServiceType varchar(500),
	@CreatedBy bigint,
	@CreationDate datetime,
	@MasterStrategyEmployed int,
	@ProgramNameId bigint,
	@OtherProgramName varchar(500)
AS
BEGIN

	SET NOCOUNT ON;

	BEGIN TRY
		BEGIN TRANSACTION
			
		Declare @OptionalDataId bigint=NULL;

	if(@EBPCycle is NOT NULL
	OR @IntendedPopulationId is NOT NULL
	OR @ServiceSettingId is NOT NULL
	OR @EBPOtherServiceType<>'')
	Begin			
			INSERT INTO dbo.Group_OptionalData(
					
			ebpCycle, 
			ServicePopulationId,
			ServiceSettingId,
			ebpOtherServiceType)
			Values
			(
			@EBPCycle, 
			@IntendedPopulationId,
			@ServiceSettingId,
			@EBPOtherServiceType)
					
			set @OptionalDataId=@@Identity

	  END

			Insert into dbo.ActivityGroup(
			ProviderAgencyId, 
			Name, 
			IsYATRelated,
			IsGamblingRelated, 
			MinActivityCount, 
			MaxActivityCount, 
			GroupType, 
			ProgramType, 
			InterventionType, 
			ServiceDomain, 
			FundingSource, 
			EBPServiceType, 
			ServicePopulation, 
			Comments, 
			GroupOptionalDataId, 
			CreatedBy, 
			CreationDate,
			MasterStrategyEmployed,
			ProgramNameId,
			OtherProgramName
			)
		
			Values(
			@ProviderAgencyId, 
			@Name, 
			@IsYATRelated,
			@IsGamblingRelated,
			@MinimumActivityCount, 
			@MaximumActivityCount, 
			@GroupTypeId, 
			@ProgramTypeId, 
			@InterventionTypeId, 
			@ServiceDomainId, 
			@FundingSourceId, 
			@EBPServiceTypeId, 
			@ServicePopulationId, 
			@Comments, 
			@OptionalDataId, 
			@CreatedBy, 
			@CreationDate,
			@MasterStrategyEmployed,
			@ProgramNameId,
			@OtherProgramName
			)
	
		Select @@IDENTITY;
	
		COMMIT TRANSACTION
	END TRY
	BEGIN CATCH
		ROLLBACK TRANSACTION
		DECLARE @ErrorMessage NVARCHAR(4000);
    DECLARE @ErrorSeverity INT;
    DECLARE @ErrorState INT;

    SELECT 
        @ErrorMessage = ERROR_MESSAGE(),
        @ErrorSeverity = ERROR_SEVERITY(),
        @ErrorState = ERROR_STATE();

    RAISERROR (@ErrorMessage, -- Message text.
               @ErrorSeverity, -- Severity.
               @ErrorState -- State.
               );
   
		--Select -1;
	END CATCH
END
