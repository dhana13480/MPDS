﻿CREATE procedure [dbo].[GetAllStaffMembers]      
	@count INT = 10,  
	@pageNumber INT = 1,  
	@SortOrder TINYINT = 1,  
	@SortId TINYINT = 1,  
	@CoordinatingAgencyId  bigint = -1,
	@ProviderAgencyId  bigint = -1,
	@SearchByLastName  Varchar(50) = '',
	@SearchByFirstName Varchar(50) = ''
AS
BEGIN 

	SET NOCOUNT ON;  

	DECLARE @statement nvarchar(max);  
	DECLARE @statementParamDec nvarchar(200);   
	DECLARE @SortBy VARCHAR(100);  
	DECLARE @SortOrd VARCHAR(100);     

	SELECT  @SortBy =
				CASE  
					WHEN  @SortId=1 THEN 'FirstName'  
					WHEN  @SortId=2 THEN 'MiddleName'   
					WHEN  @SortId=3 THEN 'LastName'
					WHEN  @SortId=4 THEN 'Email'   
					WHEN  @SortId=5 THEN 'Staff.OfficePhone'
					WHEN  @SortId=6 THEN 'Staff.StaffType'
					WHEN  @SortId=7 THEN 'Staff.IsActive'
				END  

	SELECT @SortOrd = CASE  
					WHEN @SortOrder=1 THEN 'ASC'  
					WHEN @SortOrder=0 THEN 'DESC'  
				END;   

 
	IF(@count<0)  
	BEGIN  
		set @statement='SELECT * FROM ('  
	END  
	ELSE  
	BEGIN   
		set @statement='SELECT TOP '+ CONVERT(VARCHAR, @Count) + ' * FROM ('  
	END  

	SET @statement = @statement + 
					'select 
							Staff.Id as Id,
							FirstName,
							MiddleName,
							LastName,
							Staff.CoordinatingAgencyId, 
							Staff.ProviderAgencyId,
							Email,
							MS.StaffType,
							Staff.StaffType as StaffTypeId,
							Staff.OfficePhone,
							Staff.IsActive, 
							ROW_NUMBER() OVER (ORDER BY ' + @SortBy + ' ' + @SortOrd + ') AS Row_Numb  
					FROM Staff 
					inner join Master_StaffType MS on MS.Id=Staff.StaffType
					LEFT OUTER JOIN dbo.CoordinatingAgency CA ON CA.Id = Staff.CoordinatingAgencyId
					LEFT OUTER JOIN dbo.ProviderAgency PA ON PA.Id = Staff.ProviderAgencyId
					
					where Staff.IsDeleted = 0 AND (CA.IsActive = 1 OR PA.IsActive = 1) '   
 
	IF(@ProviderAgencyId <= 0 AND @CoordinatingAgencyId > 0)
	BEGIN
		set @statement=@statement + ' AND (Staff.CoordinatingAgencyId = @CoordinatingAgencyId 
											OR Staff.ProviderAgencyId IN (Select 
																		dbo.ProviderAgency.Id 
																		
																		from dbo.ProviderAgency 
																		
																		where dbo.ProviderAgency.CoordinatingAgencyId = @CoordinatingAgencyId
																	) 
										   ) '
	END
	ELSE IF(@ProviderAgencyId > 0)--PA
	BEGIN 
		SET @statement = @statement  +' and Staff.ProviderAgencyId = @ProviderAgencyId '
	END
	ELSE IF(@CoordinatingAgencyId > 0)--CA
	BEGIN
		SET @statement = @statement  +' and Staff.CoordinatingAgencyId = @CoordinatingAgencyId '
	END
 
	IF(@SearchByLastName <> '')
	BEGIN
		SET @SearchByLastName = @SearchByLastName+'%';		
		SET @statement = @statement + ' AND Staff.LastName like @SearchByLastName'
	END

	IF(@SearchByFirstName <>'')
	BEGIN
		SET @SearchByFirstName = @SearchByFirstName + '%';
		SET @statement = @statement + ' AND Staff.FirstName like @SearchByFirstName'
	END

	SET @statement = @statement + ') AS O WHERE Row_Numb >= (@count * (@pageNumber - 1) + 1);' 
	
	SET @statementParamDec = N'@count INT, @pageNumber INT, @CoordinatingAgencyId bigint, @ProviderAgencyId bigint, @SearchByLastName varchar(50), @SearchByFirstName varchar(50)';   

	EXEC sp_executesql @statement, @statementParamDec ,@count, @pageNumber, @CoordinatingAgencyId, @ProviderAgencyId, @SearchByLastName, @SearchByFirstName;
	  
	EXEC GetAllStaffMemberCount  @CoordinatingAgencyId, @ProviderAgencyId, @SearchByLastName, @SearchByFirstName     		  
 
END
 
