﻿CREATE FUNCTION [dbo].[SplitFourCSVs](@String1 varchar(8000), @String2 varchar(8000), @String3 varchar(8000), @String4 varchar(8000), @Delimiter char(1))
returns @temptable TABLE (item1 varchar(8000), item2 varchar(8000), item3 varchar(8000), item4 varchar(8000))
as
begin
declare @idx1 int
declare @idx2 int
declare @idx3 int
declare @idx4 int

declare @slice1 varchar(8000)
declare @slice2 varchar(8000)
declare @slice3 varchar(8000)
declare @slice4 varchar(8000)

select @idx1 = 1
select @idx2 = 1
select @idx3 = 1
select @idx4 = 1
if len(@String1)<1 or @String1 is null return

while @idx1!= 0
begin
set @idx1 = charindex(@Delimiter,@String1)
set @idx2 = charindex(@Delimiter,@String2)
set @idx3 = charindex(@Delimiter,@String3)
set @idx4 = charindex(@Delimiter,@String4)
if @idx1!=0
begin
set @slice1 = left(@String1,@idx1 - 1)
set @slice2 = left(@String2,@idx2 - 1)
set @slice3 = left(@String3,@idx3 - 1)
set @slice4 = left(@String4,@idx4 - 1)
end
else
begin
set @slice1 = @String1
set @slice2 = @String2
set @slice3 = @String3
set @slice4 = @String4
end

if(len(@slice1)>0)
insert into @temptable(Item1,Item2,Item3,Item4) values(@slice1,@slice2,@slice3,@slice4)

set @String1 = right(@String1,len(@String1) - @idx1)
set @String2 = right(@String2,len(@String2) - @idx2)
set @String3 = right(@String3,len(@String3) - @idx3)
set @String4 = right(@String4,len(@String4) - @idx4)
if len(@String1) = 0 break
end
return
end
