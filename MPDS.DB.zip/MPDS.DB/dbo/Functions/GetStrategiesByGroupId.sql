﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
-- Select dbo.GetStrategiesByGroupId (1)

CREATE FUNCTION [dbo].[GetStrategiesByGroupId]
(
	@GroupId bigint
)
RETURNS VARCHAR(max)
AS
BEGIN
	
	Declare @GroupType int;
	Declare @ProgramType int;
	Declare @InterventionType int;
	Declare @ServicePopulation int;
 
	Select @GroupType = AG.GroupType,
	@ProgramType = AG.ProgramType,
	@InterventionType =AG.InterventionType,
	@ServicePopulation = AG.ServicePopulation
	from dbo.ActivityGroup AG 
	Where AG.Id = @GroupId;
	
	Declare @result as varchar(max) = '';
	SET @result=(SELECT SUBSTRING(
				(Select ','+ dbo.ValidationMatrix.Strategies from dbo.ValidationMatrix	
					where dbo.ValidationMatrix.GroupType=@GroupType
					and dbo.ValidationMatrix.ProgramType=@ProgramType
					and dbo.ValidationMatrix.InterventionType=@InterventionType
					and (',' + dbo.ValidationMatrix.ServicePopulation + ',') like ('%,' + CONVERT(varchar,@ServicePopulation) + ',%')
					FOR XML PATH('')),2,800000))
	
	return @result
END
