﻿
CREATE FUNCTION [dbo].[GetStrategiesViaVM]
(
	@GroupTypeId int,
	@ProgramTypeId int,
	@InterventionTypeId int,
	@ServicePopulation int
)
RETURNS VARCHAR(max)
AS
BEGIN
	
	Declare @result as varchar(max) = '';
	SET @result=(SELECT SUBSTRING(
				(Select ','+ dbo.ValidationMatrix.Strategies from dbo.ValidationMatrix	
					where dbo.ValidationMatrix.GroupType=@GroupTypeId
					and dbo.ValidationMatrix.ProgramType=@ProgramTypeId
					and dbo.ValidationMatrix.InterventionType=@InterventionTypeId
					and (',' + dbo.ValidationMatrix.ServicePopulation + ',') like ('%,' + CONVERT(varchar,@ServicePopulation) + ',%')
					FOR XML PATH('')),2,800000))
	
	return @result
END
