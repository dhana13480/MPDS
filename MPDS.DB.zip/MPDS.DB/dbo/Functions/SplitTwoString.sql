﻿CREATE FUNCTION [dbo].[SplitTwoString] 
(
    -- Add the parameters for the function here
    @myString1 varchar(8000),
    @myString2 varchar(8000),
    @deliminator varchar(10)
)
RETURNS 
@ReturnTable TABLE 
(
    -- Add the column definitions for the TABLE variable here
    [id] [int] IDENTITY(1,1) NOT NULL,
    [part1] [varchar](1000) NULL,
    [part2] [varchar](1000) NULL
)
AS
BEGIN
        Declare @iSpaces1 int
        Declare @iSpaces2 int
        
        Declare @part1 varchar(1000)
        Declare @part2 varchar(1000)

if len(@myString1)<1 or @myString1 is null return

        --initialize spaces
        Select @iSpaces1 = charindex(@deliminator,@myString1,0)
        Select @iSpaces2 = charindex(@deliminator,@myString2,0)
        
        While @iSpaces1 > 0

        Begin
            Select @part1 = substring(@myString1,0,charindex(@deliminator,@myString1,0))
            Select @part2 = substring(@myString2,0,charindex(@deliminator,@myString2,0))

            Insert Into @ReturnTable(part1,part2)
            Select @part1,@part2

			Select @myString1 = substring(@myString1,charindex(@deliminator,@myString1,0)+ len(@deliminator),len(@myString1) - charindex('',@myString1,0))
			Select @myString2 = substring(@myString2,charindex(@deliminator,@myString2,0)+ len(@deliminator),len(@myString2) - charindex('',@myString2,0))

            Select @iSpaces1 = charindex(@deliminator,@myString1,0)
            Select @iSpaces2 = charindex(@deliminator,@myString2,0)
            
        end

        --If len(@myString1) > 0
        Insert Into @ReturnTable
        Select @myString1,@myString2

    RETURN 
END
