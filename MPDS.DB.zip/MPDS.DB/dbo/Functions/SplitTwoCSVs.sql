﻿CREATE FUNCTION [dbo].[SplitTwoCSVs](@String1 varchar(8000), @String2 varchar(8000), @Delimiter char(1))
returns @temptable TABLE (item1 varchar(8000), item2 varchar(8000))
as
begin
declare @idx1 int
declare @idx2 int

declare @slice1 varchar(8000)
declare @slice2 varchar(8000)

select @idx1 = 1
select @idx2 = 1
if len(@String1)<1 or @String1 is null return

while @idx1!= 0
begin
set @idx1 = charindex(@Delimiter,@String1)
set @idx2 = charindex(@Delimiter,@String2)
if @idx1!=0
begin
set @slice1 = left(@String1,@idx1 - 1)
set @slice2 = left(@String2,@idx2 - 1)
end
else
begin
set @slice1 = @String1
set @slice2 = @String2
end

if(len(@slice1)>0)
insert into @temptable(Item1,Item2) values(@slice1,@slice2)

set @String1 = right(@String1,len(@String1) - @idx1)
set @String2 = right(@String2,len(@String2) - @idx2)
if len(@String1) = 0 break
end
return
end
