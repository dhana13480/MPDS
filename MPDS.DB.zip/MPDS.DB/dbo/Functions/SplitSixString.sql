﻿CREATE FUNCTION [dbo].[SplitSixString] 
(
    -- Add the parameters for the function here
    @myString1 varchar(8000),
    @myString2 varchar(8000),
    @myString3 varchar(8000),
    @myString4 varchar(8000),
    @myString5 varchar(8000),
    @myString6 varchar(8000),
    @deliminator varchar(10)
)
RETURNS 
@ReturnTable TABLE 
(
    -- Add the column definitions for the TABLE variable here
    [id] [int] IDENTITY(1,1) NOT NULL,
    [part1] [varchar](1000) NULL,
    [part2] [varchar](1000) NULL,
    [part3] [varchar](1000) NULL,
    [part4] [varchar](1000) NULL,
    [part5] [varchar](1000) NULL,
    [part6] [varchar](1000) NULL
)
AS
BEGIN
        Declare @iSpaces1 int
        Declare @iSpaces2 int
        Declare @iSpaces3 int
        Declare @iSpaces4 int
        Declare @iSpaces5 int
        Declare @iSpaces6 int
        
        Declare @part1 varchar(1000)
        Declare @part2 varchar(1000)
        Declare @part3 varchar(1000)
        Declare @part4 varchar(1000)
        Declare @part5 varchar(1000)
        Declare @part6 varchar(1000)

        --initialize spaces
        Select @iSpaces1 = charindex(@deliminator,@myString1,0)
        Select @iSpaces2 = charindex(@deliminator,@myString2,0)
        Select @iSpaces3 = charindex(@deliminator,@myString3,0)
        Select @iSpaces4 = charindex(@deliminator,@myString4,0)
        Select @iSpaces5 = charindex(@deliminator,@myString5,0)
        Select @iSpaces6 = charindex(@deliminator,@myString6,0)
        
        While @iSpaces1 > 0

        Begin
            Select @part1 = substring(@myString1,0,charindex(@deliminator,@myString1,0))
            Select @part2 = substring(@myString2,0,charindex(@deliminator,@myString2,0))
            Select @part3 = substring(@myString3,0,charindex(@deliminator,@myString3,0))
            Select @part4 = substring(@myString4,0,charindex(@deliminator,@myString4,0))
            Select @part5 = substring(@myString5,0,charindex(@deliminator,@myString5,0))
            Select @part6 = substring(@myString6,0,charindex(@deliminator,@myString6,0))

            Insert Into @ReturnTable(part1,part2,part3,part4,part5,part6)
            Select @part1,@part2,@part3,@part4,@part5,@part6

			Select @myString1 = substring(@myString1,charindex(@deliminator,@myString1,0)+ len(@deliminator),len(@myString1) - charindex('',@myString1,0))
			Select @myString2 = substring(@myString2,charindex(@deliminator,@myString2,0)+ len(@deliminator),len(@myString2) - charindex('',@myString2,0))
			Select @myString3 = substring(@myString3,charindex(@deliminator,@myString3,0)+ len(@deliminator),len(@myString3) - charindex('',@myString3,0))
			Select @myString4 = substring(@myString4,charindex(@deliminator,@myString4,0)+ len(@deliminator),len(@myString4) - charindex('',@myString4,0))
			Select @myString5 = substring(@myString5,charindex(@deliminator,@myString5,0)+ len(@deliminator),len(@myString5) - charindex('',@myString5,0))
			Select @myString6 = substring(@myString6,charindex(@deliminator,@myString6,0)+ len(@deliminator),len(@myString6) - charindex('',@myString6,0))

            Select @iSpaces1 = charindex(@deliminator,@myString1,0)
            Select @iSpaces2 = charindex(@deliminator,@myString2,0)
            Select @iSpaces3 = charindex(@deliminator,@myString3,0)
            Select @iSpaces4 = charindex(@deliminator,@myString4,0)
            Select @iSpaces5 = charindex(@deliminator,@myString5,0)
            Select @iSpaces6 = charindex(@deliminator,@myString6,0)
            
        end

        --If len(@myString1) > 0
        Insert Into @ReturnTable
        Select @myString1,@myString2,@myString3,@myString4,@myString5,@myString6

    RETURN 
END
