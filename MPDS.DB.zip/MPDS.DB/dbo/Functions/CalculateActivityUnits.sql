﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
-- Select dbo.CalculateActivityUnits (1)

CREATE FUNCTION [dbo].[CalculateActivityUnits]
(
	@Minutes int
)
RETURNS int
AS
BEGIN
		Declare @units int = 0;
		IF (@Minutes = 0)
		Begin
			set @units = 0;
		End
		ELSE IF (@Minutes > 15)
		Begin
			set @units = @Minutes / 15;
			declare @remainder int = @Minutes % 15;
			
			if (@remainder > 7)
			BEGIN
			   set @units = @units + 1;
			END
		END
		ELSE
		BEGIN
			if (@Minutes > 7)
			Begin
				SET @units = 1;
			End
		END
		return @units
END
